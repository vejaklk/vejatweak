﻿<#
    VejaTweak - motore condiviso.

    Questo file NON si esegue da solo: lo caricano sia la GUI (VejaTweak.ps1)
    sia lo script a riga di comando. Contiene il catalogo dei tweak e le
    funzioni per leggerne lo stato, applicarli e annullarli uno per uno.

    Regola di fondo: ogni tweak sa tornare indietro. Prima di scrivere
    qualsiasi cosa salviamo il valore precedente in vejatweak-backup.json,
    indicizzato per Id del tweak, cosi' spegnere un interruttore ripristina
    esattamente quello che c'era prima e nient'altro.
#>

$script:VtRoot       = $PSScriptRoot
$script:VtBackupPath = Join-Path $PSScriptRoot 'vejatweak-backup.json'
$script:VtLogPath    = Join-Path $PSScriptRoot 'vejatweak.log'
$script:VtLog        = New-Object System.Collections.ArrayList

# ---------------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------------
function Write-VtLog {
    param([string] $Msg, [ValidateSet('info','ok','warn','err')] [string] $Level = 'info')
    $riga = '{0}  [{1}]  {2}' -f (Get-Date -Format 'HH:mm:ss'), $Level.ToUpper().PadRight(4), $Msg
    [void] $script:VtLog.Add($riga)
    try { Add-Content -Path $script:VtLogPath -Value $riga -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
    Write-Verbose $riga
}

function Get-VtLog { $script:VtLog -join [Environment]::NewLine }

function Test-VtAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

# powercfg e altri exe scrivono su stderr: passiamo da cmd per non far
# esplodere PowerShell quando ErrorActionPreference e' Stop.
function Invoke-VtCmd([string] $cmdline) {
    (cmd /c "$cmdline 2>nul") | Out-String
}

# ---------------------------------------------------------------------------
# Archivio dei valori precedenti
# ---------------------------------------------------------------------------
function Get-VtStore {
    if (-not (Test-Path $script:VtBackupPath)) { return @{} }
    try {
        $json = Get-Content $script:VtBackupPath -Raw -ErrorAction Stop | ConvertFrom-Json
        $h = @{}
        foreach ($p in $json.PSObject.Properties) { $h[$p.Name] = $p.Value }
        return $h
    } catch {
        Write-VtLog "Backup illeggibile, ne creo uno nuovo: $($_.Exception.Message)" warn
        return @{}
    }
}

function Save-VtStore($store) {
    try {
        $store | ConvertTo-Json -Depth 10 | Set-Content -Path $script:VtBackupPath -Encoding UTF8
    } catch {
        Write-VtLog "Impossibile salvare il backup: $($_.Exception.Message)" err
    }
}

function Get-VtEntry([string] $id) {
    $s = Get-VtStore
    if ($s.ContainsKey($id)) { return $s[$id] }
    return $null
}

function Set-VtEntry([string] $id, $data) {
    $s = Get-VtStore
    $s[$id] = $data
    Save-VtStore $s
}

function Remove-VtEntry([string] $id) {
    $s = Get-VtStore
    if ($s.ContainsKey($id)) { $s.Remove($id); Save-VtStore $s }
}

# ---------------------------------------------------------------------------
# Registro
# ---------------------------------------------------------------------------
function Get-VtReg([string] $path, [string] $name) {
    try { return (Get-ItemProperty -Path $path -Name $name -ErrorAction Stop).$name }
    catch { return $null }
}

function Set-VtReg([string] $path, [string] $name, [string] $type, $value) {
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    New-ItemProperty -Path $path -Name $name -PropertyType $type -Value $value -Force | Out-Null
}

# ---------------------------------------------------------------------------
# Servizi
# ---------------------------------------------------------------------------
$script:VtStartMap = @{ 'Automatic' = 2; 'Manual' = 3; 'Disabled' = 4 }

function Get-VtServiceStart([string] $nome) {
    Get-VtReg "HKLM:\SYSTEM\CurrentControlSet\Services\$nome" 'Start'
}

function Set-VtServiceStart([string] $nome, [string] $start) {
    $svc = Get-Service -Name $nome -ErrorAction SilentlyContinue
    if (-not $svc) { return $false }
    Set-Service -Name $nome -StartupType $start -ErrorAction Stop
    if ($start -ne 'Automatic' -and $svc.Status -eq 'Running') {
        Stop-Service -Name $nome -Force -ErrorAction SilentlyContinue
    }
    return $true
}

# ---------------------------------------------------------------------------
# Informazioni di sistema (lette una volta sola: servono ai filtri del catalogo)
# ---------------------------------------------------------------------------
# --- Impostazioni di alimentazione, senza dipendere dalla lingua -----------
#
# powercfg /q stampa "Indice impostazione alimentazione CA corrente" in
# italiano, "AC Power Setting Index" in inglese e altro ancora nelle altre
# lingue: parsare quel testo vuol dire scrivere un tool che funziona solo
# sulle installazioni come la nostra. Il registro contiene lo stesso valore
# con un nome fisso in ogni lingua.
$script:VtPowerGuids = @{
    ProcSub     = '54533251-82be-4824-96c1-47b60b740d00'
    CoreParking = '0cc5b647-c1df-4637-891a-dec35c318583'
    ProcMin     = '893dee8e-2bef-41e0-89c6-b55d0929964c'
    PcieSub     = '501a4d13-42af-4429-9fd1-a8218c268e20'
    Aspm        = 'ee12f906-d277-404b-b6da-e5fa1a576df5'
    UsbSub      = '2a737441-1930-4402-8d77-b2bebba308a3'
    UsbSuspend  = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
}

function Get-VtActiveScheme {
    $o = Invoke-VtCmd 'powercfg /getactivescheme'
    if ($o -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { return $matches[1] }
    return $null
}

# Restituisce l'indice della singola impostazione sulla rete elettrica, o
# $null se non e' mai stata scritta (quindi il sistema usa il default).
function Get-VtPowerIndex([string] $sottogruppo, [string] $impostazione) {
    $s = Get-VtActiveScheme
    if (-not $s) { return $null }
    $k = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\$s\$sottogruppo\$impostazione"
    $v = Get-VtReg $k 'ACSettingIndex'
    if ($null -ne $v) { return [int] $v }
    return $null
}

function Get-VtSystem {
    if ($script:VtSys) { return $script:VtSys }

    $cs  = Get-CimInstance Win32_ComputerSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $os  = Get-CimInstance Win32_OperatingSystem
    $gpu = @(Get-CimInstance Win32_VideoController | Where-Object { $_.AdapterCompatibility -notmatch 'Microsoft' })
    $bat = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)

    $tipo = 'sconosciuto'
    try {
        $part = Get-Partition -DriveLetter $env:SystemDrive.TrimEnd(':') -ErrorAction Stop
        $d = Get-PhysicalDisk -ErrorAction Stop | Where-Object { $_.DeviceId -eq $part.DiskNumber }
        if ($d) { $tipo = $d.MediaType }
    } catch { }

    $script:VtSys = [pscustomobject]@{
        Cpu       = ($cpu.Name -replace '\s+', ' ').Trim()
        Core      = [int] $cpu.NumberOfCores
        Thread    = [int] $cpu.NumberOfLogicalProcessors
        RamGB     = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
        Gpu       = $gpu
        GpuNome   = if ($gpu) { $gpu[0].Name } else { 'sconosciuta' }
        Vendor    = (($gpu | ForEach-Object { $_.AdapterCompatibility }) -join ' ')
        Os        = "$($os.Caption) build $($os.BuildNumber)"
        Portatile = ($bat.Count -gt 0)
        DiscoSys  = $tipo
    }
    return $script:VtSys
}

# ---------------------------------------------------------------------------
# Rilevamento giochi
# ---------------------------------------------------------------------------
# GUID delle schede di rete con un gateway, cioe' quelle da cui passa
# davvero il traffico di gioco.
#
# Get-NetIPConfiguration darebbe lo stesso risultato ma impiega ~2,4 secondi:
# e' una catena di cmdlet CDXML che interroga mezzo stack di rete. La query
# CIM diretta costa ~50 ms. La differenza la si sentiva aprendo la sezione Rete.
function Get-VtActiveNicGuids {
    if ($null -ne $script:VtNicGuids) { return $script:VtNicGuids }
    try {
        $script:VtNicGuids = @(
            Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=true' -ErrorAction Stop |
            Where-Object { $_.DefaultIPGateway } |
            ForEach-Object { $_.SettingID }
        )
    } catch {
        Write-VtLog "Schede di rete non leggibili: $($_.Exception.Message)" warn
        $script:VtNicGuids = @()
    }
    return $script:VtNicGuids
}

function Get-VtSteamLibraries {
    $libs = @()
    $sp = Get-VtReg 'HKCU:\Software\Valve\Steam' 'SteamPath'
    if (-not $sp) { return $libs }
    $sp = $sp -replace '/', '\'
    $libs += $sp
    $vdf = Join-Path $sp 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        foreach ($l in (Get-Content $vdf -ErrorAction SilentlyContinue)) {
            if ($l -match '"path"\s+"(.+)"') { $libs += ($matches[1] -replace '\\\\', '\') }
        }
    }
    $libs | Select-Object -Unique
}

function Get-VtEpicInstalls {
    $res = @()
    # Non 'C:\ProgramData': su un PC con Windows su un'altra unita' quel
    # percorso non esiste e i giochi Epic non verrebbero trovati.
    $dir = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    if (-not (Test-Path $dir)) { return $res }
    foreach ($f in (Get-ChildItem $dir -Filter *.item -ErrorAction SilentlyContinue)) {
        try {
            $m = Get-Content $f.FullName -Raw | ConvertFrom-Json
            if ($m.InstallLocation -and $m.LaunchExecutable) {
                $res += (Join-Path $m.InstallLocation $m.LaunchExecutable)
            }
        } catch { }
    }
    $res
}

$script:VtGiochi = @(
    @{ Nome='Fortnite'; Exe='FortniteClient-Win64-Shipping.exe'
       Rel=@('Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe') }
    @{ Nome='Valorant'; Exe='VALORANT-Win64-Shipping.exe'
       Rel=@('Riot Games\VALORANT\live\ShooterGame\Binaries\Win64\VALORANT-Win64-Shipping.exe') }
    # Dopo l'uscita di Enhanced, Rockstar ha rinominato la vecchia installazione
    # in "Grand Theft Auto V Legacy": e' quella che usa FiveM.
    @{ Nome='GTA V'; Exe='GTA5.exe'
       Rel=@('Rockstar Games\Grand Theft Auto V Legacy\GTA5.exe',
             'Rockstar Games\Grand Theft Auto V\GTA5.exe',
             'steamapps\common\Grand Theft Auto V Legacy\GTA5.exe',
             'steamapps\common\Grand Theft Auto V\GTA5.exe',
             'Epic Games\GTAV\GTA5.exe') }
    @{ Nome='GTA V Enhanced'; Exe='GTA5_Enhanced.exe'
       Rel=@('Rockstar Games\Grand Theft Auto V Enhanced\GTA5_Enhanced.exe',
             'steamapps\common\Grand Theft Auto V Enhanced\GTA5_Enhanced.exe') }
    @{ Nome='Rainbow Six Siege'; Exe='RainbowSix.exe'
       Rel=@('Ubisoft\Ubisoft Game Launcher\games\Tom Clancy''s Rainbow Six Siege\RainbowSix.exe',
             'steamapps\common\Tom Clancy''s Rainbow Six Siege\RainbowSix.exe') }
    @{ Nome='R6 Siege (Vulkan)'; Exe='RainbowSix_Vulkan.exe'
       Rel=@('Ubisoft\Ubisoft Game Launcher\games\Tom Clancy''s Rainbow Six Siege\RainbowSix_Vulkan.exe',
             'steamapps\common\Tom Clancy''s Rainbow Six Siege\RainbowSix_Vulkan.exe') }
    @{ Nome='FiveM'; Exe='FiveM.exe'; Rel=@() }
)

function Find-VtGiochi {
    if ($script:VtGiochiTrovati) { return $script:VtGiochiTrovati }

    $radici = @($env:ProgramFiles, ${env:ProgramFiles(x86)})
    foreach ($d in (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
        # Le parentesi attorno a ogni voce sono OBBLIGATORIE: in PowerShell la
        # virgola lega piu' forte del '+', quindi senza di esse
        #   $d.DeviceID + '\', $d.DeviceID + '\Games'
        # non produce due percorsi ma una stringa sola,
        #   'C:\ C:\Games C:\Program Files C:\Program Files (x86)'.
        # Con quel bug le radici dei dischi non venivano mai cercate e i
        # giochi fuori da Program Files (Valorant sta in C:\Riot Games)
        # risultavano non installati.
        $radici += @(
            ($d.DeviceID + '\'),
            ($d.DeviceID + '\Games'),
            ($d.DeviceID + '\Program Files'),
            ($d.DeviceID + '\Program Files (x86)')
        )
    }
    $radici += Get-VtSteamLibraries
    $radici = $radici | Where-Object { $_ } | Select-Object -Unique

    $epic = Get-VtEpicInstalls
    $out  = @()

    foreach ($g in $script:VtGiochi) {
        $path = $null
        foreach ($r in $radici) {
            foreach ($rel in $g.Rel) {
                $p = Join-Path $r $rel
                if (Test-Path -LiteralPath $p) { $path = $p; break }
            }
            if ($path) { break }
        }
        if (-not $path) {
            $m = $epic | Where-Object { $_ -like "*$($g.Exe)" } | Select-Object -First 1
            if ($m -and (Test-Path -LiteralPath $m)) { $path = $m }
        }
        if (-not $path -and $g.Nome -eq 'FiveM') {
            $p = Join-Path $env:LOCALAPPDATA 'FiveM\FiveM.exe'
            if (Test-Path -LiteralPath $p) { $path = $p }
        }
        if ($path) { $out += [pscustomobject]@{ Nome = $g.Nome; Path = $path } }
    }

    # Il processo che renderizza davvero FiveM ha il numero di build nel nome
    # e compare solo dopo il primo avvio.
    $app = Join-Path $env:LOCALAPPDATA 'FiveM\FiveM.app'
    if (Test-Path -LiteralPath $app) {
        foreach ($e in (Get-ChildItem $app -Filter 'FiveM_*_GTAProcess.exe' -ErrorAction SilentlyContinue)) {
            $out += [pscustomobject]@{ Nome = 'FiveM (processo di gioco)'; Path = $e.FullName }
        }
    }

    $script:VtGiochiTrovati = $out
    return $out
}

# ---------------------------------------------------------------------------
# CATALOGO
#
#   Id      chiave stabile, usata per il backup: non cambiarla mai
#   Cat     sezione nella barra laterale
#   Nome    etichetta sulla card
#   Desc    cosa fa, in italiano
#   Perche  perche' aiuta gli FPS (mostrato sotto "Dettagli")
#   Warn    avvertenza, se c'e' un compromesso vero
#   Rischio 'sicuro' | 'medio' | 'alto'
#   Reboot  serve riavviare perche' abbia effetto
#   Kind    'Reg' | 'Svc' | 'Script' | 'Action'
# ---------------------------------------------------------------------------
$MM   = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
$GAME = "$MM\Tasks\Games"

function Get-VtCatalog {
    if ($script:VtCatalog) { return $script:VtCatalog }
    $sys = Get-VtSystem

    $c = @()

    # ======================= GENERALI ======================================
    $c += @{
        Id='gamedvr'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='Registrazione in background OFF'
        Desc='Spegne Game DVR, la cattura app e il buffer degli ultimi 30 secondi'
        Perche='La cattura in background tiene un encoder video sempre acceso mentre giochi. E'' la voce che da sola pesa di piu'' fra quelle di Windows: 3-10% di FPS e frame time massimi molto peggiori.'
        Items=@(
            @{ Path='HKCU:\System\GameConfigStore'; Name='GameDVR_Enabled'; Type='DWord'; Val=0 }
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name='AppCaptureEnabled'; Type='DWord'; Val=0 }
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name='HistoricalCaptureEnabled'; Type='DWord'; Val=0 }
            @{ Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR'; Name='AllowGameDVR'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='gamemode'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='Modalita'' gioco ON'
        Desc='Tiene accesa la Modalita'' gioco e il rilevamento automatico dei giochi'
        Perche='Va tenuta ACCESA, al contrario di quello che si legge in giro: sospende gli aggiornamenti durante la partita e sposta i task di sistema sui core che il gioco non sta usando.'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\GameBar'; Name='AllowAutoGameMode'; Type='DWord'; Val=1 }
            @{ Path='HKCU:\Software\Microsoft\GameBar'; Name='AutoGameModeEnabled'; Type='DWord'; Val=1 }
        )
    }
    $c += @{
        Id='gamebar-panel'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='Pannello Game Bar all''avvio OFF'
        Desc='Non apre piu'' il pannello del Game Bar quando lanci un gioco'
        Perche='Un overlay in meno che si aggancia al render nel momento peggiore, cioe'' mentre il gioco carica le shader.'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\GameBar'; Name='ShowStartupPanel'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='bg-apps'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='App in background OFF'
        Desc='Impedisce alle app del Microsoft Store di girare quando non le usi'
        Perche='Meteo, Posta, Xbox e compagnia si svegliano a intervalli per aggiornarsi. Poca CPU ciascuna, ma arrivano a raffica e proprio mentre il gioco vuole tutto.'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'; Name='GlobalUserDisabled'; Type='DWord'; Val=1 }
        )
    }
    $c += @{
        Id='notifiche'; Cat='Generali'; Kind='Reg'; Rischio='medio'
        Nome='Notifiche toast OFF'
        Desc='Niente popup di notifica dall''angolo dello schermo'
        Perche='Una notifica che compare mentre giochi costa un frame e, in schermo intero senza bordi, puo'' rubare il focus.'
        Warn='Non riceverai piu'' NESSUNA notifica di Windows, comprese quelle che potrebbero interessarti (messaggi, promemoria).'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications'; Name='ToastEnabled'; Type='DWord'; Val=0 }
        )
    }

    # ======================= MOUSE E TASTIERA ==============================
    $c += @{
        Id='mouse-accel'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Accelerazione mouse OFF'
        Desc='Disattiva "Precisione puntatore migliorata" e le sue due soglie'
        Perche='Con l''accelerazione attiva i tuoi cm/360 cambiano in base a quanto muovi in fretta: la stessa mossa del polso da'' due mire diverse. E'' il singolo motivo per cui la mira non diventa muscolo.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseSpeed'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseThreshold1'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseThreshold2'; Type='String'; Val='0' }
        )
    }
    $c += @{
        Id='mouse-1to1'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Sensibilita'' Windows 6/11 (1:1)'
        Desc='Mette il cursore di sensibilita'' di Windows nella tacca centrale'
        Perche='6/11 e'' l''unico valore che passa i conteggi del sensore cosi'' come sono. Sopra, Windows li moltiplica e salti pixel; sotto, li scarta e perdi risoluzione di mira.'
        Warn='Il puntatore sul desktop cambiera'' velocita''. Regola i DPI dal software del mouse, non da qui.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseSensitivity'; Type='String'; Val='10' }
        )
    }
    $c += @{
        Id='mouse-trails'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Scia del puntatore OFF'
        Desc='Toglie le copie del cursore disegnate a ogni frame'
        Perche='Rifinitura, ma nei menu di gioco la scia si vede ed e'' lavoro inutile per il compositor.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseTrails'; Type='String'; Val='0' }
        )
    }
    $c += @{
        Id='tasti-accessibilita'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Tasti permanenti e filtro tasti OFF'
        Desc='Disattiva tasti permanenti, filtro tasti e segnale acustico, compresi i loro hotkey'
        Perche='Il filtro tasti IGNORA le pressioni ripetute veloci: e'' input drop vero e proprio sui tap rapidi. I tasti permanenti aprono un popup a 5 MAIUSC che ruba il focus e minimizza il gioco.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Accessibility\StickyKeys'; Name='Flags'; Type='String'; Val='506' }
            @{ Path='HKCU:\Control Panel\Accessibility\Keyboard Response'; Name='Flags'; Type='String'; Val='122' }
            @{ Path='HKCU:\Control Panel\Accessibility\ToggleKeys'; Name='Flags'; Type='String'; Val='58' }
        )
    }
    $c += @{
        Id='tastiera-ripetizione'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Ripetizione tasti al massimo'
        Desc='Ritardo di ripetizione al minimo e velocita'' al massimo'
        Perche='Conta nei menu, nella chat e nei giochi che leggono la ripetizione invece dello stato del tasto.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Keyboard'; Name='KeyboardDelay'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Keyboard'; Name='KeyboardSpeed'; Type='String'; Val='31' }
        )
    }

    # ======================= INTERFACCIA ===================================
    $c += @{
        Id='trasparenze'; Cat='Interfaccia'; Kind='Reg'; Rischio='sicuro'
        Nome='Trasparenze OFF'
        Desc='Toglie gli effetti acrilici da menu Start, barra e finestre'
        Perche='Gli effetti acrilici sono un blur a schermo intero che il compositor ricalcola di continuo. Si sente in alt-tab e in finestra senza bordi.'
        Items=@(
            @{ Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize'; Name='EnableTransparency'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='animazioni'; Cat='Interfaccia'; Kind='Reg'; Rischio='sicuro'
        Nome='Animazioni superflue OFF'
        Desc='Niente animazione di riduci/ingrandisci, menu che si aprono subito'
        Perche='Alt-tab istantaneo invece che animato: quando devi rientrare nel gioco in fretta, sono decimi di secondo veri.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Desktop\WindowMetrics'; Name='MinAnimate'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Desktop'; Name='MenuShowDelay'; Type='String'; Val='0' }
        )
    }

    # ======================= CPU E SCHEDULER ===============================
    $c += @{
        Id='mmcss-risposta'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Massima risposta per i giochi'
        Desc='Riduce dal 20% al 10% la CPU che Windows tiene da parte per i task di sistema'
        Perche='Quella quota e'' riservata a prescindere, anche quando nessuno la usa. Dimezzarla lascia piu'' tempo al gioco; azzerarla del tutto invece fa saltare l''audio, quindi ci fermiamo a 10.'
        Items=@(
            @{ Path=$MM; Name='SystemResponsiveness'; Type='DWord'; Val=10 }
        )
    }
    $c += @{
        Id='net-throttling'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Throttling di rete multimediale OFF'
        Desc='Toglie il tetto di 10 pacchetti al millisecondo imposto quando c''e'' audio o video attivo'
        Perche='Il limite serviva alle schede di rete del 2008. Oggi, su FiveM e sui giochi con tickrate alto, e'' solo un tetto artificiale sui pacchetti in arrivo.'
        Items=@(
            @{ Path=$MM; Name='NetworkThrottlingIndex'; Type='DWord'; Val=-1 }
        )
    }
    $c += @{
        Id='priorita-primo-piano'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Priorita'' all''app in primo piano'
        Desc='Quanti di CPU lunghi e fissi per la finestra attiva'
        Perche='38 (0x26) da'' al gioco in primo piano fette di esecuzione lunghe e di durata costante: meno cambi di contesto, frame time piu'' regolare.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl'; Name='Win32PrioritySeparation'; Type='DWord'; Val=38 }
        )
    }
    $c += @{
        Id='profilo-giochi'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Profilo multimediale bassa latenza'
        Desc='Alza priorita'' CPU, GPU e I/O del profilo di sistema "Games"'
        Perche='E'' il profilo MMCSS che i giochi richiedono da soli al sistema. Alzare la priorita'' di I/O in particolare evita che lo streaming delle texture finisca in coda dietro ai processi di sistema: si sente sugli stutter di GTA e FiveM.'
        Items=@(
            @{ Path=$GAME; Name='Priority'; Type='DWord'; Val=6 }
            @{ Path=$GAME; Name='GPU Priority'; Type='DWord'; Val=8 }
            @{ Path=$GAME; Name='Scheduling Category'; Type='String'; Val='High' }
            @{ Path=$GAME; Name='SFIO Priority'; Type='String'; Val='High' }
        )
    }

    # ======================= SCHEDA VIDEO ==================================
    $c += @{
        Id='hags'; Cat='Scheda video'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Pianificazione GPU accelerata (HAGS)'
        Desc='Lascia che sia la GPU a gestire la propria coda di comandi'
        Perche='Toglie lavoro al thread di rendering della CPU e permette a NVIDIA Reflex di lavorare al meglio. Su una RTX/RX moderna e'' quasi sempre un guadagno netto.'
        Warn='Su GPU o driver molto vecchi puo'' invece introdurre stutter. Se dopo il riavvio noti scatti, rimettilo su OFF.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'; Name='HwSchMode'; Type='DWord'; Val=2 }
        )
    }
    # Voci specifiche NVIDIA: compaiono solo se la scheda e' NVIDIA.
    if ($sys.Vendor -match 'NVIDIA') {
        $c += @{
            Id='nv-autoaggiornamento'; Cat='Scheda video'; Kind='Script'; Rischio='medio'
            Nome='Autoaggiornamento dell''app NVIDIA OFF'
            Desc='Disattiva l''attivita'' pianificata che cerca aggiornamenti da sola'
            Perche='E'' un processo che parte a orari decisi da NVIDIA, scarica in background e ogni tanto apre finestre. Non serve: i driver puoi aggiornarli quando vuoi tu aprendo l''app.'
            Warn='Non riceverai piu'' l''avviso automatico quando esce un driver nuovo. Controlla ogni tanto a mano, perche'' i driver contano davvero sugli FPS.'
            Test={
                $t = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like 'NVIDIA App SelfUpdate*' })
                if ($t.Count -eq 0) { return $false }
                return (@($t | Where-Object { $_.State -ne 'Disabled' }).Count -eq 0)
            }
            On={
                $fatte = @()
                foreach ($t in @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -like 'NVIDIA App SelfUpdate*' })) {
                    if ($t.State -eq 'Disabled') { continue }
                    try {
                        Disable-ScheduledTask -TaskPath $t.TaskPath -TaskName $t.TaskName -ErrorAction Stop | Out-Null
                        $fatte += @{ P = $t.TaskPath; N = $t.TaskName }
                    } catch { Write-VtLog "Attivita' '$($t.TaskName)': Windows non permette di disattivarla" warn }
                }
                Set-VtEntry 'nv-autoaggiornamento' @{ Tasks = $fatte }
                Clear-VtTaskCache
            }
            Off={
                $e = Get-VtEntry 'nv-autoaggiornamento'
                if (-not $e) { return }
                foreach ($t in @($e.Tasks)) {
                    try { Enable-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction Stop | Out-Null } catch { }
                }
                Remove-VtEntry 'nv-autoaggiornamento'
                Clear-VtTaskCache
            }
        }
    }

    $c += @{
        Id='gpu-preferenza-giochi'; Cat='Scheda video'; Kind='Script'; Rischio='sicuro'
        Nome='Giochi sulla GPU dedicata'
        Desc='Forza tutti i giochi rilevati sulla scheda video dedicata invece che sull''integrata'
        Perche='Windows sceglie la GPU da solo e ogni tanto sbaglia, soprattutto su portatili e su PC con grafica integrata Intel attiva. Quando sbaglia non perdi il 10%: perdi meta'' degli FPS.'
        Test={
            $g = Find-VtGiochi
            if ($g.Count -eq 0) { return $false }
            foreach ($x in $g) {
                $v = Get-VtReg 'HKCU:\SOFTWARE\Microsoft\DirectX\UserGpuPreferences' $x.Path
                if ($v -notmatch 'GpuPreference=2') { return $false }
            }
            return $true
        }
        On={
            $k = 'HKCU:\SOFTWARE\Microsoft\DirectX\UserGpuPreferences'
            $bak = @()
            foreach ($x in (Find-VtGiochi)) {
                $bak += @{ Name = $x.Path; Val = (Get-VtReg $k $x.Path) }
                Set-VtReg $k $x.Path 'String' 'GpuPreference=2;'
                Write-VtLog "GPU dedicata forzata per $($x.Nome)" ok
            }
            Set-VtEntry 'gpu-preferenza-giochi' @{ Key = $k; Bak = $bak }
        }
        Off={
            $e = Get-VtEntry 'gpu-preferenza-giochi'
            if (-not $e) { return }
            foreach ($b in @($e.Bak)) {
                if ($null -ne $b.Val) { Set-VtReg $e.Key $b.Name 'String' $b.Val }
                else { Remove-ItemProperty -Path $e.Key -Name $b.Name -ErrorAction SilentlyContinue }
            }
            Remove-VtEntry 'gpu-preferenza-giochi'
        }
    }

    # ======================= ENERGIA =======================================
    $c += @{
        Id='piano-energia'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Piano prestazioni massime'
        Desc='Attiva Prestazioni ottimali (o Prestazioni elevate) e sposta anche il cursore di Windows 11'
        Perche='Su Bilanciato la CPU deve risalire di frequenza a ogni picco di carico, e il ritardo di risalita cade proprio dentro il frame. Su Windows 11 il cursore "Modalita'' risparmio energia" vince sul piano classico: vanno spostati tutti e due.'
        Test={
            # Confronto per GUID e non per nome: "Prestazioni elevate" si
            # chiama in modo diverso in ogni lingua di Windows.
            #   8c5e7fda... = Prestazioni elevate (fisso in ogni lingua)
            #   e9a42b02... = Prestazioni ottimali di serie
            # Il piano duplicato da noi prende un GUID nuovo, quindi ce lo
            # ricordiamo nel backup.
            $noti = @('8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c',
                      'e9a42b02-d5df-448d-aa00-03f14749eb61')
            $e = Get-VtEntry 'piano-energia'
            if ($e -and $e.Attivato) { $noti += $e.Attivato }

            $cur = Get-VtActiveScheme
            $ov  = Invoke-VtCmd 'powercfg /getactiveoverlayscheme'
            $planOk = ($cur -and ($noti -contains $cur))
            # 961cc777... = "Efficienza energetica", l'unico da evitare.
            $ovOk = ($ov -notmatch '961cc777-2547-4f9d-8174-7d86181b8a7a')
            return ($planOk -and $ovOk)
        }
        On={
            $bak = @{}
            $bak.Scheme = Get-VtActiveScheme
            $ov = Invoke-VtCmd 'powercfg /getactiveoverlayscheme'
            if ($ov -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { $bak.Overlay = $matches[1] }

            $dup = Invoke-VtCmd 'powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61'
            if ($dup -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') {
                $bak.Attivato = $matches[1]
                Invoke-VtCmd "powercfg /setactive $($matches[1])" | Out-Null
                Write-VtLog 'Piano energetico: Prestazioni ottimali' ok
            } else {
                # Non tutte le edizioni di Windows espongono Prestazioni
                # ottimali: si ripiega su Prestazioni elevate.
                $bak.Attivato = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
                Invoke-VtCmd 'powercfg /setactive SCHEME_MIN' | Out-Null
                Write-VtLog 'Piano energetico: Prestazioni elevate' ok
            }
            Set-VtEntry 'piano-energia' $bak
            Invoke-VtCmd 'powercfg /overlaysetscheme OVERLAY_MAX' | Out-Null
        }
        Off={
            $e = Get-VtEntry 'piano-energia'
            if ($e.Scheme)  { Invoke-VtCmd "powercfg /setactive $($e.Scheme)" | Out-Null }
            if ($e.Overlay) { Invoke-VtCmd "powercfg /overlaysetscheme $($e.Overlay)" | Out-Null }
            Remove-VtEntry 'piano-energia'
        }
    }
    $c += @{
        Id='core-parking'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Parcheggio dei core CPU OFF'
        Desc='Tiene tutti i core svegli quando sei alimentato dalla rete elettrica'
        Perche='Un core parcheggiato deve essere risvegliato, e il risveglio arriva a meta'' frame. E'' una delle cause piu'' comuni di 1% low bassi con FPS medi alti.'
        Test={
            (Get-VtPowerIndex $script:VtPowerGuids.ProcSub $script:VtPowerGuids.CoreParking) -eq 100
        }
        On={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 100' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
        Off={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 0' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
    }
    $c += @{
        Id='usb-suspend'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Sospensione selettiva USB OFF'
        Desc='Impedisce a Windows di addormentare le porte USB'
        Perche='Se Windows sospende la porta del mouse o della tastiera, il primo input dopo una pausa arriva in ritardo. Con un pad wireless e'' anche peggio.'
        Test={
            (Get-VtPowerIndex $script:VtPowerGuids.UsbSub $script:VtPowerGuids.UsbSuspend) -eq 0
        }
        On={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
        Off={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 1' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
    }
    $c += @{
        Id='pcie-aspm'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Risparmio energia PCI Express OFF'
        Desc='La GPU resta sempre a piena larghezza di banda sul bus'
        Perche='ASPM abbassa il link PCIe quando il traffico cala. Nei momenti di carico improvviso, tipici del caricamento di una texture, il ritorno a piena banda costa millisecondi.'
        Test={
            (Get-VtPowerIndex $script:VtPowerGuids.PcieSub $script:VtPowerGuids.Aspm) -eq 0
        }
        On={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
        Off={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 2' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
    }
    if (-not $sys.Portatile) {
        $c += @{
            Id='cpu-min-100'; Cat='Energia'; Kind='Script'; Rischio='medio'
            Nome='Frequenza minima CPU al 100%'
            Desc='La CPU non scende mai di frequenza quando sei alla rete elettrica'
            Perche='Elimina del tutto il ritardo di risalita della frequenza. E'' il modo piu'' diretto per stabilizzare i frame time nei giochi CPU-bound come FiveM.'
            Warn='La CPU consuma e scalda come sotto carico anche a PC fermo. Se hai un dissipatore modesto o temperature gia'' alte, lascia perdere.'
            Test={
                (Get-VtPowerIndex $script:VtPowerGuids.ProcSub $script:VtPowerGuids.ProcMin) -eq 100
            }
            On={
                Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 100' | Out-Null
                Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
            }
            Off={
                Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 5' | Out-Null
                Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
            }
        }
    }

    # ======================= STABILITA' DEGLI FPS ==========================
    # Queste non alzano la media: tolgono i buchi. Sono le due voci che
    # agiscono su come il kernel scandisce il tempo e su chi puo' rallentare
    # i thread del gioco, cioe' sulle due cause piu' comuni di micro-scatti
    # con FPS medi alti.
    $c += @{
        Id='timer-resolution'; Cat='Stabilita'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Risoluzione del timer a livello di sistema'
        Desc='Fa valere per tutto il sistema la risoluzione del timer richiesta dal gioco'
        Perche='Da Windows 11 22H2 una richiesta di timer ad alta risoluzione vale solo per il processo che la fa: il resto del sistema continua a svegliarsi con la granularita'' grossa. Il risultato sono frame consegnati leggermente fuori tempo, che si vedono come micro-scatti anche con FPS altissimi. Questa voce riporta il comportamento a quello vecchio, in cui la risoluzione fine vale per tutti.'
        Warn='Su un portatile a batteria consuma un po'' di piu'', perche'' il sistema si sveglia piu'' spesso.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel'; Name='GlobalTimerResolutionRequests'; Type='DWord'; Val=1 }
        )
    }
    $c += @{
        Id='power-throttling'; Cat='Stabilita'; Kind='Reg'; Rischio='sicuro'
        Nome='Limitazione energetica dei processi OFF'
        Desc='Impedisce a Windows di rallentare i processi che ritiene "in secondo piano"'
        Perche='Power Throttling (EcoQoS) abbassa la frequenza dei thread che Windows giudica poco importanti. Su una CPU con E-core come la tua puo'' spostare o rallentare thread del gioco che il sistema non riconosce come primo piano: audio, rete, caricamento risorse. E'' una causa tipica di scatti che arrivano a ondate invece che di FPS bassi costanti.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling'; Name='PowerThrottlingOff'; Type='DWord'; Val=1 }
        )
    }

    # ======================= MEMORIA E ARCHIVIAZIONE =======================
    $c += @{
        Id='avvio-rapido'; Cat='Memoria e archiviazione'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Avvio rapido OFF'
        Desc='Ogni accensione riparte da zero invece che da uno stato salvato'
        Perche='L''avvio rapido ricarica il kernel e i driver da un''immagine su disco. Dopo qualche giorno di accensioni "finte" i driver si trovano in stati strani ed e'' una causa classica di FPS che calano col passare dei giorni.'
        Warn='Il PC ci mettera'' qualche secondo in piu'' ad accendersi. In cambio ogni avvio e'' pulito.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'; Name='HiberbootEnabled'; Type='DWord'; Val=0 }
        )
    }
    # Soglia a 15 e non a 16: Windows riporta ~15.8 GB su un PC con 16 GB,
    # perche' una parte e' riservata all'hardware.
    if ($sys.RamGB -ge 15) {
        $c += @{
            Id='kernel-in-ram'; Cat='Memoria e archiviazione'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
            Nome='Kernel e driver sempre in RAM'
            Desc='Impedisce a Windows di spostare su disco le parti del kernel'
            Perche="Con $($sys.RamGB) GB hai memoria da vendere. Tenere kernel e driver sempre residenti toglie una classe di micro-stutter che arriva quando il sistema li rilegge dal disco."
            Items=@(
                @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'; Name='DisablePagingExecutive'; Type='DWord'; Val=1 }
            )
        }
    }
    $c += @{
        Id='ntfs-lastaccess'; Cat='Memoria e archiviazione'; Kind='Script'; Rischio='sicuro'
        Nome='Timestamp NTFS di ultimo accesso OFF'
        Desc='NTFS smette di scrivere la data di ultimo accesso a ogni file letto'
        Perche='Ogni lettura diventa anche una scrittura. Durante un caricamento un gioco apre migliaia di file: sono migliaia di scritture inutili sull''SSD.'
        Test={
            # Il nome della chiave non e' tradotto, la descrizione fra
            # parentesi si': ancoriamo il numero al nome, non a un '=' isolato.
            $q = Invoke-VtCmd 'fsutil behavior query disablelastaccess'
            return ($q -match 'DisableLastAccess\s*=\s*[13]')
        }
        On={
            $q = Invoke-VtCmd 'fsutil behavior query disablelastaccess'
            $old = if ($q -match 'DisableLastAccess\s*=\s*(\d)') { $matches[1] } else { '2' }
            Set-VtEntry 'ntfs-lastaccess' @{ Old = $old }
            Invoke-VtCmd 'fsutil behavior set disablelastaccess 1' | Out-Null
        }
        Off={
            $e = Get-VtEntry 'ntfs-lastaccess'
            $old = if ($e -and $e.Old) { $e.Old } else { '2' }
            Invoke-VtCmd "fsutil behavior set disablelastaccess $old" | Out-Null
            Remove-VtEntry 'ntfs-lastaccess'
        }
    }

    # ======================= RETE ==========================================
    $c += @{
        Id='nagle'; Cat='Rete'; Kind='Script'; Rischio='sicuro'
        Nome='Algoritmo di Nagle OFF'
        Desc='Le schede di rete attive smettono di accorpare i pacchetti piccoli'
        Perche='Nagle mette in coda i pacchetti piccoli per spedirne uno grande. I pacchetti di un FPS SONO piccoli: accorparli significa ritardarli. Si sente su FiveM e Valorant, non sugli FPS ma sul registro dei colpi.'
        Test={
            $root = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
            $nic = Get-VtActiveNicGuids
            if ($nic.Count -eq 0) { return $false }
            foreach ($g in $nic) {
                if ((Get-VtReg (Join-Path $root $g) 'TcpAckFrequency') -ne 1) { return $false }
            }
            return $true
        }
        On={
            $root = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
            $nic = Get-VtActiveNicGuids
            $bak = @()
            foreach ($g in $nic) {
                $k = Join-Path $root $g
                if (-not (Test-Path $k)) { continue }
                foreach ($n in 'TcpAckFrequency','TCPNoDelay','TcpDelAckTicks') {
                    $bak += @{ Key = $k; Name = $n; Val = (Get-VtReg $k $n) }
                }
                Set-VtReg $k 'TcpAckFrequency' 'DWord' 1
                Set-VtReg $k 'TCPNoDelay'      'DWord' 1
                Set-VtReg $k 'TcpDelAckTicks'  'DWord' 0
                Write-VtLog "Nagle disattivato sulla scheda $g" ok
            }
            Set-VtEntry 'nagle' @{ Bak = $bak }
        }
        Off={
            $e = Get-VtEntry 'nagle'
            if (-not $e) { return }
            foreach ($b in @($e.Bak)) {
                if ($null -ne $b.Val) { Set-VtReg $b.Key $b.Name 'DWord' $b.Val }
                else { Remove-ItemProperty -Path $b.Key -Name $b.Name -ErrorAction SilentlyContinue }
            }
            Remove-VtEntry 'nagle'
        }
    }

    # ======================= SERVIZI =======================================
    $c += @{
        Id='svc-telemetria'; Cat='Servizi'; Kind='Svc'; Rischio='sicuro'
        Nome='Servizi di telemetria OFF'
        Desc='Ferma DiagTrack, dmwappushservice e il raccoglitore di diagnostica'
        Perche='Girano sempre, raccolgono dati d''uso e li spediscono. Non ti servono a niente mentre giochi e generano I/O a caso.'
        Svc=@(
            @{ Name='DiagTrack'; Start='Disabled' }
            @{ Name='dmwappushservice'; Start='Disabled' }
            @{ Name='diagnosticshub.standardcollector.service'; Start='Manual' }
        )
    }
    $c += @{
        Id='svc-superflui'; Cat='Servizi'; Kind='Svc'; Rischio='sicuro'
        Nome='Servizi superflui su Manuale'
        Desc='Segnalazione errori, mappe, geolocalizzazione, compatibilita'', Delivery Optimization, condivisione multimediale'
        Perche='Nessuno di questi serve a un PC da gioco. Delivery Optimization in particolare usa la TUA banda per distribuire aggiornamenti Windows ad altri PC su internet: quello si sente sul ping.'
        Svc=@(
            @{ Name='WerSvc'; Start='Manual' }
            @{ Name='MapsBroker'; Start='Manual' }
            @{ Name='lfsvc'; Start='Manual' }
            @{ Name='PcaSvc'; Start='Manual' }
            @{ Name='DoSvc'; Start='Manual' }
            @{ Name='WMPNetworkSvc'; Start='Manual' }
            @{ Name='RemoteRegistry'; Start='Disabled' }
            @{ Name='RetailDemo'; Start='Disabled' }
        )
    }
    if ($sys.DiscoSys -match 'SSD') {
        $c += @{
            Id='svc-sysmain'; Cat='Servizi'; Kind='Svc'; Rischio='sicuro'
            Nome='SuperFetch (SysMain) su Manuale'
            Desc='Ferma il precaricamento in RAM dei programmi usati di frequente'
            Perche='SysMain nasce per gli hard disk meccanici: precarica in RAM per evitare le letture lente. Il tuo disco di sistema e'' un SSD, quindi qui e'' solo RAM occupata e I/O in background.'
            Svc=@( @{ Name='SysMain'; Start='Manual' } )
        }
    }
    $c += @{
        Id='svc-wsearch'; Cat='Servizi'; Kind='Svc'; Rischio='alto'
        Nome='Indicizzazione ricerca OFF'
        Desc='Ferma il servizio che indicizza i file per la ricerca'
        Perche='L''indicizzatore fa scansioni di disco in background, e le fa proprio quando il PC sembra libero, cioe'' fra una partita e l''altra.'
        Warn='PERDI la ricerca dei file dal menu Start e da Esplora risorse diventa lentissima. Se cerchi spesso i file, non attivarlo.'
        Svc=@( @{ Name='WSearch'; Start='Manual' } )
    }
    $c += @{
        Id='svc-spooler'; Cat='Servizi'; Kind='Svc'; Rischio='alto'
        Nome='Coda di stampa OFF'
        Desc='Disattiva lo spooler di stampa'
        Perche='Se non hai stampanti e'' un servizio che gira per niente (ed e'' storicamente uno dei bersagli preferiti degli exploit).'
        Warn='Non potrai piu'' stampare NULLA finche'' non lo riattivi. Non toccarlo se hai una stampante.'
        Svc=@( @{ Name='Spooler'; Start='Disabled' } )
    }
    $c += @{
        Id='task-telemetria'; Cat='Servizi'; Kind='Script'; Rischio='sicuro'
        Nome='Attivita'' pianificate di telemetria OFF'
        Desc='Disattiva le attivita'' di compatibilita'', CEIP e feedback'
        Perche='Sono processi che partono da soli a orari decisi da Windows. Il Compatibility Appraiser in particolare puo'' occupare la CPU per minuti interi, e non gli importa se sei in partita.'
        Test={
            # Serve almeno una delle attivita' note: se non ne esiste nessuna
            # su questo Windows, il tweak non ha senso e resta spento.
            # Le attivita' che il sistema si rifiuta di disattivare (PcaPatchDbTask
            # e' il caso tipico: appartiene a TrustedInstaller) vengono escluse,
            # altrimenti la voce resterebbe spenta per sempre anche dopo aver
            # fatto tutto il possibile.
            $e = Get-VtEntry 'task-telemetria'
            $saltate = @()
            if ($e -and $e.Saltate) { $saltate = @($e.Saltate) }

            $trovate = 0
            foreach ($t in (Get-VtTelemetryTasks)) {
                if ($saltate -contains $t.N) { continue }
                $x = Find-VtTask $t.P $t.N
                if (-not $x) { continue }
                $trovate++
                if ($x.State -ne 'Disabled') { return $false }
            }
            return ($trovate -gt 0)
        }
        On={
            $fatti = @(); $saltate = @()
            foreach ($t in (Get-VtTelemetryTasks)) {
                $x = Find-VtTask $t.P $t.N
                if (-not $x -or $x.State -eq 'Disabled') { continue }
                try {
                    Disable-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction Stop | Out-Null
                    $fatti += @{ P = $t.P; N = $t.N }
                } catch {
                    $saltate += $t.N
                    Write-VtLog "Attivita' '$($t.N)': Windows non permette di disattivarla" warn
                }
            }
            Set-VtEntry 'task-telemetria' @{ Tasks = $fatti; Saltate = $saltate }
            Clear-VtTaskCache
        }
        Off={
            $e = Get-VtEntry 'task-telemetria'
            if (-not $e) { return }
            foreach ($t in @($e.Tasks)) {
                try { Enable-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction Stop | Out-Null } catch { }
            }
            Remove-VtEntry 'task-telemetria'
            Clear-VtTaskCache
        }
    }

    $script:VtCatalog = $c
    return $c
}

# Una sola enumerazione di tutte le attivita' pianificate, tenuta in cache.
#
# Interrogarle una per una con -TaskPath/-TaskName costa ~550 ms a colpo: per
# le nove che ci interessano erano quasi 5 secondi. Leggerle tutte insieme ne
# costa 750 in totale, e dalla seconda volta in poi zero.
function Get-VtAllTasks {
    if ($null -ne $script:VtTasks) { return $script:VtTasks }
    try { $script:VtTasks = @(Get-ScheduledTask -ErrorAction Stop) }
    catch {
        Write-VtLog "Attivita' pianificate non leggibili: $($_.Exception.Message)" warn
        $script:VtTasks = @()
    }
    return $script:VtTasks
}

# Da chiamare dopo aver abilitato o disabilitato qualcosa, altrimenti la cache
# racconta lo stato di prima.
function Clear-VtTaskCache { $script:VtTasks = $null }

function Find-VtTask([string] $percorso, [string] $nome) {
    Get-VtAllTasks | Where-Object { $_.TaskPath -eq $percorso -and $_.TaskName -eq $nome } | Select-Object -First 1
}

function Get-VtTelemetryTasks {
    @(
        @{ P='\Microsoft\Windows\Application Experience\'; N='Microsoft Compatibility Appraiser' }
        @{ P='\Microsoft\Windows\Application Experience\'; N='ProgramDataUpdater' }
        @{ P='\Microsoft\Windows\Application Experience\'; N='PcaPatchDbTask' }
        @{ P='\Microsoft\Windows\Customer Experience Improvement Program\'; N='Consolidator' }
        @{ P='\Microsoft\Windows\Customer Experience Improvement Program\'; N='UsbCeip' }
        @{ P='\Microsoft\Windows\Autochk\'; N='Proxy' }
        @{ P='\Microsoft\Windows\Feedback\Siuf\'; N='DmClient' }
        @{ P='\Microsoft\Windows\Feedback\Siuf\'; N='DmClientOnScenarioDownload' }
        @{ P='\Microsoft\Windows\DiskDiagnostic\'; N='Microsoft-Windows-DiskDiagnosticDataCollector' }
    )
}

# Servizi che non vanno MAI disattivati: se li troviamo spenti, e' un guaio.
$script:VtProtetti = @(
    @{ Name='vgc';           Desc='Riot Vanguard: senza, Valorant non parte' }
    @{ Name='EasyAntiCheat'; Desc='Easy Anti-Cheat: usato da Fortnite' }
    @{ Name='BEService';     Desc='BattlEye: usato da Rainbow Six Siege' }
    @{ Name='Audiosrv';      Desc='audio di Windows' }
    @{ Name='wuauserv';      Desc='Windows Update: driver e patch di sicurezza' }
    @{ Name='WinDefend';     Desc='Microsoft Defender' }
)

# ---------------------------------------------------------------------------
# Stato / applica / annulla
# ---------------------------------------------------------------------------
# Confronto di valori di registro.
#
# Un DWORD scritto come -1 si rilegge come UInt32 4294967295: sono lo stesso
# valore a 32 bit, ma confrontati come testo sono diversi. Senza questa
# normalizzazione la voce "Throttling di rete OFF" risultava sempre spenta
# anche subito dopo averla applicata.
function Test-VtValoreUguale($corrente, $atteso) {
    if ($null -eq $corrente) { return $false }
    if ("$corrente" -eq "$atteso") { return $true }
    try {
        $a = [int64] $corrente
        $b = [int64] $atteso
        if ($a -eq $b) { return $true }
        # Riporta entrambi nello stesso spazio a 32 bit senza segno.
        if ($a -lt 0) { $a += 4294967296 }
        if ($b -lt 0) { $b += 4294967296 }
        return ($a -eq $b)
    } catch { return $false }
}

function Get-VtState($tweak) {
    try {
        switch ($tweak.Kind) {
            'Reg' {
                foreach ($i in $tweak.Items) {
                    if (-not (Test-VtValoreUguale (Get-VtReg $i.Path $i.Name) $i.Val)) { return $false }
                }
                return $true
            }
            'Svc' {
                # Alcuni servizi sono protetti dal sistema e rifiutano la
                # modifica anche da amministratore (DoSvc e' il caso tipico).
                # Se ci abbiamo gia' provato e non si e' lasciato cambiare, non
                # ha senso tenere la voce spenta per sempre: lo escludiamo.
                $e = Get-VtEntry $tweak.Id
                $saltati = @()
                if ($e -and $e.Saltati) { $saltati = @($e.Saltati) }
                foreach ($s in $tweak.Svc) {
                    if ($saltati -contains $s.Name) { continue }
                    if (-not (Get-Service -Name $s.Name -ErrorAction SilentlyContinue)) { continue }
                    if ((Get-VtServiceStart $s.Name) -ne $script:VtStartMap[$s.Start]) { return $false }
                }
                return $true
            }
            'Script' { return [bool] (& $tweak.Test) }
        }
    } catch {
        Write-VtLog "Stato non leggibile per '$($tweak.Id)': $($_.Exception.Message)" warn
    }
    return $false
}

function Enable-VtTweak($tweak) {
    switch ($tweak.Kind) {
        'Reg' {
            $bak = @()
            foreach ($i in $tweak.Items) {
                $old = Get-VtReg $i.Path $i.Name
                $bak += @{ Path = $i.Path; Name = $i.Name; Type = $i.Type
                           Existed = ($null -ne $old); Val = $old }
                Set-VtReg $i.Path $i.Name $i.Type $i.Val
            }
            Set-VtEntry $tweak.Id @{ Reg = $bak }
        }
        'Svc' {
            # Ogni servizio si prova per conto suo. Prima un solo servizio
            # protetto faceva fallire l'intero gruppo E impediva di salvare il
            # backup, quindi quelli gia' cambiati non si potevano piu'
            # ripristinare: il caso peggiore possibile.
            $bak = @(); $saltati = @()
            foreach ($s in $tweak.Svc) {
                if (-not (Get-Service -Name $s.Name -ErrorAction SilentlyContinue)) { continue }
                $prima = Get-VtServiceStart $s.Name
                try {
                    Set-VtServiceStart $s.Name $s.Start | Out-Null
                    $bak += @{ Name = $s.Name; Start = $prima }
                } catch {
                    $saltati += $s.Name
                    Write-VtLog "$($s.Name): non modificabile su questo sistema ($($_.Exception.Message.Split([char]10)[0]))" warn
                }
            }
            Set-VtEntry $tweak.Id @{ Svc = $bak; Saltati = $saltati }
            if ($bak.Count -eq 0 -and $saltati.Count -gt 0) {
                throw "Nessuno dei servizi si e' lasciato modificare: $($saltati -join ', ')"
            }
        }
        'Script' { & $tweak.On }
    }
    Write-VtLog "Attivato: $($tweak.Nome)" ok
}

function Disable-VtTweak($tweak) {
    switch ($tweak.Kind) {
        'Reg' {
            $e = Get-VtEntry $tweak.Id
            if (-not $e) {
                Write-VtLog "Nessun backup per '$($tweak.Id)': non posso ripristinare i valori originali." warn
                return
            }
            foreach ($b in @($e.Reg)) {
                if ($b.Existed) { Set-VtReg $b.Path $b.Name $b.Type $b.Val }
                else { Remove-ItemProperty -Path $b.Path -Name $b.Name -ErrorAction SilentlyContinue }
            }
            Remove-VtEntry $tweak.Id
        }
        'Svc' {
            $e = Get-VtEntry $tweak.Id
            if (-not $e) { Write-VtLog "Nessun backup per '$($tweak.Id)'." warn; return }
            foreach ($b in @($e.Svc)) {
                $tipo = switch ([int] $b.Start) { 4 { 'Disabled' } 3 { 'Manual' } 2 { 'Automatic' } default { $null } }
                if ($tipo) { try { Set-VtServiceStart $b.Name $tipo | Out-Null } catch { } }
            }
            Remove-VtEntry $tweak.Id
        }
        'Script' { & $tweak.Off }
    }
    Write-VtLog "Disattivato: $($tweak.Nome)" ok
}

function Set-VtTweak($tweak, [bool] $on) {
    try {
        if ($on) { Enable-VtTweak $tweak } else { Disable-VtTweak $tweak }
        return $true
    } catch {
        Write-VtLog "ERRORE su '$($tweak.Nome)': $($_.Exception.Message)" err
        return $false
    }
}

# ---------------------------------------------------------------------------
# Controlli diagnostici (quelli che nessun interruttore puo' risolvere)
# ---------------------------------------------------------------------------
function Get-VtDiagnosi {
    $out = @()
    $sys = Get-VtSystem

    if ($sys.Thread -eq $sys.Core -and $sys.Cpu -match 'Core.*i[579]|Ryzen [579]|Core.*Ultra') {
        $out += [pscustomobject]@{ Peso=1; Titolo='Hyper-Threading / SMT disattivato'
            Testo="La CPU riporta $($sys.Core) core e solo $($sys.Thread) thread. Riattiva Hyper-Threading (Intel) o SMT (AMD) nel BIOS: su FiveM, Fortnite e R6 valgono 10-20% di FPS e molto di piu' sui minimi." }
    }

    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $conf = ($mods | Measure-Object ConfiguredClockSpeed -Maximum).Maximum
        $max  = ($mods | Measure-Object Speed -Maximum).Maximum
        if ($conf -and $max -and $conf -lt ($max - 100)) {
            $out += [pscustomobject]@{ Peso=1; Titolo='Profilo XMP / EXPO non attivo'
                Testo="La RAM gira a $conf MT/s invece di $max. Attiva XMP (Intel) o EXPO (AMD) nel BIOS: sui giochi CPU-bound valgono 10-25% di FPS medi e soprattutto di 1% low. Non e' overclock del processore." }
        }
        if ($mods.Count -eq 1) {
            $out += [pscustomobject]@{ Peso=1; Titolo='RAM in single channel'
                Testo='Hai un solo banco di RAM. Aggiungerne un secondo identico vale 15-30% di FPS.' }
        }
    } catch { }

    try {
        foreach ($v in (Get-CimInstance Win32_VideoController | Where-Object { $_.CurrentRefreshRate -gt 0 })) {
            if ($v.MaxRefreshRate -gt $v.CurrentRefreshRate + 2) {
                $out += [pscustomobject]@{ Peso=1; Titolo='Monitor non al refresh massimo'
                    Testo="Lo schermo gira a $($v.CurrentRefreshRate) Hz ma supporta $($v.MaxRefreshRate) Hz. Impostazioni > Schermo > Schermo avanzato. Finche' resta cosi', tutti gli FPS sopra $($v.CurrentRefreshRate) non li vedi." }
            }
        }
    } catch { }

    foreach ($g in $sys.Gpu) {
        if ($g.DriverDate) {
            $mesi = [math]::Round(((Get-Date) - $g.DriverDate).TotalDays / 30.4)
            if ($mesi -ge 8) {
                $out += [pscustomobject]@{ Peso=2; Titolo='Driver video datato'
                    Testo="Il driver di $($g.Name) ha circa $mesi mesi. Fortnite e Valorant ricevono ottimizzazioni driver a ogni stagione." }
            }
        }
    }

    try {
        $dg = Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction Stop
        if ($dg.SecurityServicesRunning -contains 2) {
            $out += [pscustomobject]@{ Peso=2; Titolo='Integrita'' della memoria attiva'
                Testo='HVCI fa girare ogni driver dentro un hypervisor e costa tipicamente 5-15% di FPS. Puoi spegnerla da Sicurezza di Windows > Sicurezza dispositivo > Isolamento core. E'' un compromesso vero: perdi una protezione reale contro i driver malevoli.' }
        }
    } catch { }

    $bcd = Invoke-VtCmd 'bcdedit /enum "{current}"'
    # bcdedit stampa il valore tradotto ("Yes", "Si'", "Ja"...), ma il nome
    # della voce no. E soprattutto queste voci compaiono nell'elenco SOLO se
    # qualcuno le ha impostate: la loro presenza e' gia' la risposta.
    if ($bcd -match '(?im)^\s*useplatformclock\s') {
        $out += [pscustomobject]@{ Peso=1; Titolo='HPET forzato nel BCD'
            Testo='useplatformclock e'' impostato su Yes. E'' un vecchio tweak da forum che sulle CPU moderne AGGIUNGE stutter e latenza. Aprire un prompt come amministratore e dare: bcdedit /deletevalue useplatformclock' }
    }

    try {
        $auto = (Get-CimInstance Win32_ComputerSystem).AutomaticManagedPagefile
        $pf   = @(Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue)
        if (-not $auto -and $pf.Count -eq 0) {
            $out += [pscustomobject]@{ Peso=1; Titolo='File di paging disattivato'
                Testo='Spegnere il file di paging non da'' FPS: fa crashare i giochi che riservano molta memoria virtuale, e Fortnite e GTA V lo fanno. Rimettilo su "gestito dal sistema".' }
        }
    } catch { }

    foreach ($p in $script:VtProtetti) {
        if (-not (Get-Service -Name $p.Name -ErrorAction SilentlyContinue)) { continue }
        if ((Get-VtServiceStart $p.Name) -eq 4) {
            $out += [pscustomobject]@{ Peso=1; Titolo="Servizio $($p.Name) disabilitato"
                Testo="$($p.Desc). Probabilmente e' stato spento da un 'debloater'. Va rimesso su Manuale o il gioco non parte proprio." }
        }
    }

    $d = Get-PSDrive -Name ($env:SystemDrive.TrimEnd(':')) -ErrorAction SilentlyContinue
    if ($d) {
        $pct = [math]::Round(100 * $d.Free / ($d.Free + $d.Used), 1)
        if ($pct -lt 10) {
            $out += [pscustomobject]@{ Peso=2; Titolo='Disco di sistema quasi pieno'
                Testo="Sei al $pct% di spazio libero. Sotto il 10% il file di paging non si espande e la cache delle shader viene buttata e ricompilata: e' stutter garantito." }
        }
    }

    $out | Sort-Object Peso
}

# ---------------------------------------------------------------------------
# FORTNITE
#
# Qui non tocchiamo Windows: scriviamo sul file di configurazione di Fortnite,
# GameUserSettings.ini, che e' lo stesso file che il gioco scrive da solo
# quando cambi le opzioni dal menu. Nessuna iniezione, nessun driver: e' roba
# che gli anticheat non guardano nemmeno.
#
# Due regole che valgono per tutto questo blocco:
#   1. Fortnite riscrive il file quando esce. Se il gioco e' aperto mentre
#      scriviamo, le modifiche spariscono. Quindi controlliamo sempre.
#   2. Prima di ogni scrittura si fa una copia del file, e "Ripristina" la
#      rimette. Le chiavi sono tante e alcune non sono documentate.
# ---------------------------------------------------------------------------
function Get-VtFortnitePaths {
    $dir = Join-Path $env:LOCALAPPDATA 'FortniteGame\Saved\Config\WindowsClient'
    $ini = Join-Path $dir 'GameUserSettings.ini'
    [pscustomobject]@{ Dir = $dir; Ini = $ini; Esiste = (Test-Path -LiteralPath $ini) }
}

function Test-VtFortniteRunning {
    [bool] (Get-Process -Name 'FortniteClient-Win64-Shipping', 'FortniteLauncher' -ErrorAction SilentlyContinue)
}

function Test-VtFortniteReadOnly {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { return $false }
    [bool] ((Get-Item -LiteralPath $p.Ini).Attributes -band [IO.FileAttributes]::ReadOnly)
}

function Set-VtFortniteReadOnly([bool] $solaLettura) {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { throw 'File di configurazione di Fortnite non trovato.' }
    $f = Get-Item -LiteralPath $p.Ini
    if ($solaLettura) { $f.Attributes = $f.Attributes -bor [IO.FileAttributes]::ReadOnly }
    else              { $f.Attributes = $f.Attributes -band (-bnot [IO.FileAttributes]::ReadOnly) }
    Write-VtLog "GameUserSettings.ini sola lettura = $solaLettura" ok
}

function Backup-VtFortnite {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { throw 'File di configurazione di Fortnite non trovato.' }
    $dest = Join-Path $p.Dir ('GameUserSettings.ini.vejatweak.{0}.bak' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Copy-Item -LiteralPath $p.Ini -Destination $dest -Force
    Write-VtLog "Copia di sicurezza: $(Split-Path $dest -Leaf)"

    # Teniamo le cinque piu' recenti: oltre diventano solo confusione nella
    # cartella (SapoTweak ne ha lasciate otto).
    Get-ChildItem $p.Dir -Filter 'GameUserSettings.ini.vejatweak.*.bak' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip 5 |
        Remove-Item -Force -ErrorAction SilentlyContinue
    return $dest
}

function Restore-VtFortnite {
    $p = Get-VtFortnitePaths
    $bak = Get-ChildItem $p.Dir -Filter 'GameUserSettings.ini.vejatweak.*.bak' -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $bak) { throw 'Nessuna copia fatta da VejaTweak: non c''e'' niente da ripristinare.' }
    if (Test-VtFortniteReadOnly) { Set-VtFortniteReadOnly $false }
    Copy-Item -LiteralPath $bak.FullName -Destination $p.Ini -Force
    Write-VtLog "Configurazione di Fortnite ripristinata da $($bak.Name)" ok
    return $bak.Name
}

# Scrittura di un .ini per righe, non per sezioni ricostruite.
#
# GameUserSettings.ini contiene chiavi ripetute (RecentSelections compare
# cinque volte) e righe che non seguono lo schema chiave=valore: qualunque
# parser che rilegge tutto e riscrive il file da capo le perderebbe. Qui si
# tocca solo la riga interessata e tutto il resto resta byte per byte com'era.
#
# Con -SoloEsistenti le chiavi che non esistono gia' nel file vengono saltate
# invece che aggiunte. Serve per i giochi di cui non abbiamo potuto verificare
# il file di persona: scrivere una chiave sbagliata non rompe niente, ma crea
# un tweak che sembra applicato e non fa nulla. Meglio saltarlo e dirlo.
function Set-VtIniValues([string] $path, $voci, [switch] $SoloEsistenti) {
    $righe = [System.Collections.Generic.List[string]] (Get-Content -LiteralPath $path)
    $applicate = 0; $saltate = @()

    # Indice: nome sezione -> intervallo di righe che le appartengono
    $sezioni = @{}
    $corrente = ''
    for ($i = 0; $i -lt $righe.Count; $i++) {
        if ($righe[$i] -match '^\s*\[(.+?)\]\s*$') {
            $corrente = $matches[1]
            $sezioni[$corrente] = @{ Inizio = $i; Fine = $i }
        } elseif ($corrente -and $sezioni.ContainsKey($corrente)) {
            $sezioni[$corrente].Fine = $i
        }
    }

    foreach ($v in $voci) {
        $riga = '{0}={1}' -f $v.Chiave, $v.Valore

        if (-not $sezioni.ContainsKey($v.Sez)) {
            if ($SoloEsistenti) { $saltate += "$($v.Sez)/$($v.Chiave)"; continue }
            $righe.Add('')
            $righe.Add("[$($v.Sez)]")
            $righe.Add($riga)
            $sezioni[$v.Sez] = @{ Inizio = $righe.Count - 2; Fine = $righe.Count - 1 }
            $applicate++
            continue
        }

        $s = $sezioni[$v.Sez]
        $trovata = -1
        for ($i = $s.Inizio + 1; $i -le $s.Fine -and $i -lt $righe.Count; $i++) {
            if ($righe[$i] -match ('^\s*' + [regex]::Escape($v.Chiave) + '\s*=')) { $trovata = $i; break }
        }
        if ($trovata -ge 0) {
            $righe[$trovata] = $riga
            $applicate++
        } elseif ($SoloEsistenti) {
            $saltate += "$($v.Sez)/$($v.Chiave)"
        } else {
            $righe.Insert($s.Inizio + 1, $riga)
            # Le righe successive sono slittate di uno: aggiorniamo gli indici.
            foreach ($k in @($sezioni.Keys)) {
                if ($sezioni[$k].Inizio -gt $s.Inizio) { $sezioni[$k].Inizio++ }
                if ($sezioni[$k].Fine   -ge $s.Inizio) { $sezioni[$k].Fine++ }
            }
            $applicate++
        }
    }

    # UTF8 senza BOM: il gioco scrive cosi', e con il BOM la prima riga
    # (;METADATA=...) verrebbe letta male.
    [IO.File]::WriteAllLines($path, $righe, (New-Object Text.UTF8Encoding $false))
    if ($saltate.Count -gt 0) {
        Write-VtLog ("Chiavi non presenti nel file, saltate: " + ($saltate -join ', ')) warn
    }
    [pscustomobject]@{ Applicate = $applicate; Saltate = $saltate }
}

# Stessa filosofia per i file XML di GTA V / FiveM: sostituzione della singola
# riga <Tag value="..." />, mai riscrittura dell'albero. Tocca solo i tag che
# esistono gia'.
function Set-VtXmlValues([string] $path, $voci) {
    $righe = [System.Collections.Generic.List[string]] (Get-Content -LiteralPath $path)
    $applicate = 0; $saltate = @()
    foreach ($v in $voci) {
        $rx = '^(\s*)<' + [regex]::Escape($v.Tag) + '\s+value="[^"]*"\s*/>\s*$'
        $fatto = $false
        for ($i = 0; $i -lt $righe.Count; $i++) {
            if ($righe[$i] -match $rx) {
                $righe[$i] = '{0}<{1} value="{2}" />' -f $matches[1], $v.Tag, $v.Valore
                $fatto = $true; $applicate++
                break
            }
        }
        if (-not $fatto) { $saltate += $v.Tag }
    }
    [IO.File]::WriteAllLines($path, $righe, (New-Object Text.UTF8Encoding $false))
    if ($saltate.Count -gt 0) { Write-VtLog ("Tag XML non trovati, saltati: " + ($saltate -join ', ')) warn }
    [pscustomobject]@{ Applicate = $applicate; Saltate = $saltate }
}

# --- Copie di sicurezza, valide per tutti i giochi ------------------------
function Backup-VtGameFile([string] $path) {
    if (-not (Test-Path -LiteralPath $path)) { throw "File non trovato: $path" }
    $f = Get-Item -LiteralPath $path
    $dest = Join-Path $f.DirectoryName ('{0}.vejatweak.{1}.bak' -f $f.Name, (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Copy-Item -LiteralPath $path -Destination $dest -Force
    (Get-Item -LiteralPath $dest).Attributes = 'Normal'
    Get-ChildItem $f.DirectoryName -Filter "$($f.Name).vejatweak.*.bak" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip 5 |
        Remove-Item -Force -ErrorAction SilentlyContinue
    Write-VtLog "Copia di sicurezza: $(Split-Path $dest -Leaf)"
    $dest
}

function Restore-VtGameFile([string] $path) {
    $f = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    if (-not $f) { throw "File non trovato: $path" }
    $bak = Get-ChildItem $f.DirectoryName -Filter "$($f.Name).vejatweak.*.bak" -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $bak) { throw 'Nessuna copia fatta da VejaTweak per questo file.' }
    if ($f.Attributes -band [IO.FileAttributes]::ReadOnly) { $f.Attributes = 'Normal' }
    Copy-Item -LiteralPath $bak.FullName -Destination $path -Force
    Write-VtLog "Ripristinato $($f.Name) da $($bak.Name)" ok
    $bak.Name
}

function Get-VtFortniteIniMap {
    $p = Get-VtFortnitePaths
    $m = @{}
    if (-not $p.Esiste) { return $m }
    foreach ($l in (Get-Content -LiteralPath $p.Ini)) {
        if ($l -match '^\s*([A-Za-z0-9_.\[\]]+)\s*=\s*(.*)$') { $m[$matches[1]] = $matches[2] }
    }
    return $m
}

function Get-VtMonitorHz {
    try {
        $v = Get-CimInstance Win32_VideoController | Where-Object { $_.CurrentRefreshRate -gt 0 } | Select-Object -First 1
        if ($v) { return [int] $v.CurrentRefreshRate }
    } catch { }
    return 60
}

# Prepara la scrittura: controlla che il gioco sia chiuso, fa la copia e
# toglie la sola lettura se serve. Restituisce lo stato precedente del
# flag, cosi' chi chiama puo' rimetterlo.
function Start-VtFortniteEdit {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { throw 'Fortnite non ha ancora creato il file di configurazione. Avvialo una volta e richiudilo.' }
    if (Test-VtFortniteRunning) { throw 'Fortnite e'' aperto. Chiudilo prima: quando esce riscrive il file e cancellerebbe le modifiche.' }
    $ro = Test-VtFortniteReadOnly
    if ($ro) { Set-VtFortniteReadOnly $false }
    Backup-VtFortnite | Out-Null
    return $ro
}

function Complete-VtFortniteEdit([bool] $eraSolaLettura) {
    if ($eraSolaLettura) { Set-VtFortniteReadOnly $true }
}

function Invoke-VtFortnitePreset {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $hz = Get-VtMonitorHz
    $S  = '/Script/FortniteGame.FortGameUserSettings'

    $voci = @(
        # Motore di rendering: es31 e' la Modalita' Prestazioni, quella che su
        # PC modesti vale piu' di tutte le altre voci messe insieme.
        @{ Sez='D3DRHIPreference'; Chiave='PreferredFeatureLevel'; Valore='es31' }
        @{ Sez='PerformanceMode';  Chiave='MeshQuality';           Valore='0' }

        @{ Sez=$S; Chiave='bUseVSync';                Valore='False' }
        @{ Sez=$S; Chiave='bUseDynamicResolution';    Valore='False' }
        @{ Sez=$S; Chiave='bMotionBlur';              Valore='False' }
        @{ Sez=$S; Chiave='bShowGrass';               Valore='False' }
        @{ Sez=$S; Chiave='bAllowUIParallax';         Valore='False' }
        @{ Sez=$S; Chiave='FortAntiAliasingMethod';   Valore='Disabled' }
        @{ Sez=$S; Chiave='bUseNanite';               Valore='False' }
        @{ Sez=$S; Chiave='bRayTracing';              Valore='False' }
        @{ Sez=$S; Chiave='bUseLumenGI';              Valore='False' }
        @{ Sez=$S; Chiave='bUseLumenReflections';     Valore='False' }
        @{ Sez=$S; Chiave='DesiredGlobalIlluminationQuality'; Valore='0' }
        @{ Sez=$S; Chiave='DesiredReflectionQuality'; Valore='0' }

        # Reflex: 2 = On + Boost. bLatencyFlash e' solo l'indicatore a schermo.
        @{ Sez=$S; Chiave='LatencyTweak2';                Valore='2' }
        @{ Sez=$S; Chiave='bLatencyFlash';                Valore='False' }
        @{ Sez=$S; Chiave='LowInputLatencyModeIsEnabled'; Valore='True' }

        # Schermo intero esclusivo: catena di presentazione piu' corta.
        @{ Sez=$S; Chiave='FullscreenMode';              Valore='0' }
        @{ Sez=$S; Chiave='PreferredFullscreenMode';     Valore='0' }
        @{ Sez=$S; Chiave='LastConfirmedFullscreenMode'; Valore='0' }

        @{ Sez=$S; Chiave='FrameRateLimit';         Valore=('{0}.000000' -f $hz) }
        @{ Sez=$S; Chiave='FrontendFrameRateLimit'; Valore=$hz }

        @{ Sez='ScalabilityGroups'; Chiave='sg.ViewDistanceQuality';        Valore='2' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.AntiAliasingQuality';        Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ShadowQuality';              Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.GlobalIlluminationQuality';  Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ReflectionQuality';          Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.PostProcessQuality';         Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.TextureQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.EffectsQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.FoliageQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ShadingQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.LandscapeQuality';           Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ResolutionQuality';          Valore='100.000000' }
        @{ Sez=$S; Chiave='PotentiallyUpscaledResolutionQuality'; Valore='100.000000' }
        @{ Sez=$S; Chiave='NeverUpscaledResolutionQuality';       Valore='100.000000' }
    )

    # Out-Null perche' Set-VtIniValues restituisce un riepilogo che qui non
    # serve: senza, finirebbe nel valore di ritorno della funzione insieme
    # agli Hz, e chi chiama si ritroverebbe due oggetti invece di uno.
    Set-VtIniValues $p.Ini $voci | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Preset competitivo Fortnite applicato (limite FPS $hz)" ok
    return $hz
}

function Set-VtFortniteFpsLimit([int] $fps) {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $S  = '/Script/FortniteGame.FortGameUserSettings'
    Set-VtIniValues $p.Ini @(
        @{ Sez=$S; Chiave='FrameRateLimit';         Valore=('{0}.000000' -f $fps) }
        @{ Sez=$S; Chiave='FrontendFrameRateLimit'; Valore=$(if ($fps -eq 0) { 120 } else { $fps }) }
        @{ Sez=$S; Chiave='bUseVSync';              Valore='False' }
    ) | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Limite FPS di Fortnite impostato a $(if ($fps -eq 0) { 'illimitato' } else { $fps })" ok
}

# Il compromesso fra FPS e leggibilita' non e' una scelta che posso fare io al
# posto di chi gioca: la stessa impostazione che rende nitido un bersaglio
# lontano toglie frame a una CPU al limite. Qui sono tre gradini espliciti.
$script:VtQualitaFn = @(
    @{ Nome='Massimo FPS  -  risoluzione 3D 75%, distanza visuale bassa'; Res=75;  Vista=0; Fps=-1 }
    @{ Nome='Equilibrato  -  risoluzione 3D 90%, distanza visuale media'; Res=90;  Vista=1; Fps=0 }
    @{ Nome='Nitidezza    -  risoluzione 3D 100%, distanza visuale alta'; Res=100; Vista=2; Fps=0 }
)

# $fps: -1 = nessun limite, 0 = aggancia al refresh del monitor.
function Set-VtFortniteQualita([int] $res3d, [int] $vista, [int] $fps) {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $S  = '/Script/FortniteGame.FortGameUserSettings'

    $limite = if ($fps -lt 0) { 0 } else { Get-VtMonitorHz }
    Set-VtIniValues $p.Ini @(
        @{ Sez='ScalabilityGroups'; Chiave='sg.ResolutionQuality';   Valore=('{0}.000000' -f $res3d) }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ViewDistanceQuality'; Valore=$vista }
        @{ Sez=$S; Chiave='PotentiallyUpscaledResolutionQuality'; Valore=('{0}.000000' -f $res3d) }
        @{ Sez=$S; Chiave='NeverUpscaledResolutionQuality';       Valore=('{0}.000000' -f $res3d) }
        @{ Sez=$S; Chiave='FrameRateLimit';         Valore=('{0}.000000' -f $limite) }
        @{ Sez=$S; Chiave='FrontendFrameRateLimit'; Valore=$(if ($limite -eq 0) { 120 } else { $limite }) }
    ) | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Fortnite: risoluzione 3D $res3d%, distanza visuale $vista, limite FPS $(if ($limite -eq 0) { 'nessuno' } else { $limite })" ok
}

$script:VtRisoluzioni = @(
    @{ Nome='1920 x 1080  (nativa 16:9)'; X=1920; Y=1080 }
    @{ Nome='1600 x 1080  (stretched leggero)'; X=1600; Y=1080 }
    @{ Nome='1440 x 1080  (stretched 4:3, il piu'' usato)'; X=1440; Y=1080 }
    @{ Nome='1280 x 1080  (stretched spinto)'; X=1280; Y=1080 }
    @{ Nome='1024 x 768   (4:3 classico)'; X=1024; Y=768 }
)

function Set-VtFortniteResolution([int] $x, [int] $y) {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $S  = '/Script/FortniteGame.FortGameUserSettings'
    Set-VtIniValues $p.Ini @(
        @{ Sez=$S; Chiave='ResolutionSizeX';                    Valore=$x }
        @{ Sez=$S; Chiave='ResolutionSizeY';                    Valore=$y }
        @{ Sez=$S; Chiave='LastUserConfirmedResolutionSizeX';   Valore=$x }
        @{ Sez=$S; Chiave='LastUserConfirmedResolutionSizeY';   Valore=$y }
        @{ Sez=$S; Chiave='DesiredScreenWidth';                 Valore=$x }
        @{ Sez=$S; Chiave='DesiredScreenHeight';                Valore=$y }
        @{ Sez=$S; Chiave='LastUserConfirmedDesiredScreenWidth';  Valore=$x }
        @{ Sez=$S; Chiave='LastUserConfirmedDesiredScreenHeight'; Valore=$y }
        @{ Sez=$S; Chiave='WindowWidth';                        Valore=$x }
        @{ Sez=$S; Chiave='WindowHeight';                       Valore=$y }
        @{ Sez=$S; Chiave='bUseDesktopResolutionForFullscreen'; Valore='False' }
        @{ Sez=$S; Chiave='FullscreenMode';                     Valore='0' }
        @{ Sez=$S; Chiave='PreferredFullscreenMode';            Valore='0' }
        @{ Sez=$S; Chiave='LastConfirmedFullscreenMode';        Valore='0' }
    ) | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Risoluzione di Fortnite impostata a ${x}x${y}" ok
}

# Riassunto leggibile di com'e' messo il gioco adesso.
function Get-VtFortniteStato {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { return $null }
    $m = Get-VtFortniteIniMap

    $fps = $m['FrameRateLimit']
    $fpsTxt = if (-not $fps -or [double]$fps -eq 0) { 'illimitati' } else { [int][double]$fps }

    $mod = switch ($m['FullscreenMode']) { '0' { 'schermo intero esclusivo' } '1' { 'finestra senza bordi' } '2' { 'finestra' } default { 'sconosciuta' } }
    $rhi = switch ($m['PreferredFeatureLevel']) { 'es31' { 'Prestazioni' } 'sm5' { 'DirectX 11' } 'sm6' { 'DirectX 12' } default { $m['PreferredFeatureLevel'] } }
    $rfx = switch ($m['LatencyTweak2']) { '2' { 'On + Boost' } '1' { 'On' } '0' { 'Off' } default { 'sconosciuto' } }

    [pscustomobject]@{
        Risoluzione = "$($m['ResolutionSizeX']) x $($m['ResolutionSizeY'])"
        Fps         = $fpsTxt
        Modalita    = $mod
        Rendering   = $rhi
        Reflex      = $rfx
        Res3D       = $(if ($m['sg.ResolutionQuality']) { [int][double] $m['sg.ResolutionQuality'] } else { '?' })
        VSync       = $m['bUseVSync']
        SolaLettura = (Test-VtFortniteReadOnly)
        InEsecuzione= (Test-VtFortniteRunning)
    }
}

# ---------------------------------------------------------------------------
# VALORANT
#
# Due file, e vanno tenuti allineati:
#   RiotUserSettings.ini  -> [Settings], chiavi EAresIntSettingName:: e
#                            EAresBoolSettingName:: (qualita' grafica, Reflex)
#   GameUserSettings.ini  -> chiavi Unreal standard (V-Sync, limite FPS,
#                            risoluzione, schermo intero). Esiste in due copie:
#                            una per l'account e una di macchina.
# ---------------------------------------------------------------------------
function Get-VtValorantPaths {
    $base = Join-Path $env:LOCALAPPDATA 'VALORANT\Saved\Config'
    $res = [pscustomobject]@{ Riot = $null; Gus = @(); Esiste = $false }
    if (-not (Test-Path $base)) { return $res }

    # La cartella dell'account ha per nome il PUUID seguito dalla regione.
    $acc = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue |
           Where-Object { Test-Path (Join-Path $_.FullName 'Windows\RiotUserSettings.ini') } |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($acc) {
        $res.Riot = Join-Path $acc.FullName 'Windows\RiotUserSettings.ini'
        $p = Join-Path $acc.FullName 'WindowsClient\GameUserSettings.ini'
        if (Test-Path $p) { $res.Gus += $p }
    }
    $m = Join-Path $base 'WindowsClient\GameUserSettings.ini'
    if (Test-Path $m) { $res.Gus += $m }
    $res.Esiste = ($null -ne $res.Riot)
    return $res
}

function Test-VtValorantRunning {
    [bool] (Get-Process -Name 'VALORANT-Win64-Shipping', 'VALORANT', 'RiotClientServices' -ErrorAction SilentlyContinue)
}

function Get-VtValorantStato {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { return $null }
    $r = @{}
    foreach ($l in (Get-Content -LiteralPath $p.Riot)) {
        if ($l -match '^EAres\w+SettingName::(\w+)=(.+)$') { $r[$matches[1]] = $matches[2] }
    }
    $g = @{}
    if ($p.Gus.Count -gt 0) {
        foreach ($l in (Get-Content -LiteralPath $p.Gus[0])) {
            if ($l -match '^\s*(\w+)\s*=\s*(.*)$') { $g[$matches[1]] = $matches[2] }
        }
    }
    $aa = switch ($r['AntiAliasing']) { '0' { 'nessuno' } '1' { 'MSAA 2x' } '2' { 'MSAA 4x' } default { $r['AntiAliasing'] } }
    $q  = { param($v) switch ($v) { '0' { 'Basso' } '1' { 'Medio' } '2' { 'Alto' } default { $v } } }
    $rf = switch ($r['NvidiaReflexLowLatencySetting']) { '0' { 'Off' } '1' { 'On' } '2' { 'On + Boost' } default { 'sconosciuto' } }
    $fps = $g['FrameRateLimit']
    [pscustomobject]@{
        Risoluzione = "$($g['ResolutionSizeX']) x $($g['ResolutionSizeY'])"
        Fps         = if (-not $fps -or [double]$fps -eq 0) { 'illimitati' } else { [int][double]$fps }
        VSync       = $g['bUseVSync']
        AntiAlias   = $aa
        Materiali   = (& $q $r['MaterialQuality'])
        Texture     = (& $q $r['TextureQuality'])
        Dettaglio   = (& $q $r['DetailQuality'])
        Ombre       = $r['ShadowsEnabled']
        Chiarezza   = $r['ImproveClarity']
        Reflex      = $rf
        Account     = (Split-Path (Split-Path $p.Riot -Parent) -Parent | Split-Path -Leaf)
        InEsecuzione= (Test-VtValorantRunning)
    }
}

function Invoke-VtValorantPreset {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { throw 'Configurazione di Valorant non trovata. Avvia il gioco una volta.' }
    if (Test-VtValorantRunning) { throw 'Valorant o il Riot Client sono aperti. Chiudili: alla chiusura riscrivono i file.' }

    Backup-VtGameFile $p.Riot | Out-Null
    $r = Set-VtIniValues $p.Riot @(
        @{ Sez='Settings'; Chiave='EAresIntSettingName::AntiAliasing';                 Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::MaterialQuality';              Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::TextureQuality';               Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::DetailQuality';                Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::NvidiaReflexLowLatencySetting'; Valore='2' }
        @{ Sez='Settings'; Chiave='EAresBoolSettingName::ShadowsEnabled';              Valore='False' }
        @{ Sez='Settings'; Chiave='EAresBoolSettingName::ImproveClarity';              Valore='False' }
        @{ Sez='Settings'; Chiave='EAresBoolSettingName::ShowCorpses';                 Valore='False' }
    ) -SoloEsistenti

    $hz = Get-VtMonitorHz
    foreach ($g in $p.Gus) {
        Backup-VtGameFile $g | Out-Null
        Set-VtIniValues $g @(
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='bUseVSync';                Valore='False' }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='bUseDynamicResolution';    Valore='False' }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='FrameRateLimit';           Valore=('{0}.000000' -f $hz) }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='PreferredFullscreenMode';  Valore='0' }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='LastConfirmedFullscreenMode'; Valore='0' }
        ) -SoloEsistenti | Out-Null
    }
    Write-VtLog "Preset Valorant applicato ($($r.Applicate) impostazioni, limite FPS $hz)" ok
    return $hz
}

function Set-VtValorantFps([int] $fps) {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { throw 'Configurazione di Valorant non trovata.' }
    if (Test-VtValorantRunning) { throw 'Valorant o il Riot Client sono aperti. Chiudili prima.' }
    foreach ($g in $p.Gus) {
        Backup-VtGameFile $g | Out-Null
        Set-VtIniValues $g @(
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='FrameRateLimit'; Valore=('{0}.000000' -f $fps) }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='bUseVSync';      Valore='False' }
        ) -SoloEsistenti | Out-Null
    }
    Write-VtLog "Limite FPS di Valorant impostato a $(if ($fps -eq 0) { 'illimitato' } else { $fps })" ok
}

function Restore-VtValorant {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { throw 'Configurazione di Valorant non trovata.' }
    $n = Restore-VtGameFile $p.Riot
    foreach ($g in $p.Gus) { try { Restore-VtGameFile $g | Out-Null } catch { } }
    return $n
}

# ---------------------------------------------------------------------------
# FIVEM / GTA V
#
# FiveM non usa il settings.xml di GTA V: ne tiene uno suo in
# %APPDATA%\CitizenFX\gta5_settings.xml. Le voci che contano qui non sono
# quelle grafiche (che di solito sono gia' al minimo) ma quelle che caricano
# la CPU: densita' della citta', varieta' dei pedoni, distanza delle ombre.
# FiveM e' CPU-bound, ed e' li' che si vince.
# ---------------------------------------------------------------------------
function Get-VtFivemSettings {
    $p = Join-Path $env:APPDATA 'CitizenFX\gta5_settings.xml'
    [pscustomobject]@{ Path = $p; Esiste = (Test-Path -LiteralPath $p) }
}

function Test-VtFivemRunning {
    [bool] (Get-Process -Name 'FiveM', 'FiveM_GTAProcess' -ErrorAction SilentlyContinue) -or
    [bool] (Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'FiveM_*' })
}

function Get-VtFivemStato {
    $f = Get-VtFivemSettings
    if (-not $f.Esiste) { return $null }
    $m = @{}
    foreach ($l in (Get-Content -LiteralPath $f.Path)) {
        if ($l -match '<(\w+)\s+value="([^"]*)"\s*/>') { $m[$matches[1]] = $matches[2] }
    }
    [pscustomobject]@{
        Risoluzione = "$($m['ScreenWidth']) x $($m['ScreenHeight'])"
        Finestra    = switch ($m['Windowed']) { '0' { 'schermo intero' } '1' { 'finestra' } '2' { 'senza bordi' } default { $m['Windowed'] } }
        VSync       = $m['VSync']
        Msaa        = $m['MSAA']
        Ombre       = $m['ShadowQuality']
        DistanzaOmbre = $m['Shadow_Distance']
        Citta       = $m['CityDensity']
        Pedoni      = $m['PedVarietyMultiplier']
        Lod         = $m['LodScale']
        InEsecuzione= (Test-VtFivemRunning)
    }
}

function Invoke-VtFivemPreset {
    $f = Get-VtFivemSettings
    if (-not $f.Esiste) { throw 'gta5_settings.xml non trovato. Avvia FiveM una volta e richiudilo.' }
    if (Test-VtFivemRunning) { throw 'FiveM e'' aperto. Chiudilo: alla chiusura riscrive il file.' }

    Backup-VtGameFile $f.Path | Out-Null
    $r = Set-VtXmlValues $f.Path @(
        # Le tre voci che tolgono lavoro alla CPU, cioe' quelle che contano
        # davvero su un server pieno di gente.
        @{ Tag='CityDensity';          Valore='0.500000' }
        @{ Tag='PedVarietyMultiplier'; Valore='0.500000' }
        @{ Tag='LodScale';             Valore='0.700000' }

        @{ Tag='Shadow_Distance';        Valore='0.400000' }
        @{ Tag='Shadow_SoftShadows';     Valore='0' }
        @{ Tag='Shadow_ParticleShadows'; Valore='false' }
        @{ Tag='Shadow_LongShadows';     Valore='false' }
        @{ Tag='UltraShadows_Enabled';   Valore='false' }
        @{ Tag='ShadowQuality';          Valore='0' }

        @{ Tag='MSAA';            Valore='0' }
        @{ Tag='MSAAFragments';   Valore='0' }
        @{ Tag='MSAAQuality';     Valore='0' }
        @{ Tag='ReflectionMSAA';  Valore='0' }
        @{ Tag='ReflectionQuality'; Valore='0' }
        @{ Tag='SSAO';            Valore='0' }
        @{ Tag='Tessellation';    Valore='0' }
        @{ Tag='ParticleQuality'; Valore='0' }
        @{ Tag='WaterQuality';    Valore='0' }
        @{ Tag='GrassQuality';    Valore='0' }
        @{ Tag='PostFX';          Valore='0' }
        @{ Tag='DoF';             Valore='false' }
        @{ Tag='MotionBlurStrength'; Valore='0.000000' }
        @{ Tag='AnisotropicFiltering'; Valore='4' }
        @{ Tag='VSync';           Valore='0' }
    )
    Write-VtLog "Preset FiveM applicato ($($r.Applicate) voci)" ok
    return $r
}

function Restore-VtFivem {
    $f = Get-VtFivemSettings
    if (-not $f.Esiste) { throw 'gta5_settings.xml non trovato.' }
    Restore-VtGameFile $f.Path
}

# ---------------------------------------------------------------------------
# RAINBOW SIX SIEGE
#
# Il file sta in Documenti\My Games\Rainbow Six - Siege\<id Ubisoft>\
# GameSettings.ini. Su questo PC il gioco non e' installato, quindi le chiavi
# non le ho potute verificare di persona: per questo il preset gira in
# modalita' "solo chiavi esistenti" e ti dice quante ne ha saltate.
# La scelta fra Vulkan e DX11 NON sta qui: si fa da Ubisoft Connect al lancio.
# ---------------------------------------------------------------------------
function Get-VtR6Settings {
    $base = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Rainbow Six - Siege'
    $res = [pscustomobject]@{ Path = $null; Esiste = $false; Base = $base }
    if (-not (Test-Path $base)) { return $res }
    $f = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue |
         ForEach-Object { Join-Path $_.FullName 'GameSettings.ini' } |
         Where-Object { Test-Path $_ } |
         Sort-Object { (Get-Item $_).LastWriteTime } -Descending | Select-Object -First 1
    if ($f) { $res.Path = $f; $res.Esiste = $true }
    return $res
}

function Test-VtR6Running {
    [bool] (Get-Process -Name 'RainbowSix', 'RainbowSix_Vulkan' -ErrorAction SilentlyContinue)
}

function Get-VtR6Stato {
    $r = Get-VtR6Settings
    if (-not $r.Esiste) { return $null }
    $m = @{}
    foreach ($l in (Get-Content -LiteralPath $r.Path)) {
        if ($l -match '^\s*(\w+)\s*=\s*(.*)$') { $m[$matches[1]] = $matches[2].Trim() }
    }
    [pscustomobject]@{
        Risoluzione = "$($m['Width']) x $($m['Height'])"
        SchermoIntero = $m['Fullscreen']
        VSync       = $m['VSync']
        Refresh     = $m['RefreshRate']
        Chiavi      = $m.Keys.Count
        InEsecuzione= (Test-VtR6Running)
    }
}

function Invoke-VtR6Preset {
    $r = Get-VtR6Settings
    if (-not $r.Esiste) { throw 'GameSettings.ini di Rainbow Six non trovato. Avvia il gioco una volta e richiudilo.' }
    if (Test-VtR6Running) { throw 'Rainbow Six e'' aperto. Chiudilo prima.' }

    Backup-VtGameFile $r.Path | Out-Null
    $hz = Get-VtMonitorHz
    $res = Set-VtIniValues $r.Path @(
        @{ Sez='DISPLAY';  Chiave='VSync';               Valore='0' }
        @{ Sez='DISPLAY';  Chiave='Fullscreen';          Valore='1' }
        @{ Sez='DISPLAY';  Chiave='RefreshRate';         Valore=$hz }
        @{ Sez='GRAPHICS'; Chiave='ShadowQuality';       Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='ShadowMapQuality';    Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='ReflectionQuality';   Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='AmbientOcclusion';    Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='LensEffects';         Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='LensFlares';          Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='ZoomInDepthOfField';  Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='MotionBlur';          Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='AntiAliasingPostQuality'; Valore='1' }
        @{ Sez='GRAPHICS'; Chiave='RenderScaling';       Valore='100' }
        @{ Sez='GRAPHICS'; Chiave='TextureFilterQuality'; Valore='1' }
    ) -SoloEsistenti
    Write-VtLog "Preset R6 applicato: $($res.Applicate) impostazioni, $($res.Saltate.Count) saltate" ok
    return $res
}

function Restore-VtR6 {
    $r = Get-VtR6Settings
    if (-not $r.Esiste) { throw 'GameSettings.ini di Rainbow Six non trovato.' }
    Restore-VtGameFile $r.Path
}

# ---------------------------------------------------------------------------
# BIOS / UEFI
#
# Chiariamo subito il limite, perche' e' la richiesta piu' comune e la risposta
# onesta e' no: nessun programma in esecuzione su Windows puo' cambiare le
# impostazioni del BIOS. Vivono nella NVRAM del firmware, che il sistema
# operativo non puo' scrivere: non e' una protezione aggirabile, e' proprio
# l'assenza di un'interfaccia. Le utility dei produttori che sembrano farlo
# usano un driver in kernel mode firmato dal produttore stesso, ed e'
# esattamente il tipo di driver che gli anticheat segnalano.
#
# Quello che possiamo fare, e che facciamo qui:
#   - riconoscere dal sistema quali impostazioni del BIOS sono sbagliate
#   - riavviare direttamente nella schermata del firmware con un clic
#   - dire dove stanno le voci sulla marca di scheda madre giusta
#   - alla riapertura, verificare se la modifica ha fatto effetto
# ---------------------------------------------------------------------------
function Get-VtFirmware {
    if ($script:VtFw) { return $script:VtFw }
    $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
    $bi = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue

    $sb = $null
    try { $sb = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -Name UEFISecureBootEnabled -ErrorAction Stop).UEFISecureBootEnabled } catch { }

    $script:VtFw = [pscustomobject]@{
        Produttore = if ($bb) { $bb.Manufacturer } else { 'sconosciuto' }
        Scheda     = if ($bb) { $bb.Product } else { 'sconosciuta' }
        Sistema    = if ($cs) { "$($cs.Manufacturer) $($cs.Model)".Trim() } else { '' }
        Versione   = if ($bi) { $bi.SMBIOSBIOSVersion } else { '?' }
        Data       = if ($bi -and $bi.ReleaseDate) { $bi.ReleaseDate } else { $null }
        Uefi       = ($env:firmware_type -eq 'UEFI')
        SecureBoot = $sb
    }
    return $script:VtFw
}

# Il tasto per entrare nel BIOS e i nomi dei menu cambiano da marca a marca.
# Mandare qualcuno a cercare "XMP" su una scheda dove si chiama "EXPO" o
# "DOCP" e' il modo migliore per fargli pensare che l'opzione non esista.
function Get-VtBiosGuida {
    $fw = Get-VtFirmware
    $m  = "$($fw.Produttore) $($fw.Sistema)"

    if ($m -match 'ASUS|ASUSTeK') {
        return @{ Tasto='CANC (o F2)'; Note='Premi F7 per passare alla Modalita'' Avanzata, altrimenti meta'' delle voci non si vedono.'
                  Xmp='Ai Tweaker > Ai Overclock Tuner > XMP I / DOCP / EXPO'
                  Ht='Advanced > CPU Configuration > Intel (VMX) / Hyper-Threading' }
    }
    if ($m -match 'MSI|Micro-Star') {
        return @{ Tasto='CANC'; Note='Premi F7 per la Modalita'' Avanzata.'
                  Xmp='OC > Extreme Memory Profile (XMP) / EXPO'
                  Ht='OC > CPU Features > Intel Hyper-Threading Technology' }
    }
    if ($m -match 'Gigabyte|AORUS') {
        return @{ Tasto='CANC'; Note='Premi F2 per passare da Easy Mode ad Advanced Mode.'
                  Xmp='Tweaker > Extreme Memory Profile (X.M.P.) / EXPO'
                  Ht='Tweaker > Advanced CPU Settings > Hyper-Threading Technology' }
    }
    if ($m -match 'ASRock') {
        return @{ Tasto='F2 (o CANC)'; Note=''
                  Xmp='OC Tweaker > DRAM Profile Configuration > XMP / EXPO'
                  Ht='Advanced > CPU Configuration > Hyper Threading' }
    }
    if ($m -match '^HP|Hewlett') {
        return @{ Tasto='F10 subito dopo l''accensione (se non prende, prima ESC poi F10)'
                  Note='ATTENZIONE: i BIOS dei PC preassemblati HP sono volutamente ridotti. Su molti modelli consumer le voci per XMP e Hyper-Threading NON esistono proprio. Se dopo aver guardato non le trovi, non le stai cercando male: non ci sono.'
                  Xmp='Se presente: Advanced > Memory Settings (spesso assente sui modelli consumer)'
                  Ht='Se presente: Advanced > System Options > Hyper-Threading / Intel HT Technology' }
    }
    if ($m -match 'Dell|Alienware') {
        return @{ Tasto='F2'; Note='Sui Dell preassemblati molte voci sono bloccate.'
                  Xmp='Memory Settings > XMP (spesso assente)'
                  Ht='Performance > Hyper-Threading Control' }
    }
    if ($m -match 'Lenovo') {
        return @{ Tasto='F1 (o F2)'; Note='Sui Lenovo preassemblati molte voci sono bloccate.'
                  Xmp='Spesso assente sui modelli consumer'
                  Ht='Devices / Advanced > CPU Setup > Intel Hyper-Threading' }
    }
    if ($m -match 'Acer|Predator') {
        return @{ Tasto='F2'; Note='Su alcuni Acer le voci avanzate compaiono solo dopo aver impostato una password supervisore.'
                  Xmp='Advanced > Memory Configuration'
                  Ht='Advanced > CPU Configuration > Hyper-Threading' }
    }
    return @{ Tasto='CANC o F2 subito dopo l''accensione'; Note=''
              Xmp='Cerca XMP (Intel), EXPO o DOCP (AMD) nel menu della memoria o dell''overclock'
              Ht='Cerca Hyper-Threading, Intel HT Technology o SMT nel menu della CPU' }
}

# Problemi che si vedono da Windows ma si risolvono solo nel firmware.
function Get-VtBiosFindings {
    $out = @()
    $sys = Get-VtSystem
    $g   = Get-VtBiosGuida

    if ($sys.Thread -eq $sys.Core -and $sys.Cpu -match 'Core.*i[579]|Ryzen [579]|Core.*Ultra') {
        $out += [pscustomobject]@{
            Peso = 1; Stato = 'DA SISTEMARE'
            Titolo = 'Hyper-Threading / SMT disattivato'
            Testo  = "Windows vede $($sys.Core) core e $($sys.Thread) thread: su questa CPU dovrebbero essere di piu'. Ho gia' controllato che non sia un limite imposto da Windows (nessun numproc nel BCD), quindi e' spento nel firmware.`n`nDove guardare: $($g.Ht)`n`nVale 10-20% di FPS su FiveM, Fortnite e R6, e molto di piu' sui minimi." }
    }

    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $conf = ($mods | Measure-Object ConfiguredClockSpeed -Maximum).Maximum
        $max  = ($mods | Measure-Object Speed -Maximum).Maximum
        if ($conf -and $max -and $conf -lt ($max - 100)) {
            $out += [pscustomobject]@{
                Peso = 1; Stato = 'DA SISTEMARE'
                Titolo = 'Profilo XMP / EXPO non attivo'
                Testo  = "La RAM gira a $conf MT/s invece dei $max che i moduli dichiarano.`n`nDove guardare: $($g.Xmp)`n`nNon e' overclock del processore: e' il profilo che i moduli si portano dietro di fabbrica. Sui giochi CPU-bound vale 10-25%." }
        } elseif ($conf) {
            $out += [pscustomobject]@{
                Peso = 3; Stato = 'A POSTO'
                Titolo = 'Frequenza RAM corretta'
                Testo  = "La RAM gira a $conf MT/s, cioe' la frequenza dichiarata dai moduli. Niente da fare qui." }
        }
    } catch { }

    $fw = Get-VtFirmware
    if ($fw.SecureBoot -eq 1) {
        $out += [pscustomobject]@{
            Peso = 3; Stato = 'A POSTO'
            Titolo = 'Secure Boot attivo'
            Testo  = "Serve a Valorant su Windows 11: senza, Vanguard non fa partire il gioco. E' gia' attivo, non toccarlo." }
    } elseif ($null -ne $fw.SecureBoot) {
        $out += [pscustomobject]@{
            Peso = 2; Stato = 'DA SISTEMARE'
            Titolo = 'Secure Boot disattivato'
            Testo  = "Su Windows 11, Valorant richiede Secure Boot e TPM 2.0 attivi o Vanguard blocca l'avvio. Cerca 'Secure Boot' nel menu Boot o Security del BIOS.`n`nAttenzione: se hai installato Windows in modalita' Legacy/CSM, accendere Secure Boot puo' impedire l'avvio. In quel caso serve prima convertire il disco con mbr2gpt." }
    }

    # Resizable BAR non e' interrogabile in modo affidabile da Windows: meglio
    # dire dove si guarda che inventarsi un rilevamento che sbaglia.
    $out += [pscustomobject]@{
        Peso = 2; Stato = 'DA VERIFICARE'
        Titolo = 'Resizable BAR'
        Testo  = "Non e' leggibile da Windows in modo affidabile, quindi controllalo tu: Pannello NVIDIA > Guida > Informazioni sistema, voce 'Resizable BAR'. Su AMD e' in Adrenalin > Prestazioni.`n`nSe risulta No, nel BIOS servono DUE voci accese insieme: 'Above 4G Decoding' e 'Re-Size BAR Support'. Vale qualche punto percentuale, a volte di piu' su GPU recenti." }

    $out | Sort-Object Peso
}

function Test-VtCanRebootToFirmware {
    (Get-VtFirmware).Uefi
}

# shutdown /r /fw chiede al firmware di fermarsi nella schermata di setup al
# prossimo avvio. Funziona solo su UEFI e richiede privilegi elevati.
function Invoke-VtRebootToFirmware {
    if (-not (Test-VtAdmin)) { throw 'Servono privilegi di amministratore.' }
    if (-not (Test-VtCanRebootToFirmware)) { throw 'Questo PC non e'' avviato in modalita'' UEFI.' }
    Write-VtLog 'Riavvio nella schermata del firmware richiesto dall''utente' ok
    Invoke-VtCmd 'shutdown /r /fw /t 3' | Out-Null
}

# ---------------------------------------------------------------------------
# MISURA DELLA STABILITA'
#
# Gli FPS medi non dicono niente sugli scatti. Quello che si vede come
# micro-stutter e' quasi sempre tempo rubato dal kernel ai thread del gioco:
# DPC (lavoro differito dei driver) e ISR (interrupt hardware). Se un driver
# tiene la CPU in DPC per troppo tempo, il frame successivo arriva tardi e tu
# lo vedi, anche con 300 FPS di media.
#
# Non serve installare niente: i contatori stanno in WMI, e i nomi delle
# proprieta' WMI non sono tradotti (a differenza dei contatori di prestazione
# classici, che su questo PC in italiano non rispondono ai nomi inglesi).
# ---------------------------------------------------------------------------
function Get-VtStabilitySample {
    $x = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -ErrorAction Stop
    [pscustomobject]@{
        Dpc      = [double] $x.PercentDPCTime
        Isr      = [double] $x.PercentInterruptTime
        DpcSec   = [double] $x.DPCsQueuedPersec
        IntSec   = [double] $x.InterruptsPersec
        Cpu      = [double] $x.PercentProcessorTime
    }
}

# Trasforma una serie di campioni in un giudizio leggibile.
function Get-VtStabilityVerdetto($campioni) {
    if (-not $campioni -or $campioni.Count -eq 0) { return $null }

    $dpcMed = ($campioni | Measure-Object Dpc -Average).Average
    $dpcMax = ($campioni | Measure-Object Dpc -Maximum).Maximum
    $isrMed = ($campioni | Measure-Object Isr -Average).Average
    $intMed = ($campioni | Measure-Object IntSec -Average).Average
    $intMax = ($campioni | Measure-Object IntSec -Maximum).Maximum
    $picco  = if ($intMed -gt 0) { $intMax / $intMed } else { 1 }

    $problemi = @()
    if ($dpcMed -ge 5)      { $problemi += "Tempo in DPC alto ($([math]::Round($dpcMed,1))% di media): c'e' un driver che tiene occupata la CPU. E' la causa numero uno dei micro-scatti." }
    elseif ($dpcMed -ge 2)  { $problemi += "Tempo in DPC un po' alto ($([math]::Round($dpcMed,1))% di media): sopportabile, ma sotto carico puo' peggiorare." }
    if ($dpcMax -ge 10)     { $problemi += "Picco di DPC al $([math]::Round($dpcMax,1))%: qualcosa ogni tanto blocca la CPU per un tempo lungo. Sono gli scatti isolati che senti ogni pochi secondi." }
    if ($isrMed -ge 4)      { $problemi += "Tempo in interrupt alto ($([math]::Round($isrMed,1))%): spesso e' un dispositivo USB, una scheda di rete o un driver audio." }
    if ($picco -ge 3)       { $problemi += "Gli interrupt vanno a ondate (picco $([math]::Round($picco,1))x sulla media): qualcosa si sveglia a intervalli. Tipico di software di periferiche RGB, overlay e programmi di aggiornamento." }

    $stato = if ($problemi.Count -eq 0) { 'BUONO' } elseif ($dpcMed -ge 5 -or $dpcMax -ge 10) { 'DA SISTEMARE' } else { 'ACCETTABILE' }

    [pscustomobject]@{
        Stato    = $stato
        DpcMedio = [math]::Round($dpcMed, 1)
        DpcMax   = [math]::Round($dpcMax, 1)
        IsrMedio = [math]::Round($isrMed, 1)
        IntMedio = [math]::Round($intMed)
        IntMax   = [math]::Round($intMax)
        Picco    = [math]::Round($picco, 1)
        Campioni = $campioni.Count
        Problemi = $problemi
    }
}

# Gli interrupt "message signaled" non richiedono di bloccare una linea
# condivisa: su GPU e controller di archiviazione riducono la latenza DPC.
# Non lo cambiamo: sulle schede moderne e' gia' attivo, e forzarlo su un
# dispositivo che non lo supporta puo' impedire l'avvio del PC. Lo leggiamo
# e basta.
function Get-VtMsiStato {
    $out = @()
    try {
        $dev = Get-CimInstance Win32_PnPEntity -ErrorAction Stop |
               Where-Object { $_.PNPClass -in 'Display', 'Net', 'SCSIAdapter' -and $_.PNPDeviceID -like 'PCI*' }
        foreach ($d in $dev) {
            $p = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($d.PNPDeviceID)\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties"
            $v = Get-VtReg $p 'MSISupported'
            $out += [pscustomobject]@{
                Nome  = $d.Name
                Tipo  = $d.PNPClass
                Msi   = ($v -eq 1)
                Noto  = ($null -ne $v)
            }
        }
    } catch { }
    $out
}

# Programmi noti per generare interrupt a ondate mentre giochi.
function Get-VtDisturbatori {
    $noti = @(
        @{ P='iCUE';            N='Corsair iCUE';        Nota='polling continuo su tutte le periferiche RGB' }
        @{ P='RazerSynapse';    N='Razer Synapse';       Nota='hook globale sull''input, noto per micro-stutter' }
        @{ P='ArmouryCrate';    N='Armoury Crate';       Nota='monitoraggio hardware a intervalli fissi' }
        @{ P='ArmourySocketServer'; N='Armoury Crate (servizio)'; Nota='monitoraggio hardware a intervalli fissi' }
        @{ P='LogiOverlay';     N='Logitech G Overlay';  Nota='overlay agganciato al render' }
        @{ P='lghub_agent';     N='Logitech G HUB';      Nota='polling periferiche' }
        @{ P='MSIAfterburner';  N='MSI Afterburner';     Nota='campionamento hardware: con intervallo basso genera DPC' }
        @{ P='RTSS';            N='RivaTuner Statistics';Nota='si aggancia alla presentazione dei frame' }
        @{ P='OpenRGB';         N='OpenRGB';             Nota='polling continuo dei controller RGB' }
        @{ P='SignalRgb';       N='SignalRGB';           Nota='polling continuo dei controller RGB' }
        @{ P='NZXT CAM';        N='NZXT CAM';            Nota='monitoraggio hardware aggressivo' }
        @{ P='HWiNFO64';        N='HWiNFO';              Nota='con polling dei sensori basso genera DPC' }
        @{ P='Discord';         N='Discord (overlay)';   Nota='l''overlay in-game si aggancia al render' }
    )
    $attivi = @(Get-Process -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName -Unique)
    @($noti | Where-Object { $attivi -contains $_.P })
}

# ---------------------------------------------------------------------------
# DISCORD
#
# Discord e' un browser Chromium travestito: sul PC in prova gira con sei
# processi e 1,8 GB di RAM, di cui 367 MB nel solo processo che disegna con
# la scheda video. Quel processo compete con il gioco per la GPU, ed e'
# l'unica cosa di Discord che si possa spegnere da fuori.
#
# Il bello e' che l'effetto si VEDE: se l'accelerazione hardware e' spenta,
# alla riapertura il processo "gpu-process" non c'e' piu'. Quindi il tweak si
# puo' verificare invece di doverci credere.
# ---------------------------------------------------------------------------
function Get-VtDiscordSettings {
    foreach ($n in 'discord', 'discordptb', 'discordcanary') {
        $p = Join-Path $env:APPDATA "$n\settings.json"
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Test-VtDiscordRunning {
    [bool] (Get-Process -Name 'Discord', 'DiscordPTB', 'DiscordCanary' -ErrorAction SilentlyContinue)
}

function Get-VtDiscordStato {
    $s = Get-VtDiscordSettings
    if (-not $s) { return $null }

    $proc = @(Get-Process -Name 'Discord', 'DiscordPTB', 'DiscordCanary' -ErrorAction SilentlyContinue)
    $gpu = @()
    try {
        $gpu = @(Get-CimInstance Win32_Process -Filter "Name='Discord.exe'" -ErrorAction SilentlyContinue |
                 Where-Object { $_.CommandLine -match '--type=gpu-process' })
    } catch { }

    $accel = $null
    try {
        $j = Get-Content -LiteralPath $s -Raw | ConvertFrom-Json
        if ($null -ne $j.enableHardwareAcceleration) { $accel = [bool] $j.enableHardwareAcceleration }
    } catch { }

    $cacheMb = 0
    foreach ($c in 'Cache', 'Code Cache', 'GPUCache', 'DawnGraphiteCache', 'DawnWebGPUCache') {
        $p = Join-Path (Split-Path $s -Parent) $c
        if (Test-Path -LiteralPath $p) {
            $m = Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum
            $cacheMb += $m.Sum / 1MB
        }
    }

    [pscustomobject]@{
        File         = $s
        Processi     = $proc.Count
        RamMb        = if ($proc) { [math]::Round((($proc | Measure-Object WorkingSet64 -Sum).Sum) / 1MB) } else { 0 }
        ProcessoGpu  = ($gpu.Count -gt 0)
        GpuMb        = if ($gpu.Count -gt 0) { [math]::Round((Get-Process -Id $gpu[0].ProcessId -ErrorAction SilentlyContinue).WorkingSet64 / 1MB) } else { 0 }
        Accelerazione= $accel      # $null = mai impostata, quindi accesa di default
        CacheMb      = [math]::Round($cacheMb, 1)
        InEsecuzione = ($proc.Count -gt 0)
    }
}

# Scrittura del settings.json: si rilegge, si cambia la sola chiave e si
# riscrive. Discord riscrive il file quando esce, quindi va chiuso prima,
# esattamente come per i file di configurazione dei giochi.
function Set-VtDiscordAccelerazione([bool] $attiva) {
    $s = Get-VtDiscordSettings
    if (-not $s) { throw 'Discord non risulta installato (settings.json non trovato).' }
    if (Test-VtDiscordRunning) { throw 'Discord e'' aperto. Chiudilo del tutto (anche dall''icona vicino all''orologio): quando esce riscrive il file e cancellerebbe la modifica.' }

    Backup-VtGameFile $s | Out-Null
    $j = Get-Content -LiteralPath $s -Raw | ConvertFrom-Json
    if ($null -eq $j.enableHardwareAcceleration) {
        $j | Add-Member -NotePropertyName 'enableHardwareAcceleration' -NotePropertyValue $attiva -Force
    } else {
        $j.enableHardwareAcceleration = $attiva
    }
    # Depth 10: senza, gli oggetti annidati come WINDOW_BOUNDS verrebbero
    # troncati in una stringa e Discord si ritroverebbe la finestra sballata.
    $j | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $s -Encoding UTF8
    Write-VtLog "Discord: accelerazione hardware = $attiva" ok
}

# ---------------------------------------------------------------------------
# PULIZIA DEI FILE
#
# Mettiamo in chiaro una cosa, perche' e' il campo dove si raccontano piu'
# bugie: svuotare cartelle NON rende un PC piu' veloce. Serve a recuperare
# spazio. La velocita' cambia solo quando il disco e' quasi pieno (sotto il
# 10% Windows non riesce piu' a espandere il file di paging e butta via la
# cache delle shader), e quel caso lo segnala gia' la pagina Diagnosi.
#
# Per questo qui NON troverai:
#   - Prefetch: cancellarlo rallenta gli avvii finche' non si ricostruisce.
#     E' il "tweak" piu' diffuso e piu' controproducente che esista.
#   - il file di paging e i punti di ripristino: sono reti di sicurezza.
#   - le cartelle personali (Download, Documenti): non sono spazzatura.
#   - le cache dei browser: sono dati tuoi, e svuotarle rallenta la
#     navigazione per giorni.
# ---------------------------------------------------------------------------
$script:VtPulizia = @(
    @{
        Id='temp-utente'; Nome='File temporanei del tuo utente'; Rischio='sicuro'; Admin=$false
        Desc='La cartella dove i programmi buttano i file di lavoro'
        Perche='Ci finiscono installer scompattati, aggiornamenti a meta'' e file che i programmi si dimenticano di cancellare. Nessuno li rilegge mai.'
        Percorsi=@($env:TEMP)
    }
    @{
        Id='temp-windows'; Nome='File temporanei di Windows'; Rischio='sicuro'; Admin=$true
        Desc='La cartella temporanea di sistema'
        Perche='Stessa cosa della precedente, ma lato sistema. Serve l''amministratore.'
        Percorsi=@("$env:SystemRoot\Temp")
    }
    @{
        Id='cache-update'; Nome='Cache di Windows Update'; Rischio='sicuro'; Admin=$true
        Desc='I pacchetti degli aggiornamenti gia'' installati'
        Perche='Windows tiene i file scaricati anche dopo aver installato l''aggiornamento. Si ricreano da soli al prossimo aggiornamento, non si rompe niente.'
        Percorsi=@("$env:SystemRoot\SoftwareDistribution\Download")
    }
    @{
        Id='log-cbs'; Nome='Log di manutenzione di Windows'; Rischio='sicuro'; Admin=$true
        Desc='I registri del servizio componenti (CBS)'
        Perche='Crescono all''infinito e li legge solo chi diagnostica problemi di aggiornamento.'
        Percorsi=@("$env:SystemRoot\Logs\CBS")
    }
    @{
        Id='errori'; Nome='Segnalazioni errori e crash dump'; Rischio='sicuro'; Admin=$false
        Desc='I rapporti che Windows prepara quando un programma va in crash'
        Perche='Servono a Microsoft, non a te. Si ricreano al prossimo crash.'
        Percorsi=@("$env:ProgramData\Microsoft\Windows\WER\ReportQueue",
                   "$env:ProgramData\Microsoft\Windows\WER\ReportArchive",
                   "$env:LOCALAPPDATA\CrashDumps")
    }
    @{
        Id='miniature'; Nome='Cache delle miniature'; Rischio='sicuro'; Admin=$false
        Desc='Le anteprime che Esplora risorse tiene da parte'
        Perche='Si ricostruisce da sola quando riapri le cartelle. L''unico effetto e'' che la prima apertura di una cartella con tante foto e'' un attimo piu'' lenta.'
        Percorsi=@("$env:LOCALAPPDATA\Microsoft\Windows\Explorer")
        Filtro='thumbcache_*.db', 'iconcache_*.db'
    }
    @{
        Id='cestino'; Nome='Cestino'; Rischio='sicuro'; Admin=$false; Kind='Cestino'
        Desc='Svuota il cestino di tutti i dischi'
        Perche='Finche'' sono nel cestino, i file occupano ancora spazio.'
        Warn='Dopo non si recuperano piu''. Controlla di non averci lasciato dentro qualcosa.'
    }
    @{
        Id='bak-tweaker'; Nome='Vecchi backup lasciati dai tweaker'; Rischio='sicuro'; Admin=$false
        Desc='Le copie .bak dei file di configurazione dei giochi'
        Perche='SapoTweak e altri programmi ne lasciano una a ogni modifica, senza mai ripulirle. VejaTweak ne tiene solo le cinque piu'' recenti: questa voce toglie tutte le altre.'
        Percorsi=@("$env:LOCALAPPDATA\FortniteGame\Saved\Config\WindowsClient")
        Filtro='*.bak'
        TieniRecenti=5
    }
    @{
        Id='cache-discord'; Nome='Cache di Discord'; Rischio='sicuro'; Admin=$false
        Desc='Le cache del browser interno di Discord'
        Perche='Discord e'' Chromium travestito e accumula centinaia di megabyte di cache che non ripulisce mai. Si ricostruisce da sola, l''unico effetto e'' che il primo avvio dopo la pulizia e'' un attimo piu'' lento.'
        Warn='Chiudi Discord prima, altrimenti i file sono in uso e ne resta indietro la maggior parte.'
        Percorsi=@("$env:APPDATA\discord\Cache",
                   "$env:APPDATA\discord\Code Cache",
                   "$env:APPDATA\discord\GPUCache",
                   "$env:APPDATA\discord\DawnGraphiteCache",
                   "$env:APPDATA\discord\DawnWebGPUCache")
    }
    @{
        Id='log-nvidia'; Nome='Log e cache dell''app NVIDIA'; Rischio='sicuro'; Admin=$false
        Desc='I registri di debug e la cache del browser interno dell''app NVIDIA'
        Perche='L''app NVIDIA e'' fatta con un browser incorporato e lascia log da megabyte e una cache che non ripulisce mai. Non servono a niente se non a chi sviluppa l''app.'
        Percorsi=@("$env:LOCALAPPDATA\NVIDIA Corporation\NVIDIA app\CefCache",
                   "$env:LOCALAPPDATA\NVIDIA Corporation\NVIDIA App\CefCache")
        # Nella cartella dell'app si tolgono SOLO i log: accanto ci sono file
        # di configurazione che devono restare.
        Mirati=@(
            @{ Path="$env:LOCALAPPDATA\NVIDIA Corporation\NVIDIA app"; Filtro=@('*.log', '*.bak') }
        )
    }
    @{
        Id='shader'; Nome='Cache delle shader'; Rischio='medio'; Admin=$false
        Desc='Le shader gia'' compilate da driver e giochi'
        Perche='E'' quasi sempre la voce piu'' grossa del PC, ma NON e'' spazzatura: sono i calcoli che il driver ha gia'' fatto per non rifarli a ogni partita.'
        Warn='Cancellandola i giochi devono ricompilare tutto: per i primi minuti avrai STUTTER, che e'' l''opposto di quello che vuoi. Fallo solo se hai artefatti o scatti strani DOPO un aggiornamento del driver, oppure se ti serve davvero lo spazio.'
        Percorsi=@("$env:LOCALAPPDATA\D3DSCache",
                   "$env:LOCALAPPDATA\NVIDIA\DXCache",
                   "$env:LOCALAPPDATA\NVIDIA\GLCache",
                   "$env:LOCALAPPDATA\AMD\DxCache",
                   "$env:LOCALAPPDATA\AMD\GLCache")
    }
)

function Measure-VtPulizia($voce) {
    $mb = 0.0; $n = 0; $negato = $false

    if ($voce.Kind -eq 'Cestino') {
        try {
            $sh = New-Object -ComObject Shell.Application
            foreach ($i in $sh.Namespace(10).Items()) { $mb += $i.Size / 1MB; $n++ }
        } catch { $negato = $true }
        return [pscustomobject]@{ Mb = [math]::Round($mb, 1); File = $n; Negato = $negato }
    }

    foreach ($p in $voce.Percorsi) {
        # Test-Path stesso puo' sollevare "accesso negato" su cartelle di
        # sistema quando non siamo amministratori: va protetto anche lui.
        try { if (-not (Test-Path -LiteralPath $p -ErrorAction Stop)) { continue } }
        catch { $negato = $true; continue }

        try {
            $file = if ($voce.Filtro) {
                        foreach ($f in $voce.Filtro) { Get-ChildItem -LiteralPath $p -Filter $f -File -Force -ErrorAction SilentlyContinue }
                    } else {
                        Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue
                    }
            $file = @($file)
            if ($voce.TieniRecenti) {
                $file = @($file | Sort-Object LastWriteTime -Descending | Select-Object -Skip $voce.TieniRecenti)
            }
            $m = $file | Measure-Object Length -Sum
            $mb += $m.Sum / 1MB
            $n  += $m.Count
        } catch { $negato = $true }
    }

    # Percorsi in cui si tocca solo cio' che corrisponde al filtro, perche'
    # accanto ci sono file che devono restare.
    foreach ($t in @($voce.Mirati)) {
        if (-not $t) { continue }
        try { if (-not (Test-Path -LiteralPath $t.Path -ErrorAction Stop)) { continue } } catch { $negato = $true; continue }
        foreach ($f in $t.Filtro) {
            $x = @(Get-ChildItem -LiteralPath $t.Path -Filter $f -File -Force -ErrorAction SilentlyContinue)
            $m = $x | Measure-Object Length -Sum
            $mb += $m.Sum / 1MB
            $n  += $m.Count
        }
    }

    [pscustomobject]@{ Mb = [math]::Round($mb, 1); File = $n; Negato = $negato }
}

function Invoke-VtPulizia($voce) {
    $prima = Measure-VtPulizia $voce
    $errori = 0

    if ($voce.Kind -eq 'Cestino') {
        try { Clear-RecycleBin -Force -ErrorAction Stop } catch { $errori++ }
        Write-VtLog "Pulizia '$($voce.Id)': cestino svuotato" ok
        return [pscustomobject]@{ Mb = $prima.Mb; File = $prima.File; Errori = $errori }
    }

    foreach ($p in $voce.Percorsi) {
        try { if (-not (Test-Path -LiteralPath $p -ErrorAction Stop)) { continue } } catch { $errori++; continue }

        $file = if ($voce.Filtro) {
                    foreach ($f in $voce.Filtro) { Get-ChildItem -LiteralPath $p -Filter $f -File -Force -ErrorAction SilentlyContinue }
                } else {
                    Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue
                }
        $file = @($file)
        if ($voce.TieniRecenti) {
            $file = @($file | Sort-Object LastWriteTime -Descending | Select-Object -Skip $voce.TieniRecenti)
        }

        foreach ($f in $file) {
            # I file in uso non si cancellano: e' normale e non e' un errore
            # da mostrare in rosso, quindi li contiamo e basta.
            try { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop } catch { $errori++ }
        }

        # Le cartelle rimaste vuote se ne vanno, ma la cartella di partenza
        # resta: cancellare %TEMP% o Windows\Temp romperebbe dei programmi.
        if (-not $voce.Filtro) {
            try {
                Get-ChildItem -LiteralPath $p -Recurse -Directory -Force -ErrorAction SilentlyContinue |
                    Sort-Object { $_.FullName.Length } -Descending |
                    ForEach-Object {
                        if (-not (Get-ChildItem -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue)) {
                            Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
                        }
                    }
            } catch { }
        }
    }

    foreach ($t in @($voce.Mirati)) {
        if (-not $t) { continue }
        try { if (-not (Test-Path -LiteralPath $t.Path -ErrorAction Stop)) { continue } } catch { $errori++; continue }
        foreach ($f in $t.Filtro) {
            foreach ($x in @(Get-ChildItem -LiteralPath $t.Path -Filter $f -File -Force -ErrorAction SilentlyContinue)) {
                try { Remove-Item -LiteralPath $x.FullName -Force -ErrorAction Stop } catch { $errori++ }
            }
        }
    }

    $dopo = Measure-VtPulizia $voce
    $liberati = [math]::Round($prima.Mb - $dopo.Mb, 1)
    Write-VtLog "Pulizia '$($voce.Id)': liberati $liberati MB ($($errori) file in uso saltati)" ok
    [pscustomobject]@{ Mb = $liberati; File = $prima.File - $dopo.File; Errori = $errori }
}

# Compattazione dell'archivio componenti: e' l'unica pulizia che libera
# davvero parecchi GB su un Windows vecchio di qualche anno, ma va fatta con
# lo strumento di Microsoft e ci mette qualche minuto.
function Invoke-VtDism {
    if (-not (Test-VtAdmin)) { throw 'Servono i privilegi di amministratore.' }
    Write-VtLog 'Compattazione archivio componenti (DISM) avviata' ok
    $out = Invoke-VtCmd 'DISM /Online /Cleanup-Image /StartComponentCleanup'
    if ($out -match '100' -or $out -match 'complet') { return 'Compattazione completata.' }
    return 'Compattazione terminata. Riavvia per completare.'
}

# ---------------------------------------------------------------------------
# SALUTE DEL PC
#
# Nessun interruttore risolve un driver video che va in crash o una RAM
# instabile. Questi sono i sintomi che Windows registra da solo e che nessuno
# va mai a leggere.
#
# Regola imparata a mie spese scrivendo questa parte: NON si filtra per solo
# ID evento. Gli ID 17, 18 e 19 su questo PC arrivano da Windows Update, dal
# TPM e dal Bluetooth, non da errori hardware; l'ID 153 era "VBS disabilitata"
# e non un errore disco. Filtrare per solo ID avrebbe prodotto un allarme
# completamente falso. Si filtra sempre per provider PIU' id.
# ---------------------------------------------------------------------------
function Get-VtEventi([int] $giorni = 30) {
    $da = (Get-Date).AddDays(-$giorni)
    $prov = @('Microsoft-Windows-WHEA-Logger', 'Display', 'Microsoft-Windows-Kernel-Power',
              'Microsoft-Windows-WER-SystemErrorReporting', 'disk', 'nvlddmkm', 'amdkmdap')

    # Get-WinEvent fallisce l'intera query se anche UNO dei provider elencati
    # non e' registrato: su un PC NVIDIA manca amdkmdap, su uno AMD manca
    # nvlddmkm. Senza questo filtro la pagina non funzionerebbe su nessuna
    # macchina. Costa una sessantina di millisecondi.
    try {
        $registrati = (Get-WinEvent -ListLog System -ErrorAction Stop).ProviderNames
        $prov = @($prov | Where-Object { $registrati -contains $_ })
    } catch { }
    if ($prov.Count -eq 0) { return $null }

    try {
        $ev = Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=$da; ProviderName=$prov } -ErrorAction Stop
    } catch {
        # Nessun evento nel periodo: e' un caso normale, non un errore.
        if ($_.Exception.Message -match 'No events|Nessun evento') {
            $ev = @()
        } else {
            Write-VtLog "Registro eventi non leggibile: $($_.Exception.Message)" warn
            return $null
        }
    }

    $tdr   = @($ev | Where-Object { $_.Id -eq 4101 -or ($_.ProviderName -match 'nvlddmkm|amdkmdap' -and $_.Level -le 2) })
    $whea  = @($ev | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-WHEA-Logger' -and $_.Level -le 3 })
    $spegn = @($ev | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $_.Id -eq 41 })
    $bsod  = @($ev | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-WER-SystemErrorReporting' -and $_.Id -eq 1001 })
    $disco = @($ev | Where-Object { $_.ProviderName -eq 'disk' -and $_.Id -in 7, 11, 51, 52, 153 })

    [pscustomobject]@{
        Giorni = $giorni
        Tdr = $tdr.Count; TdrUltimo = ($tdr | Select-Object -First 1).TimeCreated
        Whea = $whea.Count; WheaUltimo = ($whea | Select-Object -First 1).TimeCreated
        Spegnimenti = $spegn.Count; SpegnUltimo = ($spegn | Select-Object -First 1).TimeCreated
        Bsod = $bsod.Count; BsodUltimo = ($bsod | Select-Object -First 1).TimeCreated
        Disco = $disco.Count; DiscoUltimo = ($disco | Select-Object -First 1).TimeCreated
    }
}

function Get-VtEventiDiagnosi($e) {
    $out = @()
    if (-not $e) {
        $out += [pscustomobject]@{ Peso=3; Stato='NON LEGGIBILE'; Titolo='Registro eventi non accessibile'
            Testo='Serve avviare VejaTweak come amministratore per leggere il registro di sistema.' }
        return $out
    }
    if ($e.Whea -gt 0) {
        $out += [pscustomobject]@{ Peso=1; Stato='GRAVE'; Titolo="$($e.Whea) errori hardware (WHEA) in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.WheaUltimo). Sono errori segnalati dal processore o dal bus, non da Windows. Le cause tipiche sono un profilo XMP/EXPO instabile, un overclock troppo spinto o un alimentatore al limite.`n`nSe hai attivato XMP di recente e vedi questi errori, e' il primo posto dove guardare: prova il profilo XMP piu' lento, o rimettilo su Auto e verifica se spariscono." }
    }
    if ($e.Tdr -gt 0) {
        $out += [pscustomobject]@{ Peso=1; Stato='GRAVE'; Titolo="$($e.Tdr) crash del driver video in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.TdrUltimo). Sono i 'Display driver stopped responding': lo schermo si blocca un attimo e torna. In gioco si sentono come freeze secchi.`n`nCause tipiche in ordine: driver video da reinstallare pulito (con DDU), GPU in overclock o undervolt instabile, alimentatore che non regge i picchi, temperature alte." }
    }
    if ($e.Bsod -gt 0) {
        $out += [pscustomobject]@{ Peso=1; Stato='GRAVE'; Titolo="$($e.Bsod) schermate blu in $($e.Giorni) giorni"
            Testo="Ultima: $($e.BsodUltimo). Il codice di errore sta in Visualizzatore eventi > Sistema, evento 1001. Con schermate blu ricorrenti non ha senso ottimizzare: prima si trova la causa." }
    }
    if ($e.Spegnimenti -gt 0) {
        $out += [pscustomobject]@{ Peso=2; Stato='DA GUARDARE'; Titolo="$($e.Spegnimenti) spegnimenti anomali in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.SpegnUltimo). Il PC si e' spento senza chiudere Windows. Se non e' stato un blackout o il tasto tenuto premuto, guarda alimentatore e temperature: il riavvio improvviso sotto carico e' il sintomo classico di un alimentatore che non regge." }
    }
    if ($e.Disco -gt 0) {
        $out += [pscustomobject]@{ Peso=2; Stato='DA GUARDARE'; Titolo="$($e.Disco) errori di I/O sul disco in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.DiscoUltimo). Operazioni di lettura o scrittura ritentate. Su un disco che ospita i giochi si traduce in caricamenti lunghi e stutter da streaming texture. Controlla il cavo SATA o, su NVMe, le temperature." }
    }
    if ($out.Count -eq 0) {
        $out += [pscustomobject]@{ Peso=3; Stato='PULITO'; Titolo="Nessun problema hardware negli ultimi $($e.Giorni) giorni"
            Testo='Nessun crash del driver video, nessun errore hardware WHEA, nessuna schermata blu, nessuno spegnimento anomalo, nessun errore di I/O sui dischi. Se hai scatti, la causa non e'' hardware.' }
    }
    $out | Sort-Object Peso
}

# La risoluzione del timer si legge da ntdll: e' la prova che il tweak
# corrispondente ha davvero effetto, invece di doverci credere.
if (-not ('VejaTimer' -as [type])) {
    Add-Type -Namespace Veja -Name Timer -MemberDefinition @'
[DllImport("ntdll.dll", SetLastError=true)]
public static extern int NtQueryTimerResolution(out uint Max, out uint Min, out uint Current);
'@ -ErrorAction SilentlyContinue
}

function Get-VtTimerResolution {
    try {
        $mx = 0; $mn = 0; $cur = 0
        [Veja.Timer]::NtQueryTimerResolution([ref]$mx, [ref]$mn, [ref]$cur) | Out-Null
        [pscustomobject]@{
            Attuale = [math]::Round($cur / 10000, 3)
            Minima  = [math]::Round($mn / 10000, 3)
            Default = [math]::Round($mx / 10000, 3)
        }
    } catch { return $null }
}

# Un gioco su disco meccanico e' una causa di stutter che nessun tweak copre.
function Get-VtGiochiSuDisco {
    $out = @()
    $cache = @{}
    foreach ($g in (Find-VtGiochi)) {
        $L = (Split-Path $g.Path -Qualifier).TrimEnd(':')
        if (-not $cache.ContainsKey($L)) {
            $info = [pscustomobject]@{ Disco = 'non determinabile'; Tipo = 'ignoto' }
            try {
                $part = Get-Partition -DriveLetter $L -ErrorAction Stop
                $d = Get-PhysicalDisk -ErrorAction Stop | Where-Object { $_.DeviceId -eq $part.DiskNumber }
                if ($d) { $info = [pscustomobject]@{ Disco = $d.FriendlyName; Tipo = $(if ($d.MediaType) { "$($d.MediaType)" } else { 'ignoto' }) } }
            } catch { }
            $cache[$L] = $info
        }
        $out += [pscustomobject]@{ Nome = $g.Nome; Unita = "$L`:"; Disco = $cache[$L].Disco; Tipo = $cache[$L].Tipo }
    }
    $out
}

function Get-VtDischi {
    $out = @()
    try {
        foreach ($d in (Get-PhysicalDisk -ErrorAction Stop)) {
            $r = $d | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue
            $out += [pscustomobject]@{
                Nome   = $d.FriendlyName
                Tipo   = $(if ($d.MediaType) { "$($d.MediaType)" } else { 'ignoto' })
                Salute = "$($d.HealthStatus)"
                GB     = [math]::Round($d.Size / 1GB)
                Usura  = $r.Wear
                Temp   = $r.Temperature
                Bus    = "$($d.BusType)"
            }
        }
    } catch { }
    $out
}

# ---------------------------------------------------------------------------
# RIEPILOGO HARDWARE (pagina OC / Tuning)
# ---------------------------------------------------------------------------
function Get-VtVram {
    # Win32_VideoController.AdapterRAM e' un intero a 32 bit e sopra i 4 GB
    # restituisce numeri senza senso. Il valore vero sta nel registro.
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
    foreach ($i in 0..8) {
        $k = Join-Path $base ('{0:0000}' -f $i)
        $v = Get-VtReg $k 'HardwareInformation.qwMemorySize'
        if ($v) { return [math]::Round($v / 1GB, 1) }
    }
    return $null
}

# Da "32.0.16.1088" alla versione che NVIDIA usa nelle note di rilascio,
# "610.88": sono le ultime cinque cifre del numero completo.
function ConvertTo-VtDriverVersion([string] $ver) {
    $n = $ver -replace '\D', ''
    if ($n.Length -lt 5) { return $ver }
    $c = $n.Substring($n.Length - 5)
    return "$($c.Substring(0,3)).$($c.Substring(3,2))"
}

function Get-VtRiepilogo {
    $sys = Get-VtSystem
    $fw  = Get-VtFirmware
    $os  = Get-CimInstance Win32_OperatingSystem
    $ver = (Get-VtReg 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' 'DisplayVersion')

    $gpu = $sys.Gpu | Select-Object -First 1
    $vram = Get-VtVram
    $drv  = if ($gpu) { ConvertTo-VtDriverVersion $gpu.DriverVersion } else { '?' }

    $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)
    $marca = ($mods | Select-Object -First 1).Manufacturer
    $pn    = ($mods | Select-Object -First 1).PartNumber
    if ($pn) { $pn = $pn.Trim() }
    $mhz   = ($mods | Measure-Object ConfiguredClockSpeed -Maximum).Maximum
    $mhzMax= ($mods | Measure-Object Speed -Maximum).Maximum

    # Thread attesi: se i logici sono pari ai fisici su una CPU che l'SMT ce
    # l'ha, il processore non e' tutto disponibile.
    $smtSospetto = ($sys.Thread -eq $sys.Core -and $sys.Cpu -match 'Core.*i[579]|Ryzen [579]|Core.*Ultra')

    [pscustomobject]@{
        Cpu        = $sys.Cpu
        CpuDett    = "$($sys.Core) core | $($sys.Thread) thread"
        CpuStato   = if ($smtSospetto) { 'SMT/Hyper-Threading disattivato' } else { 'CPU completa disponibile' }
        CpuStatoOk = (-not $smtSospetto)
        CpuThread  = "$($sys.Thread) thread pronti"
        Gpu        = if ($gpu) { $gpu.Name } else { 'non rilevata' }
        GpuDett    = "$(if ($vram) { "$vram GB VRAM" } else { 'VRAM ignota' }) | Driver $drv"
        Vram       = $vram
        Vendor     = $sys.Vendor
        Ram        = "$($mods.Count) moduli | $($sys.RamGB) GB$(if ($marca) { " | $marca" })$(if ($pn) { " $pn" })"
        RamDett    = "$($mods.Count) moduli attivi | $mhz MHz"
        RamOk      = (-not ($mhz -and $mhzMax -and $mhz -lt ($mhzMax - 100)))
        RamMhz     = $mhz
        RamMhzMax  = $mhzMax
        Scheda     = "$($fw.Produttore) $($fw.Scheda)"
        SchedaDett = "BIOS $($fw.Versione)"
        Sistema    = "$($os.Caption)$(if ($ver) { " - $ver" }) - build $($os.BuildNumber) - $($os.OSArchitecture)"
        Portatile  = $sys.Portatile
        Disco      = $sys.DiscoSys
    }
}

# ---------------------------------------------------------------------------
# PROFILI AUTOMATICI
#
# Non sono tweak nuovi: sono elenchi di voci gia' presenti nel catalogo,
# applicate in blocco. Cosi' non esiste un "profilo" che fa qualcosa che non
# puoi vedere e disattivare a mano dalla sua sezione.
# ---------------------------------------------------------------------------
$script:VtProfili = @(
    @{
        Id = 'base'; Nome = 'Base Gaming'; Etichetta = 'BASE'
        Sommario = 'Parti da qui se vuoi alleggerire il PC senza cambiare abitudini o toccare servizi importanti.'
        Desc = 'Pulizia leggera: niente registrazione in background, niente distrazioni, mouse e tastiera che non ti remano contro.'
        Punti = @(
            'Spegne cattura video, overlay e app in background',
            'Toglie accelerazione mouse e filtri di accessibilita'' che scartano input',
            'Non tocca servizi, rete, energia o niente che richieda riavvio'
        )
        Ids = @('gamedvr', 'gamemode', 'gamebar-panel', 'bg-apps',
                'mouse-accel', 'mouse-1to1', 'mouse-trails',
                'tasti-accessibilita', 'tastiera-ripetizione',
                'trasparenze', 'animazioni')
    }
    @{
        Id = 'competitive'; Nome = 'Competitive Gaming'; Etichetta = 'COMPETITIVE'; Consigliato = $true
        Sommario = 'La scelta giusta per Fortnite, Valorant, FiveM e R6 se vuoi un PC piu'' pulito ogni volta che accendi.'
        Desc = 'Aggiunge scheduler, energia, rete e GPU. E'' il profilo che consiglio: tutto quello che c''e'' dentro ha un effetto misurabile e nessun compromesso di comodita''.'
        Punti = @(
            'Tutto il profilo Base',
            'Scheduler, priorita'' di gioco e profilo multimediale',
            'Energia al massimo, niente parcheggio core, USB e PCIe sempre svegli',
            'HAGS, giochi sulla GPU dedicata, Nagle disattivato',
            'Telemetria e attivita'' pianificate inutili spente'
        )
        Ids = @('gamedvr', 'gamemode', 'gamebar-panel', 'bg-apps',
                'mouse-accel', 'mouse-1to1', 'mouse-trails',
                'tasti-accessibilita', 'tastiera-ripetizione',
                'trasparenze', 'animazioni',
                'mmcss-risposta', 'net-throttling', 'priorita-primo-piano', 'profilo-giochi',
                'hags', 'gpu-preferenza-giochi',
                'piano-energia', 'core-parking', 'usb-suspend', 'pcie-aspm',
                'avvio-rapido', 'kernel-in-ram', 'ntfs-lastaccess',
                'nagle', 'svc-telemetria', 'task-telemetria',
                'timer-resolution', 'power-throttling')
    }
    @{
        Id = 'massimo'; Nome = 'Maximum Gaming'; Etichetta = 'SPINTO'
        Sommario = 'Usalo solo se il PC e'' dedicato al gaming e hai gia'' provato Competitive.'
        Desc = 'Aggiunge le voci che hanno un prezzo: niente notifiche, piu'' servizi spenti, CPU sempre a frequenza piena. Ogni voce con un compromesso vero te la elenco prima di applicarla.'
        Punti = @(
            'Tutto il profilo Competitive',
            'Notifiche di Windows spente',
            'Servizi opzionali su Manuale (SuperFetch incluso, se hai un SSD)',
            'CPU sempre a frequenza piena: piu'' calore, meno ritardo di risalita'
        )
        Ids = @('gamedvr', 'gamemode', 'gamebar-panel', 'bg-apps', 'notifiche',
                'mouse-accel', 'mouse-1to1', 'mouse-trails',
                'tasti-accessibilita', 'tastiera-ripetizione',
                'trasparenze', 'animazioni',
                'mmcss-risposta', 'net-throttling', 'priorita-primo-piano', 'profilo-giochi',
                'hags', 'gpu-preferenza-giochi',
                'piano-energia', 'core-parking', 'usb-suspend', 'pcie-aspm', 'cpu-min-100',
                'avvio-rapido', 'kernel-in-ram', 'ntfs-lastaccess',
                'nagle', 'svc-telemetria', 'task-telemetria',
                'svc-superflui', 'svc-sysmain',
                'timer-resolution', 'power-throttling')
    }
)

# Solo le voci che esistono davvero su QUESTO PC: il catalogo si adatta
# (SuperFetch appare solo con un SSD, la frequenza minima solo su fisso...),
# quindi il conteggio mostrato e' quello vero, non una promessa.
function Get-VtProfiloTweaks([string] $id) {
    $p = $script:VtProfili | Where-Object { $_.Id -eq $id } | Select-Object -First 1
    if (-not $p) { return @() }
    $cat = Get-VtCatalog
    @($p.Ids | ForEach-Object { $x = $_; $cat | Where-Object { $_.Id -eq $x } })
}

function Get-VtProfiloDaFare([string] $id) {
    @(Get-VtProfiloTweaks $id | Where-Object { -not (Get-VtState $_) })
}

function Invoke-VtProfilo([string] $id) {
    $da = Get-VtProfiloDaFare $id
    $ok = 0; $ko = @(); $reboot = $false
    foreach ($t in $da) {
        if (Set-VtTweak $t $true) { $ok++; if ($t.Reboot) { $reboot = $true } }
        else { $ko += $t.Nome }
    }
    Write-VtLog "Profilo '$id': $ok applicati, $($ko.Count) falliti" ok
    [pscustomobject]@{ Applicati = $ok; Falliti = $ko; Riavvio = $reboot; Totale = $da.Count }
}

# ---------------------------------------------------------------------------
# PANNELLO DELLA SCHEDA VIDEO
#
# Chiariamo il limite come per il BIOS: le impostazioni 3D del pannello NVIDIA
# stanno in un database binario (nvdrsdb0.bin) che si scrive solo con NVAPI,
# una libreria nativa. Farlo alla cieca da PowerShell significa rischiare di
# corrompere i profili del driver. Su AMD e' lo stesso con il suo database.
# Quindi qui: apriamo il pannello con un clic e diciamo esattamente cosa
# mettere, voce per voce, come nella pagina del BIOS.
# ---------------------------------------------------------------------------
function Get-VtGpuVendor {
    $v = (Get-VtSystem).Vendor
    if ($v -match 'NVIDIA') { return 'NVIDIA' }
    if ($v -match 'AMD|Radeon|ATI') { return 'AMD' }
    if ($v -match 'Intel') { return 'Intel' }
    return 'sconosciuto'
}

# Trova come si apre il pannello su questo PC: negli ultimi driver e' una app
# del Microsoft Store, prima era un exe classico.
function Get-VtPannelloGpu {
    $vend = Get-VtGpuVendor

    if ($vend -eq 'NVIDIA') {
        try {
            $pkg = Get-AppxPackage | Where-Object { $_.Name -eq 'NVIDIACorp.NVIDIAControlPanel' } | Select-Object -First 1
            if ($pkg) {
                return [pscustomobject]@{ Tipo='appx'; Target="shell:AppsFolder\$($pkg.PackageFamilyName)!NVIDIACorp.NVIDIAControlPanel"; Nome='Pannello di controllo NVIDIA' }
            }
        } catch { }
        foreach ($p in @("$env:ProgramFiles\NVIDIA Corporation\Control Panel Client\nvcplui.exe",
                         "${env:ProgramFiles(x86)}\NVIDIA Corporation\Control Panel Client\nvcplui.exe")) {
            if (Test-Path $p) { return [pscustomobject]@{ Tipo='exe'; Target=$p; Nome='Pannello di controllo NVIDIA' } }
        }
        $app = "$env:ProgramFiles\NVIDIA Corporation\NVIDIA app\CEF\NVIDIA app.exe"
        if (Test-Path $app) { return [pscustomobject]@{ Tipo='exe'; Target=$app; Nome='NVIDIA app' } }
    }

    if ($vend -eq 'AMD') {
        foreach ($p in @("$env:ProgramFiles\AMD\CNext\CNext\RadeonSoftware.exe",
                         "$env:ProgramFiles\AMD\CNext\CNext\cncmd.exe",
                         "${env:ProgramFiles(x86)}\AMD\CNext\CNext\RadeonSoftware.exe")) {
            if (Test-Path $p) { return [pscustomobject]@{ Tipo='exe'; Target=$p; Nome='AMD Software: Adrenalin Edition' } }
        }
        try {
            $pkg = Get-AppxPackage | Where-Object { $_.Name -match 'AMDRadeonSoftware|AdvancedMicroDevicesInc' } | Select-Object -First 1
            if ($pkg) { return [pscustomobject]@{ Tipo='appx'; Target="shell:AppsFolder\$($pkg.PackageFamilyName)!App"; Nome='AMD Software' } }
        } catch { }
    }
    return $null
}

function Open-VtPannelloGpu {
    $p = Get-VtPannelloGpu
    if (-not $p) { throw 'Pannello della scheda video non trovato su questo PC.' }
    if ($p.Tipo -eq 'appx') { Start-Process 'explorer.exe' -ArgumentList $p.Target }
    else { Start-Process $p.Target }
    Write-VtLog "Aperto: $($p.Nome)" ok
}

# Impostazioni 3D, in ordine di quanto contano davvero.
function Get-VtGuidaNvidia {
    @(
        @{ Voce='Modalita'' a bassa latenza'; Valore='Ultra'
           Perche='Tiene la coda di rendering della CPU corta: e'' la voce che si sente di piu'' sul ritardo fra mouse e schermo. Se il gioco ha NVIDIA Reflex (Fortnite, Valorant, R6 ce l''hanno) usa Reflex nel gioco e lascia questa su "On": Reflex fa lo stesso lavoro meglio, dall''interno del motore.' }
        @{ Voce='Modalita'' gestione alimentazione'; Valore='Preferisci prestazioni massime'
           Perche='Senza questa la GPU abbassa le frequenze fra un picco e l''altro e le rialza con un attimo di ritardo. Nei giochi competitivi, dove il carico e'' irregolare, quel ritardo cade dentro il frame.' }
        @{ Voce='Sincronizzazione verticale'; Valore='Off'
           Perche='Il V-Sync fa aspettare la GPU: aggiunge fino a un frame intero di ritardo. Va spento qui E dentro ogni gioco, perche'' vince l''impostazione piu'' restrittiva.' }
        @{ Voce='Frame rate massimo'; Valore='Off (o il refresh del monitor)'
           Perche='Se non usi G-Sync lascialo libero. Se usi G-Sync, mettilo 3 FPS sotto il refresh: cosi'' resti dentro la finestra adattiva senza mai toccare il tetto del V-Sync.' }
        @{ Voce='Qualita'' filtraggio texture'; Valore='Prestazioni elevate'
           Perche='Qualche punto percentuale gratis. La differenza visiva in movimento e'' praticamente invisibile a 200 Hz.' }
        @{ Voce='Ottimizzazione threaded'; Valore='On'
           Perche='Lascia che il driver distribuisca il lavoro su piu'' core. Su una CPU con 6 o piu'' core e'' sempre un guadagno.' }
        @{ Voce='Cache shader'; Valore='10 GB o Illimitata'
           Perche='Le shader gia'' compilate non vengono ricompilate a ogni partita: e'' la causa piu'' comune degli stutter nei primi minuti di gioco.' }
        @{ Voce='Modalita'' a schermo intero'; Valore='Preferisci sovrapposizione ottimizzata (se presente)'
           Perche='Nei driver recenti sostituisce la vecchia catena esclusiva mantenendo la stessa latenza.' }
    )
}

function Get-VtGuidaColoriNvidia {
    @(
        @{ Voce='Vividezza digitale'; Valore='60-70%'
           Perche='E'' il vero motivo per cui i giocatori entrano in questo menu. Satura i colori e stacca i modelli dei nemici dallo sfondo, soprattutto sul grigio di Valorant e sul verde di Fortnite. Sopra 80 i colori si impastano e le skin chiare diventano una macchia: 60-70 e'' il punto dove guadagni leggibilita'' senza perdere dettaglio.' }
        @{ Voce='Contrasto'; Valore='52-55%'
           Perche='Un filo sopra il neutro aiuta a distinguere le sagome nelle zone in ombra. Alzarlo troppo chiude le ombre e li nasconde del tutto.' }
        @{ Voce='Gamma'; Valore='1.00 (alza a 1.05 solo se le mappe scure ti danno fastidio)'
           Perche='La gamma alta schiarisce tutto e appiattisce l''immagine: si vede peggio, non meglio.' }
        @{ Voce='Formato colore output'; Valore='RGB'
           Perche='Se il monitor e'' collegato in HDMI, Windows a volte sceglie YCbCr 4:2:2, che sottocampiona il colore e rende il testo e i bordi sfocati. RGB e'' pieno.' }
        @{ Voce='Intervallo dinamico output'; Valore='Completo'
           Perche='"Limitato" (16-235) schiaccia neri e bianchi: perdi proprio il dettaglio nelle zone scure dove si nascondono i nemici.' }
        @{ Voce='Profondita'' colore output'; Valore='8 bpc (10 solo con HDR)'
           Perche='A 8 bit puoi tenere il refresh piu'' alto su cavi DisplayPort al limite di banda. Su un 200 Hz conta.' }
    )
}

function Get-VtGuidaAmd {
    @(
        @{ Voce='Radeon Anti-Lag (o Anti-Lag 2)'; Valore='Attivato'
           Perche='L''equivalente della bassa latenza NVIDIA: accorcia la coda di frame fra CPU e GPU. E'' la voce che conta di piu'' sulla reattivita''.' }
        @{ Voce='Attesa sincronizzazione verticale'; Valore='Sempre disattivato'
           Perche='Come su NVIDIA: il V-Sync costa fino a un frame intero di ritardo.' }
        @{ Voce='Radeon Chill'; Valore='Disattivato'
           Perche='Chill abbassa gli FPS quando ti muovi poco per risparmiare energia. In un gioco competitivo significa frame rate che balla proprio mentre stai fermo a mirare.' }
        @{ Voce='Radeon Boost'; Valore='Disattivato'
           Perche='Abbassa la risoluzione durante i movimenti rapidi. Rende sfocato proprio il momento in cui devi vedere meglio.' }
        @{ Voce='Modalita'' filtro texture'; Valore='Prestazioni'
           Perche='Stesso ragionamento del filtraggio texture NVIDIA: guadagno gratis, differenza invisibile in movimento.' }
        @{ Voce='Modalita'' tassellazione'; Valore='Sostituisci impostazioni applicazione, massimo 8x'
           Perche='Alcuni motori chiedono livelli di tassellazione altissimi che non si vedono. Limitarli a 8x e'' il classico guadagno gratuito su Radeon.' }
        @{ Voce='Cache shader'; Valore='AMD ottimizzata'
           Perche='Evita la ricompilazione delle shader a ogni avvio: meno stutter nei primi minuti.' }
        @{ Voce='Frame rate massimo (FRTC)'; Valore='Off, oppure refresh meno 3 con FreeSync'
           Perche='Stessa logica di G-Sync: restare dentro la finestra adattiva senza toccare il tetto.' }
        @{ Voce='Anti-Aliasing morfologico (MLAA)'; Valore='Disattivato'
           Perche='Sfoca l''immagine a costo di prestazioni, e i giochi hanno gia'' il proprio anti-aliasing.' }
    )
}

function Get-VtGuidaColoriAmd {
    @(
        @{ Voce='Saturazione'; Valore='115-125 (su base 100)'
           Perche='L''equivalente AMD della vividezza digitale: stacca i modelli dei nemici dallo sfondo. Oltre 130 i colori si impastano.' }
        @{ Voce='Contrasto'; Valore='102-105'
           Perche='Aiuta a leggere le sagome in ombra senza chiudere del tutto le zone scure.' }
        @{ Voce='Luminosita'''; Valore='0 (alza solo se le mappe scure ti danno fastidio)'
           Perche='Alzarla appiattisce l''immagine invece di rivelare dettaglio.' }
        @{ Voce='Formato colore pixel'; Valore='RGB 4:4:4 Pixel Format PC Standard (Full RGB)'
           Perche='In HDMI AMD a volte imposta YCbCr limitato: neri slavati e bordi sfocati. Questa e'' la voce che lo risolve.' }
        @{ Voce='Profondita'' colore'; Valore='8 bpc (10 solo con HDR)'
           Perche='Tiene la banda del cavo libera per il refresh alto.' }
    )
}

# ---------------------------------------------------------------------------
# Ripristino totale
# ---------------------------------------------------------------------------
function Reset-VtAll {
    $n = 0
    foreach ($t in (Get-VtCatalog)) {
        if (-not (Get-VtEntry $t.Id)) { continue }
        if (Set-VtTweak $t $false) { $n++ }
    }
    Write-VtLog "Ripristino completato: $n tweak riportati allo stato originale." ok
    return $n
}



