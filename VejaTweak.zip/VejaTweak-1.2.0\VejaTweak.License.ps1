<#
    VejaTweak - licenze.

    COSA PROTEGGE E COSA NO, detto chiaro:

    Questo file impedisce che qualcuno si FABBRICHI un codice valido. I codici
    sono firmati con ECDSA P-256: la chiave privata sta solo sul PC di chi
    distribuisce l'app (owner.key), l'app spedita ai clienti contiene soltanto
    la chiave pubblica, che serve a verificare ma non a firmare.

    NON impedisce a chi scarica l'app di aprire il .ps1 e togliere il
    controllo: e' uno script in chiaro. Per impedire quello servirebbe un
    eseguibile compilato e un server di attivazione, e anche allora sarebbe
    solo piu' difficile, non impossibile.

    In pratica: ferma la condivisione di codici inventati, non ferma chi
    sa leggere PowerShell.
#>

# Write-VtLog vive in VejaTweak.Core.ps1. Quando l'app parte li carica
# entrambi, ma gli script di servizio (CreaAggiornamento) caricano solo
# questo file: senza questa rete di sicurezza, il primo messaggio di log
# farebbe fallire tutto con "termine non riconosciuto".
if (-not (Get-Command Write-VtLog -ErrorAction SilentlyContinue)) {
    function Write-VtLog { param([string] $Msg, [string] $Level = 'info') Write-Verbose "[$Level] $Msg" }
}

$script:VtLicRoot   = $PSScriptRoot
$script:VtOwnerKey  = Join-Path $PSScriptRoot 'owner.key'
$script:VtPublicKey = Join-Path $PSScriptRoot 'public.key'
$script:VtLicFile   = Join-Path $PSScriptRoot 'attivazione.dat'
$script:VtLicReg    = 'HKCU:\Software\VejaTweak'

# ---------------------------------------------------------------------------
# Base32
#
# Alfabeto senza I, L, O e U: sono i caratteri che la gente sbaglia a
# ricopiare (I/1, O/0) o che formano parole sgradite. Cosi' un codice letto
# male non diventa un codice diverso ma valido: diventa invalido e basta.
# ---------------------------------------------------------------------------
$script:VtAlfabeto = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'

function ConvertTo-VtBase32([byte[]] $dati) {
    $sb = New-Object System.Text.StringBuilder
    $buffer = 0; $bit = 0
    foreach ($b in $dati) {
        $buffer = ($buffer -shl 8) -bor $b
        $bit += 8
        while ($bit -ge 5) {
            $bit -= 5
            [void] $sb.Append($script:VtAlfabeto[($buffer -shr $bit) -band 31])
        }
    }
    if ($bit -gt 0) {
        [void] $sb.Append($script:VtAlfabeto[($buffer -shl (5 - $bit)) -band 31])
    }
    $sb.ToString()
}

function ConvertFrom-VtBase32([string] $testo) {
    $t = ($testo -replace '[^0-9A-Za-z]', '').ToUpper()
    # Correzioni di cortesia per chi ricopia a mano.
    $t = $t.Replace('I', '1').Replace('L', '1').Replace('O', '0').Replace('U', 'V')
    $out = New-Object System.Collections.Generic.List[byte]
    $buffer = 0; $bit = 0
    foreach ($ch in $t.ToCharArray()) {
        $v = $script:VtAlfabeto.IndexOf($ch)
        if ($v -lt 0) { throw "Carattere non valido nel codice: '$ch'" }
        $buffer = ($buffer -shl 5) -bor $v
        $bit += 5
        if ($bit -ge 8) {
            $bit -= 8
            $out.Add([byte](($buffer -shr $bit) -band 255))
        }
    }
    return , $out.ToArray()
}

# ---------------------------------------------------------------------------
# Identificativo della macchina
#
# Deve restare uguale fra un avvio e l'altro e cambiare da PC a PC. Uso il
# MachineGuid di Windows (stabile finche' non si reinstalla) piu' il seriale
# della scheda madre. Non e' un dato personale: e' un hash, non torna
# indietro all'utente.
# ---------------------------------------------------------------------------
function Get-VtMachineId {
    if ($script:VtMid) { return $script:VtMid }
    $parti = @()
    try { $parti += (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid -ErrorAction Stop).MachineGuid } catch { }
    try { $parti += (Get-CimInstance Win32_BaseBoard -ErrorAction Stop).SerialNumber } catch { }
    try { $parti += (Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1).ProcessorId } catch { }
    if ($parti.Count -eq 0) { $parti += $env:COMPUTERNAME }

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $h = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(($parti -join '|')))
    } finally { $sha.Dispose() }
    # 10 byte = esattamente 16 caratteri base32, quattro gruppi da quattro.
    # Con 8 byte ne uscivano 13 e il raggruppamento andava in errore.
    $script:VtMidBytes = $h[0..9]
    $s = ConvertTo-VtBase32 $script:VtMidBytes
    $script:VtMid = (($s -split '(.{4})' | Where-Object { $_ }) -join '-')
    return $script:VtMid
}

function Get-VtMachineIdBytes {
    if (-not $script:VtMidBytes) { Get-VtMachineId | Out-Null }
    return , $script:VtMidBytes
}

# ---------------------------------------------------------------------------
# Chiavi
# ---------------------------------------------------------------------------
function Test-VtOwner { Test-Path -LiteralPath $script:VtOwnerKey }

# Crea la coppia di chiavi. Da lanciare UNA volta sola, e owner.key non va
# mai distribuito insieme all'app.
function New-VtOwnerKey([switch] $Forza) {
    if ((Test-Path $script:VtOwnerKey) -and -not $Forza) {
        throw 'owner.key esiste gia''. Rigenerarlo invaliderebbe tutti i codici gia'' dati ai clienti. Usa -Forza solo se sai cosa fai.'
    }
    $ec = [System.Security.Cryptography.ECDsaCng]::new(256)
    try {
        $priv = $ec.Key.Export([System.Security.Cryptography.CngKeyBlobFormat]::EccPrivateBlob)
        $pub  = $ec.Key.Export([System.Security.Cryptography.CngKeyBlobFormat]::EccPublicBlob)
        [IO.File]::WriteAllText($script:VtOwnerKey,  [Convert]::ToBase64String($priv))
        [IO.File]::WriteAllText($script:VtPublicKey, [Convert]::ToBase64String($pub))
    } finally { $ec.Dispose() }
    return [pscustomobject]@{ Privata = $script:VtOwnerKey; Pubblica = $script:VtPublicKey }
}

function Get-VtSigner {
    if (-not (Test-VtOwner)) { throw 'owner.key non trovato: solo chi distribuisce l''app puo'' generare codici.' }
    $blob = [Convert]::FromBase64String([IO.File]::ReadAllText($script:VtOwnerKey))
    $k = [System.Security.Cryptography.CngKey]::Import($blob, [System.Security.Cryptography.CngKeyBlobFormat]::EccPrivateBlob)
    [System.Security.Cryptography.ECDsaCng]::new($k)
}

function Get-VtVerifier {
    if (-not (Test-Path -LiteralPath $script:VtPublicKey)) { return $null }
    try {
        $blob = [Convert]::FromBase64String([IO.File]::ReadAllText($script:VtPublicKey))
        $k = [System.Security.Cryptography.CngKey]::Import($blob, [System.Security.Cryptography.CngKeyBlobFormat]::EccPublicBlob)
        return [System.Security.Cryptography.ECDsaCng]::new($k)
    } catch { return $null }
}

# ---------------------------------------------------------------------------
# Codici
#
# Struttura del carico utile, 14 byte:
#   0      versione
#   1      tipo: 0 = valido ovunque, 1 = legato a una macchina
#   2-5    numero di serie (uint32)
#   6-7    scadenza in giorni dal 2020-01-01 (0 = non scade)
#   8-13   primi 6 byte dell'id macchina (solo se tipo = 1)
# Poi 64 byte di firma ECDSA.
# ---------------------------------------------------------------------------
$script:VtEpoca = [datetime]'2020-01-01'

function New-VtCode {
    param(
        [uint32] $Serial = 0,
        [int]    $Giorni = 0,
        [string] $MacchinaId = ''
    )
    if ($Serial -eq 0) { $Serial = [uint32](Get-Random -Minimum 1 -Maximum 2147483647) }

    $tipo = 0
    $mid = New-Object byte[] 6
    if (-not [string]::IsNullOrWhiteSpace($MacchinaId)) {
        $b = ConvertFrom-VtBase32 $MacchinaId
        # Senza questo controllo un ID vuoto o troncato produrrebbe in
        # silenzio un codice valido ovunque, che e' il contrario di quello
        # che si voleva.
        if ($b.Length -lt 6) { throw 'ID macchina troppo corto: dev''essere quello mostrato dall''app del cliente (16 caratteri).' }
        [Array]::Copy($b, 0, $mid, 0, 6)
        $tipo = 1
    }

    $scad = 0
    if ($Giorni -gt 0) {
        $g = [int]((Get-Date).Date.AddDays($Giorni) - $script:VtEpoca).TotalDays
        if ($g -gt 65535) { throw 'Scadenza troppo lontana.' }
        $scad = $g
    }

    $payload = New-Object byte[] 14
    $payload[0] = 1
    $payload[1] = $tipo
    [Array]::Copy([BitConverter]::GetBytes($Serial), 0, $payload, 2, 4)
    [Array]::Copy([BitConverter]::GetBytes([uint16]$scad), 0, $payload, 6, 2)
    [Array]::Copy($mid, 0, $payload, 8, 6)

    $ec = Get-VtSigner
    try { $firma = $ec.SignData($payload) } finally { $ec.Dispose() }

    $tutto = New-Object byte[] ($payload.Length + $firma.Length)
    [Array]::Copy($payload, 0, $tutto, 0, $payload.Length)
    [Array]::Copy($firma, 0, $tutto, $payload.Length, $firma.Length)

    $b32 = ConvertTo-VtBase32 $tutto
    # Gruppi da 6 per rendere il codice leggibile e ricopiabile.
    $gruppi = ($b32 -split '(.{6})' | Where-Object { $_ })
    'VEJA-' + ($gruppi -join '-')
}

function Test-VtCode([string] $Codice) {
    $esito = [pscustomobject]@{ Valido=$false; Motivo=''; Serial=0; Scadenza=$null; Legato=$false }
    if (-not $Codice) { $esito.Motivo = 'Nessun codice inserito.'; return $esito }

    try { $dati = ConvertFrom-VtBase32 ($Codice -replace '^\s*VEJA', '') }
    catch { $esito.Motivo = $_.Exception.Message; return $esito }

    if ($dati.Length -lt 78) { $esito.Motivo = 'Codice incompleto: ne manca un pezzo.'; return $esito }

    $payload = $dati[0..13]
    $firma   = $dati[14..77]

    $ec = Get-VtVerifier
    if (-not $ec) { $esito.Motivo = 'File public.key mancante: l''installazione e'' incompleta.'; return $esito }
    try { $ok = $ec.VerifyData($payload, $firma) } catch { $ok = $false } finally { $ec.Dispose() }
    if (-not $ok) { $esito.Motivo = 'Codice non valido: la firma non corrisponde.'; return $esito }

    if ($payload[0] -ne 1) { $esito.Motivo = 'Versione del codice non supportata.'; return $esito }

    $esito.Serial = [BitConverter]::ToUInt32($payload, 2)
    $scad = [BitConverter]::ToUInt16($payload, 6)
    if ($scad -gt 0) {
        $data = $script:VtEpoca.AddDays($scad)
        $esito.Scadenza = $data
        if ((Get-Date).Date -gt $data) { $esito.Motivo = "Codice scaduto il $($data.ToString('dd/MM/yyyy'))."; return $esito }
    }

    if ($payload[1] -eq 1) {
        $esito.Legato = $true
        $mio = Get-VtMachineIdBytes
        for ($i = 0; $i -lt 6; $i++) {
            if ($payload[8 + $i] -ne $mio[$i]) {
                $esito.Motivo = 'Questo codice e'' stato emesso per un altro PC.'
                return $esito
            }
        }
    }

    $esito.Valido = $true
    $esito
}

# ---------------------------------------------------------------------------
# AGGIORNAMENTI
#
# Il problema di un aggiornamento automatico e' che il programma scarica del
# codice da internet e lo esegue: se qualcuno mette le mani sul sito da cui
# scarica, si ritrova a eseguire roba sua su tutti i PC dei clienti. E' il
# modo classico in cui un programma innocuo diventa un veicolo di malware.
#
# Qui il problema non si pone, perche' la chiave di firma ce l'abbiamo gia':
# il file che descrive l'aggiornamento (versione e impronta del pacchetto) e'
# firmato con la chiave privata, e l'app verifica quella firma PRIMA di
# scaricare qualunque cosa. Poi ricontrolla l'impronta SHA-256 del file
# scaricato. Chi non ha owner.key non puo' far accettare niente all'app,
# nemmeno controllando il sito.
#
# L'indirizzo si mette in aggiornamenti.url, accanto all'app.
# ---------------------------------------------------------------------------
function Get-VtUrlAggiornamenti {
    $f = Join-Path $script:VtLicRoot 'aggiornamenti.url'
    if (Test-Path -LiteralPath $f) {
        $u = ([IO.File]::ReadAllText($f)).Trim()
        if ($u) { return $u }
    }
    return $null
}

# Firma di "versione|impronta": e' tutto quello che serve legare insieme.
function New-VtManifestFirma([string] $versione, [string] $sha) {
    $ec = Get-VtSigner
    try { $f = $ec.SignData([Text.Encoding]::UTF8.GetBytes("$versione|$sha")) } finally { $ec.Dispose() }
    [Convert]::ToBase64String($f)
}

function Test-VtManifestFirma([string] $versione, [string] $sha, [string] $firma) {
    $ec = Get-VtVerifier
    if (-not $ec) { return $false }
    try { return $ec.VerifyData([Text.Encoding]::UTF8.GetBytes("$versione|$sha"), [Convert]::FromBase64String($firma)) }
    catch { return $false }
    finally { $ec.Dispose() }
}

# Confronto fra numeri di versione tipo 1.10.2: il confronto fra stringhe
# direbbe che 1.9.0 e' maggiore di 1.10.0, che e' sbagliato.
function Compare-VtVersione([string] $a, [string] $b) {
    try { return ([version]$a).CompareTo([version]$b) } catch { return 0 }
}

function Get-VtAggiornamento([string] $Url, [string] $VersioneAttuale) {
    $esito = [pscustomobject]@{ Disponibile=$false; Versione=$null; Note=''; Motivo=''; Url=$null; Sha=$null }
    if (-not $Url) { $esito.Motivo = 'Nessun indirizzo di aggiornamento configurato (manca aggiornamenti.url).'; return $esito }

    try {
        # file:// serve per collaudare in locale senza pubblicare niente.
        if ($Url -match '^file:') { $testo = [IO.File]::ReadAllText(([uri]$Url).LocalPath) }
        else {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $testo = (New-Object Net.WebClient).DownloadString($Url)
        }
        $m = $testo | ConvertFrom-Json
    } catch {
        $esito.Motivo = "Controllo non riuscito: $($_.Exception.Message)"
        return $esito
    }

    if (-not $m.versione -or -not $m.sha256 -or -not $m.firma -or -not $m.pacchetto) {
        $esito.Motivo = 'Il file di aggiornamento e'' incompleto.'; return $esito
    }
    if (-not (Test-VtManifestFirma $m.versione $m.sha256 $m.firma)) {
        $esito.Motivo = 'FIRMA NON VALIDA: questo aggiornamento non arriva da chi ha creato il programma. Ignorato.'
        Write-VtLog $esito.Motivo err
        return $esito
    }

    $esito.Versione = $m.versione
    $esito.Note     = "$($m.note)"
    $esito.Url      = $m.pacchetto
    $esito.Sha      = $m.sha256
    if ((Compare-VtVersione $m.versione $VersioneAttuale) -gt 0) {
        $esito.Disponibile = $true
        $esito.Motivo = "Disponibile la versione $($m.versione) (hai la $VersioneAttuale)."
    } else {
        $esito.Motivo = "Sei gia' aggiornato (versione $VersioneAttuale)."
    }
    return $esito
}

function Install-VtAggiornamento($info) {
    if (-not $info -or -not $info.Disponibile) { throw 'Nessun aggiornamento da installare.' }

    $tmp = Join-Path ([IO.Path]::GetTempPath()) ("vejaupd-" + [guid]::NewGuid().ToString('N').Substring(0, 8))
    New-Item -ItemType Directory -Path $tmp -Force | Out-Null
    $zip = Join-Path $tmp 'pacchetto.zip'
    try {
        if ($info.Url -match '^file:') { Copy-Item ([uri]$info.Url).LocalPath $zip -Force }
        else {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            (New-Object Net.WebClient).DownloadFile($info.Url, $zip)
        }

        # Seconda verifica: il file scaricato deve avere l'impronta indicata
        # nel manifest firmato. Senza questo controllo la firma proteggerebbe
        # solo il manifest, non il pacchetto vero.
        $sha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
        if ($sha -ne $info.Sha.ToUpper()) {
            throw "Il file scaricato non corrisponde all'impronta firmata. Aggiornamento annullato."
        }

        $estratto = Join-Path $tmp 'estratto'
        Expand-Archive -LiteralPath $zip -DestinationPath $estratto -Force

        # Non si sovrascrivono chiavi ne' dati locali: solo il programma.
        $intoccabili = 'owner.key', 'public.key', 'attivazione.dat', 'vejatweak-backup.json', 'vejatweak.log', 'aggiornamenti.url'
        $copiati = 0
        foreach ($f in (Get-ChildItem $estratto -Recurse -File)) {
            if ($intoccabili -contains $f.Name) { continue }
            Copy-Item $f.FullName (Join-Path $script:VtLicRoot $f.Name) -Force
            $copiati++
        }
        Write-VtLog "Aggiornamento alla versione $($info.Versione): $copiati file sostituiti" ok
        return $copiati
    }
    finally { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}

# ---------------------------------------------------------------------------
# Attivazione salvata
#
# Salvata in due posti (file accanto all'app e registro utente): se uno dei
# due sparisce l'altro regge. Il codice viene risalvato tale e quale, e alla
# riapertura viene rivalidato da capo: cosi' copiare il file di attivazione
# su un altro PC non funziona con i codici legati alla macchina.
# ---------------------------------------------------------------------------
function Save-VtAttivazione([string] $Codice) {
    try { [IO.File]::WriteAllText($script:VtLicFile, $Codice) } catch { }
    try {
        if (-not (Test-Path $script:VtLicReg)) { New-Item -Path $script:VtLicReg -Force | Out-Null }
        New-ItemProperty -Path $script:VtLicReg -Name 'Codice' -Value $Codice -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $script:VtLicReg -Name 'Attivato' -Value (Get-Date).ToString('s') -PropertyType String -Force | Out-Null
    } catch { }
}

function Get-VtAttivazioneSalvata {
    foreach ($src in @(
        { if (Test-Path -LiteralPath $script:VtLicFile) { [IO.File]::ReadAllText($script:VtLicFile) } },
        { (Get-ItemProperty $script:VtLicReg -Name 'Codice' -ErrorAction Stop).Codice }
    )) {
        try { $c = & $src; if ($c) { return $c.Trim() } } catch { }
    }
    return $null
}

function Clear-VtAttivazione {
    Remove-Item -LiteralPath $script:VtLicFile -Force -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $script:VtLicReg -Name 'Codice' -ErrorAction SilentlyContinue
}

# Verdetto complessivo all'avvio.
function Get-VtStatoLicenza {
    # Chi ha la chiave privata e' chi distribuisce l'app: niente codice.
    if (Test-VtOwner) {
        return [pscustomobject]@{ Attivo=$true; Owner=$true; Motivo='Chiave di firma presente: modalita'' autore.'; Scadenza=$null; Serial=0 }
    }
    $c = Get-VtAttivazioneSalvata
    if (-not $c) {
        return [pscustomobject]@{ Attivo=$false; Owner=$false; Motivo='Nessuna attivazione registrata.'; Scadenza=$null; Serial=0 }
    }
    $r = Test-VtCode $c
    [pscustomobject]@{ Attivo=$r.Valido; Owner=$false; Motivo=$r.Motivo; Scadenza=$r.Scadenza; Serial=$r.Serial }
}
