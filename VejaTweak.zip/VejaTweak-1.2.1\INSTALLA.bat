@echo off
setlocal EnableDelayedExpansion
title Installazione VejaTweak
color 0C

set "DEST=%LOCALAPPDATA%\VejaTweak"

echo.
echo   ==========================================
echo      V E J A T W E A K   -   installazione
echo   ==========================================
echo.
echo   VejaTweak verra' copiato in:
echo      %DEST%
echo.
echo   Verra' creato un collegamento sul desktop.
echo   Non viene installato nessun servizio e nessun driver.
echo.
pause

:: Se l'app e' gia' aperta i file sono in uso e la copia fallirebbe a meta'.
tasklist /fi "imagename eq powershell.exe" 2>nul | find /i "powershell.exe" >nul
if not errorlevel 1 (
  echo.
  echo   [!] Se VejaTweak e' gia' aperto, chiudilo prima di continuare.
  echo.
  pause
)

echo.
echo   Copia dei file in corso...
if not exist "%DEST%" mkdir "%DEST%" 2>nul
if not exist "%DEST%" (
  echo   [X] Impossibile creare la cartella. Installazione annullata.
  pause
  exit /b 1
)

:: /Y sovrascrive senza chiedere: serve per aggiornare una versione precedente.
copy /Y "%~dp0VejaTweak.ps1"        "%DEST%\" >nul || goto :errore
copy /Y "%~dp0VejaTweak.Core.ps1"   "%DEST%\" >nul || goto :errore
copy /Y "%~dp0VejaTweak.License.ps1" "%DEST%\" >nul || goto :errore
copy /Y "%~dp0VejaTweak.Theme.xaml" "%DEST%\" >nul || goto :errore
copy /Y "%~dp0VEJATWEAK.bat"        "%DEST%\" >nul || goto :errore
copy /Y "%~dp0public.key"           "%DEST%\" >nul || goto :errore
copy /Y "%~dp0logo.png"             "%DEST%\" >nul 2>nul
copy /Y "%~dp0logo.ico"             "%DEST%\" >nul 2>nul
:: Indirizzo per il controllo aggiornamenti: se non c'e', l'app funziona
:: comunque, semplicemente non cerca versioni nuove.
copy /Y "%~dp0aggiornamenti.url"    "%DEST%\" >nul 2>nul

echo   [OK] File copiati.

:: Il collegamento lo crea PowerShell: il .bat da solo non sa farlo.
echo   Creazione del collegamento sul desktop...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w=New-Object -ComObject WScript.Shell;" ^
  "$s=$w.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'VejaTweak.lnk'));" ^
  "$s.TargetPath='%DEST%\VEJATWEAK.bat';" ^
  "$s.WorkingDirectory='%DEST%';" ^
  "if (Test-Path '%DEST%\logo.ico') { $s.IconLocation='%DEST%\logo.ico,0' };" ^
  "$s.Description='VejaTweak - ottimizzazione PC per i giochi';" ^
  "$s.WindowStyle=7; $s.Save()"

if errorlevel 1 (
  echo   [!] Collegamento non creato. Puoi comunque avviare VEJATWEAK.bat da:
  echo       %DEST%
) else (
  echo   [OK] Collegamento creato sul desktop.
)

echo.
echo   ==========================================
echo    Fatto.
echo   ==========================================
echo.
echo   Avvia VejaTweak dall'icona sul desktop.
echo   Al primo avvio ti chiedera' un codice di attivazione:
echo   manda a chi ti ha dato il programma l'ID che vedi
echo   nella finestra, e ricevi il codice.
echo.
echo   Windows chiedera' i permessi di amministratore:
echo   servono per modificare le impostazioni di sistema.
echo.
pause
exit /b 0

:errore
echo.
echo   [X] Copia fallita: nel pacchetto manca un file.
echo       Riscarica l'archivio ed estrailo TUTTO prima di installare.
echo.
pause
exit /b 1
