@echo off
setlocal
title VejaTweak
cd /d "%~dp0"

:: VejaTweak tocca il registro di sistema e i servizi: senza elevazione meta'
:: degli interruttori fallirebbe. Chiediamo l'amministratore subito, cosi'
:: l'utente non se ne accorge a meta' strada.
net session >nul 2>&1
if %errorlevel%==0 goto :avvia

powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b 0

:avvia
start "" powershell -NoProfile -Sta -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0VejaTweak.ps1"
exit /b 0
