﻿<#
    VejaTweak - interfaccia grafica.

    Tutta la logica sta in VejaTweak.Core.ps1: qui c'e' solo la finestra.
    Ogni interruttore legge il proprio stato reale dal sistema all'apertura,
    quindi quello che vedi acceso e' acceso davvero, non e' una preferenza
    salvata da qualche parte.
#>
[CmdletBinding()]
param(
    # Costruisce la finestra e esce senza mostrarla: serve per il collaudo.
    [switch] $SmokeTest
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'VejaTweak.Core.ps1')
. (Join-Path $PSScriptRoot 'VejaTweak.License.ps1')

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

$script:Versione = '1.2.1'

# ---------------------------------------------------------------------------
# Tema
# ---------------------------------------------------------------------------
# Il tema sta in VejaTweak.Theme.xaml, accanto a questo file: cosi' si puo'
# ridisegnare l'interfaccia senza toccare una riga di logica.
$temaPath = Join-Path $PSScriptRoot 'VejaTweak.Theme.xaml'
if (-not (Test-Path $temaPath)) { throw "Tema non trovato: $temaPath" }
$xaml = Get-Content $temaPath -Raw

$reader = New-Object System.Xml.XmlNodeReader ([xml] $xaml)
$win    = [Windows.Markup.XamlReader]::Load($reader)

function Get-El([string] $n) { $win.FindName($n) }

$BarraGruppi = Get-El 'Gruppi'
$Sotto       = Get-El 'Sotto'
$Contenuto  = Get-El 'Contenuto'
$TxtTitolo  = Get-El 'TxtTitolo'
$TxtSub     = Get-El 'TxtSub'
$TxtSearch  = Get-El 'TxtSearch'
$PanelAdmin = Get-El 'PanelAdmin'
$BadgeAdmin = Get-El 'BadgeAdmin'
$TxtAdmin   = Get-El 'TxtAdmin'
(Get-El 'TxtVer').Text = $script:Versione

function New-Brush([string] $hex) {
    [Windows.Media.SolidColorBrush]::new([Windows.Media.ColorConverter]::ConvertFromString($hex))
}

# ---------------------------------------------------------------------------
# Logo
#
# Se accanto all'app c'e' un logo.png lo usiamo; altrimenti disegniamo una V
# vettoriale, cosi' la barra non resta vuota su un'installazione appena
# copiata. Per mettere il proprio logo: .\ImpostaLogo.ps1 -Immagine <file>
# ---------------------------------------------------------------------------
function Set-VtLogo {
    $box = Get-El 'Logo'
    if (-not $box) { return }
    $file = Join-Path $PSScriptRoot 'logo.png'

    if (Test-Path -LiteralPath $file) {
        try {
            $img = New-Object Windows.Controls.Image
            $bmp = New-Object Windows.Media.Imaging.BitmapImage
            $bmp.BeginInit()
            # OnLoad: legge il file e lo chiude subito, altrimenti il PNG
            # resta bloccato e ImpostaLogo.ps1 non potrebbe sovrascriverlo
            # con l'app aperta.
            $bmp.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.UriSource = New-Object Uri $file
            $bmp.EndInit()
            $img.Source = $bmp
            $img.Stretch = 'Uniform'
            [void] $box.Children.Add($img)
            Write-VtLog 'Logo personalizzato caricato da logo.png'
            return
        } catch {
            Write-VtLog "logo.png non leggibile, uso il segno di riserva: $($_.Exception.Message)" warn
        }
    }

    # Riserva vettoriale: una V spezzata, nello stesso rosso dell'accento.
    $path = New-Object Windows.Shapes.Path
    $path.Fill = New-Brush '#FF3B4E'
    $path.Stretch = 'Uniform'
    $path.Data = [Windows.Media.Geometry]::Parse(
        'M 10,8 L 30,8 L 48,62 L 66,8 L 88,8 L 58,92 L 38,92 Z M 74,4 L 96,2 L 62,30 Z')
    [void] $box.Children.Add($path)
}

# ---------------------------------------------------------------------------
# Sezioni
# ---------------------------------------------------------------------------
# Navigazione su due livelli: quattro gruppi in alto, le sezioni del gruppo
# scelto nella riga sotto. Con sedici sezioni una lista unica sarebbe una
# colonna infinita, e comunque la barra laterale la usano tutti.
$script:Gruppi = @('Auto', 'Sistema', 'Prestazioni', 'Giochi', 'Diagnosi')

# La scheda per generare i codici esiste solo dove c'e' la chiave privata,
# cioe' sul PC di chi distribuisce l'app. Sulle copie dei clienti non compare
# proprio, non e' solo disabilitata.
if (Test-VtOwner) { $script:Gruppi += 'Genera Code' }

$script:Sezioni = @(
    @{ Gruppo='Auto';        Cat='#octuning';               Menu='OC / Tuning';       Titolo='OC / Tuning';             Sub='Riepilogo dell''hardware e profili automatici: applicano in blocco le voci che trovi nelle altre sezioni' }
    @{ Gruppo='Auto';        Cat='#nvidia';                 Menu='NVIDIA';            Titolo='Pannello NVIDIA';         Sub='Impostazioni 3D e colore da mettere nel pannello, in ordine di importanza' }
    @{ Gruppo='Auto';        Cat='#amd';                    Menu='AMD';               Titolo='AMD Adrenalin';           Sub='Impostazioni 3D e colore da mettere in AMD Software, in ordine di importanza' }
    @{ Gruppo='Sistema';     Cat='Generali';                Menu='Generali';          Titolo='Ottimizzazioni generali'; Sub='Le voci di base: registrazione in background, modalita'' gioco, app che girano quando non le usi' }
    @{ Gruppo='Sistema';     Cat='Mouse e tastiera';        Menu='Mouse e tastiera';  Titolo='Mouse e tastiera';        Sub='Accelerazione, rapporto 1:1 e i filtri di accessibilita'' che scartano i tuoi input' }
    @{ Gruppo='Sistema';     Cat='Interfaccia';             Menu='Interfaccia';       Titolo='Interfaccia di Windows';  Sub='Effetti grafici del desktop che il compositor ricalcola mentre giochi' }
    @{ Gruppo='Sistema';     Cat='Servizi';                 Menu='Servizi';           Titolo='Servizi e attivita''';    Sub='Roba che gira in background e che mentre giochi non ti serve' }
    @{ Gruppo='Sistema';     Cat='#pulizia';                Menu='Pulizia file';      Titolo='Pulizia dei file';        Sub='Recupera spazio su disco, voce per voce, sapendo sempre cosa stai togliendo' }
    @{ Gruppo='Prestazioni'; Cat='CPU e scheduler';         Menu='CPU';               Titolo='CPU e scheduler';         Sub='Come Windows divide il tempo di CPU fra il gioco e tutto il resto' }
    @{ Gruppo='Prestazioni'; Cat='Scheda video';            Menu='GPU';               Titolo='Scheda video';            Sub='Coda di comandi della GPU e scelta della scheda giusta per ogni gioco' }
    @{ Gruppo='Prestazioni'; Cat='Energia';                 Menu='Energia';           Titolo='Energia';                 Sub='Frequenze, parcheggio dei core e risparmio energetico su USB e PCI Express' }
    @{ Gruppo='Prestazioni'; Cat='Memoria e archiviazione'; Menu='Memoria';           Titolo='Memoria e archiviazione'; Sub='Paging del kernel, avvio rapido e scritture inutili sull''SSD' }
    @{ Gruppo='Prestazioni'; Cat='#rete';                   Menu='Rete';              Titolo='Rete';                    Sub='Accorpamento dei pacchetti: conta sul registro dei colpi, non sugli FPS' }
    @{ Gruppo='Prestazioni'; Cat='#stabilita';              Menu='Stabilita'' FPS';   Titolo='Stabilita'' degli FPS';   Sub='Gli scatti non si vedono nella media: qui si misurano DPC e interrupt, e si tolgono le due cause piu'' comuni' }
    @{ Gruppo='Giochi';      Cat='#fortnite';               Menu='Fortnite';          Titolo='Fortnite';                Sub='Scrive direttamente nel file di configurazione del gioco: preset, limite FPS, risoluzione stretched' }
    @{ Gruppo='Giochi';      Cat='#valorant';               Menu='Valorant';          Titolo='Valorant';                Sub='Qualita'' grafica, Reflex e limite FPS. Vanguard non viene toccato in nessun modo' }
    @{ Gruppo='Giochi';      Cat='#r6';                     Menu='Rainbow Six';       Titolo='Rainbow Six Siege';       Sub='Preset competitivo sul GameSettings.ini di Ubisoft' }
    @{ Gruppo='Giochi';      Cat='#fivem';                  Menu='FiveM';             Titolo='FiveM / GTA V';           Sub='Le voci che tolgono lavoro alla CPU: densita'' citta'', pedoni, LOD, ombre' }
    @{ Gruppo='Giochi';      Cat='#discord';                Menu='Discord';           Titolo='Discord';                 Sub='Sei processi e quasi due giga di RAM accanto al gioco: cosa si puo'' davvero spegnere' }
    @{ Gruppo='Giochi';      Cat='#giochi';                 Menu='Tutti i giochi';    Titolo='Giochi';                  Sub='Giochi rilevati sul PC e impostazioni consigliate dentro ognuno' }
    @{ Gruppo='Diagnosi';    Cat='#salute';                 Menu='Salute del PC';     Titolo='Salute del PC';           Sub='Crash del driver video, errori hardware, spegnimenti anomali, dischi: i sintomi che nessun tweak puo'' curare' }
    @{ Gruppo='Diagnosi';    Cat='#diagnosi';               Menu='Analisi del PC';    Titolo='Diagnosi';                Sub='I problemi che nessun interruttore puo'' risolvere al posto tuo' }
    @{ Gruppo='Diagnosi';    Cat='#bios';                   Menu='BIOS / UEFI';       Titolo='BIOS / UEFI';             Sub='Le impostazioni del firmware: cosa e'' sbagliato, dove sta la voce sulla tua scheda, e un pulsante per riavviare nel BIOS' }
    @{ Gruppo='Diagnosi';    Cat='#aggiornamenti';          Menu='Aggiornamenti';     Titolo='Aggiornamenti';           Sub='Controlla se esiste una versione piu'' recente, verificandone la firma prima di scaricarla' }
    @{ Gruppo='Genera Code'; Cat='#genera';                 Menu='Genera codice';     Titolo='Genera codice';           Sub='Crea i codici di attivazione da dare a chi scarica VejaTweak' }
)

# Sulle copie dei clienti la pagina di generazione non deve nemmeno esistere
# nell'elenco: senza scheda in alto sarebbe gia' irraggiungibile, ma toglierla
# del tutto evita che un domani qualche scorciatoia ci arrivi lo stesso.
if (-not (Test-VtOwner)) {
    $script:Sezioni = @($script:Sezioni | Where-Object { $_.Cat -ne '#genera' })
}

$script:SezioneAttiva = '#octuning'
$script:GruppoAttivo  = 'Sistema'
$script:BottoniGruppo = @{}
$script:BottoniSotto  = @{}

# ---------------------------------------------------------------------------
# Costruzione delle card
# ---------------------------------------------------------------------------
function New-Badge([string] $testo, [string] $fg, [string] $bg, [string] $bd) {
    $b = New-Object Windows.Controls.Border
    $b.CornerRadius = [Windows.CornerRadius]::new(6)
    $b.Background   = New-Brush $bg
    $b.BorderBrush  = New-Brush $bd
    $b.BorderThickness = [Windows.Thickness]::new(1)
    $b.Padding      = [Windows.Thickness]::new(8, 2, 8, 3)
    $b.Margin       = [Windows.Thickness]::new(0, 0, 6, 0)
    $b.VerticalAlignment = 'Center'
    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $testo; $t.FontSize = 10; $t.Foreground = New-Brush $fg
    $b.Child = $t
    $b
}

# Guscio comune a tutte le card: cornice, striscia di stato a sinistra e
# reazione al passaggio del mouse. Restituisce il contenitore in cui infilare
# il contenuto vero e proprio.
function New-CardShell([string] $coloreStriscia) {
    $card = New-Object Windows.Controls.Border
    $card.Background      = New-Brush '#210A0E'
    $card.BorderBrush     = New-Brush '#3D1219'
    $card.BorderThickness = [Windows.Thickness]::new(1)
    $card.CornerRadius    = [Windows.CornerRadius]::new(10)
    $card.Margin          = [Windows.Thickness]::new(0, 0, 0, 9)

    # Schiarita e bordo che si accendono sotto il puntatore: la card sembra
    # sollevarsi senza dover animare ombre, che in WPF costano care.
    $card.Add_MouseEnter({
        $this.Background  = New-Brush '#2B0F14'
        $this.BorderBrush = New-Brush '#5C1B27'
    })
    $card.Add_MouseLeave({
        $this.Background  = New-Brush '#210A0E'
        $this.BorderBrush = New-Brush '#3D1219'
    })

    $corpo = New-Object Windows.Controls.Grid
    $s1 = New-Object Windows.Controls.ColumnDefinition; $s1.Width = [Windows.GridLength]::Auto
    $s2 = New-Object Windows.Controls.ColumnDefinition
    $s2.Width = New-Object Windows.GridLength (1, [Windows.GridUnitType]::Star)
    $corpo.ColumnDefinitions.Add($s1); $corpo.ColumnDefinitions.Add($s2)

    $striscia = New-Object Windows.Controls.Border
    $striscia.Width = 3
    $striscia.CornerRadius = [Windows.CornerRadius]::new(10, 0, 0, 10)
    $striscia.Background = New-Brush $coloreStriscia
    [Windows.Controls.Grid]::SetColumn($striscia, 0)
    [void] $corpo.Children.Add($striscia)

    $card.Child = $corpo
    return [pscustomobject]@{ Card = $card; Corpo = $corpo; Striscia = $striscia }
}

function New-TweakCard($tweak) {
    $attivo = [bool] (Get-VtState $tweak)
    $shell = New-CardShell $(if ($attivo) { '#FF3B4E' } else { '#4A1620' })
    $card = $shell.Card

    $grid = New-Object Windows.Controls.Grid
    $grid.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
    [Windows.Controls.Grid]::SetColumn($grid, 1)
    $c1 = New-Object Windows.Controls.ColumnDefinition
    $c1.Width = New-Object Windows.GridLength (1, [Windows.GridUnitType]::Star)
    $c2 = New-Object Windows.Controls.ColumnDefinition
    $c2.Width = [Windows.GridLength]::Auto
    $grid.ColumnDefinitions.Add($c1); $grid.ColumnDefinitions.Add($c2)
    [void] $shell.Corpo.Children.Add($grid)

    $sp = New-Object Windows.Controls.StackPanel
    [Windows.Controls.Grid]::SetColumn($sp, 0)

    # Titolo in bianco, non colorato: il colore lo porta la striscia laterale.
    $tit = New-Object Windows.Controls.TextBlock
    $tit.Text = $tweak.Nome; $tit.FontSize = 14; $tit.FontWeight = 'SemiBold'
    $tit.Foreground = New-Brush '#F6E9EA'; $tit.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($tit)

    $des = New-Object Windows.Controls.TextBlock
    $des.Text = $tweak.Desc; $des.FontSize = 12; $des.Foreground = New-Brush '#B58F94'
    $des.TextWrapping = 'Wrap'; $des.Margin = [Windows.Thickness]::new(0, 6, 24, 0)
    [void] $sp.Children.Add($des)

    # Etichette: rischio e riavvio
    $badges = New-Object Windows.Controls.StackPanel
    $badges.Orientation = 'Horizontal'
    $badges.Margin = [Windows.Thickness]::new(0, 10, 0, 0)
    if ($tweak.Rischio -eq 'alto') {
        [void] $badges.Children.Add((New-Badge 'compromesso vero' '#F87171' '#3A0F16' '#5C2028'))
    } elseif ($tweak.Rischio -eq 'medio') {
        [void] $badges.Children.Add((New-Badge 'da valutare' '#FBBF24' '#3A2408' '#5C4A12'))
    }
    if ($tweak.Reboot) {
        [void] $badges.Children.Add((New-Badge 'richiede riavvio' '#FFB454' '#3A2408' '#7A3410'))
    }
    if ($badges.Children.Count -gt 0) { [void] $sp.Children.Add($badges) }

    # Dettagli richiudibili
    $exp = New-Object Windows.Controls.Expander
    $exp.Header = 'Perche'' conta'
    $exp.Foreground = New-Brush '#FFB454'
    $exp.FontSize = 11
    $exp.Margin = [Windows.Thickness]::new(0, 10, 0, 0)
    $det = New-Object Windows.Controls.StackPanel
    $det.Margin = [Windows.Thickness]::new(0, 8, 24, 0)

    $why = New-Object Windows.Controls.TextBlock
    $why.Text = $tweak.Perche; $why.FontSize = 11; $why.TextWrapping = 'Wrap'
    $why.Foreground = New-Brush '#A07F84'
    [void] $det.Children.Add($why)

    if ($tweak.Warn) {
        $w = New-Object Windows.Controls.TextBlock
        $w.Text = 'Attenzione: ' + $tweak.Warn
        $w.FontSize = 11; $w.TextWrapping = 'Wrap'
        $w.Foreground = New-Brush '#FBBF24'
        $w.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
        [void] $det.Children.Add($w)
    }
    $exp.Content = $det
    [void] $sp.Children.Add($exp)
    [void] $grid.Children.Add($sp)

    # Interruttore in alto a destra, non centrato: con le descrizioni lunghe
    # centrarlo lo faceva ballare a meta' card.
    $tog = New-Object Windows.Controls.CheckBox
    $tog.Style = $win.FindResource('Toggle')
    $tog.VerticalAlignment = 'Top'
    $tog.Margin = [Windows.Thickness]::new(0, 2, 0, 0)
    [Windows.Controls.Grid]::SetColumn($tog, 1)
    $tog.IsChecked = $attivo
    $tog.Tag = $tweak
    # Riferimento diretto alla striscia della propria card, cosi' il gestore
    # non deve andarsela a cercare risalendo l'albero degli elementi.
    $tog | Add-Member -NotePropertyName Striscia -NotePropertyValue $shell.Striscia -Force
    [void] $grid.Children.Add($tog)

    # Il gestore usa $tog.Tag invece di catturare la variabile del ciclo:
    # cosi' ogni card lavora sul proprio tweak senza sorprese di scoping.
    $handler = {
        param($sender, $e)
        $t  = $sender.Tag
        $on = [bool] $sender.IsChecked
        $win.Cursor = [Windows.Input.Cursors]::Wait
        try {
            $ok = Set-VtTweak $t $on
            if (-not $ok) {
                # Rimettiamo l'interruttore dov'era: lo stato mostrato deve
                # sempre corrispondere a quello reale del sistema. Assegnare
                # IsChecked da codice non rilancia Click, quindi non cicla.
                $sender.IsChecked = -not $on
                Show-Toast "Non riuscito: $($t.Nome). Apri il registro attivita' per il dettaglio."
            } elseif ($t.Reboot) {
                Show-Toast "$($t.Nome): ha effetto dopo il riavvio del PC."
            }
            $sender.Striscia.Background = New-Brush $(if ($sender.IsChecked) { '#FF3B4E' } else { '#4A1620' })
        } finally {
            $win.Cursor = $null
        }
    }
    $tog.Add_Click($handler)

    $card
}

function New-InfoCard([string] $titolo, [string] $testo, [string] $colore = '#FFB454') {
    $shell = New-CardShell $colore
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
    [Windows.Controls.Grid]::SetColumn($sp, 1)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $titolo; $t.FontSize = 13; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush $colore; $t.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = $testo; $d.FontSize = 12; $d.Foreground = New-Brush '#B58F94'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
    [void] $sp.Children.Add($d)

    [void] $shell.Corpo.Children.Add($sp)
    $shell.Card
}

# Card con un pulsante invece dell'interruttore: per le azioni che si fanno
# una volta e non hanno uno stato "acceso/spento".
function New-ActionCard([string] $titolo, [string] $testo, [string] $pulsante, $azione, [string] $colore = '#FF3B4E') {
    $shell = New-CardShell $colore
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
    [Windows.Controls.Grid]::SetColumn($sp, 1)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $titolo; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush '#F6E9EA'; $t.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = $testo; $d.FontSize = 12; $d.Foreground = New-Brush '#B58F94'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 20, 0)
    [void] $sp.Children.Add($d)

    $b = New-Object Windows.Controls.Button
    $b.Style = $win.FindResource($(if ($colore -eq '#FF3B4E') { 'BtnAccent' } else { 'Btn' }))
    $b.Content = $pulsante
    $b.HorizontalAlignment = 'Left'
    $b.Margin = [Windows.Thickness]::new(0, 14, 0, 0)
    $b.Add_Click($azione)
    [void] $sp.Children.Add($b)

    [void] $shell.Corpo.Children.Add($sp)
    $shell.Card
}

# Card con un menu a tendina e un pulsante: per le azioni che hanno bisogno
# di una scelta prima di partire.
function New-ChoiceCard([string] $titolo, [string] $testo, $voci, [string] $pulsante, $azione) {
    $shell = New-CardShell '#FF3B4E'
    $card = $shell.Card
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
    [Windows.Controls.Grid]::SetColumn($sp, 1)
    [void] $shell.Corpo.Children.Add($sp)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $titolo; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush '#F6E9EA'; $t.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = $testo; $d.FontSize = 12; $d.Foreground = New-Brush '#B58F94'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 20, 0)
    [void] $sp.Children.Add($d)

    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $riga.Margin = [Windows.Thickness]::new(0, 14, 0, 0)

    $cb = New-Object Windows.Controls.ComboBox
    $cb.Width = 320
    $cb.Padding = [Windows.Thickness]::new(10, 6, 10, 6)
    $cb.VerticalContentAlignment = 'Center'
    foreach ($v in $voci) { [void] $cb.Items.Add($v.Nome) }
    $cb.SelectedIndex = 0
    $cb.Tag = $voci
    [void] $riga.Children.Add($cb)

    $b = New-Object Windows.Controls.Button
    $b.Style = $win.FindResource('BtnAccent')
    $b.Content = $pulsante
    $b.Margin = [Windows.Thickness]::new(12, 0, 0, 0)
    $b.Tag = $cb
    $b.Add_Click($azione)
    [void] $riga.Children.Add($b)

    [void] $sp.Children.Add($riga)
    $card
}

function Show-Toast([string] $msg) {
    [void] [Windows.MessageBox]::Show($msg, 'VejaTweak', 'OK', 'Information')
}

# Card con due caselle numeriche per una risoluzione scritta a mano.
# La usano tutte le pagine dei giochi: stessa validazione, stessi messaggi,
# nessun gioco che accetta un valore che un altro rifiuta.
function New-RisoluzioneCard([string] $gioco, [int] $xAttuale, [int] $yAttuale, $azione) {
    $shell = New-CardShell '#FF3B4E'
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
    [Windows.Controls.Grid]::SetColumn($sp, 1)
    [void] $shell.Corpo.Children.Add($sp)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = 'Risoluzione personalizzata'; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush '#F6E9EA'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = "Scrivi i numeri che vuoi: qualsiasi stretched, non solo quelle dell'elenco. Adesso $gioco e' a $xAttuale" + 'x' + "$yAttuale ($(Get-VtFormato $xAttuale $yAttuale))."
    $d.FontSize = 12; $d.Foreground = New-Brush '#B58F94'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 20, 0)
    [void] $sp.Children.Add($d)

    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $riga.Margin = [Windows.Thickness]::new(0, 14, 0, 0)

    function New-Casella($valore) {
        $tb = New-Object Windows.Controls.TextBox
        $tb.Text = "$valore"
        $tb.Width = 90; $tb.FontSize = 14
        $tb.Background = New-Brush '#1C070A'
        $tb.Foreground = New-Brush '#F6E9EA'
        $tb.CaretBrush = New-Brush '#FF3B4E'
        $tb.BorderBrush = New-Brush '#3D1219'
        $tb.Padding = [Windows.Thickness]::new(10, 7, 10, 7)
        $tb.VerticalContentAlignment = 'Center'
        $tb
    }
    $fx = New-Casella $xAttuale
    $fy = New-Casella $yAttuale
    [void] $riga.Children.Add($fx)

    $per = New-Object Windows.Controls.TextBlock
    $per.Text = 'x'; $per.FontSize = 15; $per.Foreground = New-Brush '#8C6167'
    $per.Margin = [Windows.Thickness]::new(10, 0, 10, 0); $per.VerticalAlignment = 'Center'
    [void] $riga.Children.Add($per)
    [void] $riga.Children.Add($fy)

    $btn = New-Object Windows.Controls.Button
    $btn.Style = $win.FindResource('BtnAccent')
    $btn.Content = 'Applica'
    $btn.Margin = [Windows.Thickness]::new(14, 0, 0, 0)
    [void] $riga.Children.Add($btn)
    [void] $sp.Children.Add($riga)

    $esito = New-Object Windows.Controls.TextBlock
    $esito.FontSize = 11; $esito.TextWrapping = 'Wrap'
    $esito.Margin = [Windows.Thickness]::new(0, 10, 20, 0)
    $esito.Foreground = New-Brush '#B58F94'
    [void] $sp.Children.Add($esito)

    $btn.Add_Click({
        $v = Test-VtRisoluzione $fx.Text $fy.Text
        if (-not $v.Valida) {
            $esito.Foreground = New-Brush '#F87171'
            $esito.Text = $v.Motivo
            return
        }
        $win.Cursor = [Windows.Input.Cursors]::Wait
        try {
            & $azione $v.X $v.Y
            $esito.Foreground = New-Brush '#4ADE80'
            $esito.Text = "Impostata $($v.X)x$($v.Y) - $(Get-VtFormato $v.X $v.Y)." +
                          $(if ($v.Avviso) { "`n$($v.Avviso)" } else { '' })
            Show-Toast "$gioco impostato a $($v.X)x$($v.Y).$(if ($v.Avviso) { "`n`n$($v.Avviso)" })"
        } catch {
            $esito.Foreground = New-Brush '#F87171'
            $esito.Text = $_.Exception.Message
        } finally { $win.Cursor = $null }
    }.GetNewClosure())

    $shell.Card
}

# ---------------------------------------------------------------------------
# Finestra di attivazione
#
# Compare solo al primo avvio su un PC che non ha ancora un codice valido.
# Dopo, l'attivazione viene risalvata e rivalidata in silenzio a ogni apertura.
# ---------------------------------------------------------------------------
function Show-VtAttivazione {
    $w = New-Object Windows.Window
    $w.Title = 'VejaTweak - attivazione'
    $w.Width = 620; $w.SizeToContent = 'Height'
    $w.WindowStartupLocation = 'CenterScreen'
    $w.ResizeMode = 'NoResize'
    $w.Background = New-Brush '#140507'

    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(28, 24, 28, 24)

    function Add-Testo($testo, $size, $colore, $bold, $top) {
        $t = New-Object Windows.Controls.TextBlock
        $t.Text = $testo; $t.FontSize = $size; $t.Foreground = New-Brush $colore
        $t.TextWrapping = 'Wrap'; $t.Margin = [Windows.Thickness]::new(0, $top, 0, 0)
        if ($bold) { $t.FontWeight = 'Bold' }
        [void] $sp.Children.Add($t)
    }

    Add-Testo 'VejaTweak' 24 '#F6E9EA' $true 0
    Add-Testo 'Questa copia non e'' ancora attivata. Serve un codice, una volta sola: dalla prossima apertura non te lo chiede piu''.' 12 '#B58F94' $false 8

    Add-Testo 'ID di questo PC (mandalo a chi ti ha dato il programma)' 11 '#8C6167' $false 20
    $idBox = New-Object Windows.Controls.TextBox
    $idBox.Text = Get-VtMachineId
    $idBox.IsReadOnly = $true
    $idBox.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
    $idBox.FontSize = 16
    $idBox.Background = New-Brush '#1C070A'
    $idBox.Foreground = New-Brush '#FFB454'
    $idBox.BorderBrush = New-Brush '#3D1219'
    $idBox.Padding = [Windows.Thickness]::new(12, 9, 12, 9)
    $idBox.Margin = [Windows.Thickness]::new(0, 6, 0, 0)
    [void] $sp.Children.Add($idBox)

    $btnCopiaId = New-Object Windows.Controls.Button
    $btnCopiaId.Style = $win.FindResource('Btn')
    $btnCopiaId.Content = 'Copia ID'
    $btnCopiaId.HorizontalAlignment = 'Left'
    $btnCopiaId.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
    $btnCopiaId.Add_Click({ try { [Windows.Clipboard]::SetText($idBox.Text) } catch { } }.GetNewClosure())
    [void] $sp.Children.Add($btnCopiaId)

    Add-Testo 'Codice di attivazione' 11 '#8C6167' $false 20
    $codeBox = New-Object Windows.Controls.TextBox
    $codeBox.AcceptsReturn = $true
    $codeBox.TextWrapping = 'Wrap'
    $codeBox.Height = 90
    $codeBox.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
    $codeBox.FontSize = 12
    $codeBox.Background = New-Brush '#1C070A'
    $codeBox.Foreground = New-Brush '#F6E9EA'
    $codeBox.CaretBrush = New-Brush '#FF3B4E'
    $codeBox.BorderBrush = New-Brush '#3D1219'
    $codeBox.Padding = [Windows.Thickness]::new(12, 9, 12, 9)
    $codeBox.Margin = [Windows.Thickness]::new(0, 6, 0, 0)
    $codeBox.VerticalScrollBarVisibility = 'Auto'
    [void] $sp.Children.Add($codeBox)

    $msg = New-Object Windows.Controls.TextBlock
    $msg.FontSize = 12; $msg.TextWrapping = 'Wrap'
    $msg.Margin = [Windows.Thickness]::new(0, 12, 0, 0)
    $msg.Foreground = New-Brush '#F87171'
    [void] $sp.Children.Add($msg)

    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $riga.Margin = [Windows.Thickness]::new(0, 18, 0, 0)

    $btnOk = New-Object Windows.Controls.Button
    $btnOk.Style = $win.FindResource('BtnAccent')
    $btnOk.Content = 'Attiva'
    $btnOk.Margin = [Windows.Thickness]::new(0, 0, 10, 0)
    [void] $riga.Children.Add($btnOk)

    $btnEsci = New-Object Windows.Controls.Button
    $btnEsci.Style = $win.FindResource('Btn')
    $btnEsci.Content = 'Esci'
    [void] $riga.Children.Add($btnEsci)
    [void] $sp.Children.Add($riga)

    $w.Content = $sp
    $script:LicOk = $false

    $btnOk.Add_Click({
        $r = Test-VtCode $codeBox.Text
        if ($r.Valido) {
            Save-VtAttivazione ($codeBox.Text.Trim())
            $script:LicOk = $true
            Write-VtLog "Attivazione riuscita (serial $($r.Serial))" ok
            $w.Close()
        } else {
            $msg.Text = $r.Motivo
            Write-VtLog "Attivazione rifiutata: $($r.Motivo)" warn
        }
    }.GetNewClosure())

    $btnEsci.Add_Click({ $w.Close() }.GetNewClosure())

    [void] $w.ShowDialog()
    return $script:LicOk
}

# ---------------------------------------------------------------------------
# Pagine
# ---------------------------------------------------------------------------
# Riempie la seconda riga con le sezioni del gruppo scelto.
function Build-Sotto([string] $gruppo) {
    $script:GruppoAttivo = $gruppo
    $Sotto.Children.Clear()
    $script:BottoniSotto = @{}

    foreach ($s in ($script:Sezioni | Where-Object { $_.Gruppo -eq $gruppo })) {
        $cat = $s.Cat
        $b = New-Object Windows.Controls.Button
        $b.Style   = $win.FindResource('SottoBtn')
        $b.Content = $s.Menu
        $b.Add_Click({ Show-Sezione $cat }.GetNewClosure())
        $script:BottoniSotto[$s.Cat] = $b
        [void] $Sotto.Children.Add($b)
    }

    foreach ($k in $script:BottoniGruppo.Keys) {
        # Lo stile usa Tag='on' per accendere l'indicatore ambra: cambiare il
        # Tag fa partire da solo lo storyboard definito nel tema.
        $script:BottoniGruppo[$k].Tag = if ($k -eq $gruppo) { 'on' } else { 'off' }
    }
}

function Show-Sezione([string] $cat) {
    $sez = $script:Sezioni | Where-Object { $_.Cat -eq $cat } | Select-Object -First 1
    if (-not $sez) { return }
    $script:SezioneAttiva = $cat

    if ($sez.Gruppo -ne $script:GruppoAttivo) { Build-Sotto $sez.Gruppo }

    $TxtTitolo.Text = $sez.Titolo
    $TxtSub.Text    = $sez.Sub

    foreach ($k in $script:BottoniSotto.Keys) {
        $script:BottoniSotto[$k].Tag = if ($k -eq $cat) { 'on' } else { 'off' }
    }

    # Diagnosi e Giochi non sono elenchi di tweak: la ricerca li' non serve.
    (Get-El 'PanelSearch').Visibility = if ($cat -like '#*') { 'Collapsed' } else { 'Visible' }

    # Leggere lo stato reale di una sezione puo' richiedere qualche decimo di
    # secondo: meglio dirlo con il cursore che lasciare la finestra ferma.
    $win.Cursor = [Windows.Input.Cursors]::AppStarting
    try { Update-Contenuto } finally { $win.Cursor = $null }

    # Senza questo la nuova sezione eredita lo scorrimento della precedente e
    # si apre a meta' pagina, con le prime card gia' sopra il bordo.
    (Get-El 'Scroller').ScrollToTop()

    # Entrata: la pagina sale di 14 pixel e sfuma. Fa capire che il contenuto
    # e' cambiato anche quando due sezioni si somigliano.
    $sb = $win.FindResource('EntrataPagina')
    $sb.Begin($Contenuto)
}

function Update-Contenuto {
    $Contenuto.Children.Clear()
    $cat = $script:SezioneAttiva
    $q   = $TxtSearch.Text.Trim()

    if ($cat -eq '#diagnosi') {
        $Contenuto.Children.Add((New-InfoCard 'Analisi in corso...' 'Sto leggendo BIOS, RAM, monitor, driver e servizi.' '#FF7A5C')) | Out-Null
        $win.Dispatcher.Invoke([action] {}, 'Background')

        $res = @(Get-VtDiagnosi)
        $Contenuto.Children.Clear()
        if ($res.Count -eq 0) {
            $msg = 'Le cose che un tweaker non puo'' sistemare da solo (RAM, BIOS, monitor, driver, servizi anticheat) sul tuo PC sono gia'' a posto.'
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun problema rilevato' $msg))
            return
        }
        foreach ($r in $res) {
            $col = if ($r.Peso -eq 1) { '#F87171' } else { '#FBBF24' }
            [void] $Contenuto.Children.Add((New-InfoCard $r.Titolo $r.Testo $col))
        }
        return
    }

    if ($cat -eq '#octuning') {
        $r = Get-VtRiepilogo

        # Riquadri del riepilogo, tre per riga.
        # UniformGrid sta in Primitives, non in Controls.
        $griglia = New-Object Windows.Controls.Primitives.UniformGrid
        $griglia.Columns = 3
        $griglia.Margin = [Windows.Thickness]::new(0, 0, 0, 6)
        $voci = @(
            @{ T='CPU';           V=$r.Cpu;     D=$r.CpuDett;    Ok=$true }
            @{ T='GPU RILEVATA';  V=$r.Gpu;     D=$r.GpuDett;    Ok=$true }
            @{ T='RAM RILEVATA';  V=$r.Ram;     D=$r.RamDett;    Ok=$r.RamOk }
            @{ T='SCHEDA MADRE';  V=$r.Scheda;  D=$r.SchedaDett; Ok=$true }
            @{ T='SISTEMA';       V=$r.Sistema; D="Disco di sistema: $($r.Disco)"; Ok=$true }
            @{ T='STATO CPU';     V=$r.CpuStato; D=$r.CpuThread; Ok=$r.CpuStatoOk }
        )
        foreach ($v in $voci) {
            $b = New-Object Windows.Controls.Border
            $b.Background      = New-Brush '#210A0E'
            $b.BorderBrush     = New-Brush $(if ($v.Ok) { '#3D1219' } else { '#F87171' })
            $b.BorderThickness = [Windows.Thickness]::new(1)
            $b.CornerRadius    = [Windows.CornerRadius]::new(10)
            $b.Margin          = [Windows.Thickness]::new(0, 0, 9, 9)
            $b.Padding         = [Windows.Thickness]::new(16, 13, 16, 13)
            $sp = New-Object Windows.Controls.StackPanel
            $t1 = New-Object Windows.Controls.TextBlock
            $t1.Text = $v.T; $t1.FontSize = 9; $t1.Foreground = New-Brush '#8C6167'
            [void] $sp.Children.Add($t1)
            $t2 = New-Object Windows.Controls.TextBlock
            $t2.Text = $v.V; $t2.FontSize = 13; $t2.FontWeight = 'SemiBold'
            $t2.Foreground = New-Brush $(if ($v.Ok) { '#F6E9EA' } else { '#F87171' })
            $t2.TextWrapping = 'Wrap'; $t2.Margin = [Windows.Thickness]::new(0, 5, 0, 0)
            [void] $sp.Children.Add($t2)
            $t3 = New-Object Windows.Controls.TextBlock
            $t3.Text = $v.D; $t3.FontSize = 11; $t3.Foreground = New-Brush '#B58F94'
            $t3.TextWrapping = 'Wrap'; $t3.Margin = [Windows.Thickness]::new(0, 5, 0, 0)
            [void] $sp.Children.Add($t3)
            $b.Child = $sp
            [void] $griglia.Children.Add($b)
        }
        [void] $Contenuto.Children.Add($griglia)

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa NON trovi qui' `
            "Overclock vero di CPU, voltaggi e timing della RAM non si toccano da Windows: stanno nel firmware, e le utility che ci provano lo fanno con un driver in kernel mode. Qui c'e' solo la parte automatica che Windows controlla davvero.`n`nPer le voci di firmware vai in Diagnosi > BIOS / UEFI: ti dice cosa e' sbagliato e ti porta nel BIOS con un clic." '#FBBF24'))

        # --- profili automatici -------------------------------------------
        $tit = New-Object Windows.Controls.TextBlock
        $tit.Text = 'Profili automatici'; $tit.FontSize = 18; $tit.FontWeight = 'Bold'
        $tit.Foreground = New-Brush '#F6E9EA'
        $tit.Margin = [Windows.Thickness]::new(0, 18, 0, 4)
        [void] $Contenuto.Children.Add($tit)

        $sub = New-Object Windows.Controls.TextBlock
        $sub.Text = 'Ogni profilo accende un elenco di voci che trovi anche nelle altre sezioni: niente di nascosto, e puoi spegnerle una per una quando vuoi. Il conteggio e'' quello reale per questo PC, perche'' alcune voci non esistono su tutte le macchine.'
        $sub.FontSize = 12; $sub.Foreground = New-Brush '#B58F94'
        $sub.TextWrapping = 'Wrap'; $sub.Margin = [Windows.Thickness]::new(0, 0, 0, 12)
        [void] $Contenuto.Children.Add($sub)

        $colori = @{ base = '#FFB454'; competitive = '#FF3B4E'; massimo = '#F87171' }
        foreach ($prof in $script:VtProfili) {
            $tutti = @(Get-VtProfiloTweaks $prof.Id)
            $da    = @(Get-VtProfiloDaFare $prof.Id)
            $col   = $colori[$prof.Id]

            $testo = @()
            $testo += $prof.Sommario
            $testo += $prof.Desc
            $testo += ($prof.Punti | ForEach-Object { "  -  $_" }) -join "`n"
            $testo += "$($tutti.Count) azioni compatibili con questo PC  |  $($da.Count) ancora da applicare"
            if ($prof.Consigliato) { $testo += 'CONSIGLIATO' }

            $idProf = $prof.Id
            $nomeProf = $prof.Nome
            $etichetta = if ($da.Count -eq 0) { 'Gia'' tutto applicato' } else { "Esegui auto tuning ($($da.Count))" }

            $card = New-ActionCard "$($prof.Etichetta)  -  $($prof.Nome)" ($testo -join "`n`n") $etichetta {
                $da2 = @(Get-VtProfiloDaFare $idProf)
                if ($da2.Count -eq 0) { Show-Toast 'Su questo PC e'' gia'' tutto applicato.'; return }

                # Elenco esatto prima di toccare qualcosa, con le voci che
                # hanno un compromesso segnalate a parte.
                $elenco = ($da2 | ForEach-Object { "  - $($_.Nome)" }) -join "`n"
                $rischiose = @($da2 | Where-Object { $_.Rischio -ne 'sicuro' })
                $avviso = ''
                if ($rischiose.Count -gt 0) {
                    $avviso = "`n`nATTENZIONE, queste hanno un compromesso vero:`n" +
                              (($rischiose | ForEach-Object { "  - $($_.Nome): $($_.Warn)" }) -join "`n")
                }
                $risposta = [Windows.MessageBox]::Show(
                    "Profilo $nomeProf`n`nSto per applicare $($da2.Count) voci:`n$elenco$avviso`n`nOgnuna si puo' disattivare dopo, una per una. Procedo?",
                    'Conferma profilo', 'YesNo', 'Question')
                if ($risposta -ne 'Yes') { return }

                $win.Cursor = [Windows.Input.Cursors]::Wait
                try { $res = Invoke-VtProfilo $idProf } finally { $win.Cursor = $null }

                $msg = "Applicate $($res.Applicati) voci su $($res.Totale)."
                if ($res.Falliti.Count -gt 0) { $msg += "`n`nNon riuscite (servono i privilegi di amministratore?):`n" + (($res.Falliti | ForEach-Object { "  - $_" }) -join "`n") }
                if ($res.Riavvio) { $msg += "`n`nAlcune hanno effetto dopo il riavvio del PC." }
                Show-Toast $msg
                Update-Contenuto
            }.GetNewClosure() $col
            [void] $Contenuto.Children.Add($card)
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Dopo aver applicato un profilo' `
            "Riavvia quando hai finito: HAGS, avvio rapido e i parametri del kernel valgono dal boot successivo. VejaTweak non riavvia mai da solo.`n`nSe qualcosa non ti torna, 'Ripristina tutto' in alto a destra rimette ogni voce al valore che aveva sul tuo PC prima." '#FFB454'))
        return
    }

    if ($cat -eq '#genera') {
        if (-not (Test-VtOwner)) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Riservato a chi distribuisce l''app' `
                'Questa pagina richiede owner.key, la chiave privata di firma. Non e'' presente su questo PC.' '#FBBF24'))
            return
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Come funziona' `
            @(
                "I codici sono firmati con la tua chiave privata (owner.key). L'app che distribuisci contiene solo public.key, che verifica ma non firma: nessuno puo' fabbricarsi un codice.",
                "Codice universale: funziona su qualsiasi PC. Comodo, ma se qualcuno lo gira ad altri funziona anche a loro.",
                "Codice legato a un PC: fatti mandare dal cliente l'ID che l'app gli mostra all'avvio, incollalo qui. Quel codice funzionera' solo sul suo PC.",
                "NON distribuire mai owner.key insieme all'app, e tienine una copia: se lo perdi non puoi piu' generare codici che funzionino con le app gia' consegnate."
            ) -join "`n`n"))

        # --- modulo -------------------------------------------------------
        $shell = New-CardShell '#FF3B4E'
        $form = New-Object Windows.Controls.StackPanel
        $form.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
        [Windows.Controls.Grid]::SetColumn($form, 1)
        [void] $shell.Corpo.Children.Add($form)

        $t = New-Object Windows.Controls.TextBlock
        $t.Text = 'Genera un codice'; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
        $t.Foreground = New-Brush '#F6E9EA'
        [void] $form.Children.Add($t)

        function New-Campo([string] $etichetta, [string] $valore, [string] $suggerimento) {
            $l = New-Object Windows.Controls.TextBlock
            $l.Text = $etichetta; $l.FontSize = 11; $l.Foreground = New-Brush '#8C6167'
            $l.Margin = [Windows.Thickness]::new(0, 14, 0, 4)
            [void] $form.Children.Add($l)
            $tb = New-Object Windows.Controls.TextBox
            $tb.Text = $valore
            $tb.FontSize = 13
            $tb.Background = New-Brush '#1C070A'
            $tb.Foreground = New-Brush '#F6E9EA'
            $tb.CaretBrush = New-Brush '#FF3B4E'
            $tb.BorderBrush = New-Brush '#3D1219'
            $tb.Padding = [Windows.Thickness]::new(10, 7, 10, 7)
            $tb.Width = 380; $tb.HorizontalAlignment = 'Left'
            [void] $form.Children.Add($tb)
            if ($suggerimento) {
                $h = New-Object Windows.Controls.TextBlock
                $h.Text = $suggerimento; $h.FontSize = 10; $h.Foreground = New-Brush '#8C6167'
                $h.TextWrapping = 'Wrap'; $h.Margin = [Windows.Thickness]::new(0, 4, 0, 0)
                [void] $form.Children.Add($h)
            }
            $tb
        }

        $fSerial = New-Campo 'Numero di serie / riferimento cliente' '' 'Lascia vuoto per uno casuale. Serve solo a te per ricordarti a chi hai dato cosa.'
        $fGiorni = New-Campo 'Giorni di validita''' '0' '0 = non scade mai.'
        $fMid    = New-Campo 'ID del PC del cliente' '' 'Vuoto = codice universale, funziona ovunque. Altrimenti incolla i 16 caratteri che il cliente ti manda.'

        $btn = New-Object Windows.Controls.Button
        $btn.Style = $win.FindResource('BtnAccent')
        $btn.Content = 'Genera il codice'
        $btn.HorizontalAlignment = 'Left'
        $btn.Margin = [Windows.Thickness]::new(0, 18, 0, 0)
        [void] $form.Children.Add($btn)

        $out = New-Object Windows.Controls.TextBox
        $out.IsReadOnly = $true
        $out.AcceptsReturn = $true
        $out.TextWrapping = 'Wrap'
        $out.Height = 110
        $out.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
        $out.FontSize = 12
        $out.Background = New-Brush '#1C070A'
        $out.Foreground = New-Brush '#FFB454'
        $out.BorderBrush = New-Brush '#3D1219'
        $out.Padding = [Windows.Thickness]::new(10, 8, 10, 8)
        $out.Margin = [Windows.Thickness]::new(0, 14, 0, 0)
        $out.VerticalScrollBarVisibility = 'Auto'
        [void] $form.Children.Add($out)

        $esito = New-Object Windows.Controls.TextBlock
        $esito.FontSize = 11; $esito.TextWrapping = 'Wrap'
        $esito.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
        $esito.Foreground = New-Brush '#B58F94'
        [void] $form.Children.Add($esito)

        $btnCopia = New-Object Windows.Controls.Button
        $btnCopia.Style = $win.FindResource('Btn')
        $btnCopia.Content = 'Copia negli appunti'
        $btnCopia.HorizontalAlignment = 'Left'
        $btnCopia.Margin = [Windows.Thickness]::new(0, 10, 0, 0)
        $btnCopia.Add_Click({
            if ($out.Text) { try { [Windows.Clipboard]::SetText($out.Text); $esito.Text = 'Codice copiato negli appunti.' } catch { } }
        }.GetNewClosure())
        [void] $form.Children.Add($btnCopia)

        $btn.Add_Click({
            try {
                $ser = 0
                if ($fSerial.Text -match '^\d+$') { $ser = [uint32] $fSerial.Text }
                $gg = 0
                if ($fGiorni.Text -match '^\d+$') { $gg = [int] $fGiorni.Text }

                $codice = New-VtCode -Serial $ser -Giorni $gg -MacchinaId ($fMid.Text.Trim())
                $out.Text = $codice

                $v = Test-VtCode $codice
                $dett = @("Serie: $($v.Serial)")
                $dett += if ($v.Scadenza) { "Scade il $($v.Scadenza.ToString('dd/MM/yyyy'))" } else { 'Non scade' }
                $dett += if ($v.Legato) { 'Legato al PC indicato' } else { 'Valido su qualsiasi PC' }
                # Nota: la verifica appena fatta gira su QUESTO PC, quindi un
                # codice legato a un altro PC risulterebbe non valido qui.
                # E' normale e non vuol dire che il codice sia sbagliato.
                $esito.Foreground = New-Brush '#4ADE80'
                $esito.Text = ($dett -join '  |  ') + '   -   generato e copiabile.'
                Write-VtLog "Generato codice serie $($v.Serial)" ok
            } catch {
                $out.Text = ''
                $esito.Foreground = New-Brush '#F87171'
                $esito.Text = $_.Exception.Message
            }
        }.GetNewClosure())

        [void] $Contenuto.Children.Add($shell.Card)

        [void] $Contenuto.Children.Add((New-InfoCard 'Quanto vale davvero questa protezione' `
            "Onesto: VejaTweak e' uno script PowerShell in chiaro. Chi lo scarica puo' aprirlo e togliere il controllo del codice in trenta secondi. Nessuna licenza lato client lo impedisce.`n`nQuello che questa protezione fa davvero e' impedire che qualcuno si INVENTI un codice: senza la tua chiave privata non e' possibile, e i codici legati a un PC non funzionano se girati ad altri.`n`nSe ti serve una protezione piu' seria servono un eseguibile compilato e un server di attivazione, e anche allora si tratta di alzare l'asticella, non di renderla invalicabile." '#FBBF24'))
        return
    }

    if ($cat -eq '#salute') {
        [void] $Contenuto.Children.Add((New-InfoCard 'A cosa serve questa pagina' `
            "Nessun interruttore risolve un driver video che va in crash, una RAM instabile o un alimentatore che non regge. Windows registra questi sintomi da solo, e non li legge mai nessuno.`n`nQui li tiro fuori. Se trovi qualcosa in rosso, sistemare quello vale piu' di tutti i tweak di questa app messi insieme." '#FFB454'))

        $ev = Get-VtEventi 30
        foreach ($d in (Get-VtEventiDiagnosi $ev)) {
            $col = switch ($d.Stato) { 'GRAVE' { '#F87171' } 'DA GUARDARE' { '#FBBF24' } 'PULITO' { '#4ADE80' } default { '#B58F94' } }
            [void] $Contenuto.Children.Add((New-InfoCard "[$($d.Stato)]  $($d.Titolo)" $d.Testo $col))
        }

        # --- risoluzione del timer, misurata ------------------------------
        $tr = Get-VtTimerResolution
        if ($tr) {
            $buono = ($tr.Attuale -le 1.1)
            $txt = @(
                "Attuale: $($tr.Attuale) ms   |   migliore ottenibile: $($tr.Minima) ms   |   default di Windows: $($tr.Default) ms"
                ''
                "E' ogni quanto il kernel puo' svegliare un thread. A $($tr.Default) ms un frame puo' arrivare fino a un sedicesimo di secondo fuori tempo: e' il micro-scatto che vedi con FPS medi altissimi."
                $(if ($buono) {
                    "Il valore attuale va bene. Se qui leggessi $($tr.Default) ms vorrebbe dire che nessun programma sta chiedendo la risoluzione fine."
                } else {
                    "Il sistema sta girando alla granularita' grossa. La voce 'Risoluzione del timer a livello di sistema' in Prestazioni > Stabilita' FPS serve esattamente a questo."
                })
                "Questo numero e' letto da ntdll, non stimato: e' la prova che quel tweak fa effetto o no."
            ) -join "`n"
            [void] $Contenuto.Children.Add((New-InfoCard "Risoluzione del timer: $($tr.Attuale) ms" $txt $(if ($buono) { '#4ADE80' } else { '#FBBF24' })))
        }

        # --- dove stanno i giochi -----------------------------------------
        $gd = @(Get-VtGiochiSuDisco)
        if ($gd.Count -gt 0) {
            $suHdd = @($gd | Where-Object { $_.Tipo -match 'HDD' })
            $righe = ($gd | ForEach-Object { "  -  $($_.Nome): unita' $($_.Unita) - $($_.Disco) [$($_.Tipo)]" }) -join "`n"
            if ($suHdd.Count -gt 0) {
                [void] $Contenuto.Children.Add((New-InfoCard "$($suHdd.Count) giochi installati su disco meccanico" `
                    "$righe`n`nUn gioco su HDD e' una causa di stutter che nessun tweak puo' coprire: lo streaming delle texture e delle mesh non sta dietro. Spostarlo su un SSD e' la modifica singola piu' efficace che puoi fare su quei giochi, piu' di qualunque impostazione di questa app." '#F87171'))
            } else {
                [void] $Contenuto.Children.Add((New-InfoCard 'Tutti i giochi su unita'' a stato solido' "$righe`n`nNiente da fare: lo streaming delle risorse non e' un collo di bottiglia." '#4ADE80'))
            }
        }

        # --- salute dei dischi --------------------------------------------
        $dischi = @(Get-VtDischi)
        if ($dischi.Count -gt 0) {
            $righe = $dischi | ForEach-Object {
                $extra = @()
                if ($null -ne $_.Usura) { $extra += "usura $($_.Usura)%" }
                if ($null -ne $_.Temp)  { $extra += "$($_.Temp) C" }
                "  -  $($_.Nome) [$($_.Tipo), $($_.GB) GB, $($_.Bus)] - salute: $($_.Salute)$(if ($extra) { ' - ' + ($extra -join ', ') })"
            }
            $malati = @($dischi | Where-Object { $_.Salute -ne 'Healthy' })
            $testo = ($righe -join "`n")
            if ($dischi | Where-Object { $null -eq $_.Usura }) {
                $testo += "`n`nUsura e temperatura non sono esposte da tutti i controller: dove mancano, il dato non c'e', non e' zero."
            }
            [void] $Contenuto.Children.Add((New-InfoCard $(if ($malati.Count -gt 0) { "$($malati.Count) dischi non in salute" } else { 'Dischi in salute' }) `
                $testo $(if ($malati.Count -gt 0) { '#F87171' } else { '#4ADE80' })))
        }
        return
    }

    if ($cat -eq '#aggiornamenti') {
        $url = Get-VtUrlAggiornamenti
        [void] $Contenuto.Children.Add((New-InfoCard 'Versione installata' "VejaTweak $($script:Versione)"))

        if (-not $url) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Controllo automatico non configurato' `
                "Manca il file aggiornamenti.url accanto all'applicazione, quindi non c'e' nessun indirizzo da controllare.`n`nChi ti ha dato il programma ti mandera' le versioni nuove a mano." '#FBBF24'))
        } else {
            $stato = New-Object Windows.Controls.TextBlock
            $stato.FontSize = 12; $stato.TextWrapping = 'Wrap'
            $stato.Foreground = New-Brush '#B58F94'
            $stato.Text = "Indirizzo configurato. Premi 'Controlla' per vedere se c'e' una versione nuova."

            $azioni = New-Object Windows.Controls.StackPanel

            $cardCtrl = New-ActionCard 'Controlla aggiornamenti' `
                "Scarica solo il file che descrive l'ultima versione e ne verifica la firma. Non installa niente da solo." `
                'Controlla' {
                    param($sender, $e)
                    $sender.IsEnabled = $false
                    $win.Cursor = [Windows.Input.Cursors]::AppStarting
                    $azioni.Children.Clear()
                    try {
                        $info = Get-VtAggiornamento $url $script:Versione
                        $stato.Text = $info.Motivo
                        $stato.Foreground = New-Brush $(if ($info.Disponibile) { '#4ADE80' } elseif ($info.Motivo -match 'FIRMA') { '#F87171' } else { '#B58F94' })

                        if ($info.Disponibile) {
                            $testo = "Versione $($info.Versione)."
                            if ($info.Note) { $testo += "`n`nNovita': $($info.Note)" }
                            $testo += "`n`nIl pacchetto viene scaricato, ne viene ricontrollata l'impronta e poi sostituisce i file del programma. Attivazione, backup e impostazioni restano dove sono."
                            [void] $azioni.Children.Add((New-ActionCard "Aggiorna alla $($info.Versione)" $testo 'Scarica e installa' {
                                $win.Cursor = [Windows.Input.Cursors]::Wait
                                try {
                                    $n = Install-VtAggiornamento $info
                                    Show-Toast "Aggiornamento completato: $n file sostituiti.`n`nChiudi e riapri VejaTweak per usare la versione nuova."
                                } catch { Show-Toast $_.Exception.Message }
                                finally { $win.Cursor = $null }
                            }.GetNewClosure()))
                        }
                    } catch {
                        $stato.Text = $_.Exception.Message
                        $stato.Foreground = New-Brush '#F87171'
                    } finally {
                        $win.Cursor = $null
                        $sender.IsEnabled = $true
                        $sender.Content = 'Ricontrolla'
                    }
                }.GetNewClosure()
            [void] $Contenuto.Children.Add($cardCtrl)

            $box = New-CardShell '#FFB454'
            $sp = New-Object Windows.Controls.StackPanel
            $sp.Margin = [Windows.Thickness]::new(20, 14, 20, 14)
            [Windows.Controls.Grid]::SetColumn($sp, 1)
            [void] $sp.Children.Add($stato)
            [void] $box.Corpo.Children.Add($sp)
            [void] $Contenuto.Children.Add($box.Card)
            [void] $Contenuto.Children.Add($azioni)
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' puoi fidarti di questo aggiornamento' `
            "Un programma che scarica codice da internet e lo esegue e' il modo classico in cui una cosa innocua diventa un veicolo di malware: basta che qualcuno metta le mani sul sito da cui scarica.`n`nQui non funziona cosi'. Il file che descrive l'aggiornamento e' firmato con una chiave privata che sta solo sul PC di chi ha creato il programma, e VejaTweak verifica quella firma PRIMA di scaricare qualsiasi cosa. Poi ricontrolla l'impronta SHA-256 del pacchetto scaricato.`n`nAnche prendendo il controllo del sito, senza quella chiave non si riesce a far accettare niente." '#FF7A5C'))
        return
    }

    if ($cat -eq '#pulizia') {
        $d = Get-PSDrive C -ErrorAction SilentlyContinue
        $liberi = if ($d) { [math]::Round($d.Free / 1GB, 1) } else { 0 }
        $tot    = if ($d) { [math]::Round(($d.Free + $d.Used) / 1GB, 1) } else { 0 }
        $pct    = if ($tot -gt 0) { [math]::Round(100 * $liberi / $tot) } else { 0 }

        $intro = if ($pct -ge 20) {
            "Hai $liberi GB liberi su $tot ($pct%): di spazio ne hai. Te lo dico perche' e' il campo dove si raccontano piu' bugie: svuotare cartelle NON rende un PC piu' veloce. Serve a recuperare spazio, e basta.`n`nLa velocita' cambia solo quando il disco e' quasi pieno, sotto il 10%: li' Windows non riesce piu' a espandere il file di paging e butta via la cache delle shader. Non e' il tuo caso."
        } else {
            "Hai $liberi GB liberi su $tot ($pct%): sei sotto la soglia in cui lo spazio inizia a costare prestazioni. Windows fatica a espandere il file di paging e butta via la cache delle shader, che si traduce in stutter. Qui liberare serve davvero."
        }
        [void] $Contenuto.Children.Add((New-InfoCard 'Prima di tutto, la verita'' sulla pulizia' $intro $(if ($pct -ge 20) { '#FFB454' } else { '#F87171' })))

        $riepilogo = New-Object Windows.Controls.TextBlock
        $riepilogo.FontSize = 12; $riepilogo.TextWrapping = 'Wrap'
        $riepilogo.Foreground = New-Brush '#B58F94'
        $riepilogo.Text = 'Nessuna analisi ancora eseguita.'

        # Contenitore delle voci: riempito dall'analisi.
        $lista = New-Object Windows.Controls.StackPanel

        $cardScan = New-ActionCard 'Analizza cosa si puo'' liberare' `
            'Misura ogni categoria senza cancellare niente. Poi decidi voce per voce.' `
            'Analizza' {
                param($sender, $e)
                $sender.IsEnabled = $false
                $sender.Content = 'Analisi in corso...'
                $win.Cursor = [Windows.Input.Cursors]::AppStarting
                $lista.Children.Clear()
                $totale = 0.0
                try {
                    foreach ($v in $script:VtPulizia) {
                        $m = Measure-VtPulizia $v
                        $totale += $m.Mb

                        $etichetta = if ($m.Negato -and $m.File -eq 0) { 'serve amministratore' }
                                     elseif ($m.File -eq 0) { 'niente da togliere' }
                                     else { "$($m.Mb) MB in $($m.File) file" }

                        $testo = @($v.Desc, $v.Perche)
                        if ($v.Warn) { $testo += 'ATTENZIONE: ' + $v.Warn }
                        $testo += "Trovato adesso: $etichetta"

                        $col = if ($v.Rischio -ne 'sicuro') { '#FBBF24' } else { '#FF3B4E' }
                        $voceCorrente = $v

                        if ($m.File -gt 0) {
                            [void] $lista.Children.Add((New-ActionCard "$($v.Nome)  -  $($m.Mb) MB" ($testo -join "`n`n") 'Elimina' {
                                param($s2, $e2)
                                if ($voceCorrente.Warn) {
                                    $r = [Windows.MessageBox]::Show(
                                        "$($voceCorrente.Nome)`n`n$($voceCorrente.Warn)`n`nProcedo?",
                                        'Conferma', 'YesNo', 'Warning')
                                    if ($r -ne 'Yes') { return }
                                }
                                $s2.IsEnabled = $false
                                $win.Cursor = [Windows.Input.Cursors]::Wait
                                try {
                                    $res = Invoke-VtPulizia $voceCorrente
                                    $msg = "Liberati $($res.Mb) MB."
                                    if ($res.Errori -gt 0) { $msg += "`n`n$($res.Errori) file erano in uso e sono stati saltati: e' normale, si tolgono al prossimo riavvio." }
                                    Show-Toast $msg
                                } catch { Show-Toast $_.Exception.Message }
                                finally { $win.Cursor = $null }
                                Update-Contenuto
                            }.GetNewClosure() $col))
                        } else {
                            [void] $lista.Children.Add((New-InfoCard "$($v.Nome)  -  $etichetta" ($testo -join "`n`n") '#8C6167'))
                        }
                    }
                } finally {
                    $win.Cursor = $null
                    $sender.IsEnabled = $true
                    $sender.Content = 'Rianalizza'
                }
                $riepilogo.Text = "Totale recuperabile: $([math]::Round($totale,1)) MB. Le voci qui sotto si eliminano una per una, cosi' sai sempre cosa stai togliendo."
                $riepilogo.Foreground = New-Brush '#4ADE80'
            }.GetNewClosure()
        [void] $Contenuto.Children.Add($cardScan)

        $box = New-CardShell '#FFB454'
        $sp = New-Object Windows.Controls.StackPanel
        $sp.Margin = [Windows.Thickness]::new(20, 14, 20, 14)
        [Windows.Controls.Grid]::SetColumn($sp, 1)
        [void] $sp.Children.Add($riepilogo)
        [void] $box.Corpo.Children.Add($sp)
        [void] $Contenuto.Children.Add($box.Card)

        [void] $Contenuto.Children.Add($lista)

        [void] $Contenuto.Children.Add((New-ActionCard 'Compatta l''archivio componenti di Windows' `
            "E' l'unica pulizia che libera davvero parecchi GB su un Windows vecchio di qualche anno: rimuove le versioni superate dei componenti di sistema rimaste dopo gli aggiornamenti.`n`nLa fa DISM, lo strumento di Microsoft, non io. Ci mette qualche minuto e durante l'operazione il PC puo' sembrare lento. Serve l'amministratore." `
            'Avvia la compattazione' {
                $r = [Windows.MessageBox]::Show(
                    "DISM impieghera' qualche minuto e nel frattempo il PC potrebbe rallentare.`n`nDopo non potrai piu' disinstallare gli aggiornamenti gia' installati. Procedo?",
                    'Compattazione componenti', 'YesNo', 'Question')
                if ($r -ne 'Yes') { return }
                $win.Cursor = [Windows.Input.Cursors]::Wait
                try { Show-Toast (Invoke-VtDism) } catch { Show-Toast $_.Exception.Message } finally { $win.Cursor = $null }
            } '#FFB454'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa NON cancello, e perche''' `
            @(
                "Prefetch - cancellarlo RALLENTA gli avvii finche' Windows non lo ricostruisce. E' il tweak piu' diffuso e piu' controproducente che esista: se un programma te lo propone come ottimizzazione, sai gia' quanto vale il resto.",
                "File di paging e punti di ripristino - sono reti di sicurezza. Toglierli non da' FPS, toglie solo il paracadute.",
                "Download, Documenti, Immagini - sono roba tua, non spazzatura. Nessun programma dovrebbe decidere al posto tuo.",
                "Cache dei browser - sono dati tuoi, e svuotarle rende la navigazione piu' lenta per giorni senza darti niente in cambio."
            ) -join "`n`n" '#FF7A5C'))
        return
    }

    if ($cat -eq '#rete') {
        $nic = @(Get-VtNicAdapters)
        if ($nic.Count -eq 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessuna scheda di rete fisica attiva' `
                'Le impostazioni della scheda compaiono solo con un collegamento attivo. Se sei in Wi-Fi, molte di queste voci non esistono proprio.' '#FBBF24'))
        } else {
            foreach ($a in $nic) {
                $tipo = if ($a.InterfaceDescription -match 'Wi-?Fi|Wireless|802\.11|AX2|Dual Band') { 'Wi-Fi' } else { 'Ethernet (cavo)' }
                $righe = @(
                    "Scheda    : $($a.InterfaceDescription)"
                    "Tipo      : $tipo"
                    "Velocita' : $($a.LinkSpeed)"
                )
                $col = '#4ADE80'
                if ($tipo -eq 'Wi-Fi') {
                    $righe += ''
                    $righe += "Sei in Wi-Fi. Nessuna impostazione qui sotto recupera i millisecondi che aggiunge il collegamento radio: il cavo resta la modifica singola piu' efficace sulla latenza."
                    $col = '#FBBF24'
                } elseif ($a.LinkSpeed -match '^(10|100) Mbps') {
                    $righe += ''
                    $righe += "Il collegamento e' negoziato sotto il gigabit: cavo vecchio o rovinato, oppure porta del router a 100. Per il ping non cambia nulla, per i download si'."
                    $col = '#FBBF24'
                }
                [void] $Contenuto.Children.Add((New-InfoCard 'La tua connessione' ($righe -join "`n") $col))
            }
        }

        foreach ($t in (Get-VtCatalog | Where-Object { $_.Cat -eq 'Rete' })) {
            [void] $Contenuto.Children.Add((New-TweakCard $t))
        }

        if ($nic.Count -gt 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Cosa aspettarti da queste voci' `
                "Non danno FPS: agiscono sul ritardo e sulla regolarita' con cui i pacchetti arrivano e partono. Si sentono sul registro dei colpi, non sul contatore dei frame.`n`nOgni scheda espone un insieme diverso di impostazioni: quelle che il tuo driver non ha vengono saltate in silenzio, non forzate. Se un interruttore resta spento anche dopo averlo attivato, vuol dire che il tuo hardware non ha nessuna di quelle voci." '#B58F94'))
        }
        return
    }

    if ($cat -eq '#stabilita') {
        [void] $Contenuto.Children.Add((New-InfoCard 'Media alta, scatti lo stesso: perche''' `
            "Gli FPS medi non dicono niente sugli scatti. Quello che senti come micro-stutter e' quasi sempre tempo che il kernel toglie ai thread del gioco per servire i driver: DPC (lavoro differito) e ISR (interrupt hardware).`n`nSe un driver tiene la CPU in DPC troppo a lungo, il frame dopo arriva in ritardo e tu lo vedi, anche con 300 FPS di media. Qui lo misuriamo davvero invece di indovinare." '#FFB454'))

        # La misura richiede qualche secondo: se la facessi in un ciclo qui
        # dentro la finestra resterebbe bloccata. Campiono con un timer e
        # aggiorno la card mentre va.
        $risultato = New-Object Windows.Controls.TextBlock
        $risultato.FontSize = 12
        $risultato.Foreground = New-Brush '#B58F94'
        $risultato.TextWrapping = 'Wrap'
        $risultato.Text = 'Nessuna misura ancora eseguita. Per un risultato utile lasciala girare mentre NON stai facendo altro, oppure mentre un gioco e'' aperto in finestra.'

        $cardMis = New-ActionCard 'Misura la stabilita''' `
            "Campiona per 10 secondi il tempo che la CPU passa in DPC e in interrupt, e quanto sono regolari. Non installa niente: legge i contatori di Windows." `
            'Avvia la misura (10 s)' {
                param($sender, $e)
                $sender.IsEnabled = $false
                $sender.Content = 'Misura in corso...'
                $campioni = New-Object System.Collections.ArrayList
                $t = New-Object Windows.Threading.DispatcherTimer
                $t.Interval = [TimeSpan]::FromMilliseconds(1000)
                $t.Add_Tick({
                    try { [void] $campioni.Add((Get-VtStabilitySample)) } catch { }
                    $risultato.Text = "Misura in corso... $($campioni.Count)/10 campioni"
                    if ($campioni.Count -ge 10) {
                        $t.Stop()
                        $v = Get-VtStabilityVerdetto $campioni
                        $righe = @(
                            "Esito: $($v.Stato)"
                            ''
                            "Tempo in DPC       : $($v.DpcMedio)% medio, picco $($v.DpcMax)%"
                            "Tempo in interrupt : $($v.IsrMedio)% medio"
                            "Interrupt al secondo: $($v.IntMedio) medi, picco $($v.IntMax) ($($v.Picco)x)"
                        )
                        if ($v.Problemi.Count -gt 0) {
                            $righe += ''
                            $righe += 'Cosa non va:'
                            $righe += ($v.Problemi | ForEach-Object { "  -  $_" })
                        } else {
                            $righe += ''
                            $righe += 'Nessun segnale di driver che rubano tempo alla CPU. Se hai scatti lo stesso, guarda nel gioco: compilazione shader al primo giro, streaming texture da disco lento, o server affollato.'
                        }
                        $risultato.Text = $righe -join "`n"
                        $risultato.Foreground = New-Brush $(switch ($v.Stato) { 'BUONO' { '#4ADE80' } 'DA SISTEMARE' { '#F87171' } default { '#FBBF24' } })
                        Write-VtLog "Stabilita': $($v.Stato) - DPC $($v.DpcMedio)% (picco $($v.DpcMax)%), ISR $($v.IsrMedio)%"
                        $sender.IsEnabled = $true
                        $sender.Content = 'Ripeti la misura (10 s)'
                    }
                }.GetNewClosure())
                $t.Start()
            }.GetNewClosure()

        [void] $Contenuto.Children.Add($cardMis)

        $bordo = New-CardShell '#FFB454'
        $wrap = New-Object Windows.Controls.StackPanel
        $wrap.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
        [Windows.Controls.Grid]::SetColumn($wrap, 1)
        $ttl = New-Object Windows.Controls.TextBlock
        $ttl.Text = 'Risultato'; $ttl.FontSize = 13; $ttl.FontWeight = 'SemiBold'
        $ttl.Foreground = New-Brush '#F6E9EA'
        [void] $wrap.Children.Add($ttl)
        $risultato.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
        [void] $wrap.Children.Add($risultato)
        [void] $bordo.Corpo.Children.Add($wrap)
        [void] $Contenuto.Children.Add($bordo.Card)

        # --- le due voci che agiscono sulla regolarita' --------------------
        $tit = New-Object Windows.Controls.TextBlock
        $tit.Text = 'Voci che agiscono sulla regolarita'''
        $tit.FontSize = 17; $tit.FontWeight = 'Bold'; $tit.Foreground = New-Brush '#F6E9EA'
        $tit.Margin = [Windows.Thickness]::new(0, 18, 0, 10)
        [void] $Contenuto.Children.Add($tit)

        foreach ($t in (Get-VtCatalog | Where-Object { $_.Cat -eq 'Stabilita' })) {
            [void] $Contenuto.Children.Add((New-TweakCard $t))
        }

        $nota = New-Object Windows.Controls.TextBlock
        $nota.Text = 'Altre voci che aiutano la regolarita'' stanno gia'' nelle loro sezioni: parcheggio core e frequenza minima CPU in Energia, priorita'' I/O e profilo multimediale in CPU, kernel sempre in RAM in Memoria. Il profilo Competitive le accende tutte.'
        $nota.FontSize = 12; $nota.Foreground = New-Brush '#B58F94'
        $nota.TextWrapping = 'Wrap'; $nota.Margin = [Windows.Thickness]::new(0, 4, 0, 14)
        [void] $Contenuto.Children.Add($nota)

        # --- interrupt MSI ------------------------------------------------
        $msi = @(Get-VtMsiStato | Where-Object { $_.Tipo -eq 'Display' })
        if ($msi.Count -gt 0) {
            foreach ($m in $msi) {
                $ok = $m.Msi
                $txt = if ($ok) {
                    "Gli interrupt della scheda video sono di tipo MSI (message signaled): e' la modalita' giusta, non c'e' niente da fare.`n`nCon gli interrupt a linea condivisa la GPU deve aspettare che la linea si liberi, e quell'attesa diventa latenza DPC, cioe' scatti."
                } else {
                    "La scheda video usa interrupt a linea condivisa invece che MSI. Passare a MSI riduce la latenza DPC, ma NON lo faccio da qui: forzarlo su un dispositivo che non lo gestisce bene puo' impedire l'avvio del PC, e ripararlo richiede la modalita' provvisoria. Se vuoi provarci, fallo consapevolmente con uno strumento dedicato e con un punto di ripristino pronto."
                }
                [void] $Contenuto.Children.Add((New-InfoCard "Interrupt della GPU: $(if ($ok) { 'MSI (corretto)' } else { 'linea condivisa' })" "$($m.Nome)`n`n$txt" $(if ($ok) { '#4ADE80' } else { '#FBBF24' })))
            }
        }

        # --- programmi che disturbano -------------------------------------
        $dist = @(Get-VtDisturbatori)
        if ($dist.Count -gt 0) {
            $el = ($dist | ForEach-Object { "  -  $($_.N): $($_.Nota)" }) -join "`n"
            [void] $Contenuto.Children.Add((New-InfoCard "$($dist.Count) programmi che possono causare scatti sono aperti adesso" `
                "$el`n`nNon li tocco: alcuni ti servono. Ma se la misura qui sopra segnala interrupt a ondate, prova a chiuderli e a rifarla: la differenza si vede subito.`n`nQuelli con polling dei sensori (Afterburner, HWiNFO) spesso basta rallentarli, portando l'intervallo di campionamento a 1000-2000 ms." '#FBBF24'))
        } else {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun programma disturbatore noto in esecuzione' `
                "Non ho trovato aperti software RGB, overlay o monitor hardware fra quelli che tipicamente generano interrupt a ondate." '#4ADE80'))
        }
        return
    }

    if ($cat -eq '#nvidia' -or $cat -eq '#amd') {
        $vend = Get-VtGpuVendor
        $atteso = if ($cat -eq '#nvidia') { 'NVIDIA' } else { 'AMD' }
        $r = Get-VtRiepilogo

        if ($vend -ne $atteso) {
            [void] $Contenuto.Children.Add((New-InfoCard "Nessuna scheda $atteso rilevata" `
                "Su questo PC ho trovato: $($r.Gpu).`n`nQuesta pagina resta comunque leggibile: le voci qui sotto sono quelle da mettere su una scheda $atteso, se un domani ne monti una o se stai sistemando il PC di qualcun altro." '#FBBF24'))
        } else {
            [void] $Contenuto.Children.Add((New-InfoCard 'Scheda rilevata' "$($r.Gpu)`n$($r.GpuDett)"))
        }

        # --- quello che si puo' davvero eseguire -------------------------
        if ($vend -eq $atteso) {
            $eseguibili = @(Get-VtCatalog | Where-Object {
                $_.Cat -eq 'Scheda video' -and
                ($cat -eq '#nvidia' -and $_.Id -like 'nv-*' -or $_.Id -in 'hags', 'gpu-preferenza-giochi')
            })
            if ($eseguibili.Count -gt 0) {
                $tE = New-Object Windows.Controls.TextBlock
                $tE.Text = 'Queste le applico io'
                $tE.FontSize = 17; $tE.FontWeight = 'Bold'; $tE.Foreground = New-Brush '#F6E9EA'
                $tE.Margin = [Windows.Thickness]::new(0, 16, 0, 4)
                [void] $Contenuto.Children.Add($tE)

                $sE = New-Object Windows.Controls.TextBlock
                $sE.Text = 'Sono le sole voci della scheda video che Windows lascia scrivere a un programma. Le trovi anche in Prestazioni > GPU: sono le stesse, non doppioni.'
                $sE.FontSize = 12; $sE.Foreground = New-Brush '#B58F94'
                $sE.TextWrapping = 'Wrap'; $sE.Margin = [Windows.Thickness]::new(0, 0, 0, 10)
                [void] $Contenuto.Children.Add($sE)

                foreach ($t in $eseguibili) { [void] $Contenuto.Children.Add((New-TweakCard $t)) }
            }

            # L'overlay non e' spegnibile da script, ma quanto costa si misura.
            $ov = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'NVIDIA Overlay|nvcontainer' })
            if ($ov.Count -gt 0) {
                $mb = [math]::Round((($ov | Measure-Object WorkingSet64 -Sum).Sum) / 1MB)
                [void] $Contenuto.Children.Add((New-InfoCard "Overlay NVIDIA: $($ov.Count) processi, $mb MB di RAM" `
                    "L'overlay si aggancia al rendering di ogni gioco, e questa e' la memoria che occupa adesso sul tuo PC.`n`nNon posso spegnerlo da qui: l'impostazione non sta in nessun file scrivibile (ho guardato, storage.json e overrides.json sono vuoti). Si toglie dall'app NVIDIA: Impostazioni > Overlay di gioco, e lo metti su Off.`n`nSe non usi la registrazione istantanea ne' il contatore FPS di NVIDIA, e' RAM e frame time regalati." '#FBBF24'))
            }
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' il resto non lo imposto io' `
            @(
                "Le impostazioni 3D (bassa latenza, gestione alimentazione, V-Sync) stanno in un database binario del driver, nvdrsdb0.bin, da 2,5 MB: si scrive solo con la libreria nativa del produttore, NVAPI. Scriverci alla cieca da uno script significa rischiare di corrompere i profili e ritrovarsi giochi che partono con impostazioni a caso.",
                "Anche la vividezza digitale passa da li'. Ho provato la strada alternativa, la rampa gamma di Windows: su questo PC il driver non la espone proprio, la lettura fallisce. Un preset di colore eseguibile sarebbe finto.",
                "Il limite di potenza della scheda si potrebbe cambiare con nvidia-smi, ma la tua e' gia' al massimo consentito: non c'e' niente da guadagnare, solo da perdere.",
                "Quindi faccio come per il BIOS: ti apro il pannello con un clic e ti dico esattamente cosa mettere e perche'. Sono una decina di clic, si fanno una volta sola."
            ) -join "`n`n" '#FBBF24'))

        $pan = Get-VtPannelloGpu
        if ($pan) {
            [void] $Contenuto.Children.Add((New-ActionCard 'Apri il pannello' `
                "Apre $($pan.Nome) direttamente, senza cercarlo nel menu Start." 'Apri il pannello' {
                    try { Open-VtPannelloGpu } catch { Show-Toast $_.Exception.Message }
                }))
        } elseif ($vend -eq $atteso) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Pannello non trovato' `
                "Non ho trovato il pannello installato. Su NVIDIA si scarica dal Microsoft Store ('Pannello di controllo NVIDIA'), su AMD e' dentro AMD Software: Adrenalin Edition." '#FBBF24'))
        }

        $tit = New-Object Windows.Controls.TextBlock
        $tit.Text = 'Impostazioni 3D, in ordine di importanza'
        $tit.FontSize = 17; $tit.FontWeight = 'Bold'; $tit.Foreground = New-Brush '#F6E9EA'
        $tit.Margin = [Windows.Thickness]::new(0, 16, 0, 10)
        [void] $Contenuto.Children.Add($tit)

        $guida = if ($cat -eq '#nvidia') { Get-VtGuidaNvidia } else { Get-VtGuidaAmd }
        foreach ($g in $guida) {
            [void] $Contenuto.Children.Add((New-InfoCard "$($g.Voce)  ->  $($g.Valore)" $g.Perche '#FF3B4E'))
        }

        $tit2 = New-Object Windows.Controls.TextBlock
        $tit2.Text = 'Colore: come vedere meglio i nemici'
        $tit2.FontSize = 17; $tit2.FontWeight = 'Bold'; $tit2.Foreground = New-Brush '#F6E9EA'
        $tit2.Margin = [Windows.Thickness]::new(0, 20, 0, 4)
        [void] $Contenuto.Children.Add($tit2)

        $sub2 = New-Object Windows.Controls.TextBlock
        $sub2.Text = 'Queste non danno FPS: danno leggibilita''. Un modello che stacca dallo sfondo lo vedi mezzo secondo prima, e mezzo secondo in un duello vale piu'' di venti frame.'
        $sub2.FontSize = 12; $sub2.Foreground = New-Brush '#B58F94'
        $sub2.TextWrapping = 'Wrap'; $sub2.Margin = [Windows.Thickness]::new(0, 0, 0, 10)
        [void] $Contenuto.Children.Add($sub2)

        $colori = if ($cat -eq '#nvidia') { Get-VtGuidaColoriNvidia } else { Get-VtGuidaColoriAmd }
        foreach ($g in $colori) {
            [void] $Contenuto.Children.Add((New-InfoCard "$($g.Voce)  ->  $($g.Valore)" $g.Perche '#FFB454'))
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Un avvertimento onesto sui colori' `
            "La vividezza alta e' legale e non e' un cheat, ma e' anche una scorciatoia: ti abitua a cercare la macchia colorata invece della sagoma. Se esageri e poi giochi su un altro PC, ti trovi peggio di prima. Tienila dove ti aiuta, non dove ti droga l'occhio.`n`nE ricorda che queste impostazioni valgono per il monitor collegato adesso: se ne cambi uno, vanno rifatte." '#FF7A5C'))
        return
    }

    if ($cat -eq '#discord') {
        $st = Get-VtDiscordStato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Discord non risulta installato' `
                "Cercato settings.json in %APPDATA%\discord. Se usi la versione dal browser non c'e' niente da ottimizzare: il peso ce l'ha il browser, non Discord." '#FBBF24'))
            return
        }

        $accelTxt = switch ($st.Accelerazione) {
            $true  { 'accesa (impostata a mano)' }
            $false { 'spenta' }
            default { 'accesa (valore predefinito)' }
        }
        $riass = @(
            "Processi aperti adesso : $($st.Processi)"
            "RAM occupata           : $($st.RamMb) MB"
            "Accelerazione hardware : $accelTxt"
            "Processo GPU attivo    : $(if ($st.ProcessoGpu) { "SI, $($st.GpuMb) MB" } else { 'no' })"
            "Cache su disco         : $($st.CacheMb) MB"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo Discord adesso' $riass))

        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Discord e'' aperto' `
                "Chiudilo del tutto prima di toccare le impostazioni, anche dall'icona vicino all'orologio: quando esce riscrive settings.json e cancellerebbe la modifica. I pulsanti si rifiutano di partire finche' lo trovano aperto." '#F87171'))
        }

        # Interruttori veri, con backup e ripristino come tutti gli altri.
        foreach ($t in (Get-VtCatalog | Where-Object { $_.Cat -eq 'Discord' })) {
            [void] $Contenuto.Children.Add((New-TweakCard $t))
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Come verificare che abbiano funzionato' `
            "Applica, chiudi Discord del tutto (anche dall'icona vicino all'orologio), riaprilo e torna qui.`n`nAccelerazione hardware: la riga 'Processo GPU attivo' deve diventare 'no'.`n`nOverlay: entra in un gioco e prova la scorciatoia dell'overlay (di solito MAIUSC+`) - non deve comparire niente." '#FFB454'))

        if ($st.CacheMb -gt 50) {
            [void] $Contenuto.Children.Add((New-InfoCard "Cache: $($st.CacheMb) MB da recuperare" `
                "La trovi in Sistema > Pulizia file, voce 'Cache di Discord'. Chiudi Discord prima, altrimenti i file sono in uso e ne resta indietro la maggior parte." '#FFB454'))
        }

        # L'overlay: modulo presente su disco, ma l'interruttore sta nel
        # database interno di Discord. Lo rileviamo e spieghiamo, non lo
        # forziamo: vedi la card sotto.
        $modOv = @(Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Discord') -Directory -Recurse -Depth 3 -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -like 'discord_overlay*' -or $_.Name -like 'discord_desktop_overlay*' })
        $ovAttivo = $false
        try {
            $ovAttivo = @(Get-CimInstance Win32_Process -Filter "Name='Discord.exe'" -ErrorAction SilentlyContinue |
                          Where-Object { $_.CommandLine -match 'overlay' }).Count -gt 0
        } catch { }

        [void] $Contenuto.Children.Add((New-InfoCard 'Come funziona l''interruttore dell''overlay' `
            @(
                "L'impostazione dell'overlay sta nel database interno di Discord, in formato binario: scriverci dentro rischierebbe di azzerare tutte le tue impostazioni. Quindi agisco altrove.",
                "L'overlay e' un modulo a se', in una sua cartella dentro Discord\modules. Spegnendolo, quella cartella viene rinominata: Discord non la trova e il modulo non parte. Sul tuo PC i moduli sono $($modOv.Count), e in questo momento l'overlay risulta $(if ($ovAttivo) { 'ATTIVO' } else { 'non in esecuzione' }).",
                "Non viene cancellato niente: riaccendendo l'interruttore il nome torna quello di prima.",
                "L'unico limite onesto: un aggiornamento di Discord puo' rimettere il modulo al suo posto. Non e' un guasto silenzioso, perche' l'interruttore legge la situazione vera del disco e si mostra spento da solo: te ne accorgi e ricliccki."
            ) -join "`n`n" '#FFB454'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa non tocco, e perche''' `
            "Avvio automatico: sul tuo PC Discord non e' in avvio automatico, quindi non c'e' niente da togliere. Non aggiungo interruttori per cose che sul tuo sistema non esistono.`n`nQualita' del servizio vocale, riduzione del rumore, codec: sono impostazioni del tuo account e cambiarle dall'esterno vorrebbe dire indovinare. Stanno in Discord > Voce e video." '#B58F94'))
        return
    }

    if ($cat -eq '#fortnite') {
        $p = Get-VtFortnitePaths
        if (-not $p.Esiste) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Configurazione di Fortnite non trovata' "Non ho trovato GameUserSettings.ini in:`n$($p.Dir)`n`nAvvia Fortnite una volta e richiudilo: il file lo crea il gioco al primo avvio." '#FBBF24'))
            return
        }

        $st = Get-VtFortniteStato
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Fortnite e'' aperto adesso' "Chiudi il gioco prima di toccare qualcosa qui. Fortnite riscrive GameUserSettings.ini quando esce, quindi qualsiasi modifica fatta ora verrebbe cancellata. I pulsanti si rifiutano di partire finche' e' aperto." '#F87171'))
        }

        $riass = @(
            "Risoluzione      : $($st.Risoluzione)"
            "Limite FPS       : $($st.Fps)"
            "Modalita' schermo: $($st.Modalita)"
            "Rendering        : $($st.Rendering)"
            "NVIDIA Reflex    : $($st.Reflex)"
            "Risoluzione 3D   : $($st.Res3D)%"
            "V-Sync           : $($st.VSync)"
            "File bloccato    : $(if ($st.SolaLettura) { 'SI (sola lettura)' } else { 'no' })"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo il gioco adesso' $riass))

        [void] $Contenuto.Children.Add((New-ActionCard 'Preset competitivo' `
            "Modalita' Prestazioni, ombre ed effetti a zero, anti-aliasing off, motion blur off, erba off, Reflex On + Boost, schermo intero esclusivo, V-Sync off, risoluzione 3D al 100% e limite FPS agganciato al tuo monitor ($(Get-VtMonitorHz) Hz).`n`nLa risoluzione 3D la porta a 100: piu' nitido e bersagli piu' leggibili. Se preferisci qualche FPS in piu' a costo di un'immagine piu' morbida, in gioco rimettila a 90." `
            'Applica il preset' {
                try {
                    $hz = Invoke-VtFortnitePreset
                    Show-Toast "Preset applicato. Limite FPS impostato a $hz."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        $hz = Get-VtMonitorHz
        [void] $Contenuto.Children.Add((New-ActionCard "Blocca gli FPS a $hz (refresh del monitor)" `
            "Imposta il limite FPS al refresh reale del tuo schermo senza attivare il V-Sync.`n`nA cosa serve: sopra il refresh gli FPS in piu' non li vedi, ma la GPU li calcola lo stesso, scalda e alza il frame time. Con un limite fisso il frame time diventa regolare, ed e' quello che si sente." `
            "Blocca a $hz FPS" {
                try { Set-VtFortniteFpsLimit (Get-VtMonitorHz); Show-Toast 'Limite FPS impostato.'; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        [void] $Contenuto.Children.Add((New-ActionCard 'FPS illimitati' `
            "Toglie del tutto il limite interno di Fortnite.`n`nHa senso solo se usi Reflex (che gestisce la coda da solo) o se stai facendo dei test. Nell'uso normale il limite agganciato al monitor da' un frame time piu' costante." `
            'Togli il limite' {
                try { Set-VtFortniteFpsLimit 0; Show-Toast 'Limite FPS rimosso.'; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        [void] $Contenuto.Children.Add((New-ChoiceCard 'Compromesso FPS / nitidezza' `
            "Le tre voci che pesano davvero, in un solo gradino: risoluzione 3D, distanza visuale e limite FPS.`n`nSe dopo il preset ti sembra di aver perso frame, e' quasi sempre questo: il preset alza la risoluzione 3D al 100% e la distanza visuale, che si vedono meglio ma costano. Scegli 'Massimo FPS' e torni indietro.`n`nAttenzione al contatore: con il limite agganciato al monitor leggerai $(Get-VtMonitorHz) invece di 300, ma sopra il refresh del tuo schermo quei frame non li vedevi comunque." `
            $script:VtQualitaFn 'Applica' {
                param($sender, $e)
                $cb = $sender.Tag
                $q  = $cb.Tag[$cb.SelectedIndex]
                try {
                    Set-VtFortniteQualita $q.Res $q.Vista $q.Fps
                    Show-Toast "Applicato: risoluzione 3D $($q.Res)%, distanza visuale $($q.Vista)."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        $rx = 0; $ry = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $rx = [int]$matches[1]; $ry = [int]$matches[2] }
        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'Fortnite' $rx $ry {
            param($x, $y) Set-VtFortniteResolution $x $y
        }))

        [void] $Contenuto.Children.Add((New-ChoiceCard 'Risoluzione (scelte pronte)' `
            "Scrive la risoluzione dentro Fortnite e forza lo schermo intero esclusivo.`n`nPerche' la stretched si veda davvero devi anche impostare, nel Pannello NVIDIA > Regola dimensioni e posizione del desktop: Modalita' di ridimensionamento su 'Schermo intero' ed 'Esegui ridimensionamento su: GPU'. Senza quello ti ritrovi due bande nere ai lati invece dei modelli piu' larghi." `
            $script:VtRisoluzioni 'Applica' {
                param($sender, $e)
                $cb = $sender.Tag
                $r  = $cb.Tag[$cb.SelectedIndex]
                try {
                    Set-VtFortniteResolution $r.X $r.Y
                    Show-Toast "Risoluzione impostata a $($r.X)x$($r.Y)."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        if ($st.SolaLettura) {
            [void] $Contenuto.Children.Add((New-ActionCard 'Sblocca il file di configurazione' `
                "Il file e' in SOLA LETTURA: qualcuno l'ha bloccato (SapoTweak lo fa) perche' Fortnite non possa riscriverlo.`n`nEffetto collaterale: anche le impostazioni che cambi TU dal menu del gioco non vengono piu' salvate. Se ti sembra che il gioco 'dimentichi' le opzioni, e' questo." `
                'Sblocca il file' {
                    try { Set-VtFortniteReadOnly $false; Show-Toast 'File sbloccato.'; Update-Contenuto }
                    catch { Show-Toast $_.Exception.Message }
                } '#FBBF24'))
        } else {
            [void] $Contenuto.Children.Add((New-ActionCard 'Blocca il file di configurazione' `
                "Mette GameUserSettings.ini in sola lettura, cosi' Fortnite non puo' riscriverlo all'uscita e le impostazioni restano quelle.`n`nAttenzione: da quel momento nemmeno le modifiche che fai TU dal menu del gioco vengono salvate. Bloccalo solo quando hai finito di sistemare tutto." `
                'Blocca il file' {
                    try { Set-VtFortniteReadOnly $true; Show-Toast 'File bloccato in sola lettura.'; Update-Contenuto }
                    catch { Show-Toast $_.Exception.Message }
                }))
        }

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            "Rimette il GameUserSettings.ini come stava prima dell'ultima modifica fatta da VejaTweak. Una copia viene fatta automaticamente prima di ogni azione di questa pagina (ne teniamo le cinque piu' recenti)." `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtFortnite; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#FBBF24'))

        return
    }

    if ($cat -eq '#valorant') {
        $st = Get-VtValorantStato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Configurazione di Valorant non trovata' "Cercata in %LOCALAPPDATA%\VALORANT\Saved\Config. Avvia il gioco una volta e richiudilo: i file li crea Valorant al primo avvio." '#FBBF24'))
            return
        }
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Valorant o il Riot Client sono aperti' "Chiudili entrambi prima di toccare qualcosa: alla chiusura riscrivono i file di configurazione e le modifiche verrebbero perse. I pulsanti si rifiutano di partire finche' sono aperti." '#F87171'))
        }
        $riass = @(
            "Risoluzione    : $($st.Risoluzione)"
            "Limite FPS     : $($st.Fps)"
            "V-Sync         : $($st.VSync)"
            "Anti-aliasing  : $($st.AntiAlias)"
            "Materiali      : $($st.Materiali)"
            "Texture        : $($st.Texture)"
            "Dettaglio      : $($st.Dettaglio)"
            "Ombre          : $($st.Ombre)"
            "Migliora nitidezza: $($st.Chiarezza)"
            "NVIDIA Reflex  : $($st.Reflex)"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo Valorant adesso' $riass))

        $hz = Get-VtMonitorHz
        [void] $Contenuto.Children.Add((New-ActionCard 'Preset competitivo' `
            "Anti-aliasing off, materiali/texture/dettaglio al minimo, ombre off, 'Migliora nitidezza' off, Reflex su On + Boost, V-Sync off, schermo intero, limite FPS a $hz.`n`nDue note oneste: l'anti-aliasing e' la voce piu' costosa e lo porto a zero, ma con la tua 4060 a 1080p MSAA 4x te lo potresti permettere: se preferisci i bordi puliti rimettilo dal menu del gioco. Il filtro anisotropico non lo tocco: su una GPU moderna e' praticamente gratis, spegnerlo sarebbe un guadagno finto." `
            'Applica il preset' {
                try { $h = Invoke-VtValorantPreset; Show-Toast "Preset applicato. Limite FPS a $h."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        [void] $Contenuto.Children.Add((New-ActionCard "Blocca gli FPS a $hz" `
            "Imposta il limite al refresh del monitor senza V-Sync, su entrambe le copie del file (quella dell'account e quella di macchina: Valorant ne tiene due e vanno tenute allineate)." `
            "Blocca a $hz FPS" {
                try { Set-VtValorantFps (Get-VtMonitorHz); Show-Toast 'Limite FPS impostato.'; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        $vx = 0; $vy = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $vx = [int]$matches[1]; $vy = [int]$matches[2] }
        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'Valorant' $vx $vy {
            param($x, $y) Set-VtValorantRisoluzione $x $y
        }))

        [void] $Contenuto.Children.Add((New-InfoCard 'Nota sulle stretched in Valorant' `
            "Quando imposto una risoluzione tolgo anche il letterbox, altrimenti Valorant ti mette due bande nere ai lati invece di allargare l'immagine: e' esattamente il contrario di quello che serve.`n`nPerche' la stretched si veda davvero serve anche il ridimensionamento a schermo intero sulla GPU, dal pannello NVIDIA." '#FFB454'))

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            "Rimette i file di Valorant come stavano prima dell'ultima modifica di VejaTweak." `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtValorant; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#FBBF24'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Vanguard' "Non tocchiamo il servizio vgc ne'' Vanguard in nessun modo: si scrivono solo i file di impostazioni del gioco, cioe' gli stessi che Valorant scrive da solo quando cambi le opzioni dal menu. Se qualche 'ottimizzatore' ti propone di disattivare vgc, il gioco poi non parte." '#FF7A5C'))
        return
    }

    if ($cat -eq '#fivem') {
        $st = Get-VtFivemStato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Impostazioni di FiveM non trovate' "Cercato %APPDATA%\CitizenFX\gta5_settings.xml. Avvia FiveM una volta e richiudilo.`n`nNota: FiveM NON usa il settings.xml di GTA V, ne tiene uno suo. Modificare quello di GTA V non cambia niente in FiveM." '#FBBF24'))
            return
        }
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'FiveM e'' aperto' 'Chiudilo prima: alla chiusura riscrive il file e le modifiche andrebbero perse.' '#F87171'))
        }
        $riass = @(
            "Risoluzione       : $($st.Risoluzione)"
            "Modalita' schermo : $($st.Finestra)"
            "V-Sync            : $($st.VSync)"
            "MSAA              : $($st.Msaa)"
            "Qualita' ombre    : $($st.Ombre)"
            "Distanza ombre    : $($st.DistanzaOmbre)"
            "Densita' citta'   : $($st.Citta)"
            "Varieta' pedoni   : $($st.Pedoni)"
            "Scala LOD         : $($st.Lod)"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo FiveM adesso' $riass))

        [void] $Contenuto.Children.Add((New-ActionCard 'Preset per server affollati' `
            "Densita' citta' e varieta' pedoni a meta', scala LOD a 0.7, distanza ombre a 0.4, ombre morbide e ombre delle particelle off, MSAA e riflessi a zero.`n`nPerche' proprio queste: FiveM e' CPU-bound, e su un server pieno il collo di bottiglia e' il numero di entita' che il singolo core deve gestire, non la grafica. Densita' citta' e varieta' pedoni sono le due voci che tolgono lavoro alla CPU invece che alla GPU: sono quelle che si sentono davvero quando il server e' pieno. La grafica sul tuo PC e' gia' tutta a zero." `
            'Applica il preset' {
                try {
                    $r = Invoke-VtFivemPreset
                    Show-Toast "Preset applicato: $($r.Applicate) voci modificate$(if ($r.Saltate.Count) { ", $($r.Saltate.Count) non presenti nel file" })."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        $fx = 0; $fy = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $fx = [int]$matches[1]; $fy = [int]$matches[2] }
        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'FiveM' $fx $fy {
            param($x, $y) Set-VtFivemRisoluzione $x $y | Out-Null
        }))

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            'Rimette gta5_settings.xml come stava prima dell''ultima modifica di VejaTweak.' `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtFivem; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#FBBF24'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Quello che pesa di piu'' non e'' qui' "Su FiveM i mod grafici lato client (NVE, QuantV e simili) costano piu' di qualunque impostazione di questa pagina, e i server con tante risorse personalizzate ti fanno crollare il frame time a prescindere dal PC. Se giochi su un server pesante, la differenza la fa il server, non tu." '#FF7A5C'))
        return
    }

    if ($cat -eq '#r6') {
        $r6 = Get-VtR6Settings
        $st = Get-VtR6Stato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Rainbow Six Siege non risulta installato' "Cercato GameSettings.ini in:`n$($r6.Base)\<id Ubisoft>\`n`nSe installi il gioco, avvialo una volta e riapri questa pagina: i controlli e il preset si attivano da soli." '#FBBF24'))
            [void] $Contenuto.Children.Add((New-InfoCard 'Vulkan invece di DX11' "Quando lo installi: scegli Vulkan dal menu di avvio di Ubisoft Connect, non dalle impostazioni del gioco. Su quasi tutte le configurazioni da' piu' FPS e frame time piu' stabile di DX11. Questa scelta non sta nel file di configurazione, quindi nessun tweaker puo' farla al posto tuo." '#FF7A5C'))
            return
        }
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Rainbow Six e'' aperto' 'Chiudilo prima di applicare qualcosa.' '#F87171'))
        }
        $riass = @(
            "Risoluzione   : $($st.Risoluzione)"
            "Schermo intero: $($st.SchermoIntero)"
            "V-Sync        : $($st.VSync)"
            "Refresh       : $($st.Refresh)"
            "Chiavi lette  : $($st.Chiavi)"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo R6 adesso' $riass))

        [void] $Contenuto.Children.Add((New-ActionCard 'Preset competitivo' `
            "Ombre, riflessi, occlusione ambientale, effetti lente e sfocatura al minimo; V-Sync off, schermo intero, refresh agganciato al monitor, render scaling 100.`n`nATTENZIONE, ed e' giusto che tu lo sappia: su questo PC R6 non era installato quando ho scritto questa parte, quindi i nomi delle chiavi non li ho potuti verificare sul file vero. Per questo il preset gira in modalita' prudente: modifica SOLO le chiavi gia' presenti nel tuo file e ne salta di sicuro qualcuna. Al termine ti dice quante ne ha applicate e quante saltate." `
            'Applica il preset' {
                try {
                    $r = Invoke-VtR6Preset
                    Show-Toast "Applicate $($r.Applicate) impostazioni. Saltate perche' non presenti nel file: $($r.Saltate.Count)."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        $r6x = 0; $r6y = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $r6x = [int]$matches[1]; $r6y = [int]$matches[2] }
        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'Rainbow Six' $r6x $r6y {
            param($x, $y) Set-VtR6Risoluzione $x $y | Out-Null
        }))

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            'Rimette GameSettings.ini come stava prima dell''ultima modifica di VejaTweak.' `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtR6; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#FBBF24'))
        return
    }

    if ($cat -eq '#bios') {
        $fw = Get-VtFirmware
        $g  = Get-VtBiosGuida

        $info = "Scheda madre: $($fw.Produttore) $($fw.Scheda)"
        if ($fw.Sistema) { $info += "  ($($fw.Sistema))" }
        $info += "`nBIOS: versione $($fw.Versione)"
        if ($fw.Data) { $info += " del $($fw.Data.ToString('dd/MM/yyyy'))" }
        $info += "`nModalita' di avvio: $(if ($fw.Uefi) { 'UEFI' } else { 'Legacy / CSM' })"
        [void] $Contenuto.Children.Add((New-InfoCard 'Il tuo firmware' $info))

        # Il punto in cui bisogna essere onesti, invece di far finta.
        $limite = @(
            'Nessun programma avviato da Windows puo'' scrivere le impostazioni del BIOS: stanno nella memoria del firmware, e il sistema operativo non ha alcun modo di modificarle. Non e'' una protezione da aggirare, e'' proprio l''assenza di un''interfaccia.',
            'Le utility dei produttori che sembrano farlo installano un driver in kernel mode firmato dal produttore stesso: e'' esattamente il tipo di driver che Vanguard, BattlEye ed EAC segnalano, ed e'' anche il modo piu'' rapido per non far piu'' avviare un PC.',
            'Quindi qui trovi le tre cose che si possono fare davvero: riconoscere cosa e'' sbagliato, portarti nel BIOS con un clic, e dirti dove sta la voce sul TUO modello di scheda.'
        ) -join "`n`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' non c''e'' un pulsante "applica tutto"' $limite '#FBBF24'))

        if ($fw.Uefi) {
            $testo = "Riavvia il PC ed entra direttamente nella schermata del BIOS, senza dover azzeccare il tasto al volo.`n`nSalva tutto quello che hai aperto prima di premere: il riavvio parte dopo 3 secondi."
            if (-not (Test-VtAdmin)) { $testo += "`n`nServe avviare VejaTweak come amministratore." }
            [void] $Contenuto.Children.Add((New-ActionCard 'Riavvia direttamente nel BIOS' $testo 'Riavvia nel BIOS ora' {
                $r = [Windows.MessageBox]::Show(
                    "Il PC si riavviera' fra 3 secondi e si fermera' nella schermata del BIOS.`n`nHai salvato tutto quello che stavi facendo?",
                    'Riavvio nel BIOS', 'YesNo', 'Warning')
                if ($r -ne 'Yes') { return }
                try { Invoke-VtRebootToFirmware }
                catch { Show-Toast "Non riuscito: $($_.Exception.Message)" }
            }))
        } else {
            [void] $Contenuto.Children.Add((New-InfoCard 'Riavvio diretto nel BIOS non disponibile' "Questo PC risulta avviato in modalita' Legacy/CSM invece che UEFI, e in quel caso Windows non puo' chiedere al firmware di fermarsi nel setup. Entra nel BIOS con il tasto qui sotto, subito dopo l'accensione." '#FBBF24'))
        }

        $comeEntrare = "Tasto da premere: $($g.Tasto)"
        if ($g.Note) { $comeEntrare += "`n`n$($g.Note)" }
        [void] $Contenuto.Children.Add((New-InfoCard 'Come entrare nel BIOS su questo PC' $comeEntrare))

        foreach ($f in (Get-VtBiosFindings)) {
            $col = switch ($f.Stato) { 'DA SISTEMARE' { '#F87171' } 'DA VERIFICARE' { '#FBBF24' } default { '#34D399' } }
            [void] $Contenuto.Children.Add((New-InfoCard "[$($f.Stato)]  $($f.Titolo)" $f.Testo $col))
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Dopo aver cambiato qualcosa' "Salva ed esci dal BIOS (di solito F10), fai ripartire Windows e riapri VejaTweak su questa pagina. I controlli qui sopra rileggono la situazione reale e ti dicono se la modifica ha fatto effetto davvero." '#FF7A5C'))
        return
    }

    if ($cat -eq '#giochi') {
        $g = @(Find-VtGiochi)
        if ($g.Count -eq 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun gioco rilevato' 'Non ho trovato Fortnite, Valorant, GTA V, FiveM o Rainbow Six nei percorsi standard. Se li hai installati altrove, la preferenza GPU va impostata a mano da Impostazioni > Schermo > Grafica.'))
        } else {
            foreach ($x in $g) {
                $pref = Get-VtReg 'HKCU:\SOFTWARE\Microsoft\DirectX\UserGpuPreferences' $x.Path
                $st = if ($pref -match 'GpuPreference=2') { 'forzato sulla GPU dedicata' } else { 'nessuna preferenza GPU impostata' }
                [void] $Contenuto.Children.Add((New-InfoCard $x.Nome ("$($x.Path)`n`nStato: $st")))
            }
        }
        foreach ($c in (Get-VtConsigli)) {
            [void] $Contenuto.Children.Add((New-InfoCard $c.Titolo $c.Testo '#FF7A5C'))
        }
        return
    }

    $lista = @(Get-VtCatalog | Where-Object { $_.Cat -eq $cat })
    if ($q) {
        $lista = @($lista | Where-Object { $_.Nome -like "*$q*" -or $_.Desc -like "*$q*" -or $_.Perche -like "*$q*" })
    }
    if ($lista.Count -eq 0) {
        [void] $Contenuto.Children.Add((New-InfoCard 'Nessun risultato' 'Nessun tweak di questa sezione corrisponde alla ricerca.'))
        return
    }
    foreach ($t in $lista) { [void] $Contenuto.Children.Add((New-TweakCard $t)) }
}

function Get-VtConsigli {
    $sys = Get-VtSystem
    $out = @()
    $out += [pscustomobject]@{ Titolo='Validi per tutti i giochi'; Testo=@(
        'V-Sync sempre off, nel gioco E nel pannello del driver: aggiunge fino a un frame intero di ritardo.',
        'Raw input attivo dove esiste: bypassa accelerazione e filtri di Windows.',
        'Schermo intero esclusivo dove il gioco lo offre: catena di presentazione piu'' corta.',
        'Ombre e post-processing sono i due cursori che pesano di piu'': abbassa quelli prima delle texture.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='Fortnite'; Testo=@(
        'Modalita'' rendering: Performance. DX11 e DX12 sono molto piu'' pesanti; Performance puo'' triplicare gli FPS.',
        'Ombre OFF, anti-aliasing OFF, effetti Bassi, post-processing Basso.',
        'Distanza visuale Epica: costa pochissimo e ti fa vedere i nemici lontani.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='Valorant'; Testo=@(
        'Limita FPS sempre: ON, con il limite al refresh del monitor.',
        'Multithreaded Rendering: ON, altrimenti usa un core solo.',
        'Ombre OFF, vignetta OFF, distorsione OFF, dettaglio e texture su Basso.',
        'Vanguard (vgc) deve restare attivo: se lo disattivi, il gioco non parte.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='GTA V e FiveM'; Testo=@(
        'MSAA OFF: e'' la voce che costa di piu'' in assoluto.',
        'Ombre Normali, riflessi MSAA off, ombreggiatura morbida "Piu'' nitida".',
        'Avanzate: ombre a lunga distanza OFF, popolazione a meta''.',
        'FiveM e'' CPU-bound: gli FPS li decide il singolo core, non la GPU. Su server affollati il frame time peggiora e non e'' colpa del tuo PC. I mod grafici tipo NVE o QuantV pesano piu'' di qualunque tweak di Windows.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='Rainbow Six Siege'; Testo=@(
        'API Vulkan: piu'' FPS e frame time piu'' stabile di DX11 su quasi tutte le configurazioni.',
        'Render scaling 100, ombre e riflessi Bassi.',
        'BattlEye deve restare attivo.'
    ) -join "`n`n" }

    if ($sys.Vendor -match 'NVIDIA') {
        $out += [pscustomobject]@{ Titolo='Pannello di controllo NVIDIA'; Testo=@(
            'Modalita'' a bassa latenza: Ultra. Se il gioco ha Reflex (Fortnite, Valorant, R6) usa quello e lascia stare il limite manuale.',
            'Gestione alimentazione: prestazioni massime. Sincronizzazione verticale: Off.',
            'Filtraggio texture qualita'': Prestazioni.'
        ) -join "`n`n" }
    }
    if ($sys.Vendor -match 'AMD|Radeon') {
        $out += [pscustomobject]@{ Titolo='AMD Adrenalin'; Testo=@(
            'Anti-Lag: On. Radeon Chill: Off. Sincronizzazione verticale: Off.',
            'Modalita'' texture: Prestazioni. Attenua tassellazione: Sostituisci, 8x.'
        ) -join "`n`n" }
    }
    $out
}

# ---------------------------------------------------------------------------
# Navigazione: quattro gruppi nella barra in alto
# ---------------------------------------------------------------------------
# Tag e' gia' impegnato dallo stile (Tag='on' accende l'indicatore ambra),
# quindi il nome del gruppo lo catturiamo in una closure invece di appoggiarlo
# sul controllo.
foreach ($g in $script:Gruppi) {
    $gruppo = $g
    $b = New-Object Windows.Controls.Button
    $b.Style   = $win.FindResource('GruppoBtn')
    $b.Content = $g.ToUpper()
    $b.Add_Click({
        Build-Sotto $gruppo
        # Entrando in un gruppo si apre la sua prima sezione.
        $prima = $script:Sezioni | Where-Object { $_.Gruppo -eq $gruppo } | Select-Object -First 1
        Show-Sezione $prima.Cat
    }.GetNewClosure())
    $script:BottoniGruppo[$g] = $b
    [void] $BarraGruppi.Children.Add($b)
}

# ---------------------------------------------------------------------------
# Eventi
# ---------------------------------------------------------------------------
$TxtSearch.Add_TextChanged({
    (Get-El 'TxtHint').Visibility = if ($TxtSearch.Text) { 'Collapsed' } else { 'Visible' }
    if ($script:SezioneAttiva -notlike '#*') { Update-Contenuto }
})

(Get-El 'BtnLog').Add_Click({
    $w = New-Object Windows.Window
    $w.Title = 'VejaTweak - registro attivita'''
    $w.Width = 900; $w.Height = 560
    $w.Background = New-Brush '#0E0A14'
    $w.WindowStartupLocation = 'CenterOwner'
    $w.Owner = $win
    $tb = New-Object Windows.Controls.TextBox
    $tb.Text = Get-VtLog
    $tb.IsReadOnly = $true
    $tb.Background = New-Brush '#151020'
    $tb.Foreground = New-Brush '#C8C0DA'
    $tb.BorderThickness = [Windows.Thickness]::new(0)
    $tb.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
    $tb.FontSize = 12
    $tb.VerticalScrollBarVisibility = 'Auto'
    $tb.Padding = [Windows.Thickness]::new(16)
    $w.Content = $tb
    [void] $w.ShowDialog()
})

(Get-El 'BtnReset').Add_Click({
    $r = [Windows.MessageBox]::Show(
        "Rimetto TUTTO com'era prima di VejaTweak?`n`nOgni tweak che hai attivato torna al valore che aveva sul tuo PC, uno per uno.",
        'Ripristina tutto', 'YesNo', 'Question')
    if ($r -ne 'Yes') { return }
    $win.Cursor = [Windows.Input.Cursors]::Wait
    try { $n = Reset-VtAll } finally { $win.Cursor = $null }
    Show-Toast "Ripristinati $n tweak. Riavvia il PC per completare."
    Update-Contenuto
})

(Get-El 'BtnAdmin').Add_Click({
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @(
            '-NoProfile', '-Sta', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
        $win.Close()
    } catch {
        Show-Toast 'Elevazione annullata.'
    }
})

# ---------------------------------------------------------------------------
# Indicatori CPU / GPU / RAM
#
# I contatori GPU costano circa un secondo a campione: se li leggessimo sul
# thread della UI la finestra si impianterebbe a ogni aggiornamento. Girano
# quindi in un runspace separato che scrive su una hashtable condivisa, e la
# UI si limita a leggerla.
# ---------------------------------------------------------------------------
$script:Sync = [hashtable]::Synchronized(@{ Cpu = 0; Gpu = 0; Ram = 0; Stop = $false })

$monitor = {
    while (-not $sync.Stop) {
        try {
            $sync.Cpu = [int] (Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'").PercentProcessorTime
        } catch { }
        try {
            $os = Get-CimInstance Win32_OperatingSystem
            $sync.Ram = [int] (100 * ($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize)
        } catch { }
        try {
            $g = (Get-Counter '\GPU Engine(*engtype_3D)\Utilization Percentage' -ErrorAction Stop).CounterSamples |
                 Measure-Object CookedValue -Sum
            $sync.Gpu = [int] [math]::Min(100, [math]::Round($g.Sum))
        } catch { }
        Start-Sleep -Milliseconds 900
    }
}

$rs = [runspacefactory]::CreateRunspace()
$rs.ApartmentState = 'MTA'
$rs.ThreadOptions  = 'ReuseThread'
$rs.Open()
$rs.SessionStateProxy.SetVariable('sync', $script:Sync)
$ps = [powershell]::Create()
$ps.Runspace = $rs
[void] $ps.AddScript($monitor)
$hMon = $ps.BeginInvoke()

$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(700)
$timer.Add_Tick({
    (Get-El 'TxtCpu').Text  = "$($script:Sync.Cpu)%"
    (Get-El 'BarCpu').Value = $script:Sync.Cpu
    (Get-El 'TxtGpu').Text  = "$($script:Sync.Gpu)%"
    (Get-El 'BarGpu').Value = $script:Sync.Gpu
    (Get-El 'TxtRam').Text  = "$($script:Sync.Ram)%"
    (Get-El 'BarRam').Value = $script:Sync.Ram
})

$win.Add_Closed({
    $script:Sync.Stop = $true
    $timer.Stop()
    try { $ps.Dispose(); $rs.Close(); $rs.Dispose() } catch { }
})

# ---------------------------------------------------------------------------
# Avvio
# ---------------------------------------------------------------------------
if (Test-VtAdmin) {
    $PanelAdmin.Visibility = 'Collapsed'
    $TxtAdmin.Text = 'amministratore'
} else {
    $PanelAdmin.Visibility = 'Visible'
    $BadgeAdmin.Background  = New-Brush '#2E1206'
    $BadgeAdmin.BorderBrush = New-Brush '#7A3410'
    $TxtAdmin.Foreground    = New-Brush '#FBBF24'
    $TxtAdmin.Text = 'utente normale'
}

Set-VtLogo

# --- licenza ---------------------------------------------------------------
# Il controllo sta qui, prima di mostrare la finestra principale. In modalita'
# collaudo si salta: serve a verificare le pagine, non l'attivazione.
$script:Licenza = Get-VtStatoLicenza
if (-not $script:Licenza.Attivo -and -not $SmokeTest) {
    Write-VtLog "Copia non attivata: $($script:Licenza.Motivo)" warn
    if (-not (Show-VtAttivazione)) {
        Write-VtLog 'Attivazione annullata, chiusura.' warn
        $script:Sync.Stop = $true
        try { $ps.Dispose(); $rs.Close() } catch { }
        exit 1
    }
    $script:Licenza = Get-VtStatoLicenza
}

$sysInfo = Get-VtSystem
$lic = if ($script:Licenza.Owner) { 'autore' }
       elseif ($script:Licenza.Scadenza) { "licenza $($script:Licenza.Serial), scade il $($script:Licenza.Scadenza.ToString('dd/MM/yyyy'))" }
       else { "licenza $($script:Licenza.Serial)" }
(Get-El 'TxtStato').Text = "$($sysInfo.Cpu)   |   $($sysInfo.GpuNome)   |   $($sysInfo.RamGB) GB   |   $lic"

Write-VtLog "VejaTweak $($script:Versione) avviato (admin: $(Test-VtAdmin))"
# GruppoAttivo parte vuoto apposta: cosi' la prima Show-Sezione costruisce
# anche la riga delle sezioni, che altrimenti resterebbe vuota.
$script:GruppoAttivo = ''
Show-Sezione '#octuning'

if ($SmokeTest) {
    # Attraversa tutte le sezioni: e' il modo piu' rapido per accorgersi che
    # una pagina non si costruisce, senza doverci cliccare sopra a mano.
    foreach ($s in $script:Sezioni) {
        Show-Sezione $s.Cat
        Write-Host ("  {0,-28} {1} card" -f $s.Titolo, $Contenuto.Children.Count)
    }
    $script:Sync.Stop = $true
    try { $ps.Dispose(); $rs.Close() } catch { }
    Write-Host "SMOKE OK - $($script:Sezioni.Count) sezioni, $((Get-VtCatalog).Count) tweak"
    exit 0
}

$timer.Start()

# Le letture costose (elenco attivita' pianificate, scansione dei giochi sui
# dischi) sono a carico della prima sezione che le usa. Le facciamo qui, subito
# dopo che la finestra e' comparsa: cosi' la pausa cade mentre l'utente sta
# ancora guardando la prima schermata, invece che al clic su Servizi o Giochi.
$warm = New-Object Windows.Threading.DispatcherTimer
$warm.Interval = [TimeSpan]::FromMilliseconds(400)
$warm.Add_Tick({
    $warm.Stop()
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        Get-VtAllTasks | Out-Null
        Find-VtGiochi  | Out-Null
        Write-VtLog "Cache pronta in $($sw.ElapsedMilliseconds) ms"
    } catch {
        Write-VtLog "Precaricamento non riuscito: $($_.Exception.Message)" warn
    }
})
$warm.Start()

[void] $win.ShowDialog()







