﻿<#
    VejaTweak - motore condiviso.

    Questo file NON si esegue da solo: lo caricano sia la GUI (VejaTweak.ps1)
    sia lo script a riga di comando. Contiene il catalogo dei tweak e le
    funzioni per leggerne lo stato, applicarli e annullarli uno per uno.

    Regola di fondo: ogni tweak sa tornare indietro. Prima di scrivere
    qualsiasi cosa salviamo il valore precedente in vejatweak-backup.json,
    indicizzato per Id del tweak, cosi' spegnere un interruttore ripristina
    esattamente quello che c'era prima e nient'altro.
#>

$script:VtRoot       = $PSScriptRoot
$script:VtBackupPath = Join-Path $PSScriptRoot 'vejatweak-backup.json'
$script:VtLogPath    = Join-Path $PSScriptRoot 'vejatweak.log'
$script:VtLog        = New-Object System.Collections.ArrayList

# ---------------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------------
function Write-VtLog {
    param([string] $Msg, [ValidateSet('info','ok','warn','err')] [string] $Level = 'info')
    $riga = '{0}  [{1}]  {2}' -f (Get-Date -Format 'HH:mm:ss'), $Level.ToUpper().PadRight(4), $Msg
    [void] $script:VtLog.Add($riga)
    try { Add-Content -Path $script:VtLogPath -Value $riga -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
    Write-Verbose $riga
}

function Get-VtLog { $script:VtLog -join [Environment]::NewLine }

function Test-VtAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

# powercfg e altri exe scrivono su stderr: passiamo da cmd per non far
# esplodere PowerShell quando ErrorActionPreference e' Stop.
function Invoke-VtCmd([string] $cmdline) {
    (cmd /c "$cmdline 2>nul") | Out-String
}

# ---------------------------------------------------------------------------
# Archivio dei valori precedenti
# ---------------------------------------------------------------------------
function Get-VtStore {
    if (-not (Test-Path $script:VtBackupPath)) { return @{} }
    try {
        $json = Get-Content $script:VtBackupPath -Raw -ErrorAction Stop | ConvertFrom-Json
        $h = @{}
        foreach ($p in $json.PSObject.Properties) { $h[$p.Name] = $p.Value }
        return $h
    } catch {
        Write-VtLog "Backup illeggibile, ne creo uno nuovo: $($_.Exception.Message)" warn
        return @{}
    }
}

function Save-VtStore($store) {
    try {
        $store | ConvertTo-Json -Depth 10 | Set-Content -Path $script:VtBackupPath -Encoding UTF8
    } catch {
        Write-VtLog "Impossibile salvare il backup: $($_.Exception.Message)" err
    }
}

function Get-VtEntry([string] $id) {
    $s = Get-VtStore
    if ($s.ContainsKey($id)) { return $s[$id] }
    return $null
}

function Set-VtEntry([string] $id, $data) {
    $s = Get-VtStore
    $s[$id] = $data
    Save-VtStore $s
}

function Remove-VtEntry([string] $id) {
    $s = Get-VtStore
    if ($s.ContainsKey($id)) { $s.Remove($id); Save-VtStore $s }
}

# ---------------------------------------------------------------------------
# Registro
# ---------------------------------------------------------------------------
function Get-VtReg([string] $path, [string] $name) {
    try { return (Get-ItemProperty -Path $path -Name $name -ErrorAction Stop).$name }
    catch { return $null }
}

function Set-VtReg([string] $path, [string] $name, [string] $type, $value) {
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
    New-ItemProperty -Path $path -Name $name -PropertyType $type -Value $value -Force | Out-Null
}

# ---------------------------------------------------------------------------
# Servizi
# ---------------------------------------------------------------------------
$script:VtStartMap = @{ 'Automatic' = 2; 'Manual' = 3; 'Disabled' = 4 }

function Get-VtServiceStart([string] $nome) {
    Get-VtReg "HKLM:\SYSTEM\CurrentControlSet\Services\$nome" 'Start'
}

function Set-VtServiceStart([string] $nome, [string] $start) {
    $svc = Get-Service -Name $nome -ErrorAction SilentlyContinue
    if (-not $svc) { return $false }
    Set-Service -Name $nome -StartupType $start -ErrorAction Stop
    if ($start -ne 'Automatic' -and $svc.Status -eq 'Running') {
        Stop-Service -Name $nome -Force -ErrorAction SilentlyContinue
    }
    return $true
}

# ---------------------------------------------------------------------------
# Informazioni di sistema (lette una volta sola: servono ai filtri del catalogo)
# ---------------------------------------------------------------------------
# --- Impostazioni di alimentazione, senza dipendere dalla lingua -----------
#
# powercfg /q stampa "Indice impostazione alimentazione CA corrente" in
# italiano, "AC Power Setting Index" in inglese e altro ancora nelle altre
# lingue: parsare quel testo vuol dire scrivere un tool che funziona solo
# sulle installazioni come la nostra. Il registro contiene lo stesso valore
# con un nome fisso in ogni lingua.
$script:VtPowerGuids = @{
    ProcSub     = '54533251-82be-4824-96c1-47b60b740d00'
    CoreParking = '0cc5b647-c1df-4637-891a-dec35c318583'
    ProcMin     = '893dee8e-2bef-41e0-89c6-b55d0929964c'
    PcieSub     = '501a4d13-42af-4429-9fd1-a8218c268e20'
    Aspm        = 'ee12f906-d277-404b-b6da-e5fa1a576df5'
    UsbSub      = '2a737441-1930-4402-8d77-b2bebba308a3'
    UsbSuspend  = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
}

function Get-VtActiveScheme {
    $o = Invoke-VtCmd 'powercfg /getactivescheme'
    if ($o -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { return $matches[1] }
    return $null
}

# Restituisce l'indice della singola impostazione sulla rete elettrica, o
# $null se non e' mai stata scritta (quindi il sistema usa il default).
function Get-VtPowerIndex([string] $sottogruppo, [string] $impostazione) {
    $s = Get-VtActiveScheme
    if (-not $s) { return $null }
    $k = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\$s\$sottogruppo\$impostazione"
    $v = Get-VtReg $k 'ACSettingIndex'
    if ($null -ne $v) { return [int] $v }
    return $null
}

# Le due parti care di Get-VtSystem, tenute da parte.
#
# Win32_Processor costa un secondo pieno e Get-Partition altri ottocento
# millisecondi (e' l'import del modulo Storage a pesare, non la query). Le
# altre quattro query CIM insieme stanno sotto i 250 ms.
#
# Chi apre la pagina NVIDIA vuole sapere che scheda ha, non quanti core ha la
# CPU ne' se il disco di sistema e' un SSD: prima pagava lo stesso quei due
# secondi, ed era tutto il "delay" che si sentiva cambiando sezione. Ora si
# pagano solo se qualcuno legge davvero quei campi.
function Get-VtCpuInfo {
    if ($script:VtCpuInfo) { return $script:VtCpuInfo }
    $c = Get-CimInstance Win32_Processor | Select-Object -First 1
    $script:VtCpuInfo = [pscustomobject]@{
        Nome   = ($c.Name -replace '\s+', ' ').Trim()
        Core   = [int] $c.NumberOfCores
        Thread = [int] $c.NumberOfLogicalProcessors
    }
    return $script:VtCpuInfo
}

# SSD o meccanico. Serve al catalogo (alcune voci hanno senso solo su SSD),
# quindi si paga a ogni avvio.
#
# Get-Partition e Get-PhysicalDisk danno la risposta giusta ma costano
# ottocento millisecondi, e non e' la query: e' l'import del modulo Storage.
# Le stesse identiche classi si interrogano via CIM senza caricare il modulo,
# e si scende a centosettanta. Se per qualche motivo non rispondono si torna
# ai cmdlet, che restano la strada sicura.
function Get-VtDiscoSys {
    if ($script:VtDisco) { return $script:VtDisco }
    $script:VtDisco = 'sconosciuto'
    $lettera = $env:SystemDrive.TrimEnd(':')

    try {
        $ns = 'root\Microsoft\Windows\Storage'
        $part = Get-CimInstance -Namespace $ns -ClassName MSFT_Partition -ErrorAction Stop |
                Where-Object { $_.DriveLetter -eq $lettera } | Select-Object -First 1
        if ($null -ne $part) {
            $d = Get-CimInstance -Namespace $ns -ClassName MSFT_PhysicalDisk -ErrorAction Stop |
                 Where-Object { [string] $_.DeviceId -eq [string] $part.DiskNumber } | Select-Object -First 1
            if ($d) {
                # MediaType torna come numero via CIM e come parola quando il
                # modulo Storage e' gia' in memoria: vanno gestiti entrambi.
                $m = "$($d.MediaType)"
                $script:VtDisco = switch ($m) {
                    '3' { 'HDD' }
                    '4' { 'SSD' }
                    '5' { 'SCM' }
                    '0' { 'sconosciuto' }
                    default { $m }
                }
            }
        }
    } catch { }

    if ($script:VtDisco -eq 'sconosciuto') {
        try {
            $part = Get-Partition -DriveLetter $lettera -ErrorAction Stop
            $d = Get-PhysicalDisk -ErrorAction Stop | Where-Object { $_.DeviceId -eq $part.DiskNumber }
            if ($d) { $script:VtDisco = $d.MediaType }
        } catch { }
    }
    return $script:VtDisco
}

function Get-VtSystem {
    if ($script:VtSys) { return $script:VtSys }

    $cs  = Get-CimInstance Win32_ComputerSystem
    $os  = Get-CimInstance Win32_OperatingSystem
    $gpu = @(Get-CimInstance Win32_VideoController | Where-Object { $_.AdapterCompatibility -notmatch 'Microsoft' })
    $bat = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)

    $o = [pscustomobject]@{
        RamGB     = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
        Gpu       = $gpu
        GpuNome   = if ($gpu) { $gpu[0].Name } else { 'sconosciuta' }
        Vendor    = (($gpu | ForEach-Object { $_.AdapterCompatibility }) -join ' ')
        Os        = "$($os.Caption) build $($os.BuildNumber)"
        Portatile = ($bat.Count -gt 0)
    }

    # ScriptProperty e non campi normali: da fuori .Cpu si legge esattamente
    # come prima, ma il conto lo si paga solo a chi lo chiede.
    Add-Member -InputObject $o -MemberType ScriptProperty -Name Cpu      -Value { (Get-VtCpuInfo).Nome }
    Add-Member -InputObject $o -MemberType ScriptProperty -Name Core     -Value { (Get-VtCpuInfo).Core }
    Add-Member -InputObject $o -MemberType ScriptProperty -Name Thread   -Value { (Get-VtCpuInfo).Thread }
    Add-Member -InputObject $o -MemberType ScriptProperty -Name DiscoSys -Value { Get-VtDiscoSys }

    $script:VtSys = $o
    return $script:VtSys
}

# ---------------------------------------------------------------------------
# Rilevamento giochi
# ---------------------------------------------------------------------------
# GUID delle schede di rete con un gateway, cioe' quelle da cui passa
# davvero il traffico di gioco.
#
# Get-NetIPConfiguration darebbe lo stesso risultato ma impiega ~2,4 secondi:
# e' una catena di cmdlet CDXML che interroga mezzo stack di rete. La query
# CIM diretta costa ~50 ms. La differenza la si sentiva aprendo la sezione Rete.
function Get-VtActiveNicGuids {
    if ($null -ne $script:VtNicGuids) { return $script:VtNicGuids }
    try {
        $script:VtNicGuids = @(
            Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=true' -ErrorAction Stop |
            Where-Object { $_.DefaultIPGateway } |
            ForEach-Object { $_.SettingID }
        )
    } catch {
        Write-VtLog "Schede di rete non leggibili: $($_.Exception.Message)" warn
        $script:VtNicGuids = @()
    }
    return $script:VtNicGuids
}

# ---------------------------------------------------------------------------
# PANNELLO NVIDIA (NVAPI)
#
# Le impostazioni 3D non stanno nel registro: vivono in un database binario
# del driver (nvdrsdb0.bin) che si tocca solo attraverso NVAPI, la libreria
# nativa di NVIDIA. nvapi64.dll espone una sola funzione, nvapi_QueryInterface:
# tutte le altre si ottengono passando un identificatore numerico.
#
# Perche' qui mi fido, mentre all'inizio avevo detto di no: la struttura
# NVDRS_SETTING porta in testa un campo "versione" calcolato dalla sua
# dimensione. Se sbaglio anche di quattro byte, il driver risponde
# "versione incompatibile" e non fa NIENTE: fallisce in sicurezza.
# E la prova che i conti tornano c'e': leggendo la sincronizzazione verticale
# esce 0x60925292, la costante NVIDIA per "usa l'impostazione del gioco".
# Con un allineamento sbagliato uscirebbe un numero a caso.
#
# Si scrive sul profilo BASE, cioe' le "Impostazioni globali" del pannello:
# le stesse che cambieresti a mano.
# ---------------------------------------------------------------------------
if (-not ('VejaNvApi' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class VejaNvApi
{
    [DllImport("nvapi64.dll", EntryPoint = "nvapi_QueryInterface", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr QI(uint id);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Init();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_CreateSession(out IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_LoadSettings(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_GetBaseProfile(IntPtr h, out IntPtr p);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_GetSetting(IntPtr h, IntPtr p, uint id, IntPtr s);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_SetSetting(IntPtr h, IntPtr p, IntPtr s);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_SaveSettings(IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Destroy(IntPtr h);

    static T Get<T>(uint id) where T : class
    {
        IntPtr p = QI(id);
        return p == IntPtr.Zero ? null : Marshal.GetDelegateForFunctionPointer(p, typeof(T)) as T;
    }

    // version 4 + settingName 4096 + 5 campi da 4 + unione predefinita 4100
    // + unione corrente 4100 = 12320
    const int SIZE = 12320;
    const int OFF_ID = 4100;      // settingId
    const int OFF_TYPE = 4104;    // settingType (0 = intero senza segno)
    const int OFF_CUR = 8220;     // valore corrente
    static uint VER = (uint)(SIZE | (1 << 16));

    public static bool Disponibile()
    {
        try { var i = Get<D_Init>(0x0150E828); return i != null && i() == 0; }
        catch { return false; }
    }

    // Restituisce -1 se non si riesce a leggere.
    public static long Leggi(uint settingId)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null || init() != 0) return -1;
        var crea = Get<D_CreateSession>(0x0694D52E);
        var load = Get<D_LoadSettings>(0x375DBD6B);
        var bas  = Get<D_GetBaseProfile>(0xDA8466A0);
        var get  = Get<D_GetSetting>(0x73BF8338);
        var dis  = Get<D_Destroy>(0xDAD9CFF8);
        if (crea == null || load == null || bas == null || get == null) return -1;

        IntPtr s;
        if (crea(out s) != 0) return -1;
        try
        {
            if (load(s) != 0) return -1;
            IntPtr prof;
            if (bas(s, out prof) != 0) return -1;
            IntPtr buf = Marshal.AllocHGlobal(SIZE);
            try
            {
                for (int i = 0; i < SIZE; i++) Marshal.WriteByte(buf, i, 0);
                Marshal.WriteInt32(buf, 0, (int)VER);
                if (get(s, prof, settingId, buf) != 0) return -1;
                return (uint)Marshal.ReadInt32(buf, OFF_CUR);
            }
            finally { Marshal.FreeHGlobal(buf); }
        }
        finally { if (dis != null) dis(s); }
    }

    // Ritorna il codice NVAPI: 0 = riuscito.
    public static int Scrivi(uint settingId, uint valore)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null) return -1000;
        int st = init();
        if (st != 0) return st;

        var crea = Get<D_CreateSession>(0x0694D52E);
        var load = Get<D_LoadSettings>(0x375DBD6B);
        var bas  = Get<D_GetBaseProfile>(0xDA8466A0);
        var set  = Get<D_SetSetting>(0x577DD202);
        var save = Get<D_SaveSettings>(0xFCBC7E14);
        var dis  = Get<D_Destroy>(0xDAD9CFF8);
        if (crea == null || load == null || bas == null || set == null || save == null) return -1001;

        IntPtr s;
        st = crea(out s);
        if (st != 0) return st;
        try
        {
            st = load(s); if (st != 0) return st;
            IntPtr prof;
            st = bas(s, out prof); if (st != 0) return st;

            IntPtr buf = Marshal.AllocHGlobal(SIZE);
            try
            {
                for (int i = 0; i < SIZE; i++) Marshal.WriteByte(buf, i, 0);
                Marshal.WriteInt32(buf, 0, (int)VER);
                Marshal.WriteInt32(buf, OFF_ID, (int)settingId);
                Marshal.WriteInt32(buf, OFF_TYPE, 0);          // intero senza segno
                Marshal.WriteInt32(buf, OFF_CUR, (int)valore);
                st = set(s, prof, buf);
                if (st != 0) return st;
                return save(s);
            }
            finally { Marshal.FreeHGlobal(buf); }
        }
        finally { if (dis != null) dis(s); }
    }

    // -----------------------------------------------------------------
    // PROFILI PER SINGOLO GIOCO (quello che fa NVIDIA Profile Inspector)
    //
    // Un profilo e' un contenitore con un nome, una lista di eseguibili e
    // una lista di impostazioni: quando lanci uno di quegli eseguibili il
    // driver applica quelle impostazioni al posto delle globali.
    //
    // NVDRS_PROFILE: version 4 + profileName 4096 + gpuSupport 4
    //                + isPredefined 4 + numOfApps 4 + numOfSettings 4 = 4116
    // NVDRS_APPLICATION_V1: version 4 + isPredefined 4 + appName 4096
    //                       + userFriendlyName 4096 + launcher 4096 = 12296
    // -----------------------------------------------------------------
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_CreateProfile(IntPtr h, IntPtr p, out IntPtr ph);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_FindProfile(IntPtr h, IntPtr nome, out IntPtr ph);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_CreateApp(IntPtr h, IntPtr ph, IntPtr app);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_DeleteProfile(IntPtr h, IntPtr ph);

    const int P_SIZE = 4116;
    static uint P_VER = (uint)(P_SIZE | (1 << 16));
    const int A_SIZE = 12296;
    static uint A_VER = (uint)(A_SIZE | (1 << 16));

    static IntPtr Zero(int n)
    {
        IntPtr b = Marshal.AllocHGlobal(n);
        for (int i = 0; i < n; i++) Marshal.WriteByte(b, i, 0);
        return b;
    }

    // NvAPI_UnicodeString: UTF-16 a terminazione zero dentro un buffer fisso.
    static void PutStr(IntPtr b, int off, string s)
    {
        if (s == null) s = "";
        for (int i = 0; i < s.Length; i++) Marshal.WriteInt16(b, off + i * 2, (short)s[i]);
        Marshal.WriteInt16(b, off + s.Length * 2, 0);
    }

    // Cerca un profilo per nome. Restituisce il puntatore, o Zero.
    static IntPtr Trova(D_FindProfile trova, IntPtr sess, string nome)
    {
        IntPtr nb = Zero(4096);
        try
        {
            PutStr(nb, 0, nome);
            IntPtr ph;
            return trova(sess, nb, out ph) == 0 ? ph : IntPtr.Zero;
        }
        finally { Marshal.FreeHGlobal(nb); }
    }

    // Quali di queste impostazioni il driver installato conosce davvero.
    //
    // Serve perche' un file .nip puo' contenere voci di un driver piu' nuovo
    // (o piu' vecchio) del tuo: quelle il driver le rifiuta con -137 e senza
    // questo controllo tutto il profilo fallirebbe per colpa di una riga.
    //
    // Si lavora su un profilo temporaneo e NON si chiama mai SaveSettings:
    // finche' non si salva, per il disco non e' successo niente.
    public static bool[] VociSupportate(uint[] ids)
    {
        var esito = new bool[ids.Length];
        var init = Get<D_Init>(0x0150E828);
        if (init == null || init() != 0) return esito;
        var crea  = Get<D_CreateSession>(0x0694D52E);
        var load  = Get<D_LoadSettings>(0x375DBD6B);
        var creaP = Get<D_CreateProfile>(0xCC176068);
        var set   = Get<D_SetSetting>(0x577DD202);
        var dis   = Get<D_Destroy>(0xDAD9CFF8);
        if (crea == null || load == null || creaP == null || set == null) return esito;

        IntPtr s;
        if (crea(out s) != 0) return esito;
        try
        {
            if (load(s) != 0) return esito;
            IntPtr pb = Zero(P_SIZE);
            IntPtr ph;
            int st;
            try
            {
                Marshal.WriteInt32(pb, 0, (int)P_VER);
                PutStr(pb, 4, "VejaTweak controllo voci");
                st = creaP(s, pb, out ph);
            }
            finally { Marshal.FreeHGlobal(pb); }
            if (st != 0) return esito;

            for (int i = 0; i < ids.Length; i++)
            {
                IntPtr sb = Zero(SIZE);
                try
                {
                    Marshal.WriteInt32(sb, 0, (int)VER);
                    Marshal.WriteInt32(sb, OFF_ID, (int)ids[i]);
                    Marshal.WriteInt32(sb, OFF_TYPE, 0);
                    Marshal.WriteInt32(sb, OFF_CUR, 0);
                    esito[i] = set(s, ph, sb) == 0;
                }
                finally { Marshal.FreeHGlobal(sb); }
            }
            return esito;
        }
        finally { if (dis != null) dis(s); }   // niente Save: la sessione muore qui
    }

    // Legge PIU' impostazioni con UNA sola sessione.
    //
    // Aprire una sessione costa ~165 ms, perche' LoadSettings tira su tutto
    // nvdrsdb0.bin (2,5 MB). Leggendo una voce per volta, lo stato del solo
    // profilo Fortnite (quindici voci) costava 2,9 secondi: era quasi tutto
    // il ritardo che si sentiva aprendo le pagine.
    //
    // profilo == null significa "profilo base", cioe' le impostazioni globali.
    // Nel risultato, -1 vuol dire "non leggibile".
    public static long[] LeggiMolti(string profilo, uint[] ids)
    {
        var res = new long[ids.Length];
        for (int i = 0; i < res.Length; i++) res[i] = -1;

        var init = Get<D_Init>(0x0150E828);
        if (init == null || init() != 0) return res;
        var crea  = Get<D_CreateSession>(0x0694D52E);
        var load  = Get<D_LoadSettings>(0x375DBD6B);
        var bas   = Get<D_GetBaseProfile>(0xDA8466A0);
        var trova = Get<D_FindProfile>(0x7E4A9A0B);
        var get   = Get<D_GetSetting>(0x73BF8338);
        var dis   = Get<D_Destroy>(0xDAD9CFF8);
        if (crea == null || load == null || get == null) return res;

        IntPtr s;
        if (crea(out s) != 0) return res;
        try
        {
            if (load(s) != 0) return res;

            IntPtr prof;
            // IsNullOrEmpty e non "== null": passando $null a un parametro
            // dichiarato [string], PowerShell lo consegna come stringa VUOTA.
            // Con il solo controllo su null si finiva a cercare un profilo di
            // nome "", che ovviamente non esiste, e tutte le letture globali
            // tornavano "non leggibile".
            if (string.IsNullOrEmpty(profilo))
            {
                if (bas == null || bas(s, out prof) != 0) return res;
            }
            else
            {
                if (trova == null) return res;
                prof = Trova(trova, s, profilo);
                if (prof == IntPtr.Zero) return res;
            }

            IntPtr buf = Marshal.AllocHGlobal(SIZE);
            try
            {
                for (int i = 0; i < ids.Length; i++)
                {
                    for (int b = 0; b < SIZE; b++) Marshal.WriteByte(buf, b, 0);
                    Marshal.WriteInt32(buf, 0, (int)VER);
                    if (get(s, prof, ids[i], buf) == 0)
                        res[i] = (uint)Marshal.ReadInt32(buf, OFF_CUR);
                }
            }
            finally { Marshal.FreeHGlobal(buf); }
            return res;
        }
        finally { if (dis != null) dis(s); }
    }

    public static bool ProfiloEsiste(string nome)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null || init() != 0) return false;
        var crea  = Get<D_CreateSession>(0x0694D52E);
        var load  = Get<D_LoadSettings>(0x375DBD6B);
        var trova = Get<D_FindProfile>(0x7E4A9A0B);
        var dis   = Get<D_Destroy>(0xDAD9CFF8);
        if (crea == null || load == null || trova == null) return false;
        IntPtr s;
        if (crea(out s) != 0) return false;
        try { return load(s) == 0 && Trova(trova, s, nome) != IntPtr.Zero; }
        finally { if (dis != null) dis(s); }
    }

    // Legge un'impostazione dentro un profilo di gioco. -1 se non c'e'.
    public static long LeggiProfilo(string nome, uint settingId)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null || init() != 0) return -1;
        var crea  = Get<D_CreateSession>(0x0694D52E);
        var load  = Get<D_LoadSettings>(0x375DBD6B);
        var trova = Get<D_FindProfile>(0x7E4A9A0B);
        var get   = Get<D_GetSetting>(0x73BF8338);
        var dis   = Get<D_Destroy>(0xDAD9CFF8);
        if (crea == null || load == null || trova == null || get == null) return -1;
        IntPtr s;
        if (crea(out s) != 0) return -1;
        try
        {
            if (load(s) != 0) return -1;
            IntPtr ph = Trova(trova, s, nome);
            if (ph == IntPtr.Zero) return -1;
            IntPtr buf = Zero(SIZE);
            try
            {
                Marshal.WriteInt32(buf, 0, (int)VER);
                if (get(s, ph, settingId, buf) != 0) return -1;
                return (uint)Marshal.ReadInt32(buf, OFF_CUR);
            }
            finally { Marshal.FreeHGlobal(buf); }
        }
        finally { if (dis != null) dis(s); }
    }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_RestoreDefault(IntPtr h, IntPtr ph, uint id);

    const int OFF_PREDEF = 4112;   // isCurrentPredefined: 1 = valore di fabbrica

    // Fotografia di un'impostazione dentro un profilo, per poterla rimettere:
    //   -1  il profilo non esiste
    //   -2  c'e' il valore di fabbrica (da ripristinare con RestoreDefault)
    //   >=0 c'e' un valore scelto da qualcuno, ed e' questo
    public static long FotografaProfilo(string nome, uint settingId)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null || init() != 0) return -1;
        var crea  = Get<D_CreateSession>(0x0694D52E);
        var load  = Get<D_LoadSettings>(0x375DBD6B);
        var trova = Get<D_FindProfile>(0x7E4A9A0B);
        var get   = Get<D_GetSetting>(0x73BF8338);
        var dis   = Get<D_Destroy>(0xDAD9CFF8);
        if (crea == null || load == null || trova == null || get == null) return -1;
        IntPtr s;
        if (crea(out s) != 0) return -1;
        try
        {
            if (load(s) != 0) return -1;
            IntPtr ph = Trova(trova, s, nome);
            if (ph == IntPtr.Zero) return -1;
            IntPtr buf = Zero(SIZE);
            try
            {
                Marshal.WriteInt32(buf, 0, (int)VER);
                if (get(s, ph, settingId, buf) != 0) return -2;
                if (Marshal.ReadInt32(buf, OFF_PREDEF) != 0) return -2;
                return (uint)Marshal.ReadInt32(buf, OFF_CUR);
            }
            finally { Marshal.FreeHGlobal(buf); }
        }
        finally { if (dis != null) dis(s); }
    }

    // Applica le impostazioni al profilo del gioco.
    //
    // I profili dei giochi noti (Fortnite compreso) il driver ce li ha gia',
    // predefiniti, e NON si possono cancellare: si modificano, ed e'
    // esattamente quello che fa Profile Inspector. Quindi qui il profilo si
    // crea solo se non esiste; se esiste gli si scrive dentro.
    //
    // 'creato' dice al chiamante cosa dovra' fare per annullare: cancellare
    // tutto il profilo (l'abbiamo fatto noi) o rimettere valore per valore.
    public static int ApplicaProfilo(string nome, string[] exe, uint[] ids, uint[] valori, out bool creato)
    {
        creato = false;
        if (ids.Length != valori.Length) return -1002;
        var init = Get<D_Init>(0x0150E828);
        if (init == null) return -1000;
        int st = init();
        if (st != 0) return st;

        var crea   = Get<D_CreateSession>(0x0694D52E);
        var load   = Get<D_LoadSettings>(0x375DBD6B);
        var save   = Get<D_SaveSettings>(0xFCBC7E14);
        var dis    = Get<D_Destroy>(0xDAD9CFF8);
        var creaP  = Get<D_CreateProfile>(0xCC176068);
        var trovaP = Get<D_FindProfile>(0x7E4A9A0B);
        var creaA  = Get<D_CreateApp>(0x4347A9DE);
        var set    = Get<D_SetSetting>(0x577DD202);
        if (crea == null || load == null || save == null || creaP == null ||
            trovaP == null || creaA == null || set == null) return -1001;

        IntPtr s;
        st = crea(out s);
        if (st != 0) return st;
        try
        {
            st = load(s); if (st != 0) return st;

            IntPtr ph = Trova(trovaP, s, nome);
            if (ph == IntPtr.Zero)
            {
                IntPtr pb = Zero(P_SIZE);
                try
                {
                    Marshal.WriteInt32(pb, 0, (int)P_VER);
                    PutStr(pb, 4, nome);
                    st = creaP(s, pb, out ph);
                }
                finally { Marshal.FreeHGlobal(pb); }
                if (st != 0) return st;
                creato = true;

                foreach (string e in exe)
                {
                    if (string.IsNullOrEmpty(e)) continue;
                    IntPtr ab = Zero(A_SIZE);
                    try
                    {
                        Marshal.WriteInt32(ab, 0, (int)A_VER);
                        Marshal.WriteInt32(ab, 4, 0);        // isPredefined
                        PutStr(ab, 8, e);                     // appName
                        PutStr(ab, 8 + 4096, e);              // userFriendlyName
                        st = creaA(s, ph, ab);
                    }
                    finally { Marshal.FreeHGlobal(ab); }
                    // -167 = eseguibile gia' rivendicato da un altro profilo.
                    // Succede sul serio: GTA5.exe appartiene al profilo
                    // "Grand Theft Auto V" che il driver porta di fabbrica.
                    // Non e' un motivo per fermarsi, ma nemmeno una vittoria:
                    // per quell'eseguibile il nostro profilo non varra'.
                    if (st != 0 && st != -167) return st;
                }
            }

            for (int i = 0; i < ids.Length; i++)
            {
                IntPtr sb = Zero(SIZE);
                try
                {
                    Marshal.WriteInt32(sb, 0, (int)VER);
                    Marshal.WriteInt32(sb, OFF_ID, (int)ids[i]);
                    Marshal.WriteInt32(sb, OFF_TYPE, 0);
                    Marshal.WriteInt32(sb, OFF_CUR, (int)valori[i]);
                    st = set(s, ph, sb);
                }
                finally { Marshal.FreeHGlobal(sb); }
                if (st != 0) return st;
            }

            return save(s);
        }
        finally { if (dis != null) dis(s); }
    }

    // Rimette una singola impostazione al valore di fabbrica del profilo.
    public static int RipristinaVoce(string nome, uint settingId)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null) return -1000;
        int st = init(); if (st != 0) return st;
        var crea   = Get<D_CreateSession>(0x0694D52E);
        var load   = Get<D_LoadSettings>(0x375DBD6B);
        var save   = Get<D_SaveSettings>(0xFCBC7E14);
        var dis    = Get<D_Destroy>(0xDAD9CFF8);
        var trovaP = Get<D_FindProfile>(0x7E4A9A0B);
        var restore= Get<D_RestoreDefault>(0x53F0381E);
        if (crea == null || load == null || save == null || trovaP == null || restore == null) return -1001;
        IntPtr s;
        st = crea(out s); if (st != 0) return st;
        try
        {
            st = load(s); if (st != 0) return st;
            IntPtr ph = Trova(trovaP, s, nome);
            if (ph == IntPtr.Zero) return 0;
            restore(s, ph, settingId);      // se non c'era, va bene lo stesso
            return save(s);
        }
        finally { if (dis != null) dis(s); }
    }

    // Scrive un valore preciso dentro un profilo di gioco (usata per rimettere
    // com'era un'impostazione che qualcuno aveva gia' scelto a mano).
    public static int ScriviProfilo(string nome, uint settingId, uint valore)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null) return -1000;
        int st = init(); if (st != 0) return st;
        var crea   = Get<D_CreateSession>(0x0694D52E);
        var load   = Get<D_LoadSettings>(0x375DBD6B);
        var save   = Get<D_SaveSettings>(0xFCBC7E14);
        var dis    = Get<D_Destroy>(0xDAD9CFF8);
        var trovaP = Get<D_FindProfile>(0x7E4A9A0B);
        var set    = Get<D_SetSetting>(0x577DD202);
        if (crea == null || load == null || save == null || trovaP == null || set == null) return -1001;
        IntPtr s;
        st = crea(out s); if (st != 0) return st;
        try
        {
            st = load(s); if (st != 0) return st;
            IntPtr ph = Trova(trovaP, s, nome);
            if (ph == IntPtr.Zero) return 0;
            IntPtr sb = Zero(SIZE);
            try
            {
                Marshal.WriteInt32(sb, 0, (int)VER);
                Marshal.WriteInt32(sb, OFF_ID, (int)settingId);
                Marshal.WriteInt32(sb, OFF_TYPE, 0);
                Marshal.WriteInt32(sb, OFF_CUR, (int)valore);
                st = set(s, ph, sb);
            }
            finally { Marshal.FreeHGlobal(sb); }
            if (st != 0) return st;
            return save(s);
        }
        finally { if (dis != null) dis(s); }
    }

    public static int EliminaProfilo(string nome)
    {
        var init = Get<D_Init>(0x0150E828);
        if (init == null) return -1000;
        int st = init();
        if (st != 0) return st;
        var crea   = Get<D_CreateSession>(0x0694D52E);
        var load   = Get<D_LoadSettings>(0x375DBD6B);
        var save   = Get<D_SaveSettings>(0xFCBC7E14);
        var dis    = Get<D_Destroy>(0xDAD9CFF8);
        var trovaP = Get<D_FindProfile>(0x7E4A9A0B);
        var delP   = Get<D_DeleteProfile>(0x17093206);
        if (crea == null || load == null || save == null || trovaP == null || delP == null) return -1001;

        IntPtr s;
        st = crea(out s);
        if (st != 0) return st;
        try
        {
            st = load(s); if (st != 0) return st;
            IntPtr ph = Trova(trovaP, s, nome);
            if (ph == IntPtr.Zero) return 0;   // non c'e': va bene cosi'
            st = delP(s, ph); if (st != 0) return st;
            return save(s);
        }
        finally { if (dis != null) dis(s); }
    }
}
'@ -ErrorAction SilentlyContinue
}

function Test-VtNvApi {
    if ($null -ne $script:VtNvOk) { return $script:VtNvOk }
    $script:VtNvOk = $false
    try {
        if ((Get-VtGpuVendor) -eq 'NVIDIA' -and ('VejaNvApi' -as [type])) {
            $script:VtNvOk = [VejaNvApi]::Disponibile()
        }
    } catch { }
    return $script:VtNvOk
}

# Cache dei valori NVIDIA gia' letti in questo giro di pagina.
#
# Non tradisce la regola "lo stato si legge dal sistema": si legge davvero,
# solo che quindici letture della stessa sessione diventano una. La cache
# viene buttata via a ogni scrittura, quindi non puo' mostrare un valore
# vecchio dopo che qualcosa e' cambiato.
function Clear-VtNvCache { $script:VtNvVal = $null }

function Get-VtNvMolti([string] $profilo, $ids) {
    if (-not (Test-VtNvApi)) { return @{} }
    if (-not $script:VtNvVal) { $script:VtNvVal = @{} }
    $chiave = if ($profilo) { $profilo } else { '<globale>' }
    if (-not $script:VtNvVal.ContainsKey($chiave)) { $script:VtNvVal[$chiave] = @{} }
    $memo = $script:VtNvVal[$chiave]

    $mancanti = @($ids | Where-Object { -not $memo.ContainsKey([string] $_) })
    if ($mancanti.Count -gt 0) {
        try {
            $letti = [VejaNvApi]::LeggiMolti($profilo, [uint32[]] $mancanti)
            for ($i = 0; $i -lt $mancanti.Count; $i++) { $memo[[string] $mancanti[$i]] = $letti[$i] }
        } catch {
            foreach ($m in $mancanti) { $memo[[string] $m] = -1 }
        }
    }
    return $memo
}

# Le impostazioni globali che il catalogo usa. Stanno qui perche' alla prima
# lettura conviene tirarle su tutte insieme: sono quattro interruttori, e
# leggerli uno per uno voleva dire quattro sessioni da 165 ms invece di una.
$script:VtNvIdGlobali = @(0x00A879CF, 0x1057EB71, 0x007BA09E, 0x20C1221E)

function Get-VtNvSetting([uint32] $id) {
    if (-not (Test-VtNvApi)) { return $null }
    $chiedi = @($id)
    if (-not $script:VtNvVal -or -not $script:VtNvVal.ContainsKey('<globale>')) {
        $chiedi = @($script:VtNvIdGlobali) + @($id) | Select-Object -Unique
    }
    $m = Get-VtNvMolti $null $chiedi
    $v = $m[[string] $id]
    if ($null -eq $v -or $v -lt 0) { return $null }
    return [uint32] $v
}

function Set-VtNvSetting([uint32] $id, [uint32] $valore) {
    if (-not (Test-VtNvApi)) { throw 'NVAPI non disponibile su questo sistema.' }
    Clear-VtNvCache
    $st = [VejaNvApi]::Scrivi($id, $valore)
    if ($st -ne 0) { throw "Il driver NVIDIA ha rifiutato la modifica (codice $st)." }
    Clear-VtNvCache

    # Rilettura di controllo: se il driver accetta ma non applica, meglio
    # accorgersene qui che lasciare l'interruttore acceso a vuoto.
    $ora = Get-VtNvSetting $id
    if ($ora -ne $valore) { throw "Scrittura accettata ma il valore non e' cambiato (letto $ora, atteso $valore)." }
    Write-VtLog ("NVIDIA: impostazione 0x{0:X} portata a 0x{1:X}" -f $id, $valore) ok
}

function Test-VtNvTweak($voci) {
    foreach ($v in $voci) {
        $cur = Get-VtNvSetting $v.Id
        if ($null -eq $cur -or $cur -ne $v.Val) { return $false }
    }
    return $true
}

function Set-VtNvTweak([string] $id, $voci) {
    $bak = @()
    foreach ($v in $voci) {
        $prima = Get-VtNvSetting $v.Id
        Set-VtNvSetting $v.Id $v.Val
        $bak += @{ Id = $v.Id; Valore = $prima }
    }
    Set-VtEntry $id @{ Nv = $bak }
}

function Restore-VtNvTweak([string] $id) {
    $e = Get-VtEntry $id
    if (-not $e) { return }
    foreach ($b in @($e.Nv)) {
        if ($null -eq $b.Valore) { continue }
        try { Set-VtNvSetting ([uint32] $b.Id) ([uint32] $b.Valore) } catch { Write-VtLog "Ripristino NVIDIA non riuscito: $($_.Exception.Message)" warn }
    }
    Remove-VtEntry $id
}

# ---------------------------------------------------------------------------
# PROFILI PER SINGOLO GIOCO  (quello che si fa con NVIDIA Profile Inspector)
#
# Un file .nip non e' altro che l'elenco degli eseguibili di un gioco piu' un
# elenco di impostazioni. Qui non serve installare Profile Inspector: le
# stesse chiamate NVAPI che scrivono le impostazioni globali sanno scrivere
# anche dentro un profilo di gioco.
#
# Attenzione a una cosa che ho scoperto provando: i profili dei giochi noti
# (Fortnite fra questi) il driver li ha gia' dentro, marcati "predefiniti", e
# NON si possono cancellare. Si modificano, ed e' esattamente quello che fa
# Profile Inspector. Per questo l'annullamento non e' "cancella il profilo" ma
# "rimetti ogni voce com'era", e com'era lo fotografo prima di toccarla.
# ---------------------------------------------------------------------------

function Get-VtFivemExeNvidia {
    # NVIDIA riconosce i giochi dal nome dell'eseguibile. FiveM cambia il
    # nome del processo di gioco a ogni build (FiveM_b3570_GTAProcess.exe),
    # quindi i nomi fissi non bastano: quelli veri li leggo dal disco.
    #
    # GTA5.exe di proposito NON c'e': appartiene gia' al profilo "Grand Theft
    # Auto V" che il driver porta di fabbrica, e NVAPI non lascia che due
    # profili si contendano lo stesso eseguibile. Non e' una perdita: FiveM
    # non lancia GTA5.exe, lancia il proprio processo di gioco.
    $l = [System.Collections.Generic.List[string]]::new()
    foreach ($n in 'FiveM.exe', 'FiveM_GTAProcess.exe') { $l.Add($n) }
    foreach ($radice in @("$env:LOCALAPPDATA\FiveM", "$env:APPDATA\CitizenFX")) {
        if (-not (Test-Path $radice)) { continue }
        try {
            Get-ChildItem $radice -Filter 'FiveM_b*_GTAProcess.exe' -Recurse -File -ErrorAction SilentlyContinue |
                ForEach-Object { if (-not $l.Contains($_.Name)) { $l.Add($_.Name) } }
        } catch { }
    }
    # NON "return , $l.ToArray()": qui il chiamante vuole i nomi uno per uno,
    # e la virgola glieli consegnerebbe impacchettati dentro un elemento solo.
    return $l.ToArray()
}

function Get-VtNvProfili {
    if ($null -ne $script:VtNvProfili) { return $script:VtNvProfili }

    # --- Fortnite: le impostazioni del file .nip fornito ------------------
    # Le riporto una per una, con il nome che hanno nel pannello, cosi' in
    # GUI si vede cosa entra e non si deve credere sulla parola.
    $fortnite = @(
        @{ Id = 6600001;   Val = 1;         Voce = 'Frequenza di aggiornamento preferita'; Val_ = 'la piu'' alta disponibile' }
        @{ Id = 7573135;   Val = 10;        Voce = 'Filtro texture - LOD Bias';            Val_ = '+10' }
        @{ Id = 8703344;   Val = 1;         Voce = 'Filtro anisotropico - ottimizzazione'; Val_ = 'attiva' }
        @{ Id = 11041231;  Val = 138504007; Voce = 'Sincronizzazione verticale';           Val_ = 'forzata OFF' }
        @{ Id = 13510289;  Val = 20;        Voce = 'Filtro texture - Qualita''';           Val_ = 'prestazioni elevate' }
        @{ Id = 15151633;  Val = 1;         Voce = 'Campionamento anisotropico - ottimiz.'; Val_ = 'attiva' }
        @{ Id = 273507943; Val = 0;         Voce = 'Conteggio multi-frame DLSSG';          Val_ = 'disattivato' }
        @{ Id = 276757595; Val = 1;         Voce = 'Antialiasing - Modalita''';            Val_ = 'controllato dal gioco' }
        @{ Id = 278196567; Val = 0;         Voce = 'Funzione VRR globale';                 Val_ = 'disattivata' }
        @{ Id = 279476652; Val = 1;         Voce = 'G-SYNC';                               Val_ = 'attivo' }
        @{ Id = 279476687; Val = 1;         Voce = 'G-SYNC';                               Val_ = 'attivo' }
        @{ Id = 282364549; Val = 8;         Voce = 'Antialiasing - supersampling traspar.'; Val_ = '8x' }
        @{ Id = 283385347; Val = 0;         Voce = 'Override DLSS-FG';                     Val_ = 'disattivato' }
        @{ Id = 294973784; Val = 0;         Voce = 'G-SYNC globale';                       Val_ = 'disattivato' }
        @{ Id = 541081465; Val = 20;        Voce = 'Voce senza nome nel driver';           Val_ = '20' }
    )

    # --- FiveM: profilo scritto da me ------------------------------------
    # Regola che mi sono dato: dentro ci va solo quello che toglie lavoro
    # senza far diventare il gioco brutto. Per questo NON c'e' il LOD Bias,
    # che e' la voce che sfoca le texture in lontananza: e' quella che fa
    # sembrare "sporchi" i profili tirati via.
    $fivem = @(
        # Gli identificatori qui sono in esadecimale di proposito: le prime due
        # volte li avevo convertiti a mano in decimale e due su nove erano
        # sbagliati. Il driver li rifiutava (codice -137) senza dire quale.
        @{ Id = 6600001;    Val = 1;         Voce = 'Frequenza di aggiornamento preferita'; Val_ = 'la piu'' alta disponibile' }
        @{ Id = 0x1057EB71; Val = 1;         Voce = 'Gestione alimentazione';               Val_ = 'prestazioni massime' }
        @{ Id = 0x007BA09E; Val = 1;         Voce = 'Fotogrammi pre-renderizzati';          Val_ = '1 (bassa latenza)' }
        @{ Id = 0x20C1221E; Val = 1;         Voce = 'Ottimizzazione threaded';              Val_ = 'attiva' }
        @{ Id = 11041231;   Val = 138504007; Voce = 'Sincronizzazione verticale';           Val_ = 'forzata OFF' }
        @{ Id = 8703344;   Val = 1;         Voce = 'Filtro anisotropico - ottimizzazione'; Val_ = 'attiva' }
        @{ Id = 15151633;  Val = 1;         Voce = 'Campionamento anisotropico - ottimiz.'; Val_ = 'attiva' }
        @{ Id = 13510289;  Val = 20;        Voce = 'Filtro texture - Qualita''';           Val_ = 'prestazioni elevate' }
        @{ Id = 276757595; Val = 1;         Voce = 'Antialiasing - Modalita''';            Val_ = 'controllato dal gioco' }
    )

    $script:VtNvProfili = @(
        @{
            Id = 'nip-fortnite'; Profilo = 'Fortnite'; Gioco = 'Fortnite'
            Exe = @('fortniteclient-win64-shipping.exe', 'fortniteclient-win64-shipping_be.exe',
                    'fortniteclient-win64-shipping_eac.exe', 'fortniteclient-win64-shipping_eac_eos.exe',
                    'fortniteclient-win64-test.exe', 'fortniteclient.exe', 'fortnitelauncher.exe')
            Voci = $fortnite
        }
        @{
            Id = 'nip-fivem'; Profilo = 'FiveM (VejaTweak)'; Gioco = 'FiveM / GTA V'
            Exe = @(Get-VtFivemExeNvidia)
            Voci = $fivem
        }
    )
    return $script:VtNvProfili
}

# ---------------------------------------------------------------------------
# CARICARE UN FILE .nip QUALSIASI
#
# Un .nip e' un XML: una lista di profili, ognuno con i suoi eseguibili e le
# sue impostazioni. Non serve NVIDIA Profile Inspector installato: le stesse
# chiamate NVAPI che scrivono i profili del catalogo scrivono anche questi.
#
# Cosa NON si applica, e viene detto invece di essere nascosto:
#   - le voci di tipo diverso da Dword (testo, binario): il nostro writer
#     scrive interi, e fingere di aver applicato una stringa sarebbe una bugia;
#   - le voci che il driver installato non conosce (codice -137).
# ---------------------------------------------------------------------------
function Read-VtNipFile([string] $percorso) {
    if (-not (Test-Path -LiteralPath $percorso)) { throw "File non trovato: $percorso" }
    try { $xml = [xml] (Get-Content -LiteralPath $percorso -Raw) }
    catch { throw "Questo non sembra un file .nip valido: $($_.Exception.Message)" }

    $prof = @($xml.ArrayOfProfile.Profile)
    if ($prof.Count -eq 0 -or -not $prof[0]) { throw 'Nel file non c''e'' nessun profilo.' }

    $out = @()
    foreach ($p in $prof) {
        $exe = @()
        if ($p.Executeables) { $exe = @($p.Executeables.string | Where-Object { $_ }) }

        $voci = @(); $ignorate = @()
        foreach ($s in @($p.Settings.ProfileSetting)) {
            if (-not $s) { continue }
            $nome = if ($s.SettingNameInfo) { "$($s.SettingNameInfo)" } else { "voce senza nome ($($s.SettingID))" }
            if ("$($s.ValueType)" -ne 'Dword') {
                $ignorate += "$nome (tipo $($s.ValueType), non gestito)"
                continue
            }
            try {
                $voci += @{
                    Id   = [uint32] $s.SettingID
                    Val  = [uint32] $s.SettingValue
                    Voce = $nome
                    Val_ = "$($s.SettingValue)"
                }
            } catch {
                $ignorate += "$nome (valore illeggibile: $($s.SettingValue))"
            }
        }
        $out += [pscustomobject]@{
            Nome     = "$($p.ProfileName)"
            Exe      = $exe
            Voci     = $voci
            Ignorate = $ignorate
        }
    }
    return $out
}

# Applica un file .nip, tenendo da parte tutto quello che serve per annullarlo.
function Import-VtNip([string] $percorso) {
    if (-not (Test-VtNvApi)) { throw 'NVAPI non disponibile: serve una scheda NVIDIA con i driver installati.' }
    $profili = @(Read-VtNipFile $percorso)

    $riepilogo = @()
    $istantanee = @()
    Clear-VtNvCache
    Clear-VtStateCache

    foreach ($p in $profili) {
        if ($p.Voci.Count -eq 0) {
            $riepilogo += "$($p.Nome): nessuna voce applicabile"
            continue
        }

        # Le voci che il driver di QUESTO PC non conosce vanno tolte prima,
        # altrimenti una riga sconosciuta fa fallire tutto il profilo.
        $valide = @($p.Voci)
        try {
            $sup = [VejaNvApi]::VociSupportate([uint32[]] @($p.Voci | ForEach-Object { [uint32] $_.Id }))
            $valide = @(for ($i = 0; $i -lt $p.Voci.Count; $i++) { if ($sup[$i]) { $p.Voci[$i] } })
        } catch { }
        $scartate = $p.Voci.Count - $valide.Count
        if ($valide.Count -eq 0) {
            $riepilogo += "$($p.Nome): il driver installato non conosce nessuna delle $($p.Voci.Count) voci"
            continue
        }

        # Fotografia PRIMA di scrivere: senza questa "annulla" sarebbe un
        # "spero fosse cosi'".
        $prima = @()
        foreach ($v in $valide) {
            $prima += @{ Id = [uint32] $v.Id; Valore = [VejaNvApi]::FotografaProfilo($p.Nome, [uint32] $v.Id) }
        }

        $creato = $false
        $st = [VejaNvApi]::ApplicaProfilo(
            $p.Nome,
            [string[]] @($p.Exe),
            [uint32[]] @($valide | ForEach-Object { [uint32] $_.Id }),
            [uint32[]] @($valide | ForEach-Object { [uint32] $_.Val }),
            [ref] $creato)
        if ($st -ne 0) {
            $riepilogo += "$($p.Nome): il driver ha rifiutato il profilo (codice $st)"
            continue
        }

        $istantanee += @{ Profilo = $p.Nome; Creato = $creato; Voci = $prima }
        $r = "$($p.Nome): $($valide.Count) impostazioni su $($p.Exe.Count) eseguibili"
        if ($scartate -gt 0)          { $r += ", $scartate ignorate dal driver" }
        if ($p.Ignorate.Count -gt 0)  { $r += ", $($p.Ignorate.Count) di tipo non gestito" }
        $riepilogo += $r
    }

    Clear-VtNvCache
    if ($istantanee.Count -eq 0) { throw ("Non ho applicato niente.`n`n" + ($riepilogo -join "`n")) }

    # Gli import si impilano: annullando si torna indietro uno alla volta,
    # nell'ordine inverso, come ci si aspetta.
    $e = Get-VtEntry 'nip-manuale'
    $pila = if ($e) { @($e.Importi) } else { @() }
    $pila += @{
        File    = (Split-Path $percorso -Leaf)
        Data    = (Get-Date).ToString('yyyy-MM-dd HH:mm')
        Profili = $istantanee
    }
    Set-VtEntry 'nip-manuale' @{ Importi = $pila }

    Write-VtLog "File .nip '$(Split-Path $percorso -Leaf)' applicato: $($istantanee.Count) profili" ok
    [pscustomobject]@{ Righe = $riepilogo; Profili = $istantanee.Count }
}

# Chi chiama DEVE avvolgere in @(): con un solo import il valore torna dal
# backup come oggetto singolo, e un .Count diretto conterebbe i suoi campi
# invece degli import.
function Get-VtNipImporti {
    $e = Get-VtEntry 'nip-manuale'
    if (-not $e) { return @() }
    return @($e.Importi)
}

function Undo-VtNipUltimo {
    $pila = @(Get-VtNipImporti)
    if ($pila.Count -eq 0) { throw 'Non c''e'' nessun file .nip caricato da annullare.' }
    $ultimo = $pila[-1]
    Clear-VtNvCache

    foreach ($p in @($ultimo.Profili)) {
        if ($p.Creato) {
            # L'avevamo creato noi: via tutto.
            $st = [VejaNvApi]::EliminaProfilo($p.Profilo)
            if ($st -ne 0) { Write-VtLog "Profilo '$($p.Profilo)' non eliminato (codice $st)" warn }
        } else {
            foreach ($b in @($p.Voci)) {
                try {
                    if ([int64] $b.Valore -ge 0) { [void] [VejaNvApi]::ScriviProfilo($p.Profilo, [uint32] $b.Id, [uint32] $b.Valore) }
                    else                         { [void] [VejaNvApi]::RipristinaVoce($p.Profilo, [uint32] $b.Id) }
                } catch { Write-VtLog "Ripristino voce non riuscito: $($_.Exception.Message)" warn }
            }
        }
    }

    Clear-VtNvCache
    $resto = @($pila | Select-Object -First ($pila.Count - 1))
    if ($resto.Count -gt 0) { Set-VtEntry 'nip-manuale' @{ Importi = $resto } }
    else                    { Remove-VtEntry 'nip-manuale' }

    Write-VtLog "File .nip '$($ultimo.File)' annullato" ok
    return $ultimo.File
}

# Profile Inspector NON viene scaricato: VejaTweak fa gia' da solo quello che
# serve. Se pero' ce l'hai gia' sul PC, tanto vale saperlo dire.
function Find-VtProfileInspector {
    $nomi = 'nvidiaProfileInspector.exe', 'nvidiaInspector.exe'
    $dove = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA,
              (Join-Path $env:USERPROFILE 'Downloads'), (Join-Path $env:USERPROFILE 'Desktop'))
    foreach ($d in ($dove | Where-Object { $_ -and (Test-Path $_) })) {
        foreach ($n in $nomi) {
            $p = Join-Path $d $n
            if (Test-Path -LiteralPath $p) { return $p }
            try {
                $t = Get-ChildItem $d -Filter $n -Recurse -Depth 2 -File -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($t) { return $t.FullName }
            } catch { }
        }
    }
    return $null
}

function Get-VtNvProfilo([string] $id) {
    Get-VtNvProfili | Where-Object { $_.Id -eq $id } | Select-Object -First 1
}

# Le voci che il driver installato accetta davvero.
#
# Un file .nip nasce sul PC di qualcun altro, con un altro driver: puo'
# contenere voci che il tuo non conosce. Senza questo filtro basterebbe una
# riga sconosciuta per far fallire tutto il profilo, e l'utente vedrebbe solo
# un codice di errore. Il controllo si fa una volta e si tiene in cache.
function Get-VtNvVociValide($def) {
    if (-not $script:VtNvVoci) { $script:VtNvVoci = @{} }
    if ($script:VtNvVoci.ContainsKey($def.Id)) { return $script:VtNvVoci[$def.Id] }

    $tutte = @($def.Voci)
    $ok = @($tutte)
    try {
        $ids = [uint32[]] @($tutte | ForEach-Object { [uint32] $_.Id })
        $sup = [VejaNvApi]::VociSupportate($ids)
        $ok = @(for ($i = 0; $i -lt $tutte.Count; $i++) { if ($sup[$i]) { $tutte[$i] } })
        $scartate = $tutte.Count - $ok.Count
        if ($scartate -gt 0) {
            Write-VtLog "Profilo '$($def.Profilo)': $scartate voci ignorate, il driver installato non le conosce" warn
        }
    } catch { }
    $script:VtNvVoci[$def.Id] = $ok
    return $ok
}

# Acceso solo se TUTTE le voci applicabili sono gia' al valore previsto.
function Test-VtNvProfilo($def) {
    if (-not (Test-VtNvApi)) { return $false }
    try {
        $voci = @(Get-VtNvVociValide $def)
        if ($voci.Count -eq 0) { return $false }
        # Una sola sessione per tutte le voci: prima ne apriva una per voce
        # piu' una per il controllo di esistenza, e il profilo Fortnite da
        # solo costava quasi tre secondi a ogni apertura di pagina.
        $m = Get-VtNvMolti $def.Profilo @($voci | ForEach-Object { [uint32] $_.Id })
        foreach ($v in $voci) {
            $cur = $m[[string] [uint32] $v.Id]
            if ($null -eq $cur -or $cur -lt 0 -or [uint32] $cur -ne [uint32] $v.Val) { return $false }
        }
        return $true
    } catch { return $false }
}

function Set-VtNvProfilo([string] $id) {
    # Questa scrive nel driver senza passare da Set-VtTweak, quindi la
    # fotografia dello stato se la deve buttare da sola.
    Clear-VtStateCache
    $def = Get-VtNvProfilo $id
    if (-not $def) { throw "Profilo '$id' sconosciuto." }
    if (-not (Test-VtNvApi)) { throw 'NVAPI non disponibile: serve una scheda NVIDIA con i driver installati.' }

    $voci = @(Get-VtNvVociValide $def)
    if ($voci.Count -eq 0) { throw 'Il driver installato non conosce nessuna delle impostazioni di questo profilo.' }

    # Fotografia PRIMA di toccare: senza questa l'annullamento sarebbe un
    # "spero fosse cosi'".
    $prima = @()
    foreach ($v in $voci) {
        $p = [VejaNvApi]::FotografaProfilo($def.Profilo, [uint32] $v.Id)
        $prima += @{ Id = [uint32] $v.Id; Valore = $p }   # -1 profilo assente, -2 valore di fabbrica
    }

    $ids  = [uint32[]] @($voci | ForEach-Object { [uint32] $_.Id })
    $vals = [uint32[]] @($voci | ForEach-Object { [uint32] $_.Val })
    # Da qui in poi i valori in cache non valgono piu': si scrive.
    Clear-VtNvCache
    $creato = $false
    $st = [VejaNvApi]::ApplicaProfilo($def.Profilo, [string[]] @($def.Exe), $ids, $vals, [ref] $creato)
    if ($st -ne 0) {
        # "codice -137" non dice niente a nessuno. Se il driver ha rifiutato,
        # riprovo le voci una per una su un profilo usa-e-getta per poter dire
        # QUALE non gli va giu'. Costa solo sulla strada dell'errore.
        $colpevoli = @()
        foreach ($v in $voci) {
            $c = $false
            $s = [VejaNvApi]::ApplicaProfilo('VejaTweak diagnosi', [string[]] @(), [uint32[]] @([uint32] $v.Id), [uint32[]] @([uint32] $v.Val), [ref] $c)
            if ($s -ne 0) { $colpevoli += "$($v.Voce) (codice $s)" }
        }
        [void] [VejaNvApi]::EliminaProfilo('VejaTweak diagnosi')
        $dettaglio = if ($colpevoli.Count -gt 0) { " Voci rifiutate: $($colpevoli -join '; ')." } else { '' }
        throw "Il driver NVIDIA ha rifiutato il profilo (codice $st).$dettaglio"
    }

    if (-not (Test-VtNvProfilo $def)) {
        throw 'Il driver ha accettato ma rileggendo i valori non tornano: non lascio l''interruttore acceso a vuoto.'
    }
    Clear-VtNvCache
    Set-VtEntry $id @{ Profilo = $def.Profilo; Creato = $creato; Voci = $prima }
    Write-VtLog "Profilo NVIDIA '$($def.Profilo)': $($voci.Count) impostazioni applicate" ok
}

function Restore-VtNvProfilo([string] $id) {
    $e = Get-VtEntry $id
    if (-not $e) { return }
    Clear-VtNvCache
    if ($e.Creato) {
        # L'abbiamo creato noi: via tutto, cosi' non resta niente in giro.
        $st = [VejaNvApi]::EliminaProfilo($e.Profilo)
        if ($st -ne 0) { Write-VtLog "Profilo '$($e.Profilo)' non eliminato (codice $st)" warn }
    } else {
        foreach ($b in @($e.Voci)) {
            try {
                if ([int64] $b.Valore -ge 0) { [void] [VejaNvApi]::ScriviProfilo($e.Profilo, [uint32] $b.Id, [uint32] $b.Valore) }
                else                         { [void] [VejaNvApi]::RipristinaVoce($e.Profilo, [uint32] $b.Id) }
            } catch { Write-VtLog "Ripristino voce NVIDIA non riuscito: $($_.Exception.Message)" warn }
        }
    }
    Clear-VtNvCache
    Remove-VtEntry $id
    Write-VtLog "Profilo NVIDIA '$($e.Profilo)' riportato com'era" ok
}

# ---------------------------------------------------------------------------
# SCHEDA DI RETE
#
# I driver Ethernet espongono decine di impostazioni avanzate che nessuno va
# mai a guardare, e diverse sono accese di fabbrica per risparmiare corrente,
# non per andare veloci: la scheda si addormenta, e il primo pacchetto dopo
# una pausa arriva in ritardo.
#
# Si scrivono per VALORE NUMERICO (RegistryValue) e non per nome: i nomi sono
# tradotti ("Disabilitato", "Disabled", "Deaktiviert") e un confronto sul
# testo funzionerebbe solo in italiano.
# ---------------------------------------------------------------------------
# Via CIM invece che con Get-NetAdapter: 150 ms contro 630. E' la stessa
# classe che il cmdlet avvolge, ma senza caricare il modulo NetAdapter, ed e'
# un costo che si pagava a ogni avvio dentro la costruzione del catalogo.
#
# Verificato che i due campi usati dopo siano identici sui due percorsi:
#   .Name           serve a Set-NetAdapterAdvancedProperty -Name
#   .InterfaceGuid  serve a ritrovare la chiave PnP nel registro
# Corrispondenze dei filtri: ConnectorPresent = -Physical,
# InterfaceOperationalStatus 1 = Status 'Up'.
#
# Se la query CIM non risponde si torna al cmdlet: piu' lento ma sicuro.
function Get-VtNicAdapters {
    if ($null -ne $script:VtNics) { return $script:VtNics }
    $script:VtNics = $null

    try {
        $script:VtNics = @(
            Get-CimInstance -Namespace 'root\StandardCimv2' -ClassName MSFT_NetAdapter -ErrorAction Stop |
            Where-Object { $_.ConnectorPresent -and $_.InterfaceOperationalStatus -eq 1 -and
                           $_.InterfaceDescription -notmatch 'Virtual|Hyper-V|Loopback|TAP|VPN' })
    } catch { $script:VtNics = $null }

    # Zero schede puo' essere vero (portatile in Wi-Fi spento) ma puo' anche
    # voler dire che la classe non esiste su questo Windows: nel dubbio si
    # ricontrolla col cmdlet, che e' la strada storica.
    if ($null -eq $script:VtNics -or $script:VtNics.Count -eq 0) {
        try {
            $script:VtNics = @(Get-NetAdapter -Physical -ErrorAction Stop |
                               Where-Object { $_.Status -eq 'Up' -and $_.InterfaceDescription -notmatch 'Virtual|Hyper-V|Loopback|TAP|VPN' })
        } catch { $script:VtNics = @() }
    }
    # La virgola e' obbligatoria: con UNA sola scheda PowerShell srotolerebbe
    # l'array e chi chiama riceverebbe l'oggetto singolo, con .Count vuoto.
    # Risultato: la condizione "ci sono schede?" falliva e le voci di rete
    # non entravano nel catalogo, pur essendoci una Ethernet attiva.
    return , $script:VtNics
}

function Clear-VtNicCache { $script:VtNics = $null }

# Aspetta che almeno una scheda fisica torni attiva dopo un riavvio del
# driver. Senza, tutto quello che viene dopo legge il vuoto e conclude che
# non ci sono schede.
function Wait-VtNicPronte([int] $SecondiMax = 40) {
    # Restart-NetAdapter torna PRIMA che il driver sia sceso davvero: se si
    # controlla subito, la scheda risulta ancora attiva e si tira dritto,
    # per poi trovare il vuoto un attimo dopo. Quindi si lascia il tempo al
    # ciclo di spegnimento di cominciare, e solo dopo si aspetta il ritorno.
    Start-Sleep -Seconds 3

    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $SecondiMax) {
        Clear-VtNicCache
        $a = @(Get-VtNicAdapters)
        if ($a.Count -gt 0) {
            # Essere "attiva" non basta: il driver deve anche rispondere alle
            # interrogazioni sulle proprieta' avanzate, che e' cio' che
            # useremo subito dopo. Questa e' la vera prova di pronto.
            $prova = $null
            try {
                $prova = Get-NetAdapterAdvancedProperty -Name $a[0].Name -ErrorAction Stop | Select-Object -First 1
            } catch { }
            if ($prova) {
                Write-VtLog "Scheda di rete pronta dopo $([math]::Round($sw.Elapsed.TotalSeconds + 3, 1)) secondi"
                return $true
            }
        }
        Start-Sleep -Milliseconds 800
    }
    Write-VtLog "La scheda di rete non e' tornata pronta entro $SecondiMax secondi." warn
    return $false
}

# Legge il valore grezzo di una proprieta' avanzata, o $null se il driver
# non la espone (cosa normalissima: ogni scheda ne ha un insieme diverso).
function Get-VtNicProp($adattatore, [string] $keyword) {
    try {
        $p = Get-NetAdapterAdvancedProperty -Name $adattatore.Name -RegistryKeyword $keyword -ErrorAction Stop
        if ($p -and $p.RegistryValue) { return "$($p.RegistryValue[0])" }
    } catch { }
    return $null
}

function Test-VtNicProps($voci) {
    $adattatori = @(Get-VtNicAdapters)
    if ($adattatori.Count -eq 0) { return $false }
    $trovate = 0
    foreach ($a in $adattatori) {
        foreach ($v in $voci) {
            $cur = Get-VtNicProp $a $v.Keyword
            if ($null -eq $cur) { continue }   # la scheda non ce l'ha: si salta
            $trovate++
            if ($cur -ne $v.Valore) { return $false }
        }
    }
    # Se nessuna delle proprieta' esiste su questo hardware, il tweak non ha
    # senso e resta spento invece di dichiararsi applicato.
    return ($trovate -gt 0)
}

function Set-VtNicProps([string] $id, $voci) {
    $adattatori = @(Get-VtNicAdapters)
    if ($adattatori.Count -eq 0) { throw 'Nessuna scheda di rete fisica attiva.' }

    $bak = @(); $saltate = @(); $fatte = 0
    foreach ($a in $adattatori) {
        foreach ($v in $voci) {
            $cur = Get-VtNicProp $a $v.Keyword
            if ($null -eq $cur) { $saltate += "$($a.Name)/$($v.Keyword)"; continue }
            if ($cur -eq $v.Valore) { continue }
            try {
                Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword $v.Keyword `
                    -RegistryValue $v.Valore -NoRestart -ErrorAction Stop
                $bak += @{ Nic = $a.Name; Keyword = $v.Keyword; Valore = $cur }
                $fatte++
            } catch {
                $saltate += "$($a.Name)/$($v.Keyword)"
                Write-VtLog "$($a.Name): '$($v.Keyword)' non modificabile ($($_.Exception.Message))" warn
            }
        }
    }

    Set-VtEntry $id @{ Nic = $bak; Saltate = $saltate }

    # -NoRestart su ogni singola proprieta' e poi un riavvio solo alla fine:
    # cosi' la connessione cade una volta per un paio di secondi invece di
    # cadere una volta per ogni impostazione cambiata.
    if ($fatte -gt 0) {
        foreach ($a in ($bak.Nic | Select-Object -Unique)) {
            try { Restart-NetAdapter -Name $a -ErrorAction Stop } catch { Write-VtLog "Riavvio della scheda '$a' non riuscito: la modifica avra' effetto al prossimo riavvio del PC." warn }
        }
        Clear-VtNicCache
        # Il riavvio della scheda richiede qualche secondo. Senza questa
        # attesa la lettura successiva non trova nessuna scheda attiva: la
        # voce appena applicata risultava spenta, e la voce successiva del
        # profilo falliva del tutto perche' "non c'e' nessuna scheda".
        Wait-VtNicPronte
    }
    Clear-VtNicCache
    Write-VtLog "Rete '$id': $fatte impostazioni cambiate, $($saltate.Count) non disponibili su questo hardware" ok
    return $fatte
}

function Restore-VtNicProps([string] $id) {
    $e = Get-VtEntry $id
    if (-not $e) { return }
    $nic = @()
    foreach ($b in @($e.Nic)) {
        try {
            Set-NetAdapterAdvancedProperty -Name $b.Nic -RegistryKeyword $b.Keyword `
                -RegistryValue $b.Valore -NoRestart -ErrorAction Stop
            $nic += $b.Nic
        } catch { }
    }
    foreach ($a in ($nic | Select-Object -Unique)) {
        try { Restart-NetAdapter -Name $a -ErrorAction Stop } catch { }
    }
    Remove-VtEntry $id
    Clear-VtNicCache
}

# "Consenti al computer di spegnere il dispositivo per risparmiare energia":
# la spunta sta nelle proprieta' della scheda, ma il valore vero e' questo.
# 24 (0x18) = risparmio energia disattivato.
function Get-VtNicPnpKeys {
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}'
    $out = @()
    foreach ($a in (Get-VtNicAdapters)) {
        foreach ($i in 0..20) {
            $k = Join-Path $base ('{0:0000}' -f $i)
            if (-not (Test-Path $k)) { continue }
            $net = Get-VtReg $k 'NetCfgInstanceId'
            if ($net -and $net -eq $a.InterfaceGuid) { $out += $k; break }
        }
    }
    $out
}

function Get-VtSteamLibraries {
    $libs = @()
    $sp = Get-VtReg 'HKCU:\Software\Valve\Steam' 'SteamPath'
    if (-not $sp) { return $libs }
    $sp = $sp -replace '/', '\'
    $libs += $sp
    $vdf = Join-Path $sp 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        foreach ($l in (Get-Content $vdf -ErrorAction SilentlyContinue)) {
            if ($l -match '"path"\s+"(.+)"') { $libs += ($matches[1] -replace '\\\\', '\') }
        }
    }
    $libs | Select-Object -Unique
}

function Get-VtEpicInstalls {
    $res = @()
    # Non 'C:\ProgramData': su un PC con Windows su un'altra unita' quel
    # percorso non esiste e i giochi Epic non verrebbero trovati.
    $dir = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    if (-not (Test-Path $dir)) { return $res }
    foreach ($f in (Get-ChildItem $dir -Filter *.item -ErrorAction SilentlyContinue)) {
        try {
            $m = Get-Content $f.FullName -Raw | ConvertFrom-Json
            if ($m.InstallLocation -and $m.LaunchExecutable) {
                $res += (Join-Path $m.InstallLocation $m.LaunchExecutable)
            }
        } catch { }
    }
    $res
}

$script:VtGiochi = @(
    @{ Nome='Fortnite'; Exe='FortniteClient-Win64-Shipping.exe'
       Rel=@('Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe') }
    @{ Nome='Valorant'; Exe='VALORANT-Win64-Shipping.exe'
       Rel=@('Riot Games\VALORANT\live\ShooterGame\Binaries\Win64\VALORANT-Win64-Shipping.exe') }
    # Dopo l'uscita di Enhanced, Rockstar ha rinominato la vecchia installazione
    # in "Grand Theft Auto V Legacy": e' quella che usa FiveM.
    @{ Nome='GTA V'; Exe='GTA5.exe'
       Rel=@('Rockstar Games\Grand Theft Auto V Legacy\GTA5.exe',
             'Rockstar Games\Grand Theft Auto V\GTA5.exe',
             'steamapps\common\Grand Theft Auto V Legacy\GTA5.exe',
             'steamapps\common\Grand Theft Auto V\GTA5.exe',
             'Epic Games\GTAV\GTA5.exe') }
    @{ Nome='GTA V Enhanced'; Exe='GTA5_Enhanced.exe'
       Rel=@('Rockstar Games\Grand Theft Auto V Enhanced\GTA5_Enhanced.exe',
             'steamapps\common\Grand Theft Auto V Enhanced\GTA5_Enhanced.exe') }
    @{ Nome='Rainbow Six Siege'; Exe='RainbowSix.exe'
       Rel=@('Ubisoft\Ubisoft Game Launcher\games\Tom Clancy''s Rainbow Six Siege\RainbowSix.exe',
             'steamapps\common\Tom Clancy''s Rainbow Six Siege\RainbowSix.exe') }
    @{ Nome='R6 Siege (Vulkan)'; Exe='RainbowSix_Vulkan.exe'
       Rel=@('Ubisoft\Ubisoft Game Launcher\games\Tom Clancy''s Rainbow Six Siege\RainbowSix_Vulkan.exe',
             'steamapps\common\Tom Clancy''s Rainbow Six Siege\RainbowSix_Vulkan.exe') }
    @{ Nome='FiveM'; Exe='FiveM.exe'; Rel=@() }
)

function Find-VtGiochi {
    if ($script:VtGiochiTrovati) { return $script:VtGiochiTrovati }

    $radici = @($env:ProgramFiles, ${env:ProgramFiles(x86)})
    foreach ($d in (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
        # Le parentesi attorno a ogni voce sono OBBLIGATORIE: in PowerShell la
        # virgola lega piu' forte del '+', quindi senza di esse
        #   $d.DeviceID + '\', $d.DeviceID + '\Games'
        # non produce due percorsi ma una stringa sola,
        #   'C:\ C:\Games C:\Program Files C:\Program Files (x86)'.
        # Con quel bug le radici dei dischi non venivano mai cercate e i
        # giochi fuori da Program Files (Valorant sta in C:\Riot Games)
        # risultavano non installati.
        $radici += @(
            ($d.DeviceID + '\'),
            ($d.DeviceID + '\Games'),
            ($d.DeviceID + '\Program Files'),
            ($d.DeviceID + '\Program Files (x86)')
        )
    }
    $radici += Get-VtSteamLibraries
    $radici = $radici | Where-Object { $_ } | Select-Object -Unique

    $epic = Get-VtEpicInstalls
    $out  = @()

    foreach ($g in $script:VtGiochi) {
        $path = $null
        foreach ($r in $radici) {
            foreach ($rel in $g.Rel) {
                $p = Join-Path $r $rel
                if (Test-Path -LiteralPath $p) { $path = $p; break }
            }
            if ($path) { break }
        }
        if (-not $path) {
            $m = $epic | Where-Object { $_ -like "*$($g.Exe)" } | Select-Object -First 1
            if ($m -and (Test-Path -LiteralPath $m)) { $path = $m }
        }
        if (-not $path -and $g.Nome -eq 'FiveM') {
            $p = Join-Path $env:LOCALAPPDATA 'FiveM\FiveM.exe'
            if (Test-Path -LiteralPath $p) { $path = $p }
        }
        if ($path) { $out += [pscustomobject]@{ Nome = $g.Nome; Path = $path } }
    }

    # Il processo che renderizza davvero FiveM ha il numero di build nel nome
    # e compare solo dopo il primo avvio.
    #
    # La ricerca DEVE essere ricorsiva: non stanno in FiveM.app ma in
    # FiveM.app\data\cache\subprocess. Cercando solo nella cartella superiore
    # non se ne trovava mai nemmeno uno, e tutto quello che si appoggiava a
    # questo elenco - schermo intero compreso - finiva sul lanciatore invece
    # che sul gioco.
    $app = Join-Path $env:LOCALAPPDATA 'FiveM\FiveM.app'
    if (Test-Path -LiteralPath $app) {
        foreach ($e in (Get-ChildItem $app -Filter 'FiveM_*_GTAProcess.exe' -Recurse -File -ErrorAction SilentlyContinue)) {
            $out += [pscustomobject]@{ Nome = 'FiveM (processo di gioco)'; Path = $e.FullName }
        }
    }

    $script:VtGiochiTrovati = $out
    return $out
}

# --- Stato reale della sicurezza basata su virtualizzazione ----------------
# Il registro dice cosa abbiamo chiesto; questo dice cosa sta succedendo
# davvero, ed e' quello che va scritto nella descrizione.
function Get-VtVbsDescrizione {
    if ($null -ne $script:VtVbsDesc) { return $script:VtVbsDesc }
    $script:VtVbsDesc = ''
    try {
        $d = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace 'root\Microsoft\Windows\DeviceGuard' -ErrorAction Stop
        $attiva = (@($d.SecurityServicesRunning) -contains 2)
        $script:VtVbsDesc = if ($attiva) {
            'Sul tuo PC adesso e'' ACCESA, quindi qui c''e'' da guadagnare.'
        } else {
            'Sul tuo PC adesso risulta gia'' spenta: applicare questa voce non ti dara'' frame in piu'', serve solo a impedire che Windows te la riaccenda.'
        }
    } catch { }
    return $script:VtVbsDesc
}

# --- Menu contestuale classico di Windows 11 -------------------------------
# Il menu nuovo passa per un componente moderno che si carica al momento: il
# ritardo fra clic destro e menu si vede a occhio nudo. Quello classico
# compare istantaneo. Si ottiene creando una chiave con il valore predefinito
# VUOTO: non e' una forzatura, e' l'interruttore che Microsoft ha lasciato.
$script:VtMenuClassicoKey = 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32'

function Test-VtMenuClassico { return (Test-Path -LiteralPath $script:VtMenuClassicoKey) }

function Set-VtMenuClassico([bool] $classico) {
    if ($classico) {
        New-Item -Path $script:VtMenuClassicoKey -Force | Out-Null
        Set-ItemProperty -Path $script:VtMenuClassicoKey -Name '(Default)' -Value '' -ErrorAction Stop
    } else {
        $padre = Split-Path $script:VtMenuClassicoKey -Parent
        Remove-Item -Path $padre -Recurse -Force -ErrorAction SilentlyContinue
    }
    # Explorer legge questa chiave all'avvio: senza riavviarlo non cambia
    # niente e sembrerebbe che il tweak non funzioni.
    try {
        Stop-Process -Name explorer -Force -ErrorAction Stop
        Start-Sleep -Milliseconds 700
        if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer.exe }
    } catch { Write-VtLog 'Explorer non riavviato: il menu cambiera'' al prossimo accesso' warn }
    Write-VtLog "Menu contestuale: $(if ($classico) { 'classico' } else { 'quello di Windows 11' })" ok
}

# ---------------------------------------------------------------------------
# VENTOLE DELLA SCHEDA VIDEO (NVAPI)
#
# Il canale vecchio (GetTachReading, SetCoolerLevels) su molte schede recenti
# risponde "non supportato": e' quello che usano le guide, ed e' il motivo per
# cui certi tool sembrano rotti. Quello che funziona e' il canale nuovo,
# ClientFanCoolers, e le strutture le ho trovate provandole a tappeto in sola
# lettura finche' il driver non ne ha accettata una.
#
#   STATO      1704 byte, versione 1. Intestazione 40, poi 32 ventole da 52:
#              id +0, giri +4, minimo% +8, massimo% +12, attuale% +16
#   CONTROLLO  1452 byte, versione 1. Intestazione 44 (versione, ?, conteggio,
#              riservati), poi 32 ventole da 44:
#              id +0, livello% +4, modo +8 (0 = automatico, 1 = manuale)
#
# ATTENZIONE a cosa fa davvero: questa API imposta una velocita' FISSA, non
# una curva. In manuale la ventola non sale piu' con la temperatura, resta
# dove l'hai messa. Per questo i preset partono da valori alti e per questo
# si torna in automatico con un clic.
#
# Il voltaggio NON si tocca, ed e' una scelta: le ventole non rovinano niente,
# la tensione del core si'.
if (-not ('VejaVentole' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class VejaVentole
{
    [DllImport("nvapi64.dll", EntryPoint = "nvapi_QueryInterface", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr QI(uint id);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Init();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_EnumGpu([Out] IntPtr[] h, out int n);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Buf(IntPtr g, IntPtr b);

    const int S_SIZE = 1704, S_HEAD = 40;
    const int C_SIZE = 1452, C_HEAD = 44, C_ITEM = 44;

    static T G<T>(uint id) where T : class {
        IntPtr p = QI(id);
        return p == IntPtr.Zero ? null : Marshal.GetDelegateForFunctionPointer(p, typeof(T)) as T;
    }
    static IntPtr Vuoto(int n) {
        IntPtr b = Marshal.AllocHGlobal(n);
        for (int i = 0; i < n; i++) Marshal.WriteByte(b, i, 0);
        return b;
    }
    static IntPtr Gpu() {
        var init = G<D_Init>(0x0150E828);
        if (init == null || init() != 0) return IntPtr.Zero;
        var e = G<D_EnumGpu>(0xE5AC921F);
        IntPtr[] g = new IntPtr[64]; int n;
        if (e == null || e(g, out n) != 0 || n == 0) return IntPtr.Zero;
        return g[0];
    }

    // "giri;minimo;massimo;attuale" oppure "" se non leggibile.
    public static string Stato()
    {
        IntPtr g = Gpu(); if (g == IntPtr.Zero) return "";
        var s = G<D_Buf>(0x35AED5E8); if (s == null) return "";
        IntPtr b = Vuoto(S_SIZE);
        try {
            Marshal.WriteInt32(b, 0, S_SIZE | (1 << 16));
            if (s(g, b) != 0) return "";
            if (Marshal.ReadInt32(b, 4) < 1) return "";
            return Marshal.ReadInt32(b, S_HEAD + 4) + ";" + Marshal.ReadInt32(b, S_HEAD + 8) + ";" +
                   Marshal.ReadInt32(b, S_HEAD + 12) + ";" + Marshal.ReadInt32(b, S_HEAD + 16);
        } finally { Marshal.FreeHGlobal(b); }
    }

    // 0 = automatico, 1 = manuale, -1 = non leggibile.
    public static int Modo()
    {
        IntPtr g = Gpu(); if (g == IntPtr.Zero) return -1;
        var c = G<D_Buf>(0x814B209F); if (c == null) return -1;
        IntPtr b = Vuoto(C_SIZE);
        try {
            Marshal.WriteInt32(b, 0, C_SIZE | (1 << 16));
            if (c(g, b) != 0) return -1;
            return Marshal.ReadInt32(b, C_HEAD + 8);
        } finally { Marshal.FreeHGlobal(b); }
    }

    // livello < 0 significa "torna automatico". Restituisce il codice NVAPI.
    public static int Imposta(int livello)
    {
        IntPtr g = Gpu(); if (g == IntPtr.Zero) return -1000;
        var get = G<D_Buf>(0x814B209F);
        var set = G<D_Buf>(0xA58971A5);
        if (get == null || set == null) return -1001;
        IntPtr b = Vuoto(C_SIZE);
        try {
            Marshal.WriteInt32(b, 0, C_SIZE | (1 << 16));
            int r = get(g, b);
            if (r != 0) return r;
            int cnt = Marshal.ReadInt32(b, 8);
            if (cnt < 1) cnt = 1;
            for (int i = 0; i < cnt; i++) {
                int o = C_HEAD + i * C_ITEM;
                if (livello < 0) { Marshal.WriteInt32(b, o + 8, 0); }
                else { Marshal.WriteInt32(b, o + 4, livello); Marshal.WriteInt32(b, o + 8, 1); }
            }
            return set(g, b);
        } finally { Marshal.FreeHGlobal(b); }
    }
}
'@ -ErrorAction SilentlyContinue
}

function Get-VtVentolaStato {
    if (-not (Test-VtNvApi)) { return $null }
    try {
        $s = [VejaVentole]::Stato()
        if (-not $s) { return $null }
        $p = $s.Split(';')
        [pscustomobject]@{ Giri = [int] $p[0]; Min = [int] $p[1]; Max = [int] $p[2]; Attuale = [int] $p[3] }
    } catch { return $null }
}

# Prova di capacita' INNOCUA: si chiede "torna automatico". Se le ventole
# sono gia' in automatico - e lo sono, di serie - non cambia niente; se il
# driver accetta il comando vuol dire che accettera' anche gli altri.
# E' l'unico modo di sapere se il controllo funziona senza muovere davvero
# la ventola di chi sta usando il programma.
function Test-VtVentoleControllabili {
    if ($null -ne $script:VtVentOk) { return $script:VtVentOk }
    $script:VtVentOk = $false
    try {
        if ((Test-VtNvApi) -and (Get-VtVentolaStato)) {
            $script:VtVentOk = ([VejaVentole]::Imposta(-1) -eq 0)
        }
    } catch { }
    return $script:VtVentOk
}

function Set-VtVentola([int] $livello) {
    $st = Get-VtVentolaStato
    if (-not $st) { throw 'Le ventole di questa scheda non sono leggibili.' }

    if ($livello -ge 0) {
        # Mai sotto il minimo dichiarato dalla scheda: sotto quella soglia
        # certe ventole si fermano del tutto, e in manuale non ripartirebbero
        # da sole quando la temperatura sale.
        if ($livello -lt $st.Min) { $livello = $st.Min }
        if ($livello -gt $st.Max) { $livello = $st.Max }
    }
    $r = [VejaVentole]::Imposta($livello)
    if ($r -ne 0) {
        throw "Il driver ha rifiutato il comando (codice $r). Su molte schede di PC preassemblati la ventola la gestisce la scheda madre, non la GPU, e NVIDIA non lascia scriverci."
    }
    Write-VtLog "Ventola GPU: $(if ($livello -lt 0) { 'tornata automatica' } else { "portata al $livello%" })" ok
}

# ---------------------------------------------------------------------------
# RISPARMIO ENERGIA SUI DISPOSITIVI DI INPUT
#
# Windows puo' mettere mouse e tastiera in stato di basso consumo quando non
# li usi. Il primo movimento dopo una pausa serve a risvegliarli, e arriva
# in ritardo: e' quella sensazione di puntatore che "parte con uno scatto"
# dopo qualche secondo di fermo.
#
# Si tocca un solo valore per dispositivo, EnhancedPowerManagementEnabled,
# che e' quello dietro la casella "Consenti al computer di spegnere questo
# dispositivo" in Gestione dispositivi. Niente di piu'.
#
# Nota su cosa NON faccio: le curve SmoothMouseXCurve/YCurve le lascio stare.
# Girano decine di guide che le riscrivono "per togliere l'accelerazione
# residua", ma Windows le usa SOLO quando "Migliora precisione del
# puntatore" e' acceso. Con quella spenta - e qui e' spenta - riscriverle
# non cambia un pixel. Sarebbe un tweak che sembra fare qualcosa e non fa
# niente.
# ---------------------------------------------------------------------------
# In cache perche' Get-PnpDevice costa quattrocento millisecondi e questa
# funzione veniva chiamata tre volte: due di fila nella costruzione del
# catalogo (una per sapere se la voce serve, una per contare i dispositivi) e
# una per leggere lo stato dell'interruttore. Un secondo e due per una
# risposta sola.
#
# Si svuota quando si scrive, che e' l'unico momento in cui puo' cambiare.
function Clear-VtInputPowerCache { $script:VtInput = $null }

function Get-VtInputPower {
    if ($null -ne $script:VtInput) { return $script:VtInput }
    $out = @()
    try {
        foreach ($d in (Get-PnpDevice -Class 'Mouse', 'Keyboard', 'HIDClass' -Status OK -ErrorAction Stop)) {
            $k = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($d.InstanceId)\Device Parameters"
            if (-not (Test-Path -LiteralPath $k)) { continue }
            $v = (Get-ItemProperty -LiteralPath $k -Name 'EnhancedPowerManagementEnabled' -ErrorAction SilentlyContinue).EnhancedPowerManagementEnabled
            if ($null -eq $v) { continue }
            $out += [pscustomobject]@{ Nome = $d.FriendlyName; Chiave = $k; Valore = [int] $v }
        }
    } catch { }
    $script:VtInput = $out
    return $script:VtInput
}

function Test-VtInputPowerOff {
    $d = @(Get-VtInputPower)
    if ($d.Count -eq 0) { return $false }
    foreach ($x in $d) { if ($x.Valore -ne 0) { return $false } }
    return $true
}

function Set-VtInputPower([bool] $risparmio) {
    $d = @(Get-VtInputPower)
    if ($d.Count -eq 0) { throw 'Nessun dispositivo di input espone questa impostazione.' }
    # Da qui in poi i valori letti non valgono piu': si riparte dal registro.
    Clear-VtInputPowerCache

    if (-not $risparmio) {
        $prima = @()
        $fatti = 0; $saltati = @()
        foreach ($x in $d) {
            try {
                Set-ItemProperty -LiteralPath $x.Chiave -Name 'EnhancedPowerManagementEnabled' -Value 0 -Type DWord -ErrorAction Stop
                $prima += @{ Chiave = $x.Chiave; Valore = $x.Valore }
                $fatti++
            } catch {
                # Alcune chiavi Enum appartengono a TrustedInstaller: si salta
                # quel dispositivo, non si butta via tutto il gruppo.
                $saltati += $x.Nome
            }
        }
        if ($fatti -eq 0) { throw 'Nessun dispositivo modificato: permessi insufficienti sulle chiavi.' }
        Set-VtEntry 'input-power' @{ Voci = $prima; Saltati = $saltati }
        if ($saltati.Count -gt 0) { Write-VtLog ("Risparmio energia non modificabile su: " + ($saltati -join ', ')) warn }
        Write-VtLog "Risparmio energia disattivato su $fatti dispositivi di input" ok
    } else {
        $e = Get-VtEntry 'input-power'
        if ($e) {
            foreach ($b in @($e.Voci)) {
                try { Set-ItemProperty -LiteralPath $b.Chiave -Name 'EnhancedPowerManagementEnabled' -Value ([int] $b.Valore) -Type DWord -ErrorAction Stop } catch { }
            }
            Remove-VtEntry 'input-power'
        }
        Write-VtLog 'Risparmio energia sui dispositivi di input riportato com''era' ok
    }
    Clear-VtInputPowerCache
}

# ---------------------------------------------------------------------------
# CONTROLLER
#
# Chi gioca con il pad ha problemi diversi da chi gioca con mouse e tastiera,
# e nessuno dei tweak classici li tocca. I tre guai veri sono:
#
#   1. i driver dei controller disattivati. Succede da solo: gli script che
#      "spengono cinquanta servizi per andare piu' veloce" prendono in mezzo
#      XboxGipSvc, e da quel momento un pad Xbox non viene piu' riconosciuto.
#      Il cliente pensa che sia rotto il controller.
#   2. Windows che spegne le porte USB per risparmiare corrente, e il pad che
#      si scollega da solo a meta' partita.
#   3. il tasto Xbox che apre la Game Bar sopra il gioco.
#
# Il deadzone e la sensibilita' degli stick NON stanno in Windows: sono dentro
# ogni gioco. Qui non si puo' fare niente, e infatti non si finge di poterlo.
# ---------------------------------------------------------------------------

# Gamepad collegati adesso.
#
# Il riconoscimento e' su HID_DEVICE_SYSTEM_GAME, il marchio che Windows mette
# ai dispositivi di gioco: non dipende dalla lingua di Windows ne' dalla marca
# del pad. Cercare "Xbox" o "Controller" nel nome avrebbe funzionato solo in
# italiano e solo con le marche a cui avessi pensato io.
function Get-VtGamepad {
    if ($null -ne $script:VtGamepad) { return $script:VtGamepad }
    $out = @()
    try {
        $q = "PNPClass='HIDClass' OR PNPClass='XnaComposite' OR PNPClass='XboxComposite'"
        foreach ($d in (Get-CimInstance Win32_PnPEntity -Filter $q -ErrorAction Stop)) {
            if (@($d.CompatibleID) -notcontains 'HID_DEVICE_SYSTEM_GAME') { continue }
            $out += [pscustomobject]@{ Nome = $d.Name; Id = $d.DeviceID; Stato = $d.Status }
        }
    } catch { }
    $script:VtGamepad = @($out)
    return $script:VtGamepad
}

function Clear-VtGamepadCache { $script:VtGamepad = $null }

# I pad gia' visti da questo PC, anche se adesso non sono collegati.
#
# La fonte e' il ramo Joystick\OEM, che Windows scrive la prima volta che
# colleghi un dispositivo di gioco e non ripulisce mai. Avevo provato prima
# con Enum\HID e il marchio HID_DEVICE_SYSTEM_GAME: li' non resta niente una
# volta scollegato il pad, quindi l'elenco veniva sempre vuoto.
#
# Il nome per esteso c'e' solo per alcuni; per gli altri resta il codice
# VID/PID, e almeno il produttore si puo' dire.
$script:VtVendorUsb = @{
    '045E' = 'Microsoft / Xbox'
    '054C' = 'Sony'
    '057E' = 'Nintendo'
    '046D' = 'Logitech'
    '28DE' = 'Valve'
    '0F0D' = 'Hori'
    '24C6' = 'PowerA'
    '2DC8' = '8BitDo'
    '0079' = 'DragonRise'
    '1532' = 'Razer'
    '0E6F' = 'PDP'
}

function Get-VtGamepadStorici {
    $out = @()
    try {
        $k = 'HKCU:\System\CurrentControlSet\Control\MediaProperties\PrivateProperties\Joystick\OEM'
        foreach ($i in (Get-ChildItem $k -ErrorAction Stop)) {
            $n = (Get-ItemProperty $i.PSPath -Name 'OEMName' -ErrorAction SilentlyContinue).OEMName
            if (-not $n) {
                $vid = ''
                if ("$($i.PSChildName)" -match 'VID_([0-9A-Fa-f]{4})') { $vid = $Matches[1].ToUpper() }
                $marca = $script:VtVendorUsb[$vid]
                $n = if ($marca) { "controller $marca ($($i.PSChildName))" } else { "controller $($i.PSChildName)" }
            }
            if ($out -notcontains $n) { $out += $n }
        }
    } catch { }
    return $out
}

# I driver che servono ai controller, con il valore di avvio con cui Windows
# li installa. 3 = manuale: partono quando colleghi il pad.
#
# Non c'e' niente da "ottimizzare" qui: c'e' solo da rimettere a posto quello
# che qualcun altro ha spento.
$script:VtServiziController = @(
    @{ Name='XboxGipSvc'; Start=3; Perche='Servizio dei controller Xbox (Game Input Protocol). Disattivato, un pad Xbox collegato via cavo o via adattatore wireless non viene riconosciuto: Windows lo vede ma i giochi no.' }
    @{ Name='xboxgip';    Start=3; Perche='Il driver vero e proprio del protocollo Xbox. Va in coppia con XboxGipSvc.' }
    @{ Name='xinputhid';  Start=3; Perche='Filtro XInput: e'' l''interfaccia con cui praticamente tutti i giochi moderni leggono un pad. Senza, il controller risponde nei menu di Windows ma non nel gioco.' }
    @{ Name='hidusb';     Start=3; Perche='Driver HID su USB. Sotto ci stanno pad, mouse e tastiere collegati via cavo.' }
    @{ Name='HidBth';     Start=3; Perche='Driver HID su Bluetooth: serve ai pad senza filo collegati direttamente, senza dongle (DualSense e DualShock 4 fanno cosi'').' }
    @{ Name='BthEnum';    Start=3; Perche='Enumeratore Bluetooth: e'' quello che presenta al sistema i dispositivi accoppiati.' }
    @{ Name='BTHUSB';     Start=3; Perche='Driver della radio Bluetooth. Disattivato, il Bluetooth non esiste proprio.' }
)

function Get-VtControllerServizi {
    $out = @()
    foreach ($s in $script:VtServiziController) {
        $k = "HKLM:\SYSTEM\CurrentControlSet\Services\$($s.Name)"
        if (-not (Test-Path $k)) { continue }
        $now = $null
        try { $now = [int] (Get-ItemProperty $k -Name Start -ErrorAction Stop).Start } catch { continue }
        $out += [pscustomobject]@{
            Name    = $s.Name
            Perche  = $s.Perche
            Atteso  = [int] $s.Start
            Attuale = $now
            Spento  = ($now -eq 4)
        }
    }
    return $out
}

function Get-VtControllerSpenti { @(Get-VtControllerServizi | Where-Object { $_.Spento }) }

# "A posto" = nessuno disattivato. Un manuale al posto di un automatico puo'
# essere una scelta di Windows; un disabilitato no.
function Test-VtControllerServiziOk {
    $tutti = @(Get-VtControllerServizi)
    if ($tutti.Count -eq 0) { return $false }
    return (@($tutti | Where-Object { $_.Spento }).Count -eq 0)
}

function Set-VtControllerServizi([bool] $sistema) {
    if (-not (Test-VtAdmin)) { throw 'Servono i permessi di amministratore.' }

    if ($sistema) {
        $rotti = @(Get-VtControllerSpenti)
        if ($rotti.Count -eq 0) { return }
        $prima = @(); $fatti = 0; $saltati = @()
        foreach ($r in $rotti) {
            # Set-Service e NON la scrittura diretta nel registro: il Gestore
            # controllo servizi tiene una copia caricata all'avvio e
            # continuerebbe a rispondere 1058 "servizio disabilitato".
            # Questa lezione e' gia' costata un'ora una volta.
            $tipo = switch ($r.Atteso) { 2 { 'Automatic' } 3 { 'Manual' } default { 'Manual' } }
            try {
                Set-Service -Name $r.Name -StartupType $tipo -ErrorAction Stop
                $prima += @{ N = $r.Name; V = $r.Attuale }
                $fatti++
            } catch {
                $saltati += $r.Name
                Write-VtLog "Driver controller '$($r.Name)' non modificabile: $($_.Exception.Message)" warn
            }
        }
        if ($fatti -eq 0) { throw 'Nessun driver dei controller modificato: Windows li protegge.' }
        Set-VtEntry 'ctrl-servizi' @{ Voci = $prima; Saltati = $saltati }
        Write-VtLog "Driver dei controller riattivati: $fatti" ok
    } else {
        $e = Get-VtEntry 'ctrl-servizi'
        if ($e) {
            foreach ($b in @($e.Voci)) {
                $tipo = switch ([int] $b.V) { 2 { 'Automatic' } 3 { 'Manual' } 4 { 'Disabled' } default { 'Manual' } }
                try { Set-Service -Name $b.N -StartupType $tipo -ErrorAction Stop } catch { }
            }
            Remove-VtEntry 'ctrl-servizi'
        }
        Write-VtLog 'Driver dei controller riportati com''erano' ok
    }
}

# --- risparmio energia sugli hub USB ---------------------------------------
#
# Distinto da 'input-power', che agisce sui DISPOSITIVI (mouse, tastiera,
# pad). Qui si tratta degli HUB, cioe' le porte: Windows puo' spegnere l'hub
# anche se il dispositivo attaccato e' impostato per restare acceso, e il
# risultato e' il pad che si scollega da solo dopo qualche minuto fermo.
#
# EnhancedPowerManagementEnabled = 0 e' esattamente la casella "Consenti al
# computer di spegnere questo dispositivo" di Gestione dispositivi.
function Get-VtUsbHub {
    if ($null -ne $script:VtUsbHub) { return $script:VtUsbHub }
    $out = @()
    try {
        foreach ($v in (Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Enum\USB' -ErrorAction Stop)) {
            foreach ($i in (Get-ChildItem $v.PSPath -ErrorAction SilentlyContinue)) {
                $p = Get-ItemProperty $i.PSPath -ErrorAction SilentlyContinue
                if ($p.Service -notin 'usbhub', 'USBHUB3') { continue }
                $dp = Join-Path $i.PSPath 'Device Parameters'
                if (-not (Test-Path -LiteralPath $dp)) { continue }
                $val = (Get-ItemProperty -LiteralPath $dp -Name 'EnhancedPowerManagementEnabled' -ErrorAction SilentlyContinue).EnhancedPowerManagementEnabled
                $out += [pscustomobject]@{
                    Nome   = ("$($p.DeviceDesc)" -replace '.*;', '')
                    Chiave = $dp
                    # $null significa "il valore non c'e'", che per Windows
                    # vuol dire acceso. Va distinto da uno zero scritto, se no
                    # l'annullamento scriverebbe un valore che prima non c'era.
                    Valore = $(if ($null -eq $val) { $null } else { [int] $val })
                }
            }
        }
    } catch { }
    $script:VtUsbHub = @($out)
    return $script:VtUsbHub
}

function Clear-VtUsbHubCache { $script:VtUsbHub = $null }

function Test-VtUsbHubPowerOff {
    $h = @(Get-VtUsbHub)
    if ($h.Count -eq 0) { return $false }
    foreach ($x in $h) { if ($x.Valore -ne 0) { return $false } }
    return $true
}

function Set-VtUsbHubPower([bool] $risparmio) {
    $h = @(Get-VtUsbHub)
    if ($h.Count -eq 0) { throw 'Nessun hub USB trovato nel registro.' }
    Clear-VtUsbHubCache

    if (-not $risparmio) {
        $prima = @(); $fatti = 0; $saltati = @()
        foreach ($x in $h) {
            try {
                Set-ItemProperty -LiteralPath $x.Chiave -Name 'EnhancedPowerManagementEnabled' -Value 0 -Type DWord -ErrorAction Stop
                # Assente lo segno come -1: in JSON un $null si perde.
                $prima += @{ K = $x.Chiave; V = $(if ($null -eq $x.Valore) { -1 } else { [int] $x.Valore }) }
                $fatti++
            } catch { $saltati += $x.Nome }
        }
        if ($fatti -eq 0) { throw 'Nessun hub USB modificato: permessi insufficienti sulle chiavi.' }
        Set-VtEntry 'ctrl-usb-power' @{ Voci = $prima; Saltati = $saltati }
        Write-VtLog "Risparmio energia disattivato su $fatti hub USB" ok
    } else {
        $e = Get-VtEntry 'ctrl-usb-power'
        if ($e) {
            foreach ($b in @($e.Voci)) {
                try {
                    if ([int] $b.V -lt 0) {
                        Remove-ItemProperty -LiteralPath $b.K -Name 'EnhancedPowerManagementEnabled' -ErrorAction Stop
                    } else {
                        Set-ItemProperty -LiteralPath $b.K -Name 'EnhancedPowerManagementEnabled' -Value ([int] $b.V) -Type DWord -ErrorAction Stop
                    }
                } catch { }
            }
            Remove-VtEntry 'ctrl-usb-power'
        }
        Write-VtLog 'Risparmio energia sugli hub USB riportato com''era' ok
    }
    Clear-VtUsbHubCache
}

# ---------------------------------------------------------------------------
# MSI: interrupt a messaggio sulla scheda audio
#
# Un dispositivo PCI puo' avvisare la CPU in due modi. Alla vecchia maniera
# (line-based) usa un piedino fisico che spesso e' CONDIVISO con altri
# dispositivi: il sistema deve chiedere a ognuno "sei stato tu?", e quel giro
# di domande e' tempo passato in interrupt. Con MSI il dispositivo scrive
# direttamente in memoria, senza piedino condiviso e senza interrogatorio.
#
# Sul tuo PC video, rete e disco NVMe usano gia' MSI: gli unici rimasti
# indietro sono i due controller audio. E l'audio e' il caso peggiore, perche'
# genera interrupt in continuazione mentre giochi.
#
# Non e' overclock e non tocca tensioni: e' solo il modo in cui il dispositivo
# bussa alla CPU. Si annulla riportando il valore com'era.
function Get-VtAudioPci {
    if ($null -ne $script:VtAudioPci) { return $script:VtAudioPci }
    $out = @()
    try {
        foreach ($dev in (Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Enum\PCI' -ErrorAction Stop)) {
            foreach ($ist in (Get-ChildItem $dev.PSPath -ErrorAction SilentlyContinue)) {
                $desc = (Get-ItemProperty $ist.PSPath -Name 'DeviceDesc' -ErrorAction SilentlyContinue).DeviceDesc
                if ("$desc" -notmatch 'Audio') { continue }
                $mp = Join-Path $ist.PSPath 'Device Parameters\Interrupt Management\MessageSignaledInterruptProperties'
                $val = $null
                if (Test-Path -LiteralPath $mp) {
                    $val = (Get-ItemProperty -LiteralPath $mp -Name 'MSISupported' -ErrorAction SilentlyContinue).MSISupported
                }
                $out += [pscustomobject]@{
                    Nome   = ("$desc" -replace '.*;', '')
                    Chiave = $mp
                    Valore = $(if ($null -eq $val) { $null } else { [int] $val })
                }
            }
        }
    } catch { }
    $script:VtAudioPci = @($out)
    return $script:VtAudioPci
}

function Clear-VtAudioPciCache { $script:VtAudioPci = $null }

function Test-VtMsiAudioOn {
    $a = @(Get-VtAudioPci)
    if ($a.Count -eq 0) { return $false }
    foreach ($x in $a) { if ($x.Valore -ne 1) { return $false } }
    return $true
}

function Set-VtMsiAudio([bool] $acceso) {
    if (-not (Test-VtAdmin)) { throw 'Servono i permessi di amministratore.' }
    $a = @(Get-VtAudioPci)
    if ($a.Count -eq 0) { throw 'Nessun controller audio PCI trovato.' }
    Clear-VtAudioPciCache

    if ($acceso) {
        $prima = @(); $fatti = 0
        foreach ($x in $a) {
            try {
                if (-not (Test-Path -LiteralPath $x.Chiave)) { New-Item -Path $x.Chiave -Force -ErrorAction Stop | Out-Null }
                Set-ItemProperty -LiteralPath $x.Chiave -Name 'MSISupported' -Value 1 -Type DWord -ErrorAction Stop
                $prima += @{ K = $x.Chiave; V = $(if ($null -eq $x.Valore) { -1 } else { [int] $x.Valore }) }
                $fatti++
            } catch {
                Write-VtLog "MSI non impostabile su '$($x.Nome)': $($_.Exception.Message)" warn
            }
        }
        if ($fatti -eq 0) { throw 'Nessun controller audio modificato: permessi insufficienti sulle chiavi.' }
        Set-VtEntry 'msi-audio' @{ Voci = $prima }
        Write-VtLog "MSI attivato su $fatti controller audio (serve il riavvio)" ok
    } else {
        $e = Get-VtEntry 'msi-audio'
        if ($e) {
            foreach ($b in @($e.Voci)) {
                try {
                    if ([int] $b.V -lt 0) { Remove-ItemProperty -LiteralPath $b.K -Name 'MSISupported' -ErrorAction Stop }
                    else { Set-ItemProperty -LiteralPath $b.K -Name 'MSISupported' -Value ([int] $b.V) -Type DWord -ErrorAction Stop }
                } catch { }
            }
            Remove-VtEntry 'msi-audio'
        }
        Write-VtLog 'MSI sull''audio riportato com''era (serve il riavvio)' ok
    }
    Clear-VtAudioPciCache
}

# ---------------------------------------------------------------------------
# MEMORIA IN STANDBY
#
# Quando chiudi un programma, Windows non butta via la memoria che aveva
# letto dal disco: la tiene "in standby", pronta nel caso serva ancora. E'
# una buona idea, finche' quella lista non diventa enorme. A quel punto un
# gioco che chiede molta memoria tutta insieme costringe il sistema a
# svuotarla di corsa, e quel lavoro si sente come uno scatto secco.
#
# Succede soprattutto dopo ore di sessione, o dopo aver chiuso qualcosa di
# pesante (un altro gioco, un browser con venti schede) e averne aperto un
# altro subito dopo.
#
# Qui non si disattiva niente: si svuota la lista adesso, una volta. Nessuna
# impostazione cambia, e al prossimo avvio Windows ricomincia come sempre.
# ---------------------------------------------------------------------------
function Get-VtMemoriaStato {
    $c = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $standby = $null
    try {
        # Via WMI e non con Get-Counter: i nomi dei contatori sono TRADOTTI,
        # quindi '\Memory\Standby Cache Reserve Bytes' non esiste su un
        # Windows italiano e la lettura falliva in silenzio. I nomi delle
        # proprieta' WMI invece sono gli stessi in tutte le lingue.
        $m = Get-CimInstance Win32_PerfRawData_PerfOS_Memory -ErrorAction Stop
        $standby = [math]::Round(([double] $m.StandbyCacheCoreBytes +
                                  [double] $m.StandbyCacheNormalPriorityBytes +
                                  [double] $m.StandbyCacheReserveBytes) / 1MB)
    } catch { }
    [pscustomobject]@{
        TotaleMb  = if ($c) { [math]::Round($c.TotalVisibleMemorySize / 1KB) } else { 0 }
        LiberaMb  = if ($c) { [math]::Round($c.FreePhysicalMemory / 1KB) } else { 0 }
        StandbyMb = $standby
    }
}

function Clear-VtMemoriaStandby {
    if (-not (Test-VtAdmin)) { throw 'Servono i permessi di amministratore.' }

    if (-not ('VejaMem' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class VejaMem
{
    [StructLayout(LayoutKind.Sequential)] struct LUID { public uint Low; public int High; }
    [StructLayout(LayoutKind.Sequential)] struct LUID_AND_ATTRIBUTES { public LUID Luid; public uint Attributes; }
    [StructLayout(LayoutKind.Sequential)] struct TOKEN_PRIVILEGES { public uint Count; public LUID_AND_ATTRIBUTES Priv; }

    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool OpenProcessToken(IntPtr h, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern bool LookupPrivilegeValue(string sys, string name, out LUID luid);
    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool AdjustTokenPrivileges(IntPtr token, bool disableAll, ref TOKEN_PRIVILEGES nw, uint len, IntPtr prev, IntPtr rl);
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
    [DllImport("ntdll.dll")]
    static extern int NtSetSystemInformation(int infoClass, IntPtr info, int length);

    // 80 = SystemMemoryListInformation ; comando 4 = PurgeStandbyList
    const int SystemMemoryListInformation = 80;
    const int MemoryPurgeStandbyList = 4;

    public static int Svuota()
    {
        IntPtr tok;
        if (!OpenProcessToken(GetCurrentProcess(), 0x0020 | 0x0008, out tok)) return -1;
        try {
            LUID luid;
            if (!LookupPrivilegeValue(null, "SeProfileSingleProcessPrivilege", out luid)) return -2;
            TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
            tp.Count = 1; tp.Priv.Luid = luid; tp.Priv.Attributes = 0x00000002;
            if (!AdjustTokenPrivileges(tok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero)) return -3;
            if (Marshal.GetLastWin32Error() != 0) return -4;

            IntPtr buf = Marshal.AllocHGlobal(sizeof(int));
            try {
                Marshal.WriteInt32(buf, MemoryPurgeStandbyList);
                return NtSetSystemInformation(SystemMemoryListInformation, buf, sizeof(int));
            } finally { Marshal.FreeHGlobal(buf); }
        } finally { CloseHandle(tok); }
    }
}
'@ -ErrorAction Stop
    }

    $prima = Get-VtMemoriaStato
    $r = [VejaMem]::Svuota()
    if ($r -ne 0) {
        $motivo = switch ($r) {
            -1 { 'non riesco ad aprire il token del processo' }
            -2 { 'il privilegio richiesto non esiste su questo Windows' }
            -3 { 'Windows ha rifiutato il privilegio' }
            -4 { 'il privilegio non e'' stato concesso: serve l''avvio come amministratore' }
            default { "il kernel ha risposto $r" }
        }
        throw "Non sono riuscito a svuotare la memoria in standby: $motivo."
    }
    $dopo = Get-VtMemoriaStato
    Write-VtLog "Memoria in standby svuotata: da $($prima.StandbyMb) a $($dopo.StandbyMb) MB" ok
    return [pscustomobject]@{ Prima = $prima; Dopo = $dopo }
}

# ---------------------------------------------------------------------------
# SERVIZI CHE NON SI TOCCANO
#
# Ogni tanto arriva un cliente con FiveM che non parte piu', o senza audio, o
# senza rete, dopo aver passato sopra al PC uno di quegli script che
# disattivano cinquanta servizi "per andare piu' veloce". Qui ci sono quelli
# che non vanno disattivati mai, con accanto il valore di avvio GIUSTO.
#
# Perche' il valore giusto e non "automatico" per tutti: rimettere tutto su
# automatico e' quasi altrettanto sbagliato. 'bam' e' un driver che parte al
# boot (Start=1): metterlo su automatico ne cambia l'ordine di caricamento.
# 'Appinfo' di fabbrica e' manuale (Start=3) e va benissimo cosi': parte
# quando serve. I file .cmd che girano in rete mettono auto su tutto e questi
# due li peggiorano.
#
#   Start 0/1 = driver (boot / sistema)   2 = automatico   3 = manuale
# ---------------------------------------------------------------------------
$script:VtServiziEssenziali = @(
    @{ Name='bam';        Start=1; Perche='Registra l''attivita' + [char]39 + ' dei programmi in background. FiveM e diversi antibarare lo interrogano all''avvio: disattivato, il gioco puo'' rifiutarsi di partire senza spiegare perche''.' }
    @{ Name='Appinfo';    Start=3; Perche='E'' il servizio che gestisce la richiesta di permessi amministratore. Disattivato, i programmi che si avviano come amministratore - FiveM compreso - non partono.' }
    @{ Name='BFE';        Start=2; Perche='Motore di filtraggio di base: sotto ci stanno il firewall e tutto il filtraggio di rete di Windows. Disattivato si porta dietro mezza rete.' }
    @{ Name='mpssvc';     Start=2; Perche='Windows Defender Firewall. Senza, il PC e'' esposto e diversi programmi non riescono ad aprire le proprie porte.' }
    @{ Name='RpcSs';      Start=2; Perche='Chiamate di procedura remota: e'' l''impalcatura su cui poggia meta'' di Windows. Toccarlo rende il sistema non avviabile.' }
    @{ Name='DcomLaunch'; Start=2; Perche='Avvia i processi server DCOM. Stessa storia di RpcSs: senza, Windows non arriva al desktop.' }
    @{ Name='CryptSvc';   Start=2; Perche='Servizi di crittografia: verificano le firme dei file. Disattivato, aggiornamenti e installazioni cominciano a fallire con errori incomprensibili.' }
    @{ Name='Dhcp';       Start=2; Perche='Senza, il PC non prende l''indirizzo IP dal router: niente rete.' }
    @{ Name='Dnscache';   Start=2; Perche='Risoluzione dei nomi. Disattivato, i siti e i server di gioco non si raggiungono per nome.' }
    @{ Name='nsi';        Start=2; Perche='Archivio di stato della rete. Disattivarlo toglie la connessione e basta.' }
    @{ Name='EventLog';   Start=2; Perche='Registro eventi. Ci dipendono altri servizi, e senza si perde ogni traccia dei crash: e'' anche quello che permette a VejaTweak di dirti se il driver video e'' andato in errore.' }
    @{ Name='AudioSrv';           Start=2; Perche='Audio di Windows. Disattivato, il PC resta muto.' }
    @{ Name='AudioEndpointBuilder'; Start=2; Perche='Rileva cuffie e casse. Senza, l''audio non trova un''uscita.' }
    @{ Name='Winmgmt';    Start=2; Perche='Strumentazione di gestione: la usano mezzo Windows e tutti i programmi che leggono lo stato del sistema, VejaTweak compreso.' }
    @{ Name='Power';      Start=2; Perche='Gestione del risparmio energia. Disattivato, i piani di alimentazione smettono di funzionare e la CPU resta dove capita.' }
    @{ Name='ProfSvc';    Start=2; Perche='Carica il profilo utente all''accesso. Senza, si finisce con un profilo temporaneo e il desktop vuoto.' }
    @{ Name='Schedule';   Start=2; Perche='Utilita'' di pianificazione. Ci girano manutenzione, aggiornamenti dei driver e diverse cose dei giochi.' }
    @{ Name='gpsvc';      Start=2; Perche='Criteri di gruppo. Disattivarlo e'' uno dei modi piu'' rapidi per ritrovarsi con un Windows che non applica piu'' niente.' }
    @{ Name='UserManager';        Start=2; Perche='Gestisce le sessioni utente. Senza, il menu Start e la barra smettono di funzionare.' }
    @{ Name='SystemEventsBroker'; Start=2; Perche='Smista gli eventi di sistema alle app. Disattivato, molte app moderne non partono.' }
    @{ Name='StateRepository';    Start=2; Perche='Archivio di stato delle app. Senza, il menu Start e le app di Windows si rompono.' }
    @{ Name='DusmSvc';    Start=2; Perche='Consumo dati. Non e'' vitale, ma se lo disattivi mentre e'' attivo il conteggio di rete Windows registra errori a ogni avvio.' }
    @{ Name='DPS';        Start=2; Perche='Criteri di diagnostica: e'' quello che fa funzionare la risoluzione problemi di rete quando qualcosa non va.' }

    # --- controllati dallo staff dei server di ruolo -----------------------
    # Non servono alle prestazioni: servono a NON farti passare per uno che
    # ha cancellato le tracce. Tengono nota di cosa e' stato eseguito sul PC,
    # ed e' esattamente per questo che chi bara li spegne.
    @{ Name='PcaSvc';    Start=3; Staff=$true; Perche='Tiene traccia dei programmi eseguiti. E'' nella lista che lo staff dei server di ruolo controlla: trovarlo fermo vale come prove cancellate.' }
    @{ Name='SysMain';   Start=2; Staff=$true; Perche='I file di prefetch che genera dicono quali programmi hai lanciato. Lo staff lo controlla: fermo, sembra che tu abbia ripulito.' }
    @{ Name='DiagTrack'; Start=2; Staff=$true; Perche='Telemetria di Microsoft. A te non serve, ma lo staff dei server di ruolo la controlla perche'' registra l''uso delle applicazioni: spenta, sei sospetto.' }
    @{ Name='CDPSvc';    Start=2; Staff=$true; Perche='Piattaforma dispositivi connessi. Compare nell''elenco che controlla lo staff dei server di ruolo.' }
    @{ Name='SSDPSRV';   Start=3; Staff=$true; Perche='Individuazione SSDP. Compare nell''elenco che controlla lo staff dei server di ruolo.' }
)

function Get-VtServiziEssenziali {
    # La pagina del controllo staff la chiama, e poi Get-VtControlloStaff la
    # richiama da capo: due giri di Get-Service su ventotto servizi per la
    # stessa risposta.
    if ($null -ne $script:VtEssenzC) { return $script:VtEssenzC }
    $out = @()
    foreach ($s in $script:VtServiziEssenziali) {
        $k = "HKLM:\SYSTEM\CurrentControlSet\Services\$($s.Name)"
        if (-not (Test-Path $k)) { continue }
        $now = $null
        try { $now = (Get-ItemProperty $k -Name Start -ErrorAction Stop).Start } catch { continue }
        $srv = Get-Service $s.Name -ErrorAction SilentlyContinue
        $out += [pscustomobject]@{
            Name       = $s.Name
            Perche     = $s.Perche
            Staff      = [bool] $s.Staff
            Atteso     = [int] $s.Start
            Attuale    = [int] $now
            Disattivato= ([int] $now -eq 4)
            # Per le voci del controllo staff non basta che non siano
            # disabilitate: devono essere IN ESECUZIONE, perche' e' lo stato
            # che il comando dello staff legge.
            Fermo      = ([bool] $s.Staff -and $srv -and $srv.Status -ne 'Running')
            Stato      = $(if ($srv) { "$($srv.Status)" } else { 'sconosciuto' })
            Nome       = $(if ($srv) { $srv.DisplayName } else { $s.Name })
        }
    }
    $script:VtEssenzC = @($out)
    return $script:VtEssenzC
}

# Le voci che farebbero fallire il controllo dello staff: spente o ferme.
function Get-VtControlloStaff {
    @(Get-VtServiziEssenziali | Where-Object { $_.Staff }) | ForEach-Object {
        $ok = (-not $_.Disattivato) -and ($_.Stato -eq 'Running')
        $_ | Add-Member -NotePropertyName Passa -NotePropertyValue $ok -Force
        $_
    }
}

# Quelli messi su "Disabilitato": e' l'unico valore inequivocabilmente
# sbagliato per queste voci. Un manuale al posto di un automatico puo' essere
# una scelta; un disabilitato no.
function Get-VtServiziRotti { @(Get-VtServiziEssenziali | Where-Object { $_.Disattivato -or $_.Fermo }) }

function Repair-VtServizi {
    if (-not (Test-VtAdmin)) { throw 'Servono i permessi di amministratore.' }
    Clear-VtStateCache
    $rotti = @(Get-VtServiziRotti)
    if ($rotti.Count -eq 0) { return [pscustomobject]@{ Riparati = 0; Falliti = @() } }

    $ok = 0; $ko = @(); $alRiavvio = @()
    foreach ($r in $rotti) {
        try {
            if ($r.Atteso -le 1) {
                # Driver: il tipo di avvio "boot"/"sistema" non si esprime con
                # Set-Service, e comunque un driver lo carica il kernel
                # all'accensione. Qui si scrive il valore e si aspetta.
                Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$($r.Name)" -Name Start -Value $r.Atteso -ErrorAction Stop
                $alRiavvio += $r.Name
                $ok++
            } else {
                # Set-Service, NON la scrittura diretta nel registro.
                #
                # Questa e' costata un'ora: cambiando il valore Start a mano,
                # il registro risulta corretto ma il Gestore controllo servizi
                # continua a usare la copia che ha caricato all'avvio, e
                # rispondeva 1058 "il servizio e' disabilitato" su un servizio
                # che nel registro era automatico. Set-Service passa dall'API
                # del gestore e aggiorna tutte e due.
                $tipo = if ($r.Atteso -eq 2) { 'Automatic' } else { 'Manual' }
                Set-Service -Name $r.Name -StartupType $tipo -ErrorAction Stop
                try {
                    Start-Service -Name $r.Name -ErrorAction Stop
                } catch {
                    # Alcuni si avviano solo su richiesta di chi li usa: aver
                    # rimesso il tipo di avvio giusto e' gia' il risultato.
                    Write-VtLog "'$($r.Name)': tipo di avvio corretto, non avviato ora ($($_.Exception.Message))" warn
                }
                $ok++
            }
            Write-VtLog "Servizio '$($r.Name)' rimesso al valore corretto ($($r.Atteso))" ok
        } catch {
            $ko += "$($r.Name): $($_.Exception.Message)"
        }
    }
    # Dopo la riparazione l'elenco in cache non vale piu': senza questo la
    # pagina continuerebbe a mostrare i servizi come rotti.
    Clear-VtStateCache
    [pscustomobject]@{ Riparati = $ok; Falliti = $ko; AlRiavvio = $alRiavvio }
}

# --- Modalita' video che lo schermo accetta davvero ------------------------
#
# Serve per lo schermo intero ESCLUSIVO: per andarci, la risoluzione che
# chiedi deve esistere come modalita' della scheda video. Se non esiste, il
# gioco non puo' cambiare modo e ripiega su una finestra - ed e' esattamente
# il motivo per cui una stretched scritta a mano "va solo in finestra".
# Le stretched che il driver NVIDIA ha gia' registrato ci sono; una inventata
# al momento no, e va creata prima dal pannello.
if (-not ('VejaSchermo' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public class VejaSchermo
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct DEVMODE {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
        public int dmFields, dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
        public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
        public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2, dmPanningWidth, dmPanningHeight;
    }
    [DllImport("user32.dll")] static extern bool EnumDisplaySettings(string dev, int mode, ref DEVMODE dm);

    // "LARGHEZZAxALTEZZA@HZ" per ogni modalita' a 32 bit.
    public static string[] Modi()
    {
        var l = new List<string>();
        var dm = new DEVMODE();
        dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
        for (int i = 0; EnumDisplaySettings(null, i, ref dm); i++)
            if (dm.dmBitsPerPel == 32)
                l.Add(dm.dmPelsWidth + "x" + dm.dmPelsHeight + "@" + dm.dmDisplayFrequency);
        return l.ToArray();
    }
}
'@ -ErrorAction SilentlyContinue
}

function Get-VtModiSchermo {
    if ($null -ne $script:VtModi) { return $script:VtModi }
    $script:VtModi = @()
    try { $script:VtModi = @([VejaSchermo]::Modi()) } catch { }
    return $script:VtModi
}

# Vero se quella risoluzione esiste come modalita' (a qualsiasi frequenza).
function Test-VtRisoluzioneDisponibile([int] $x, [int] $y) {
    $m = @(Get-VtModiSchermo)
    if ($m.Count -eq 0) { return $true }   # non si e' potuto leggere: non blocco
    return [bool] (@($m | Where-Object { $_ -like "${x}x${y}@*" }).Count -gt 0)
}

function Get-VtHzMassimo([int] $x, [int] $y) {
    $hz = @(Get-VtModiSchermo | Where-Object { $_ -like "${x}x${y}@*" } | ForEach-Object { [int] $_.Split('@')[1] })
    if ($hz.Count -eq 0) { return 0 }
    return ($hz | Measure-Object -Maximum).Maximum
}

# Le risoluzioni da proporre, prese da quelle che lo schermo espone DAVVERO.
#
# Prima l'elenco era fisso: 1920x1080, 1600x1080, 1440x1080, 1280x1080,
# 1024x768. Il guaio e' che due di quelle - 1600x1080 e 1280x1080 - su un
# monitor normale non esistono, perche' le stretched vanno create a mano nel
# pannello NVIDIA. Il cliente le sceglieva, VejaTweak scriveva "impostata", e
# poi il gioco non riusciva ad andare in schermo intero esclusivo a quella
# misura: ripiegava sulla nativa e riscriveva il file. Risultato: la
# risoluzione "non si applica" e il file resta a meta'.
#
# Adesso si propone solo cio' che esiste. Le stretched che l'utente si e'
# creato nel pannello compaiono da sole, che e' meglio di qualsiasi elenco
# scritto da me.
function Get-VtRisoluzioniProponibili {
    $modi = @(Get-VtModiSchermo)
    if ($modi.Count -eq 0) { return @() }

    $nativa = $null
    try {
        $v = Get-CimInstance Win32_VideoController -ErrorAction Stop |
             Where-Object { $_.CurrentHorizontalResolution -gt 0 } | Select-Object -First 1
        if ($v) { $nativa = [pscustomobject]@{ X = [int] $v.CurrentHorizontalResolution; Y = [int] $v.CurrentVerticalResolution } }
    } catch { }

    $viste = @{}
    $out = @()
    foreach ($m in $modi) {
        $p = $m.Split('@')[0].Split('x')
        if ($p.Count -ne 2) { continue }
        $x = [int] $p[0]; $y = [int] $p[1]
        $k = "${x}x${y}"
        if ($viste.ContainsKey($k)) { continue }
        $viste[$k] = $true

        # Sotto gli 800 di larghezza non ha senso proporre niente: sono
        # modalita' che il driver espone per compatibilita', non da giocarci.
        if ($x -lt 800) { continue }

        $out += [pscustomobject]@{
            X = $x; Y = $y
            Nativa = ($nativa -and $x -eq $nativa.X -and $y -eq $nativa.Y)
            Formato = (Get-VtFormato $x $y)
            Hz = (Get-VtHzMassimo $x $y)
        }
    }

    # Ordine utile a chi gioca: prima la nativa, poi le stretched dalla piu'
    # larga alla piu' stretta, e in fondo il resto.
    $ordine = {
        if ($_.Nativa) { return 0 }
        if ($nativa -and $_.Y -eq $nativa.Y) { return 1 }
        return 2
    }
    return @($out | Sort-Object @{ E = $ordine }, @{ E = 'X'; Descending = $true })
}

# --- Ottimizzazioni schermo intero, per gioco ------------------------------
# Le "fullscreen optimizations" fanno girare il gioco in una finestra senza
# bordi gestita dal compositore di Windows anche quando chiedi lo schermo
# intero. Comodo per l'Alt+Tab, ma aggiunge un passaggio fra il fotogramma
# finito e il monitor. Disattivandole si torna allo schermo intero vero.
$script:VtLayersKey = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'

function Get-VtGiochiExe {
    $out = @()
    foreach ($g in (Find-VtGiochi)) {
        if ($g.Path -and $g.Path -like '*.exe' -and (Test-Path -LiteralPath $g.Path)) { $out += $g.Path }
    }
    return ($out | Select-Object -Unique)
}

function Test-VtSchermoIntero {
    $exe = @(Get-VtGiochiExe)
    if ($exe.Count -eq 0) { return $false }
    if (-not (Test-Path $script:VtLayersKey)) { return $false }
    $p = Get-ItemProperty $script:VtLayersKey -ErrorAction SilentlyContinue
    foreach ($e in $exe) {
        $v = $p.$e
        if (-not $v -or $v -notmatch 'DISABLEDXMAXIMIZEDWINDOWEDMODE') { return $false }
    }
    return $true
}

function Set-VtSchermoIntero([bool] $disattiva) {
    $exe = @(Get-VtGiochiExe)
    if ($exe.Count -eq 0) { throw 'Nessun gioco rilevato su questo PC.' }
    if (-not (Test-Path $script:VtLayersKey)) { New-Item -Path $script:VtLayersKey -Force | Out-Null }

    if ($disattiva) {
        $prima = @()
        $p = Get-ItemProperty $script:VtLayersKey -ErrorAction SilentlyContinue
        foreach ($e in $exe) {
            $vecchio = if ($p -and $p.$e) { "$($p.$e)" } else { $null }
            $prima += @{ Exe = $e; Valore = $vecchio }
            # Si CONSERVA quello che c'era (per esempio HIGHDPIAWARE) e si
            # aggiunge la voce nostra, invece di sovrascrivere tutto.
            $nuovo = if ($vecchio -and $vecchio -notmatch 'DISABLEDXMAXIMIZEDWINDOWEDMODE') {
                ($vecchio.TrimEnd() + ' DISABLEDXMAXIMIZEDWINDOWEDMODE')
            } elseif ($vecchio) { $vecchio } else { '~ DISABLEDXMAXIMIZEDWINDOWEDMODE' }
            Set-ItemProperty -Path $script:VtLayersKey -Name $e -Value $nuovo -ErrorAction Stop
        }
        Set-VtEntry 'giochi-schermo-intero' @{ Exe = $prima }
        Write-VtLog "Ottimizzazioni schermo intero disattivate su $($exe.Count) giochi" ok
    } else {
        $e2 = Get-VtEntry 'giochi-schermo-intero'
        if ($e2) {
            foreach ($b in @($e2.Exe)) {
                try {
                    if ($b.Valore) { Set-ItemProperty -Path $script:VtLayersKey -Name $b.Exe -Value $b.Valore -ErrorAction Stop }
                    else           { Remove-ItemProperty -Path $script:VtLayersKey -Name $b.Exe -ErrorAction SilentlyContinue }
                } catch { Write-VtLog "Ripristino '$($b.Exe)' non riuscito: $($_.Exception.Message)" warn }
            }
            Remove-VtEntry 'giochi-schermo-intero'
        }
        Write-VtLog 'Ottimizzazioni schermo intero riportate come prima' ok
    }
}

# Vero se il gioco risulta installato. Usata dal catalogo per non mostrare
# voci di giochi che non hai: un interruttore che non puo' servire a niente
# e' solo un modo per far perdere fiducia nel resto.
function Get-VtGioco([string] $nome) {
    return [bool] (@(Find-VtGiochi | Where-Object { $_.Nome -eq $nome }).Count -gt 0)
}

# ---------------------------------------------------------------------------
# CATALOGO
#
#   Id      chiave stabile, usata per il backup: non cambiarla mai
#   Cat     sezione nella barra laterale
#   Nome    etichetta sulla card
#   Desc    cosa fa, in italiano
#   Perche  perche' aiuta gli FPS (mostrato sotto "Dettagli")
#   Warn    avvertenza, se c'e' un compromesso vero
#   Rischio 'sicuro' | 'medio' | 'alto'
#   Reboot  serve riavviare perche' abbia effetto
#   Kind    'Reg' | 'Svc' | 'Script' | 'Action'
# ---------------------------------------------------------------------------
$MM   = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
$GAME = "$MM\Tasks\Games"

function Get-VtCatalog {
    if ($script:VtCatalog) { return $script:VtCatalog }
    $sys = Get-VtSystem

    $c = @()

    # ======================= GENERALI ======================================
    $c += @{
        Id='gamedvr'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='Registrazione in background OFF'
        Desc='Spegne Game DVR, la cattura app e il buffer degli ultimi 30 secondi'
        Perche='La cattura in background tiene un encoder video sempre acceso mentre giochi. E'' la voce che da sola pesa di piu'' fra quelle di Windows: 3-10% di FPS e frame time massimi molto peggiori.'
        Items=@(
            @{ Path='HKCU:\System\GameConfigStore'; Name='GameDVR_Enabled'; Type='DWord'; Val=0 }
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name='AppCaptureEnabled'; Type='DWord'; Val=0 }
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; Name='HistoricalCaptureEnabled'; Type='DWord'; Val=0 }
            @{ Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR'; Name='AllowGameDVR'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='gamemode'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='Modalita'' gioco ON'
        Desc='Tiene accesa la Modalita'' gioco e il rilevamento automatico dei giochi'
        Perche='Va tenuta ACCESA, al contrario di quello che si legge in giro: sospende gli aggiornamenti durante la partita e sposta i task di sistema sui core che il gioco non sta usando.'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\GameBar'; Name='AllowAutoGameMode'; Type='DWord'; Val=1 }
            @{ Path='HKCU:\Software\Microsoft\GameBar'; Name='AutoGameModeEnabled'; Type='DWord'; Val=1 }
        )
    }
    $c += @{
        Id='gamebar-panel'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='Pannello Game Bar all''avvio OFF'
        Desc='Non apre piu'' il pannello del Game Bar quando lanci un gioco'
        Perche='Un overlay in meno che si aggancia al render nel momento peggiore, cioe'' mentre il gioco carica le shader.'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\GameBar'; Name='ShowStartupPanel'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='bg-apps'; Cat='Generali'; Kind='Reg'; Rischio='sicuro'
        Nome='App in background OFF'
        Desc='Impedisce alle app del Microsoft Store di girare quando non le usi'
        Perche='Meteo, Posta, Xbox e compagnia si svegliano a intervalli per aggiornarsi. Poca CPU ciascuna, ma arrivano a raffica e proprio mentre il gioco vuole tutto.'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'; Name='GlobalUserDisabled'; Type='DWord'; Val=1 }
        )
    }
    $c += @{
        Id='notifiche'; Cat='Generali'; Kind='Reg'; Rischio='medio'
        Nome='Notifiche toast OFF'
        Desc='Niente popup di notifica dall''angolo dello schermo'
        Perche='Una notifica che compare mentre giochi costa un frame e, in schermo intero senza bordi, puo'' rubare il focus.'
        Warn='Non riceverai piu'' NESSUNA notifica di Windows, comprese quelle che potrebbero interessarti (messaggi, promemoria).'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications'; Name='ToastEnabled'; Type='DWord'; Val=0 }
        )
    }

    # ======================= MOUSE E TASTIERA ==============================
    $c += @{
        Id='mouse-accel'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Accelerazione mouse OFF'
        Desc='Disattiva "Precisione puntatore migliorata" e le sue due soglie'
        Perche='Con l''accelerazione attiva i tuoi cm/360 cambiano in base a quanto muovi in fretta: la stessa mossa del polso da'' due mire diverse. E'' il singolo motivo per cui la mira non diventa muscolo.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseSpeed'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseThreshold1'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseThreshold2'; Type='String'; Val='0' }
        )
    }
    $c += @{
        Id='mouse-1to1'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Sensibilita'' Windows 6/11 (1:1)'
        Desc='Mette il cursore di sensibilita'' di Windows nella tacca centrale'
        Perche='6/11 e'' l''unico valore che passa i conteggi del sensore cosi'' come sono. Sopra, Windows li moltiplica e salti pixel; sotto, li scarta e perdi risoluzione di mira.'
        Warn='Il puntatore sul desktop cambiera'' velocita''. Regola i DPI dal software del mouse, non da qui.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseSensitivity'; Type='String'; Val='10' }
        )
    }
    if (@(Get-VtInputPower).Count -gt 0) {
        $nInput = @(Get-VtInputPower).Count
        $c += @{
            Id='input-power'; Cat='Mouse e tastiera'; Kind='Script'; Rischio='sicuro'
            Nome='Risparmio energia su mouse e tastiera OFF'
            Desc="Impedisce a Windows di mettere in basso consumo i $nInput dispositivi di input collegati"
            Perche='Windows puo'' spegnere mouse e tastiera quando non li usi per qualche secondo. Il primo movimento dopo la pausa serve a risvegliarli e arriva in ritardo: e'' quella sensazione di puntatore che parte con uno scatto quando riprendi in mano il mouse dopo esserti fermato. Nei momenti morti di una partita succede piu'' spesso di quanto sembri. E'' la stessa casella che trovi in Gestione dispositivi sotto "Consenti al computer di spegnere questo dispositivo".'
            Nota='Su un portatile a batteria consuma qualche milliwatt in piu''. Su un fisso non cambia niente.'
            Test={ Test-VtInputPowerOff }
            On={  Set-VtInputPower $false }
            Off={ Set-VtInputPower $true }
        }
    }
    $c += @{
        Id='mouse-trails'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Scia del puntatore OFF'
        Desc='Toglie le copie del cursore disegnate a ogni frame'
        Perche='Rifinitura, ma nei menu di gioco la scia si vede ed e'' lavoro inutile per il compositor.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Mouse'; Name='MouseTrails'; Type='String'; Val='0' }
        )
    }
    $c += @{
        Id='tasti-accessibilita'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Tasti permanenti e filtro tasti OFF'
        Desc='Disattiva tasti permanenti, filtro tasti e segnale acustico, compresi i loro hotkey'
        Perche='Il filtro tasti IGNORA le pressioni ripetute veloci: e'' input drop vero e proprio sui tap rapidi. I tasti permanenti aprono un popup a 5 MAIUSC che ruba il focus e minimizza il gioco.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Accessibility\StickyKeys'; Name='Flags'; Type='String'; Val='506' }
            @{ Path='HKCU:\Control Panel\Accessibility\Keyboard Response'; Name='Flags'; Type='String'; Val='122' }
            @{ Path='HKCU:\Control Panel\Accessibility\ToggleKeys'; Name='Flags'; Type='String'; Val='58' }
        )
    }
    $c += @{
        Id='tastiera-ripetizione'; Cat='Mouse e tastiera'; Kind='Reg'; Rischio='sicuro'
        Nome='Ripetizione tasti al massimo'
        Desc='Ritardo di ripetizione al minimo e velocita'' al massimo'
        Perche='Conta nei menu, nella chat e nei giochi che leggono la ripetizione invece dello stato del tasto.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Keyboard'; Name='KeyboardDelay'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Keyboard'; Name='KeyboardSpeed'; Type='String'; Val='31' }
        )
    }

    # ======================= CONTROLLER ====================================
    # Le voci ci sono sempre, anche senza un pad collegato adesso: un cliente
    # che lo attacca dopo non deve ritrovarsi una sezione sparita.
    $ctrlSpenti = @(Get-VtControllerSpenti)
    $c += @{
        Id='ctrl-servizi'; Cat='Controller'; Kind='Script'; Rischio='sicuro'
        Nome='Driver dei controller attivi'
        Desc=$(if ($ctrlSpenti.Count -gt 0) {
                "Riattiva i $($ctrlSpenti.Count) driver dei controller che risultano disattivati su questo PC"
            } else {
                'Tiene attivi i driver che servono a far funzionare i pad'
            })
        Perche='Non e'' un''ottimizzazione, e'' una riparazione. Gli script che spengono cinquanta servizi "per andare piu'' veloce" prendono in mezzo anche XboxGipSvc e xinputhid, e da quel momento il pad non viene piu'' riconosciuto dai giochi: nei menu di Windows magari risponde, in partita no. Il cliente pensa che si sia rotto il controller e compra un controller nuovo.'
        Test={ Test-VtControllerServiziOk }
        On={  Set-VtControllerServizi $true }
        Off={ Set-VtControllerServizi $false }
    }
    $c += @{
        Id='ctrl-usb-power'; Cat='Controller'; Kind='Script'; Rischio='sicuro'
        Nome='Risparmio energia sulle porte USB OFF'
        Desc='Impedisce a Windows di spegnere gli hub USB, cioe'' le porte'
        Perche='E'' la causa numero uno del pad che si scollega da solo dopo qualche minuto fermo, e del mouse che "si addormenta". La voce di Mouse e tastiera agisce sui DISPOSITIVI; questa sugli HUB, cioe'' sulle porte: Windows puo'' spegnere la porta anche se il dispositivo attaccato e'' impostato per restare acceso, e allora non serve a niente aver sistemato il dispositivo.'
        Nota='Su un fisso non cambia niente in bolletta. Su un portatile a batteria consuma qualche milliwatt in piu''.'
        Test={ Test-VtUsbHubPowerOff }
        On={  Set-VtUsbHubPower $false }
        Off={ Set-VtUsbHubPower $true }
    }
    $c += @{
        Id='ctrl-gamebar'; Cat='Controller'; Kind='Reg'; Rischio='sicuro'
        Nome='Il tasto Xbox non apre la Game Bar'
        Desc='Il tasto centrale del pad smette di aprire l''overlay di Windows'
        Perche='Di serie il tasto Xbox (o PS) apre la Game Bar SOPRA il gioco. Se lo sfiori in partita ti ritrovi l''overlay davanti, il gioco perde il focus e in certi casi cala anche di frame. Il tasto continua a funzionare dentro i giochi che lo usano: quello che si toglie e'' solo la scorciatoia di Windows.'
        Items=@(
            @{ Path='HKCU:\SOFTWARE\Microsoft\GameBar'; Name='UseNexusForGameBarEnabled'; Type='DWord'; Val=0 }
        )
    }

    # ======================= INTERFACCIA ===================================
    $c += @{
        Id='trasparenze'; Cat='Interfaccia'; Kind='Reg'; Rischio='sicuro'
        Nome='Trasparenze OFF'
        Desc='Toglie gli effetti acrilici da menu Start, barra e finestre'
        Perche='Gli effetti acrilici sono un blur a schermo intero che il compositor ricalcola di continuo. Si sente in alt-tab e in finestra senza bordi.'
        Items=@(
            @{ Path='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize'; Name='EnableTransparency'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='animazioni'; Cat='Interfaccia'; Kind='Reg'; Rischio='sicuro'
        Nome='Animazioni superflue OFF'
        Desc='Niente animazione di riduci/ingrandisci, menu che si aprono subito'
        Perche='Alt-tab istantaneo invece che animato: quando devi rientrare nel gioco in fretta, sono decimi di secondo veri.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Desktop\WindowMetrics'; Name='MinAnimate'; Type='String'; Val='0' }
            @{ Path='HKCU:\Control Panel\Desktop'; Name='MenuShowDelay'; Type='String'; Val='0' }
        )
    }

    # ======================= CPU E SCHEDULER ===============================
    $c += @{
        Id='mmcss-risposta'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Massima risposta per i giochi'
        Desc='Riduce dal 20% al 10% la CPU che Windows tiene da parte per i task di sistema'
        Perche='Quella quota e'' riservata a prescindere, anche quando nessuno la usa. Dimezzarla lascia piu'' tempo al gioco; azzerarla del tutto invece fa saltare l''audio, quindi ci fermiamo a 10.'
        Items=@(
            @{ Path=$MM; Name='SystemResponsiveness'; Type='DWord'; Val=10 }
        )
    }
    $c += @{
        Id='net-throttling'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Throttling di rete multimediale OFF'
        Desc='Toglie il tetto di 10 pacchetti al millisecondo imposto quando c''e'' audio o video attivo'
        Perche='Il limite serviva alle schede di rete del 2008. Oggi, su FiveM e sui giochi con tickrate alto, e'' solo un tetto artificiale sui pacchetti in arrivo.'
        Items=@(
            @{ Path=$MM; Name='NetworkThrottlingIndex'; Type='DWord'; Val=-1 }
        )
    }
    $c += @{
        Id='priorita-primo-piano'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Priorita'' all''app in primo piano'
        Desc='Quanti di CPU lunghi e fissi per la finestra attiva'
        Perche='38 (0x26) da'' al gioco in primo piano fette di esecuzione lunghe e di durata costante: meno cambi di contesto, frame time piu'' regolare.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl'; Name='Win32PrioritySeparation'; Type='DWord'; Val=38 }
        )
    }
    $c += @{
        Id='profilo-giochi'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='sicuro'
        Nome='Profilo multimediale bassa latenza'
        Desc='Alza priorita'' CPU, GPU e I/O del profilo di sistema "Games"'
        Perche='E'' il profilo MMCSS che i giochi richiedono da soli al sistema. Alzare la priorita'' di I/O in particolare evita che lo streaming delle texture finisca in coda dietro ai processi di sistema: si sente sugli stutter di GTA e FiveM.'
        Items=@(
            @{ Path=$GAME; Name='Priority'; Type='DWord'; Val=6 }
            @{ Path=$GAME; Name='GPU Priority'; Type='DWord'; Val=8 }
            @{ Path=$GAME; Name='Scheduling Category'; Type='String'; Val='High' }
            @{ Path=$GAME; Name='SFIO Priority'; Type='String'; Val='High' }
        )
    }

    # ======================= SCHEDA VIDEO ==================================
    $c += @{
        Id='hags'; Cat='Scheda video'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Pianificazione GPU accelerata (HAGS)'
        Desc='Lascia che sia la GPU a gestire la propria coda di comandi'
        Perche='Toglie lavoro al thread di rendering della CPU e permette a NVIDIA Reflex di lavorare al meglio. Su una RTX/RX moderna e'' quasi sempre un guadagno netto.'
        Warn='Su GPU o driver molto vecchi puo'' invece introdurre stutter. Se dopo il riavvio noti scatti, rimettilo su OFF.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'; Name='HwSchMode'; Type='DWord'; Val=2 }
        )
    }
    # Voci di Discord: compaiono solo se Discord e' installato.
    if (Get-VtDiscordSettings) {
        $c += @{
            Id='discord-hwaccel'; Cat='Discord'; Kind='Script'; Rischio='sicuro'
            Nome='Accelerazione hardware OFF'
            Desc='Discord smette di usare la scheda video per disegnare la propria interfaccia'
            Perche='Discord e'' un browser Chromium travestito e apre un processo dedicato alla GPU: su questo PC occupa centinaia di megabyte e compete con il gioco proprio mentre giochi. Spento, disegna con la CPU: consuma un filo di processore quando lo guardi, ma smette di disturbare la scheda video quando non lo guardi.'
            Warn='Discord dev''essere chiuso, altrimenti riscrive il file quando esce e cancella la modifica.'
            Test={
                $s = Get-VtDiscordSettings
                if (-not $s) { return $false }
                try {
                    $j = Get-Content -LiteralPath $s -Raw | ConvertFrom-Json
                    return ($j.enableHardwareAcceleration -eq $false)
                } catch { return $false }
            }
            On={ Set-VtDiscordAccelerazione $false }
            Off={ Set-VtDiscordAccelerazione $true }
        }
        $c += @{
            Id='discord-overlay'; Cat='Discord'; Kind='Script'; Rischio='medio'
            Nome='Overlay di Discord OFF'
            Desc='Impedisce all''overlay di agganciarsi ai giochi'
            Perche='L''overlay si inserisce nella catena di rendering di ogni gioco per disegnarci sopra la sua finestra: e'' il pezzo di Discord che pesa di piu'' sui frame e sul ritardo fra mouse e schermo. Qui viene neutralizzato il modulo che lo carica, quindi non parte proprio invece di partire e restare nascosto.'
            Warn='Perdi la finestra di Discord dentro il gioco (rispondere ai messaggi senza uscire). E soprattutto: un aggiornamento di Discord puo'' rimettere il modulo al suo posto. Non e'' un problema silenzioso, perche'' l''interruttore torna spento da solo e te ne accorgi: basta riattivarlo. Discord dev''essere chiuso per applicarlo.'
            Test={ Test-VtDiscordOverlayOff }
            On={  Set-VtDiscordOverlay $false | Out-Null }
            Off={ Set-VtDiscordOverlay $true  | Out-Null }
        }
    }

    # Movimento e strafe di FiveM. Compare solo se fivem.cfg esiste davvero:
    # il file nasce al primo avvio del gioco.
    if ((Get-VtFivemCfg).Esiste) {
        $c += @{
            Id='fivem-movimento'; Cat='FiveM movimento'; Kind='Script'; Rischio='sicuro'
            Nome='Strafe e movimento: togli tutto quello che si mette in mezzo'
            Desc='Dieci voci di fivem.cfg che rendono ripetibile il cambio di direzione A-D'
            Perche='Con l''accelerazione attiva lo stesso movimento del polso non da'' mai lo stesso risultato: il colpo dopo lo strafe non e'' ripetibile, e ti sembra di sbagliare tu. Qui vengono azzerate accelerazione del mouse, accelerazione della mira (sul tuo file era a 7 su 10), inerzia, oscillazione della testa, auto-livellamento e auto-centratura. Sono le stesse voci delle impostazioni del gioco, cambiate tutte insieme e rimettibili com''erano.'
            Nota='La velocita'' con cui il personaggio si muove NON si tocca: quella la decide il server, e cambiarla da qui sarebbe barare. Qui si toglie solo quello che sta fra il tasto che premi e quello che vedi.'
            Test={ Test-VtFivemMovimento }
            On={  Set-VtFivemMovimento }
            Off={ Restore-VtFivemMovimento }
        }
    }

    # Impostazioni del pannello NVIDIA, scritte via NVAPI sul profilo globale.
    # Compaiono solo se la libreria risponde davvero: su una scheda AMD, o con
    # driver troppo vecchi, la sezione non esiste invece di dare errori.
    if (Test-VtNvApi) {
        $c += @{
            Id='nv-vsync'; Cat='Pannello NVIDIA'; Kind='Nvapi'; Rischio='medio'
            Nome='Sincronizzazione verticale forzata OFF'
            Desc='Il driver ignora il V-Sync chiesto dai giochi'
            Perche='Il V-Sync fa aspettare la GPU che il monitor sia pronto: aggiunge fino a un frame intero di ritardo fra il tuo clic e quello che vedi. Su un 200 Hz e'' il singolo ritardo piu'' grosso che puoi toglierti.'
            Warn='Se hai G-Sync o FreeSync, questa NON e'' la scelta giusta: con lo schermo adattivo la regola e'' V-Sync ATTIVO nel pannello piu'' un limite FPS qualche frame sotto il refresh. Forzandolo off perdi la sincronizzazione adattiva e vedrai il tearing.'
            Nv=@(@{ Id=0x00A879CF; Val=0x08416747 })   # VSYNCMODE = forzata off
        }
        $c += @{
            Id='nv-power'; Cat='Pannello NVIDIA'; Kind='Nvapi'; Rischio='sicuro'
            Nome='Gestione alimentazione: prestazioni massime'
            Desc='La GPU non abbassa le frequenze fra un carico e l''altro'
            Perche='Di serie la scheda cala di regime appena il carico scende, e le rialza con un attimo di ritardo. Nei giochi competitivi il carico e'' irregolare per natura, e quel ritardo cade dentro il frame. Costa qualche watt in piu'' a riposo.'
            Nv=@(@{ Id=0x1057EB71; Val=1 })            # PREFERRED_PSTATE = prefer max
        }
        $c += @{
            Id='nv-prerender'; Cat='Pannello NVIDIA'; Kind='Nvapi'; Rischio='sicuro'
            Nome='Bassa latenza: un solo frame in coda'
            Desc='La CPU non prepara piu'' di un fotogramma in anticipo'
            Perche='E'' quello che il pannello chiama "Modalita'' a bassa latenza". Meno fotogrammi in coda significa che il movimento del mouse arriva prima allo schermo: la coda e'' tempo gia'' deciso, che non puoi piu'' correggere.'
            Nv=@(@{ Id=0x007BA09E; Val=1 })            # MAXFRAMES (prerender limit)
        }
        $c += @{
            Id='nv-threaded'; Cat='Pannello NVIDIA'; Kind='Nvapi'; Rischio='sicuro'
            Nome='Ottimizzazione threaded attiva'
            Desc='Il driver distribuisce il proprio lavoro su piu'' core'
            Perche='Senza, il driver fa tutto su un core solo, che diventa il collo di bottiglia proprio nei giochi CPU-bound come FiveM. Con sei o piu'' core e'' sempre un guadagno.'
            Nv=@(@{ Id=0x20C1221E; Val=1 })            # OGL_THREAD_CONTROL = enable
        }

        # Profili per singolo gioco: la stessa cosa che si fa con NVIDIA
        # Profile Inspector, ma senza doverlo scaricare. Compaiono solo se il
        # gioco c'e' sul PC: un profilo per un gioco che non hai e' rumore.
        if (Get-VtGioco 'Fortnite') {
            $c += @{
                Id='nip-fortnite'; Cat='Profili di gioco NVIDIA'; Kind='NvProf'; Rischio='medio'
                Nome='Profilo Fortnite (file .nip)'
                Desc='Scrive nel profilo Fortnite del driver le impostazioni del file .nip fornito'
                Perche='Le impostazioni globali valgono per tutto; un profilo di gioco vale solo per Fortnite, quindi si puo'' spingere di piu'' senza rovinare il resto. Dentro ci sono frequenza di aggiornamento massima, V-Sync forzato off, filtro texture in modalita'' prestazioni e LOD Bias +10. Il file ne contiene quindici: quelle che il driver installato non conosce le salto invece di far fallire tutto, e lo scrivo nel registro delle operazioni.'
                Warn='Due voci hanno un prezzo visibile. Il LOD Bias +10 rende le texture piu'' sfocate a distanza: e'' voluto, serve a togliere lavoro alla scheda, ma si vede. E il file contiene sia G-SYNC attivo sia "G-SYNC globale" disattivato: se non hai un monitor G-Sync non cambia niente, se ce l''hai controlla di persona che si comporti come vuoi. Spegnendo l''interruttore rimetto ogni voce esattamente com''era.'
            }
        }
        if (Get-VtGioco 'FiveM') {
            $c += @{
                Id='nip-fivem'; Cat='Profili di gioco NVIDIA'; Kind='NvProf'; Rischio='sicuro'
                Nome='Profilo FiveM / GTA V'
                Desc='Crea nel driver un profilo dedicato a FiveM con 9 impostazioni'
                Perche='FiveM lavora quasi tutto sulla CPU, quindi il guadagno arriva da dove il driver smette di far aspettare: alimentazione sempre al massimo, un solo fotogramma in coda, lavoro del driver distribuito sui core, V-Sync fuori dai piedi e filtro texture in modalita'' prestazioni. Gli eseguibili li leggo dal tuo disco, perche'' FiveM cambia il nome del processo a ogni build.'
                Nota='Qui dentro NON c''e'' il LOD Bias, che e'' la voce che sfoca le texture in lontananza: e'' quella che fa sembrare sporchi i profili tirati via, e non volevo. La grafica resta com''e'', cambia solo quanto lavoro fa il driver.'
            }
        }
    }

    # Voci specifiche NVIDIA: compaiono solo se la scheda e' NVIDIA.
    if ($sys.Vendor -match 'NVIDIA') {
        $c += @{
            Id='nv-autoaggiornamento'; Cat='Scheda video'; Kind='Script'; Rischio='medio'
            Nome='Autoaggiornamento dell''app NVIDIA OFF'
            Desc='Disattiva l''attivita'' pianificata che cerca aggiornamenti da sola'
            Perche='E'' un processo che parte a orari decisi da NVIDIA, scarica in background e ogni tanto apre finestre. Non serve: i driver puoi aggiornarli quando vuoi tu aprendo l''app.'
            Warn='Non riceverai piu'' l''avviso automatico quando esce un driver nuovo. Controlla ogni tanto a mano, perche'' i driver contano davvero sugli FPS.'
            # Get-VtAllTasks e non Get-ScheduledTask: l'elenco delle attivita'
            # pianificate costa mezzo secondo a leggerlo, e questa voce lo
            # rileggeva da capo per conto suo mentre 'task-telemetria' ne
            # faceva un'altra copia. Un elenco solo, in cache, per tutti.
            Test={
                $t = @(Get-VtAllTasks | Where-Object { $_.TaskName -like 'NVIDIA App SelfUpdate*' })
                if ($t.Count -eq 0) { return $false }
                return (@($t | Where-Object { $_.State -ne 'Disabled' }).Count -eq 0)
            }
            On={
                $fatte = @()
                foreach ($t in @(Get-VtAllTasks | Where-Object { $_.TaskName -like 'NVIDIA App SelfUpdate*' })) {
                    if ($t.State -eq 'Disabled') { continue }
                    try {
                        Disable-ScheduledTask -TaskPath $t.TaskPath -TaskName $t.TaskName -ErrorAction Stop | Out-Null
                        $fatte += @{ P = $t.TaskPath; N = $t.TaskName }
                    } catch { Write-VtLog "Attivita' '$($t.TaskName)': Windows non permette di disattivarla" warn }
                }
                Set-VtEntry 'nv-autoaggiornamento' @{ Tasks = $fatte }
                Clear-VtTaskCache
            }
            Off={
                $e = Get-VtEntry 'nv-autoaggiornamento'
                if (-not $e) { return }
                foreach ($t in @($e.Tasks)) {
                    try { Enable-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction Stop | Out-Null } catch { }
                }
                Remove-VtEntry 'nv-autoaggiornamento'
                Clear-VtTaskCache
            }
        }
    }

    $c += @{
        Id='gpu-preferenza-giochi'; Cat='Scheda video'; Kind='Script'; Rischio='sicuro'
        Nome='Giochi sulla GPU dedicata'
        Desc='Forza tutti i giochi rilevati sulla scheda video dedicata invece che sull''integrata'
        Perche='Windows sceglie la GPU da solo e ogni tanto sbaglia, soprattutto su portatili e su PC con grafica integrata Intel attiva. Quando sbaglia non perdi il 10%: perdi meta'' degli FPS.'
        Test={
            $g = Find-VtGiochi
            if ($g.Count -eq 0) { return $false }
            foreach ($x in $g) {
                $v = Get-VtReg 'HKCU:\SOFTWARE\Microsoft\DirectX\UserGpuPreferences' $x.Path
                if ($v -notmatch 'GpuPreference=2') { return $false }
            }
            return $true
        }
        On={
            $k = 'HKCU:\SOFTWARE\Microsoft\DirectX\UserGpuPreferences'
            $bak = @()
            foreach ($x in (Find-VtGiochi)) {
                $bak += @{ Name = $x.Path; Val = (Get-VtReg $k $x.Path) }
                Set-VtReg $k $x.Path 'String' 'GpuPreference=2;'
                Write-VtLog "GPU dedicata forzata per $($x.Nome)" ok
            }
            Set-VtEntry 'gpu-preferenza-giochi' @{ Key = $k; Bak = $bak }
        }
        Off={
            $e = Get-VtEntry 'gpu-preferenza-giochi'
            if (-not $e) { return }
            foreach ($b in @($e.Bak)) {
                if ($null -ne $b.Val) { Set-VtReg $e.Key $b.Name 'String' $b.Val }
                else { Remove-ItemProperty -Path $e.Key -Name $b.Name -ErrorAction SilentlyContinue }
            }
            Remove-VtEntry 'gpu-preferenza-giochi'
        }
    }

    # ======================= ENERGIA =======================================
    $c += @{
        Id='piano-energia'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Piano prestazioni massime'
        Desc='Attiva Prestazioni ottimali (o Prestazioni elevate) e sposta anche il cursore di Windows 11'
        Perche='Su Bilanciato la CPU deve risalire di frequenza a ogni picco di carico, e il ritardo di risalita cade proprio dentro il frame. Su Windows 11 il cursore "Modalita'' risparmio energia" vince sul piano classico: vanno spostati tutti e due.'
        Test={
            # Confronto per GUID e non per nome: "Prestazioni elevate" si
            # chiama in modo diverso in ogni lingua di Windows.
            #   8c5e7fda... = Prestazioni elevate (fisso in ogni lingua)
            #   e9a42b02... = Prestazioni ottimali di serie
            # Il piano duplicato da noi prende un GUID nuovo, quindi ce lo
            # ricordiamo nel backup.
            $noti = @('8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c',
                      'e9a42b02-d5df-448d-aa00-03f14749eb61')
            $e = Get-VtEntry 'piano-energia'
            if ($e -and $e.Attivato) { $noti += $e.Attivato }

            $cur = Get-VtActiveScheme
            $ov  = Invoke-VtCmd 'powercfg /getactiveoverlayscheme'
            $planOk = ($cur -and ($noti -contains $cur))
            # 961cc777... = "Efficienza energetica", l'unico da evitare.
            $ovOk = ($ov -notmatch '961cc777-2547-4f9d-8174-7d86181b8a7a')
            return ($planOk -and $ovOk)
        }
        On={
            $bak = @{}
            $bak.Scheme = Get-VtActiveScheme
            $ov = Invoke-VtCmd 'powercfg /getactiveoverlayscheme'
            if ($ov -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { $bak.Overlay = $matches[1] }

            $dup = Invoke-VtCmd 'powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61'
            if ($dup -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') {
                $bak.Attivato = $matches[1]
                Invoke-VtCmd "powercfg /setactive $($matches[1])" | Out-Null
                Write-VtLog 'Piano energetico: Prestazioni ottimali' ok
            } else {
                # Non tutte le edizioni di Windows espongono Prestazioni
                # ottimali: si ripiega su Prestazioni elevate.
                $bak.Attivato = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
                Invoke-VtCmd 'powercfg /setactive SCHEME_MIN' | Out-Null
                Write-VtLog 'Piano energetico: Prestazioni elevate' ok
            }
            Set-VtEntry 'piano-energia' $bak
            Invoke-VtCmd 'powercfg /overlaysetscheme OVERLAY_MAX' | Out-Null
        }
        Off={
            $e = Get-VtEntry 'piano-energia'
            if ($e.Scheme)  { Invoke-VtCmd "powercfg /setactive $($e.Scheme)" | Out-Null }
            if ($e.Overlay) { Invoke-VtCmd "powercfg /overlaysetscheme $($e.Overlay)" | Out-Null }
            Remove-VtEntry 'piano-energia'
        }
    }
    $c += @{
        Id='core-parking'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Parcheggio dei core CPU OFF'
        Desc='Tiene tutti i core svegli quando sei alimentato dalla rete elettrica'
        Perche='Un core parcheggiato deve essere risvegliato, e il risveglio arriva a meta'' frame. E'' una delle cause piu'' comuni di 1% low bassi con FPS medi alti.'
        Test={
            (Get-VtPowerIndex $script:VtPowerGuids.ProcSub $script:VtPowerGuids.CoreParking) -eq 100
        }
        On={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 100' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
        Off={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 0' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
    }
    $c += @{
        Id='usb-suspend'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Sospensione selettiva USB OFF'
        Desc='Impedisce a Windows di addormentare le porte USB'
        Perche='Se Windows sospende la porta del mouse o della tastiera, il primo input dopo una pausa arriva in ritardo. Con un pad wireless e'' anche peggio.'
        Test={
            (Get-VtPowerIndex $script:VtPowerGuids.UsbSub $script:VtPowerGuids.UsbSuspend) -eq 0
        }
        On={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
        Off={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 1' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
    }
    $c += @{
        Id='pcie-aspm'; Cat='Energia'; Kind='Script'; Rischio='sicuro'
        Nome='Risparmio energia PCI Express OFF'
        Desc='La GPU resta sempre a piena larghezza di banda sul bus'
        Perche='ASPM abbassa il link PCIe quando il traffico cala. Nei momenti di carico improvviso, tipici del caricamento di una texture, il ritorno a piena banda costa millisecondi.'
        Test={
            (Get-VtPowerIndex $script:VtPowerGuids.PcieSub $script:VtPowerGuids.Aspm) -eq 0
        }
        On={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
        Off={
            Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 2' | Out-Null
            Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
        }
    }
    if (-not $sys.Portatile) {
        $c += @{
            Id='cpu-min-100'; Cat='Energia'; Kind='Script'; Rischio='medio'
            Nome='Frequenza minima CPU al 100%'
            Desc='La CPU non scende mai di frequenza quando sei alla rete elettrica'
            Perche='Elimina del tutto il ritardo di risalita della frequenza. E'' il modo piu'' diretto per stabilizzare i frame time nei giochi CPU-bound come FiveM.'
            Warn='La CPU consuma e scalda come sotto carico anche a PC fermo. Se hai un dissipatore modesto o temperature gia'' alte, lascia perdere.'
            Test={
                (Get-VtPowerIndex $script:VtPowerGuids.ProcSub $script:VtPowerGuids.ProcMin) -eq 100
            }
            On={
                Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 100' | Out-Null
                Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
            }
            Off={
                Invoke-VtCmd 'powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 5' | Out-Null
                Invoke-VtCmd 'powercfg /setactive SCHEME_CURRENT' | Out-Null
            }
        }
    }

    # ======================= STABILITA' DEGLI FPS ==========================
    # Queste non alzano la media: tolgono i buchi. Sono le due voci che
    # agiscono su come il kernel scandisce il tempo e su chi puo' rallentare
    # i thread del gioco, cioe' sulle due cause piu' comuni di micro-scatti
    # con FPS medi alti.
    $c += @{
        Id='timer-resolution'; Cat='Stabilita'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Risoluzione del timer a livello di sistema'
        Desc='Fa valere per tutto il sistema la risoluzione del timer richiesta dal gioco'
        Perche='Da Windows 11 22H2 una richiesta di timer ad alta risoluzione vale solo per il processo che la fa: il resto del sistema continua a svegliarsi con la granularita'' grossa. Il risultato sono frame consegnati leggermente fuori tempo, che si vedono come micro-scatti anche con FPS altissimi. Questa voce riporta il comportamento a quello vecchio, in cui la risoluzione fine vale per tutti.'
        Warn='Su un portatile a batteria consuma un po'' di piu'', perche'' il sistema si sveglia piu'' spesso.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel'; Name='GlobalTimerResolutionRequests'; Type='DWord'; Val=1 }
        )
    }
    $c += @{
        Id='power-throttling'; Cat='Stabilita'; Kind='Reg'; Rischio='sicuro'
        Nome='Limitazione energetica dei processi OFF'
        Desc='Impedisce a Windows di rallentare i processi che ritiene "in secondo piano"'
        Perche='Power Throttling (EcoQoS) abbassa la frequenza dei thread che Windows giudica poco importanti. Su una CPU con E-core come la tua puo'' spostare o rallentare thread del gioco che il sistema non riconosce come primo piano: audio, rete, caricamento risorse. E'' una causa tipica di scatti che arrivano a ondate invece che di FPS bassi costanti.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling'; Name='PowerThrottlingOff'; Type='DWord'; Val=1 }
        )
    }

    # --- Integrita' della memoria (VBS/HVCI) -----------------------------
    #
    # E' il freno piu' pesante rimasto su un Windows 11 di fabbrica, e quasi
    # nessuno sa di averlo acceso. Va detto con precisione cosa si guadagna e
    # cosa si perde, perche' questa non e' una voce cosmetica.
    $c += @{
        Id='vbs-off'; Cat='CPU e scheduler'; Kind='Reg'; Rischio='medio'; Reboot=$true
        Nome='Integrita'' della memoria (VBS) spenta e bloccata'
        Desc='Toglie lo strato di virtualizzazione che Windows 11 mette fra la CPU e il sistema'
        Perche="Con l'integrita' della memoria accesa, Windows gira dentro un livello di virtualizzazione e ogni chiamata al kernel passa per un controllo in piu'. Nei giochi si sente: a seconda della CPU si parla del 5-15% di fotogrammi, ed e' la differenza piu' grossa che resta da fare su una macchina gia' sistemata. $(Get-VtVbsDescrizione) Scriverlo nel registro non serve solo a spegnerlo: serve a tenerlo spento, perche' gli aggiornamenti importanti di Windows lo riaccendono da soli senza dire niente."
        Warn='Qui non stai spegnendo un fronzolo: e'' una protezione vera. Serve a impedire a un driver malevolo di iniettare codice nel kernel, ed e'' la difesa che rende inutili certi rootkit. Sul PC di chi gioca, scarica mod e usa programmi di terze parti, e'' un rischio che esiste davvero. Antivirus e Defender continuano a funzionare normalmente, e si riaccende in un clic. Se il PC lo usi anche per lavoro o ci tieni dentro cose importanti, valuta se ne vale la pena.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity'; Name='Enabled'; Type='DWord'; Val=0 }
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard'; Name='EnableVirtualizationBasedSecurity'; Type='DWord'; Val=0 }
        )
    }

    # --- Reattivita' percepita di Windows --------------------------------
    $c += @{
        Id='focus-primo-piano'; Cat='Interfaccia'; Kind='Reg'; Rischio='sicuro'
        Nome='Il gioco puo'' prendere il primo piano subito'
        Desc='Toglie l''attesa che Windows impone prima di lasciar passare una finestra davanti'
        Perche='Windows blocca per due secondi il passaggio in primo piano dopo che hai toccato qualcosa, per impedire alle finestre di rubarti il clic. Il risultato, quando lanci un gioco o ci torni con Alt+Tab, e'' che resta dietro o parte minimizzato e devi cliccarci sopra. Azzerato, la finestra del gioco viene avanti quando lo chiede lei.'
        Items=@(
            @{ Path='HKCU:\Control Panel\Desktop'; Name='ForegroundLockTimeout'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='menu-classico'; Cat='Interfaccia'; Kind='Script'; Rischio='sicuro'
        Nome='Menu del tasto destro classico'
        Desc='Rimette il menu contestuale di Windows 10 al posto di quello di Windows 11'
        Perche='Il menu di Windows 11 non e'' solo piu'' corto: passa per un componente moderno che deve caricarsi al momento, e il ritardo fra il clic destro e il menu che compare si vede a occhio nudo. Quello classico e'' istantaneo, e ha dentro tutte le voci senza dover premere "Mostra altre opzioni". E'' la modifica che si nota di piu'' nell''uso di tutti i giorni.'
        Nota='Per applicarlo Explorer viene riavviato: la barra e le finestre delle cartelle spariscono e tornano in un secondo. I programmi aperti non si chiudono.'
        Test={ Test-VtMenuClassico }
        On={  Set-VtMenuClassico $true }
        Off={ Set-VtMenuClassico $false }
    }
    if (@(Get-VtGiochiExe).Count -gt 0) {
        $c += @{
            Id='giochi-schermo-intero'; Cat='Scheda video'; Kind='Script'; Rischio='sicuro'
            Nome='Schermo intero vero per i giochi rilevati'
            Desc="Disattiva le ottimizzazioni schermo intero sui $(@(Get-VtGiochiExe).Count) giochi trovati sul disco"
            Perche='Le "ottimizzazioni schermo intero" fanno girare il gioco in una finestra senza bordi gestita dal compositore di Windows anche quando gli chiedi lo schermo intero. Comodo per l''Alt+Tab, ma mette un passaggio in piu'' fra il fotogramma finito e il monitor, e quel passaggio e'' ritardo. Disattivandole si torna allo schermo intero esclusivo vero.'
            Nota='Quello che c''era gia'' impostato su ogni gioco (per esempio la gestione DPI) viene conservato: si aggiunge una voce, non si sovrascrive.'
            Test={ Test-VtSchermoIntero }
            On={  Set-VtSchermoIntero $true }
            Off={ Set-VtSchermoIntero $false }
        }
    }
    $c += @{
        Id='widget-off'; Cat='Interfaccia'; Kind='Reg'; Rischio='sicuro'
        Nome='Widget della barra OFF'
        Desc='Toglie il riquadro meteo e notizie, e con lui il processo che lo tiene aggiornato'
        Perche='Il widget non e'' un''icona: dietro c''e'' un processo che resta acceso, scarica notizie e meteo a intervalli e disegna un pannello con dentro un motore web. Si sveglia anche mentre giochi, e la barra ci passa sopra il puntatore per sbaglio piu'' spesso di quanto sembri.'
        Items=@(
            @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; Name='TaskbarDa'; Type='DWord'; Val=0 }
        )
    }

    # --- Stuttering e micro-lag ------------------------------------------
    $c += @{
        Id='fth-off'; Cat='Stabilita'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Fault Tolerant Heap OFF'
        Desc='Toglie lo "strato di compatibilita'' della memoria" che Windows applica da solo'
        Perche='Se un programma va in errore anche una volta sola, Windows lo iscrive al Fault Tolerant Heap e da quel momento intercetta ogni sua allocazione di memoria per proteggerlo. Il programma continua a funzionare ma diventa piu'' lento, e nessuno lo dice: e'' una causa classica di giochi che "prima andavano bene e adesso scattano". Spento, si ritorna alle allocazioni normali.'
        Items=@(
            @{ Path='HKLM:\SOFTWARE\Microsoft\FTH'; Name='Enabled'; Type='DWord'; Val=0 }
        )
    }
    $c += @{
        Id='timer-distribuiti'; Cat='Stabilita'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Timer distribuiti sui core'
        Desc='Le scadenze dei timer non si accumulano tutte sullo stesso core'
        Perche='Di serie molte scadenze di timer maturano sul core 0. Quando ne scadono tante insieme, quel core smette per un attimo di fare altro: se ci sta girando un thread del gioco, quello e'' un micro-scatto. Distribuendole, il picco si spalma.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel'; Name='DistributeTimers'; Type='DWord'; Val=1 }
        )
    }
    $c += @{
        Id='msi-audio'; Cat='Stabilita'; Kind='Script'; Rischio='medio'; Reboot=$true
        Nome='Interrupt a messaggio (MSI) sulla scheda audio'
        Desc="Toglie l'audio dal piedino di interrupt condiviso: $(@(Get-VtAudioPci).Count) controller interessati"
        Perche='Un dispositivo PCI puo'' avvisare la CPU in due modi. Alla vecchia maniera usa un piedino fisico spesso CONDIVISO con altri dispositivi, e il sistema deve chiedere a ognuno "sei stato tu?": quel giro di domande e'' tempo passato in interrupt, cioe'' esattamente il tipo di ritardo che si vede come micro-scatto. Con MSI il dispositivo scrive direttamente in memoria e non disturba nessun altro. Sul tuo PC scheda video, rete e disco NVMe usano gia'' MSI: gli unici rimasti indietro sono i controller audio, che sono anche quelli che generano piu'' interrupt mentre giochi.'
        Warn='Questa e'' l''unica voce di questa sezione che puo'' dare fastidio invece che aiutare: su qualche scheda audio piu'' vecchia MSI provoca crepitii, oppure il dispositivo non riparte e resti senza audio finche'' non lo rimetti com''era. Non danneggia niente e si annulla da qui in un clic piu'' un riavvio, ma va detto prima. Se dopo il riavvio l''audio non ti convince, rimetti l''interruttore su OFF.'
        Test={ Test-VtMsiAudioOn }
        On={  Set-VtMsiAudio $true }
        Off={ Set-VtMsiAudio $false }
    }
    $c += @{
        Id='ndu-off'; Cat='Stabilita'; Kind='Reg'; Rischio='medio'; Reboot=$true
        Nome='Driver di conteggio dati di rete OFF'
        Desc='Disattiva Ndu, il driver che misura quanta rete consuma ogni processo'
        Perche='Ndu lavora dentro il kernel a ogni pacchetto per attribuirlo al processo giusto. Il conteggio serve solo a riempire una colonna di Gestione attivita'', ma il lavoro lo fa in una parte del sistema dove i ritardi diventano DPC, cioe'' esattamente il tipo di ritardo che si vede come micro-scatto mentre giochi online.'
        Warn='Perdi la colonna "Rete" per processo in Gestione attivita''. Il totale di rete e la connessione non cambiano in nessun modo.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Services\Ndu'; Name='Start'; Type='DWord'; Val=4 }
        )
    }

    # --- Profilo memoria in base alla RAM --------------------------------
    $ramP = Get-VtRamProfilo
    $c += @{
        Id='ram-profilo'; Cat='Memoria e archiviazione'; Kind='Script'; Rischio='medio'; Reboot=$true
        Nome="Profilo memoria per $($ramP.Gb) GB di RAM"
        Desc="File di paging fisso a $($ramP.PfMin)-$($ramP.PfMax) MB, compressione $(if ($ramP.Comprimi) { 'accesa' } else { 'spenta' })"
        Perche="Non esiste un tweak della RAM valido per tutti: con 8 GB le scelte giuste sono l'opposto di quelle giuste con 64. Sul tuo PC ho misurato $($ramP.Gb) GB. $($ramP.Nota) Il file di paging gestito da Windows parte piccolo e si allarga quando serve, e l'allargamento e' una scrittura su disco che capita mentre giochi: e' uno dei modi in cui nasce lo scatto isolato che poi non si riesce a spiegare."
        # Concatenazione fra due stringhe a virgolette DOPPIE: qui l'apostrofo
        # non va raddoppiato, altrimenti ne compaiono due sullo schermo.
        Warn=("Il file di paging cambia solo dopo il riavvio, e occupa davvero lo spazio che gli assegni: se il disco di sistema e' quasi pieno mi rifiuto invece di riempirlo." +
              $(if ($ramP.Comprimi) { " Attenzione a una cosa controcorrente: con $($ramP.Gb) GB questo interruttore ACCENDE la compressione della memoria, non la spegne. Molti tweak la spengono sempre; sotto i 32 GB e' un errore, perche' senza compressione un server FiveM pieno ti manda a leggere dal disco, che costa mille volte di piu' della CPU che la compressione consuma." } else { '' }))
        Test={ Test-VtRamProfilo }
        On={  Set-VtRamProfilo }
        Off={ Restore-VtRamProfilo }
    }

    # --- Rete: pacchetti e lavoro in background --------------------------
    $c += @{
        Id='do-peering'; Cat='Rete'; Kind='Reg'; Rischio='sicuro'
        Nome='Condivisione degli aggiornamenti con altri PC OFF'
        Desc='Windows smette di distribuire i propri aggiornamenti ad altri computer'
        Perche='Delivery Optimization usa il tuo PC come sorgente per far scaricare gli aggiornamenti ad altri, anche fuori dalla tua rete. E'' banda in uscita che parte senza avvisare, e la banda in uscita satura e'' quella che fa salire il ping: la coda del router si riempie e i tuoi pacchetti di gioco aspettano dietro. Gli aggiornamenti continuano ad arrivare normalmente dai server Microsoft.'
        Items=@(
            @{ Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'; Name='DODownloadMode'; Type='DWord'; Val=0 }
        )
    }
    # RSC e' il gemello di Nagle visto dal lato di chi riceve, e finora
    # mancava: Nagle accorpa i pacchetti in uscita, RSC quelli in entrata.
    # La condizione giusta non e' "esiste una scheda di rete" ma "RSC si puo'
    # davvero comandare": sul PC dell'autore la scheda Realtek non lo espone
    # affatto, e con il controllo sbagliato l'interruttore compariva senza
    # poter fare niente.
    if (Test-VtRscDisponibile) {
        $c += @{
            Id='net-rsc'; Cat='Rete'; Kind='Script'; Rischio='sicuro'
            Nome='Accorpamento dei pacchetti in arrivo OFF'
            Desc='La scheda consegna subito ogni pacchetto ricevuto invece di ammucchiarne'
            Perche='RSC (Receive Segment Coalescing) trattiene i pacchetti che arrivano e li unisce in blocchi piu'' grandi prima di passarli a Windows: fa risparmiare CPU quando scarichi file grossi, ma su un gioco significa che l''aggiornamento della posizione degli altri giocatori resta fermo nella scheda ad aspettare compagnia. E'' esattamente Nagle, ma dal lato di chi riceve: avevo gia'' tolto quello in uscita e mancava questo.'
            Test={ Test-VtRscOff }
            On={  Set-VtRsc $false }
            Off={ Set-VtRsc $true }
        }
    }

    # ======================= MEMORIA E ARCHIVIAZIONE =======================
    $c += @{
        Id='avvio-rapido'; Cat='Memoria e archiviazione'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
        Nome='Avvio rapido OFF'
        Desc='Ogni accensione riparte da zero invece che da uno stato salvato'
        Perche='L''avvio rapido ricarica il kernel e i driver da un''immagine su disco. Dopo qualche giorno di accensioni "finte" i driver si trovano in stati strani ed e'' una causa classica di FPS che calano col passare dei giorni.'
        Warn='Il PC ci mettera'' qualche secondo in piu'' ad accendersi. In cambio ogni avvio e'' pulito.'
        Items=@(
            @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'; Name='HiberbootEnabled'; Type='DWord'; Val=0 }
        )
    }
    # Soglia a 15 e non a 16: Windows riporta ~15.8 GB su un PC con 16 GB,
    # perche' una parte e' riservata all'hardware.
    if ($sys.RamGB -ge 15) {
        $c += @{
            Id='kernel-in-ram'; Cat='Memoria e archiviazione'; Kind='Reg'; Rischio='sicuro'; Reboot=$true
            Nome='Kernel e driver sempre in RAM'
            Desc='Impedisce a Windows di spostare su disco le parti del kernel'
            Perche="Con $($sys.RamGB) GB hai memoria da vendere. Tenere kernel e driver sempre residenti toglie una classe di micro-stutter che arriva quando il sistema li rilegge dal disco."
            Items=@(
                @{ Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'; Name='DisablePagingExecutive'; Type='DWord'; Val=1 }
            )
        }
    }
    $c += @{
        Id='ntfs-lastaccess'; Cat='Memoria e archiviazione'; Kind='Script'; Rischio='sicuro'
        Nome='Timestamp NTFS di ultimo accesso OFF'
        Desc='NTFS smette di scrivere la data di ultimo accesso a ogni file letto'
        Perche='Ogni lettura diventa anche una scrittura. Durante un caricamento un gioco apre migliaia di file: sono migliaia di scritture inutili sull''SSD.'
        Test={
            # Il nome della chiave non e' tradotto, la descrizione fra
            # parentesi si': ancoriamo il numero al nome, non a un '=' isolato.
            $q = Invoke-VtCmd 'fsutil behavior query disablelastaccess'
            return ($q -match 'DisableLastAccess\s*=\s*[13]')
        }
        On={
            $q = Invoke-VtCmd 'fsutil behavior query disablelastaccess'
            $old = if ($q -match 'DisableLastAccess\s*=\s*(\d)') { $matches[1] } else { '2' }
            Set-VtEntry 'ntfs-lastaccess' @{ Old = $old }
            Invoke-VtCmd 'fsutil behavior set disablelastaccess 1' | Out-Null
        }
        Off={
            $e = Get-VtEntry 'ntfs-lastaccess'
            $old = if ($e -and $e.Old) { $e.Old } else { '2' }
            Invoke-VtCmd "fsutil behavior set disablelastaccess $old" | Out-Null
            Remove-VtEntry 'ntfs-lastaccess'
        }
    }

    # ======================= RETE ==========================================
    $c += @{
        Id='nagle'; Cat='Rete'; Kind='Script'; Rischio='sicuro'
        Nome='Algoritmo di Nagle OFF'
        Desc='Le schede di rete attive smettono di accorpare i pacchetti piccoli'
        Perche='Nagle mette in coda i pacchetti piccoli per spedirne uno grande. I pacchetti di un FPS SONO piccoli: accorparli significa ritardarli. Si sente su FiveM e Valorant, non sugli FPS ma sul registro dei colpi.'
        Test={
            $root = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
            $nic = Get-VtActiveNicGuids
            if ($nic.Count -eq 0) { return $false }
            foreach ($g in $nic) {
                if ((Get-VtReg (Join-Path $root $g) 'TcpAckFrequency') -ne 1) { return $false }
            }
            return $true
        }
        On={
            $root = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
            $nic = Get-VtActiveNicGuids
            $bak = @()
            foreach ($g in $nic) {
                $k = Join-Path $root $g
                if (-not (Test-Path $k)) { continue }
                foreach ($n in 'TcpAckFrequency','TCPNoDelay','TcpDelAckTicks') {
                    $bak += @{ Key = $k; Name = $n; Val = (Get-VtReg $k $n) }
                }
                Set-VtReg $k 'TcpAckFrequency' 'DWord' 1
                Set-VtReg $k 'TCPNoDelay'      'DWord' 1
                Set-VtReg $k 'TcpDelAckTicks'  'DWord' 0
                Write-VtLog "Nagle disattivato sulla scheda $g" ok
            }
            Set-VtEntry 'nagle' @{ Bak = $bak }
        }
        Off={
            $e = Get-VtEntry 'nagle'
            if (-not $e) { return }
            foreach ($b in @($e.Bak)) {
                if ($null -ne $b.Val) { Set-VtReg $b.Key $b.Name 'DWord' $b.Val }
                else { Remove-ItemProperty -Path $b.Key -Name $b.Name -ErrorAction SilentlyContinue }
            }
            Remove-VtEntry 'nagle'
        }
    }

    # ======================= SCHEDA DI RETE ================================
    # Solo se c'e' una scheda fisica attiva: su un portatile in Wi-Fi molte
    # di queste voci non esistono e il catalogo non le mostra.
    if (@(Get-VtNicAdapters).Count -gt 0) {
        $c += @{
            Id='nic-risparmio'; Cat='Rete'; Kind='Nic'; Rischio='sicuro'
            Nome='Risparmio energia della scheda di rete OFF'
            Desc='Impedisce alla scheda Ethernet di addormentarsi o rallentare per consumare meno'
            Perche='Le schede Realtek e Intel escono di fabbrica con una manciata di risparmi energetici accesi: Energy Efficient Ethernet, Green Ethernet, Gigabit Lite. Quando il traffico cala, la scheda scende di regime o abbassa il collegamento; il primo pacchetto dopo la pausa arriva in ritardo. In un gioco quella pausa cade fra un tuo colpo e la risposta del server.'
            Warn='La connessione cade per un paio di secondi mentre la scheda si riavvia: non farlo mentre scarichi o sei in partita.'
            Nic=@(
                @{ Keyword='PowerSavingMode';     Valore='0' }
                @{ Keyword='EnableGreenEthernet'; Valore='0' }
                @{ Keyword='*EEE';                Valore='0' }
                @{ Keyword='AdvancedEEE';         Valore='0' }
                @{ Keyword='GigaLite';            Valore='0' }
                @{ Keyword='AutoDisableGigabit';  Valore='0' }
                @{ Keyword='ULPMode';             Valore='0' }
            )
        }
        $c += @{
            Id='nic-lso'; Cat='Rete'; Kind='Nic'; Rischio='sicuro'
            Nome='Large Send Offload OFF'
            Desc='La scheda smette di accorpare i pacchetti in uscita prima di spedirli'
            Perche='Il Large Send Offload fa scrivere alla CPU un blocco unico che poi la scheda spezza da sola. Ottimo per scaricare file grossi, controproducente per un gioco: i pacchetti piccoli aspettano di essere impacchettati insieme, e quell''attesa e'' ritardo. E'' lo stesso ragionamento dell''algoritmo di Nagle, ma un gradino piu'' in basso, dentro la scheda.'
            Warn='La connessione cade per un paio di secondi mentre la scheda si riavvia.'
            Nic=@(
                @{ Keyword='*LsoV2IPv4'; Valore='0' }
                @{ Keyword='*LsoV2IPv6'; Valore='0' }
            )
        }
        $c += @{
            Id='nic-interrupt'; Cat='Rete'; Kind='Nic'; Rischio='sicuro'
            Nome='Moderazione interrupt OFF'
            Desc='La scheda avvisa la CPU a ogni pacchetto invece di raggrupparli'
            Perche='La moderazione degli interrupt serve a non disturbare la CPU troppo spesso: raccoglie i pacchetti e la avvisa a lotti. Ogni lotto e'' attesa. Spegnendola la CPU lavora un filo di piu'', ma i pacchetti del gioco vengono consegnati appena arrivano.'
            Warn='La connessione cade per un paio di secondi mentre la scheda si riavvia.'
            Nic=@(
                @{ Keyword='*InterruptModeration'; Valore='0' }
            )
        }
        $c += @{
            Id='nic-flowcontrol'; Cat='Rete'; Kind='Nic'; Rischio='sicuro'
            Nome='Controllo di flusso OFF'
            Desc='La scheda non chiede piu'' allo switch di rallentare quando e'' congestionata'
            Perche='Il controllo di flusso manda una pausa allo switch quando i buffer si riempiono: blocca TUTTO il traffico per qualche millisecondo, gioco compreso, per far respirare qualcos''altro. Su una rete domestica non serve, e quei millisecondi si sentono.'
            Warn='La connessione cade per un paio di secondi mentre la scheda si riavvia.'
            Nic=@(
                @{ Keyword='*FlowControl'; Valore='0' }
            )
        }
        $c += @{
            Id='nic-wake'; Cat='Rete'; Kind='Nic'; Rischio='medio'
            Nome='Riattivazione del PC dalla rete OFF'
            Desc='La scheda non puo'' piu'' svegliare il computer ne'' rispondere mentre e'' spento'
            Perche='Per poter svegliare il PC la scheda resta parzialmente alimentata e continua ad ascoltare il traffico anche a computer spento. E'' anche il motivo per cui certi PC si riaccendono da soli nel cuore della notte.'
            Warn='Perdi il Wake-on-LAN: se accendi il PC da remoto, da un telefono o da un altro computer, non funzionera'' piu''. La connessione cade per un paio di secondi mentre la scheda si riavvia.'
            Nic=@(
                @{ Keyword='*WakeOnMagicPacket'; Valore='0' }
                @{ Keyword='*WakeOnPattern';     Valore='0' }
                @{ Keyword='S5WakeOnLan';        Valore='0' }
                @{ Keyword='*PMARPOffload';      Valore='0' }
                @{ Keyword='*PMNSOffload';       Valore='0' }
            )
        }
    }

    # ======================= SERVIZI =======================================
    $c += @{
        Id='svc-telemetria'; Cat='Servizi'; Kind='Svc'; Rischio='sicuro'
        Nome='Servizi di telemetria OFF'
        Desc='Ferma dmwappushservice e il raccoglitore di diagnostica'
        Perche='Girano sempre, raccolgono dati d''uso e li spediscono. Non ti servono a niente mentre giochi e generano I/O a caso.'
        Nota='DiagTrack NON viene piu'' toccato, anche se sarebbe il candidato piu'' ovvio. Lo staff dei server di ruolo lo controlla: e'' uno dei servizi che tengono traccia di cosa hai eseguito, e trovarlo spento ti fa passare per uno che ha cancellato le prove. Qualche megabyte di telemetria non vale un ban.'
        Svc=@(
            @{ Name='dmwappushservice'; Start='Disabled' }
            @{ Name='diagnosticshub.standardcollector.service'; Start='Manual' }
        )
    }
    $c += @{
        Id='svc-superflui'; Cat='Servizi'; Kind='Svc'; Rischio='sicuro'
        Nome='Servizi superflui su Manuale'
        Desc='Segnalazione errori, mappe, geolocalizzazione, Delivery Optimization, condivisione multimediale'
        Perche='Nessuno di questi serve a un PC da gioco. Delivery Optimization in particolare usa la TUA banda per distribuire aggiornamenti Windows ad altri PC su internet: quello si sente sul ping.'
        Nota='PcaSvc e'' stato tolto da questo gruppo: lo staff dei server di ruolo lo controlla, perche'' tiene traccia dei programmi eseguiti. Fermarlo fa sospettare che tu abbia cancellato le prove, e non vale i pochi MB che libera.'
        Svc=@(
            @{ Name='WerSvc'; Start='Manual' }
            @{ Name='MapsBroker'; Start='Manual' }
            @{ Name='lfsvc'; Start='Manual' }
            @{ Name='DoSvc'; Start='Manual' }
            @{ Name='WMPNetworkSvc'; Start='Manual' }
            @{ Name='RemoteRegistry'; Start='Disabled' }
            @{ Name='RetailDemo'; Start='Disabled' }
        )
    }
    if ($sys.DiscoSys -match 'SSD') {
        $c += @{
            Id='svc-sysmain'; Cat='Servizi'; Kind='Svc'; Rischio='medio'
            Nome='SuperFetch (SysMain) su Manuale'
            Desc='Ferma il precaricamento in RAM dei programmi usati di frequente'
            Perche='SysMain nasce per gli hard disk meccanici: precarica in RAM per evitare le letture lente. Il tuo disco di sistema e'' un SSD, quindi qui e'' solo RAM occupata e I/O in background.'
            Warn='Se giochi su server di ruolo NON attivarlo. Lo staff controlla che SysMain sia in esecuzione, perche'' i file di prefetch che genera sono la prova di quali programmi hai lanciato: trovarlo fermo equivale ad aver cancellato le prove, e finisce in ban anche se non hai fatto niente. Per questo l''ho tolto dal profilo Maximum: il guadagno e'' qualche decina di MB di RAM, il rischio e'' l''accesso al server.'
            Svc=@( @{ Name='SysMain'; Start='Manual' } )
        }
    }
    $c += @{
        Id='svc-wsearch'; Cat='Servizi'; Kind='Svc'; Rischio='alto'
        Nome='Indicizzazione ricerca OFF'
        Desc='Ferma il servizio che indicizza i file per la ricerca'
        Perche='L''indicizzatore fa scansioni di disco in background, e le fa proprio quando il PC sembra libero, cioe'' fra una partita e l''altra.'
        Warn='PERDI la ricerca dei file dal menu Start e da Esplora risorse diventa lentissima. Se cerchi spesso i file, non attivarlo.'
        Svc=@( @{ Name='WSearch'; Start='Manual' } )
    }
    $c += @{
        Id='svc-spooler'; Cat='Servizi'; Kind='Svc'; Rischio='alto'
        Nome='Coda di stampa OFF'
        Desc='Disattiva lo spooler di stampa'
        Perche='Se non hai stampanti e'' un servizio che gira per niente (ed e'' storicamente uno dei bersagli preferiti degli exploit).'
        Warn='Non potrai piu'' stampare NULLA finche'' non lo riattivi. Non toccarlo se hai una stampante.'
        Svc=@( @{ Name='Spooler'; Start='Disabled' } )
    }
    $c += @{
        Id='task-telemetria'; Cat='Servizi'; Kind='Script'; Rischio='sicuro'
        Nome='Attivita'' pianificate di telemetria OFF'
        Desc='Disattiva le attivita'' di compatibilita'', CEIP e feedback'
        Perche='Sono processi che partono da soli a orari decisi da Windows. Il Compatibility Appraiser in particolare puo'' occupare la CPU per minuti interi, e non gli importa se sei in partita.'
        Test={
            # Serve almeno una delle attivita' note: se non ne esiste nessuna
            # su questo Windows, il tweak non ha senso e resta spento.
            # Le attivita' che il sistema si rifiuta di disattivare (PcaPatchDbTask
            # e' il caso tipico: appartiene a TrustedInstaller) vengono escluse,
            # altrimenti la voce resterebbe spenta per sempre anche dopo aver
            # fatto tutto il possibile.
            $e = Get-VtEntry 'task-telemetria'
            $saltate = @()
            if ($e -and $e.Saltate) { $saltate = @($e.Saltate) }

            $trovate = 0
            foreach ($t in (Get-VtTelemetryTasks)) {
                if ($saltate -contains $t.N) { continue }
                $x = Find-VtTask $t.P $t.N
                if (-not $x) { continue }
                $trovate++
                if ($x.State -ne 'Disabled') { return $false }
            }
            return ($trovate -gt 0)
        }
        On={
            $fatti = @(); $saltate = @()
            foreach ($t in (Get-VtTelemetryTasks)) {
                $x = Find-VtTask $t.P $t.N
                if (-not $x -or $x.State -eq 'Disabled') { continue }
                try {
                    Disable-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction Stop | Out-Null
                    $fatti += @{ P = $t.P; N = $t.N }
                } catch {
                    $saltate += $t.N
                    Write-VtLog "Attivita' '$($t.N)': Windows non permette di disattivarla" warn
                }
            }
            Set-VtEntry 'task-telemetria' @{ Tasks = $fatti; Saltate = $saltate }
            Clear-VtTaskCache
        }
        Off={
            $e = Get-VtEntry 'task-telemetria'
            if (-not $e) { return }
            foreach ($t in @($e.Tasks)) {
                try { Enable-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction Stop | Out-Null } catch { }
            }
            Remove-VtEntry 'task-telemetria'
            Clear-VtTaskCache
        }
    }

    $script:VtCatalog = $c
    return $c
}

# Una sola enumerazione di tutte le attivita' pianificate, tenuta in cache.
#
# Interrogarle una per una con -TaskPath/-TaskName costa ~550 ms a colpo: per
# le nove che ci interessano erano quasi 5 secondi. Leggerle tutte insieme ne
# costa 750 in totale, e dalla seconda volta in poi zero.
function Get-VtAllTasks {
    if ($null -ne $script:VtTasks) { return $script:VtTasks }
    try { $script:VtTasks = @(Get-ScheduledTask -ErrorAction Stop) }
    catch {
        Write-VtLog "Attivita' pianificate non leggibili: $($_.Exception.Message)" warn
        $script:VtTasks = @()
    }
    return $script:VtTasks
}

# Da chiamare dopo aver abilitato o disabilitato qualcosa, altrimenti la cache
# racconta lo stato di prima.
function Clear-VtTaskCache { $script:VtTasks = $null }

function Find-VtTask([string] $percorso, [string] $nome) {
    Get-VtAllTasks | Where-Object { $_.TaskPath -eq $percorso -and $_.TaskName -eq $nome } | Select-Object -First 1
}

function Get-VtTelemetryTasks {
    @(
        @{ P='\Microsoft\Windows\Application Experience\'; N='Microsoft Compatibility Appraiser' }
        @{ P='\Microsoft\Windows\Application Experience\'; N='ProgramDataUpdater' }
        @{ P='\Microsoft\Windows\Application Experience\'; N='PcaPatchDbTask' }
        @{ P='\Microsoft\Windows\Customer Experience Improvement Program\'; N='Consolidator' }
        @{ P='\Microsoft\Windows\Customer Experience Improvement Program\'; N='UsbCeip' }
        @{ P='\Microsoft\Windows\Autochk\'; N='Proxy' }
        @{ P='\Microsoft\Windows\Feedback\Siuf\'; N='DmClient' }
        @{ P='\Microsoft\Windows\Feedback\Siuf\'; N='DmClientOnScenarioDownload' }
        @{ P='\Microsoft\Windows\DiskDiagnostic\'; N='Microsoft-Windows-DiskDiagnosticDataCollector' }
    )
}

# Servizi che non vanno MAI disattivati: se li troviamo spenti, e' un guaio.
$script:VtProtetti = @(
    @{ Name='vgc';           Desc='Riot Vanguard: senza, Valorant non parte' }
    @{ Name='EasyAntiCheat'; Desc='Easy Anti-Cheat: usato da Fortnite' }
    @{ Name='BEService';     Desc='BattlEye: usato da Rainbow Six Siege' }
    @{ Name='Audiosrv';      Desc='audio di Windows' }
    @{ Name='wuauserv';      Desc='Windows Update: driver e patch di sicurezza' }
    @{ Name='WinDefend';     Desc='Microsoft Defender' }
)

# ---------------------------------------------------------------------------
# Stato / applica / annulla
# ---------------------------------------------------------------------------
# Confronto di valori di registro.
#
# Un DWORD scritto come -1 si rilegge come UInt32 4294967295: sono lo stesso
# valore a 32 bit, ma confrontati come testo sono diversi. Senza questa
# normalizzazione la voce "Throttling di rete OFF" risultava sempre spenta
# anche subito dopo averla applicata.
function Test-VtValoreUguale($corrente, $atteso) {
    if ($null -eq $corrente) { return $false }
    if ("$corrente" -eq "$atteso") { return $true }
    try {
        $a = [int64] $corrente
        $b = [int64] $atteso
        if ($a -eq $b) { return $true }
        # Riporta entrambi nello stesso spazio a 32 bit senza segno.
        if ($a -lt 0) { $a += 4294967296 }
        if ($b -lt 0) { $b += 4294967296 }
        return ($a -eq $b)
    } catch { return $false }
}

# Fotografia dello stato, che dura pochi secondi.
#
# Non tradisce la regola "lo stato si legge dal sistema": dentro un singolo
# disegno il sistema non cambia, quindi rileggere la stessa voce dieci volte
# da' dieci volte lo stesso risultato, solo dieci volte piu' lentamente. E
# nella pagina OC/Tuning succedeva davvero: i tre profili condividono decine
# di voci e ognuna veniva interrogata da capo per ogni profilo che la
# contiene. Da li' i 2,8 secondi di attesa cambiando sezione.
#
# Perche' non solo per un disegno: chi clicca fra le sezioni le rivede a
# raffica, e rileggere tutto il catalogo a ogni ritorno vuol dire un secondo e
# mezzo ogni volta.
#
# Perche' non per sempre: se qualcosa cambia da fuori (l'utente apre i
# servizi, un altro programma scrive nel registro) la finestra deve
# accorgersene da sola. Mostrare uno stato vecchio e' esattamente il difetto
# che abbiamo gia' pagato caro una volta.
#
# Due minuti, non dodici secondi: con dodici la fotografia scadeva mentre
# l'utente stava ancora leggendo la pagina, e il ritorno alla sezione
# successiva ripagava tutto il conto. Il caso vero - esco dal programma,
# cambio qualcosa altrove, rientro - e' coperto meglio da Clear-VtStateCache
# agganciato al momento in cui la finestra ritorna in primo piano, che sta
# nella GUI.
#
# Dopo ogni scrittura la cache si svuota comunque, subito.
$script:VtStatiDurata = 120
# Due svuotamenti diversi, perche' le due cose invecchiano a velocita' diverse.
#
#   Clear-VtStatiTweak  - solo lo stato degli interruttori. Va buttato spesso:
#                         basta che l'utente apra i servizi in un'altra
#                         finestra perche' non sia piu' vero. Lo chiama anche
#                         il ritorno in primo piano della finestra.
#
#   Clear-VtStateCache  - stato PIU' le letture di diagnosi (registro eventi,
#                         salute dei dischi, interrupt, elenco servizi). Serve
#                         dopo una scrittura, dove puo' essere cambiato tutto.
#
# La diagnosi non si butta a ogni alt-tab di proposito: sono un secondo e
# mezzo di letture, e un errore WHEA di tre giorni fa non cambia perche' hai
# cambiato finestra.
function Clear-VtStatiTweak { $script:VtStati = $null }

function Clear-VtDiagnosiCache {
    $script:VtEventi   = $null
    $script:VtDischiC  = $null
    $script:VtMsiC     = $null
    $script:VtEssenzC  = $null
    $script:VtDiagC    = $null
    $script:VtRiepC    = $null
}

function Clear-VtStateCache {
    Clear-VtStatiTweak
    Clear-VtDiagnosiCache
}

function Get-VtState($tweak) {
    $ora = [datetime]::UtcNow
    if ($script:VtStati -and ($ora - $script:VtStatiOra).TotalSeconds -gt $script:VtStatiDurata) {
        $script:VtStati = $null
    }
    if (-not $script:VtStati) { $script:VtStati = @{}; $script:VtStatiOra = $ora }

    $k = "$($tweak.Id)"
    if ($k -and $script:VtStati.ContainsKey($k)) { return $script:VtStati[$k] }
    $v = Get-VtStateReale $tweak
    if ($k) { $script:VtStati[$k] = $v }
    return $v
}

function Get-VtStateReale($tweak) {
    try {
        switch ($tweak.Kind) {
            'Reg' {
                foreach ($i in $tweak.Items) {
                    if (-not (Test-VtValoreUguale (Get-VtReg $i.Path $i.Name) $i.Val)) { return $false }
                }
                return $true
            }
            'Svc' {
                # Alcuni servizi sono protetti dal sistema e rifiutano la
                # modifica anche da amministratore (DoSvc e' il caso tipico).
                # Se ci abbiamo gia' provato e non si e' lasciato cambiare, non
                # ha senso tenere la voce spenta per sempre: lo escludiamo.
                $e = Get-VtEntry $tweak.Id
                $saltati = @()
                if ($e -and $e.Saltati) { $saltati = @($e.Saltati) }
                foreach ($s in $tweak.Svc) {
                    if ($saltati -contains $s.Name) { continue }
                    if (-not (Get-Service -Name $s.Name -ErrorAction SilentlyContinue)) { continue }
                    if ((Get-VtServiceStart $s.Name) -ne $script:VtStartMap[$s.Start]) { return $false }
                }
                return $true
            }
            'Nic'    { return (Test-VtNicProps $tweak.Nic) }
            'Nvapi'  { return (Test-VtNvTweak $tweak.Nv) }
            'NvProf' { return (Test-VtNvProfilo (Get-VtNvProfilo $tweak.Id)) }
            'Script' { return [bool] (& $tweak.Test) }
        }
    } catch {
        Write-VtLog "Stato non leggibile per '$($tweak.Id)': $($_.Exception.Message)" warn
    }
    return $false
}

function Enable-VtTweak($tweak) {
    switch ($tweak.Kind) {
        'Reg' {
            $bak = @()
            foreach ($i in $tweak.Items) {
                $old = Get-VtReg $i.Path $i.Name
                $bak += @{ Path = $i.Path; Name = $i.Name; Type = $i.Type
                           Existed = ($null -ne $old); Val = $old }
                Set-VtReg $i.Path $i.Name $i.Type $i.Val
            }
            Set-VtEntry $tweak.Id @{ Reg = $bak }
        }
        'Svc' {
            # Ogni servizio si prova per conto suo. Prima un solo servizio
            # protetto faceva fallire l'intero gruppo E impediva di salvare il
            # backup, quindi quelli gia' cambiati non si potevano piu'
            # ripristinare: il caso peggiore possibile.
            $bak = @(); $saltati = @()
            foreach ($s in $tweak.Svc) {
                if (-not (Get-Service -Name $s.Name -ErrorAction SilentlyContinue)) { continue }
                $prima = Get-VtServiceStart $s.Name
                try {
                    Set-VtServiceStart $s.Name $s.Start | Out-Null
                    $bak += @{ Name = $s.Name; Start = $prima }
                } catch {
                    $saltati += $s.Name
                    Write-VtLog "$($s.Name): non modificabile su questo sistema ($($_.Exception.Message.Split([char]10)[0]))" warn
                }
            }
            Set-VtEntry $tweak.Id @{ Svc = $bak; Saltati = $saltati }
            if ($bak.Count -eq 0 -and $saltati.Count -gt 0) {
                throw "Nessuno dei servizi si e' lasciato modificare: $($saltati -join ', ')"
            }
        }
        'Nic'    { Set-VtNicProps $tweak.Id $tweak.Nic | Out-Null }
        'Nvapi'  { Set-VtNvTweak $tweak.Id $tweak.Nv }
        'NvProf' { Set-VtNvProfilo $tweak.Id }
        'Script' { & $tweak.On }
    }
    Write-VtLog "Attivato: $($tweak.Nome)" ok
}

function Disable-VtTweak($tweak) {
    switch ($tweak.Kind) {
        'Reg' {
            $e = Get-VtEntry $tweak.Id
            if (-not $e) {
                Write-VtLog "Nessun backup per '$($tweak.Id)': non posso ripristinare i valori originali." warn
                return
            }
            foreach ($b in @($e.Reg)) {
                if ($b.Existed) { Set-VtReg $b.Path $b.Name $b.Type $b.Val }
                else { Remove-ItemProperty -Path $b.Path -Name $b.Name -ErrorAction SilentlyContinue }
            }
            Remove-VtEntry $tweak.Id
        }
        'Svc' {
            $e = Get-VtEntry $tweak.Id
            if (-not $e) { Write-VtLog "Nessun backup per '$($tweak.Id)'." warn; return }
            foreach ($b in @($e.Svc)) {
                $tipo = switch ([int] $b.Start) { 4 { 'Disabled' } 3 { 'Manual' } 2 { 'Automatic' } default { $null } }
                if ($tipo) { try { Set-VtServiceStart $b.Name $tipo | Out-Null } catch { } }
            }
            Remove-VtEntry $tweak.Id
        }
        'Nic'    { Restore-VtNicProps $tweak.Id }
        'Nvapi'  { Restore-VtNvTweak $tweak.Id }
        'NvProf' { Restore-VtNvProfilo $tweak.Id }
        'Script' { & $tweak.Off }
    }
    Write-VtLog "Disattivato: $($tweak.Nome)" ok
}

function Set-VtTweak($tweak, [bool] $on) {
    # Dopo una scrittura la fotografia in cache non vale piu'.
    Clear-VtStateCache
    try {
        if ($on) { Enable-VtTweak $tweak } else { Disable-VtTweak $tweak }
        Clear-VtStateCache
        return $true
    } catch {
        Write-VtLog "ERRORE su '$($tweak.Nome)': $($_.Exception.Message)" err
        return $false
    }
}

# ---------------------------------------------------------------------------
# Controlli diagnostici (quelli che nessun interruttore puo' risolvere)
# ---------------------------------------------------------------------------
function Get-VtDiagnosi {
    # Un secondo e due alla prima chiamata: legge BIOS, CPU, dischi, driver.
    # Sono fatti che non cambiano finche' il programma resta aperto.
    if ($null -ne $script:VtDiagC) { return $script:VtDiagC }
    $out = @()
    $sys = Get-VtSystem

    if ($sys.Thread -eq $sys.Core -and $sys.Cpu -match 'Core.*i[579]|Ryzen [579]|Core.*Ultra') {
        $out += [pscustomobject]@{ Peso=1; Titolo='Hyper-Threading / SMT disattivato'
            Testo="La CPU riporta $($sys.Core) core e solo $($sys.Thread) thread. Riattiva Hyper-Threading (Intel) o SMT (AMD) nel BIOS: su FiveM, Fortnite e R6 valgono 10-20% di FPS e molto di piu' sui minimi." }
    }

    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $conf = ($mods | Measure-Object ConfiguredClockSpeed -Maximum).Maximum
        $max  = ($mods | Measure-Object Speed -Maximum).Maximum
        if ($conf -and $max -and $conf -lt ($max - 100)) {
            $out += [pscustomobject]@{ Peso=1; Titolo='Profilo XMP / EXPO non attivo'
                Testo="La RAM gira a $conf MT/s invece di $max. Attiva XMP (Intel) o EXPO (AMD) nel BIOS: sui giochi CPU-bound valgono 10-25% di FPS medi e soprattutto di 1% low. Non e' overclock del processore." }
        }
        if ($mods.Count -eq 1) {
            $out += [pscustomobject]@{ Peso=1; Titolo='RAM in single channel'
                Testo='Hai un solo banco di RAM. Aggiungerne un secondo identico vale 15-30% di FPS.' }
        }
    } catch { }

    try {
        foreach ($v in (Get-CimInstance Win32_VideoController | Where-Object { $_.CurrentRefreshRate -gt 0 })) {
            if ($v.MaxRefreshRate -gt $v.CurrentRefreshRate + 2) {
                $out += [pscustomobject]@{ Peso=1; Titolo='Monitor non al refresh massimo'
                    Testo="Lo schermo gira a $($v.CurrentRefreshRate) Hz ma supporta $($v.MaxRefreshRate) Hz. Impostazioni > Schermo > Schermo avanzato. Finche' resta cosi', tutti gli FPS sopra $($v.CurrentRefreshRate) non li vedi." }
            }
        }
    } catch { }

    foreach ($g in $sys.Gpu) {
        if ($g.DriverDate) {
            $mesi = [math]::Round(((Get-Date) - $g.DriverDate).TotalDays / 30.4)
            if ($mesi -ge 8) {
                $out += [pscustomobject]@{ Peso=2; Titolo='Driver video datato'
                    Testo="Il driver di $($g.Name) ha circa $mesi mesi. Fortnite e Valorant ricevono ottimizzazioni driver a ogni stagione." }
            }
        }
    }

    try {
        $dg = Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction Stop
        if ($dg.SecurityServicesRunning -contains 2) {
            $out += [pscustomobject]@{ Peso=2; Titolo='Integrita'' della memoria attiva'
                Testo='HVCI fa girare ogni driver dentro un hypervisor e costa tipicamente 5-15% di FPS. Puoi spegnerla da Sicurezza di Windows > Sicurezza dispositivo > Isolamento core. E'' un compromesso vero: perdi una protezione reale contro i driver malevoli.' }
        }
    } catch { }

    $bcd = Invoke-VtCmd 'bcdedit /enum "{current}"'
    # bcdedit stampa il valore tradotto ("Yes", "Si'", "Ja"...), ma il nome
    # della voce no. E soprattutto queste voci compaiono nell'elenco SOLO se
    # qualcuno le ha impostate: la loro presenza e' gia' la risposta.
    if ($bcd -match '(?im)^\s*useplatformclock\s') {
        $out += [pscustomobject]@{ Peso=1; Titolo='HPET forzato nel BCD'
            Testo='useplatformclock e'' impostato su Yes. E'' un vecchio tweak da forum che sulle CPU moderne AGGIUNGE stutter e latenza. Aprire un prompt come amministratore e dare: bcdedit /deletevalue useplatformclock' }
    }

    try {
        $auto = (Get-CimInstance Win32_ComputerSystem).AutomaticManagedPagefile
        $pf   = @(Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue)
        if (-not $auto -and $pf.Count -eq 0) {
            $out += [pscustomobject]@{ Peso=1; Titolo='File di paging disattivato'
                Testo='Spegnere il file di paging non da'' FPS: fa crashare i giochi che riservano molta memoria virtuale, e Fortnite e GTA V lo fanno. Rimettilo su "gestito dal sistema".' }
        }
    } catch { }

    foreach ($p in $script:VtProtetti) {
        if (-not (Get-Service -Name $p.Name -ErrorAction SilentlyContinue)) { continue }
        if ((Get-VtServiceStart $p.Name) -eq 4) {
            $out += [pscustomobject]@{ Peso=1; Titolo="Servizio $($p.Name) disabilitato"
                Testo="$($p.Desc). Probabilmente e' stato spento da un 'debloater'. Va rimesso su Manuale o il gioco non parte proprio." }
        }
    }

    $d = Get-PSDrive -Name ($env:SystemDrive.TrimEnd(':')) -ErrorAction SilentlyContinue
    if ($d) {
        $pct = [math]::Round(100 * $d.Free / ($d.Free + $d.Used), 1)
        if ($pct -lt 10) {
            $out += [pscustomobject]@{ Peso=2; Titolo='Disco di sistema quasi pieno'
                Testo="Sei al $pct% di spazio libero. Sotto il 10% il file di paging non si espande e la cache delle shader viene buttata e ricompilata: e' stutter garantito." }
        }
    }

    $script:VtDiagC = @($out | Sort-Object Peso)
    return $script:VtDiagC
}

# ---------------------------------------------------------------------------
# FORTNITE
#
# Qui non tocchiamo Windows: scriviamo sul file di configurazione di Fortnite,
# GameUserSettings.ini, che e' lo stesso file che il gioco scrive da solo
# quando cambi le opzioni dal menu. Nessuna iniezione, nessun driver: e' roba
# che gli anticheat non guardano nemmeno.
#
# Due regole che valgono per tutto questo blocco:
#   1. Fortnite riscrive il file quando esce. Se il gioco e' aperto mentre
#      scriviamo, le modifiche spariscono. Quindi controlliamo sempre.
#   2. Prima di ogni scrittura si fa una copia del file, e "Ripristina" la
#      rimette. Le chiavi sono tante e alcune non sono documentate.
# ---------------------------------------------------------------------------
function Get-VtFortnitePaths {
    $dir = Join-Path $env:LOCALAPPDATA 'FortniteGame\Saved\Config\WindowsClient'
    $ini = Join-Path $dir 'GameUserSettings.ini'
    [pscustomobject]@{ Dir = $dir; Ini = $ini; Esiste = (Test-Path -LiteralPath $ini) }
}

function Test-VtFortniteRunning {
    [bool] (Get-Process -Name 'FortniteClient-Win64-Shipping', 'FortniteLauncher' -ErrorAction SilentlyContinue)
}

function Test-VtFortniteReadOnly {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { return $false }
    [bool] ((Get-Item -LiteralPath $p.Ini).Attributes -band [IO.FileAttributes]::ReadOnly)
}

function Set-VtFortniteReadOnly([bool] $solaLettura) {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { throw 'File di configurazione di Fortnite non trovato.' }
    $f = Get-Item -LiteralPath $p.Ini
    if ($solaLettura) { $f.Attributes = $f.Attributes -bor [IO.FileAttributes]::ReadOnly }
    else              { $f.Attributes = $f.Attributes -band (-bnot [IO.FileAttributes]::ReadOnly) }
    Write-VtLog "GameUserSettings.ini sola lettura = $solaLettura" ok
}

function Backup-VtFortnite {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { throw 'File di configurazione di Fortnite non trovato.' }
    $dest = Join-Path $p.Dir ('GameUserSettings.ini.vejatweak.{0}.bak' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Copy-Item -LiteralPath $p.Ini -Destination $dest -Force
    Write-VtLog "Copia di sicurezza: $(Split-Path $dest -Leaf)"

    # Teniamo le cinque piu' recenti: oltre diventano solo confusione nella
    # cartella (SapoTweak ne ha lasciate otto).
    Get-ChildItem $p.Dir -Filter 'GameUserSettings.ini.vejatweak.*.bak' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip 5 |
        Remove-Item -Force -ErrorAction SilentlyContinue
    return $dest
}

function Restore-VtFortnite {
    $p = Get-VtFortnitePaths
    $bak = Get-ChildItem $p.Dir -Filter 'GameUserSettings.ini.vejatweak.*.bak' -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $bak) { throw 'Nessuna copia fatta da VejaTweak: non c''e'' niente da ripristinare.' }
    if (Test-VtFortniteReadOnly) { Set-VtFortniteReadOnly $false }
    Copy-Item -LiteralPath $bak.FullName -Destination $p.Ini -Force
    Write-VtLog "Configurazione di Fortnite ripristinata da $($bak.Name)" ok
    return $bak.Name
}

# Scrittura di un .ini per righe, non per sezioni ricostruite.
#
# GameUserSettings.ini contiene chiavi ripetute (RecentSelections compare
# cinque volte) e righe che non seguono lo schema chiave=valore: qualunque
# parser che rilegge tutto e riscrive il file da capo le perderebbe. Qui si
# tocca solo la riga interessata e tutto il resto resta byte per byte com'era.
#
# Con -SoloEsistenti le chiavi che non esistono gia' nel file vengono saltate
# invece che aggiunte. Serve per i giochi di cui non abbiamo potuto verificare
# il file di persona: scrivere una chiave sbagliata non rompe niente, ma crea
# un tweak che sembra applicato e non fa nulla. Meglio saltarlo e dirlo.
function Set-VtIniValues([string] $path, $voci, [switch] $SoloEsistenti) {
    $righe = [System.Collections.Generic.List[string]] (Get-Content -LiteralPath $path)
    $applicate = 0; $saltate = @()

    # Indice: nome sezione -> intervallo di righe che le appartengono
    $sezioni = @{}
    $corrente = ''
    for ($i = 0; $i -lt $righe.Count; $i++) {
        if ($righe[$i] -match '^\s*\[(.+?)\]\s*$') {
            $corrente = $matches[1]
            $sezioni[$corrente] = @{ Inizio = $i; Fine = $i }
        } elseif ($corrente -and $sezioni.ContainsKey($corrente)) {
            $sezioni[$corrente].Fine = $i
        }
    }

    foreach ($v in $voci) {
        $riga = '{0}={1}' -f $v.Chiave, $v.Valore

        if (-not $sezioni.ContainsKey($v.Sez)) {
            if ($SoloEsistenti) { $saltate += "$($v.Sez)/$($v.Chiave)"; continue }
            $righe.Add('')
            $righe.Add("[$($v.Sez)]")
            $righe.Add($riga)
            $sezioni[$v.Sez] = @{ Inizio = $righe.Count - 2; Fine = $righe.Count - 1 }
            $applicate++
            continue
        }

        $s = $sezioni[$v.Sez]
        $trovata = -1
        for ($i = $s.Inizio + 1; $i -le $s.Fine -and $i -lt $righe.Count; $i++) {
            if ($righe[$i] -match ('^\s*' + [regex]::Escape($v.Chiave) + '\s*=')) { $trovata = $i; break }
        }
        if ($trovata -ge 0) {
            $righe[$trovata] = $riga
            $applicate++
        } elseif ($SoloEsistenti) {
            $saltate += "$($v.Sez)/$($v.Chiave)"
        } else {
            $righe.Insert($s.Inizio + 1, $riga)
            # Le righe successive sono slittate di uno: aggiorniamo gli indici.
            foreach ($k in @($sezioni.Keys)) {
                if ($sezioni[$k].Inizio -gt $s.Inizio) { $sezioni[$k].Inizio++ }
                if ($sezioni[$k].Fine   -ge $s.Inizio) { $sezioni[$k].Fine++ }
            }
            $applicate++
        }
    }

    # UTF8 senza BOM: il gioco scrive cosi', e con il BOM la prima riga
    # (;METADATA=...) verrebbe letta male.
    [IO.File]::WriteAllLines($path, $righe, (New-Object Text.UTF8Encoding $false))
    if ($saltate.Count -gt 0) {
        Write-VtLog ("Chiavi non presenti nel file, saltate: " + ($saltate -join ', ')) warn
    }
    [pscustomobject]@{ Applicate = $applicate; Saltate = $saltate }
}

# Stessa filosofia per i file XML di GTA V / FiveM: sostituzione della singola
# riga <Tag value="..." />, mai riscrittura dell'albero. Tocca solo i tag che
# esistono gia'.
function Set-VtXmlValues([string] $path, $voci) {
    $righe = [System.Collections.Generic.List[string]] (Get-Content -LiteralPath $path)
    $applicate = 0; $saltate = @()
    foreach ($v in $voci) {
        $rx = '^(\s*)<' + [regex]::Escape($v.Tag) + '\s+value="[^"]*"\s*/>\s*$'
        $fatto = $false
        for ($i = 0; $i -lt $righe.Count; $i++) {
            if ($righe[$i] -match $rx) {
                $righe[$i] = '{0}<{1} value="{2}" />' -f $matches[1], $v.Tag, $v.Valore
                $fatto = $true; $applicate++
                break
            }
        }
        if (-not $fatto) { $saltate += $v.Tag }
    }
    [IO.File]::WriteAllLines($path, $righe, (New-Object Text.UTF8Encoding $false))
    if ($saltate.Count -gt 0) { Write-VtLog ("Tag XML non trovati, saltati: " + ($saltate -join ', ')) warn }
    [pscustomobject]@{ Applicate = $applicate; Saltate = $saltate }
}

# --- Copie di sicurezza, valide per tutti i giochi ------------------------
function Backup-VtGameFile([string] $path) {
    if (-not (Test-Path -LiteralPath $path)) { throw "File non trovato: $path" }
    $f = Get-Item -LiteralPath $path
    $dest = Join-Path $f.DirectoryName ('{0}.vejatweak.{1}.bak' -f $f.Name, (Get-Date -Format 'yyyyMMdd-HHmmss'))
    Copy-Item -LiteralPath $path -Destination $dest -Force
    (Get-Item -LiteralPath $dest).Attributes = 'Normal'
    Get-ChildItem $f.DirectoryName -Filter "$($f.Name).vejatweak.*.bak" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -Skip 5 |
        Remove-Item -Force -ErrorAction SilentlyContinue
    Write-VtLog "Copia di sicurezza: $(Split-Path $dest -Leaf)"
    $dest
}

function Restore-VtGameFile([string] $path) {
    $f = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    if (-not $f) { throw "File non trovato: $path" }
    $bak = Get-ChildItem $f.DirectoryName -Filter "$($f.Name).vejatweak.*.bak" -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $bak) { throw 'Nessuna copia fatta da VejaTweak per questo file.' }
    if ($f.Attributes -band [IO.FileAttributes]::ReadOnly) { $f.Attributes = 'Normal' }
    Copy-Item -LiteralPath $bak.FullName -Destination $path -Force
    Write-VtLog "Ripristinato $($f.Name) da $($bak.Name)" ok
    $bak.Name
}

# Legge il file di Fortnite RISPETTANDO LE SEZIONI.
#
# Prima leggeva tutto di fila ignorandole, e con un file .ini e' un errore che
# prima o poi si paga: lo stesso nome di chiave puo' comparire in piu'
# sezioni, e vinceva l'ultima incontrata. Caso vero trovato su questo PC:
#
#     [/Script/FortniteGame.FortGameUserSettings]
#     WindowHeight=1080        <- quella giusta
#     ...
#     [ChatSettings]
#     WindowHeight=0           <- questa vinceva
#
# Il risultato era che il programma leggeva l'altezza della finestra come 0 e
# la riportava sbagliata, facendo sembrare rotto un file che era a posto.
#
# Non si puo' pero' leggere SOLO quella sezione, perche' altre voci che
# servono stanno altrove per costruzione del gioco:
#   sg.ResolutionQuality, sg.ViewDistanceQuality  ->  [ScalabilityGroups]
#   PreferredFeatureLevel                         ->  [D3DRHIPreference]
#
# Quindi si legge tutto, ma a parita' di nome vince la sezione delle
# impostazioni di gioco, non l'ultima incontrata nel file.
function Get-VtFortniteIniMap {
    $p = Get-VtFortnitePaths
    $m = @{}
    if (-not $p.Esiste) { return $m }

    $sezGioco = '/Script/FortniteGame.FortGameUserSettings'
    $gioco = @{}
    $sez = ''
    foreach ($l in (Get-Content -LiteralPath $p.Ini)) {
        if ($l -match '^\s*\[(.+)\]\s*$') { $sez = $matches[1]; continue }
        if ($l -notmatch '^\s*([A-Za-z0-9_.\[\]]+)\s*=\s*(.*)$') { continue }
        $k = $matches[1]; $v = $matches[2]
        if ($sez -eq $sezGioco) { $gioco[$k] = $v }
        $m[$k] = $v
    }
    foreach ($k in $gioco.Keys) { $m[$k] = $gioco[$k] }
    return $m
}

function Get-VtMonitorHz {
    try {
        $v = Get-CimInstance Win32_VideoController | Where-Object { $_.CurrentRefreshRate -gt 0 } | Select-Object -First 1
        if ($v) { return [int] $v.CurrentRefreshRate }
    } catch { }
    return 60
}

# Prepara la scrittura: controlla che il gioco sia chiuso, fa la copia e
# toglie la sola lettura se serve. Restituisce lo stato precedente del
# flag, cosi' chi chiama puo' rimetterlo.
function Start-VtFortniteEdit {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { throw 'Fortnite non ha ancora creato il file di configurazione. Avvialo una volta e richiudilo.' }
    if (Test-VtFortniteRunning) { throw 'Fortnite e'' aperto. Chiudilo prima: quando esce riscrive il file e cancellerebbe le modifiche.' }
    $ro = Test-VtFortniteReadOnly
    if ($ro) { Set-VtFortniteReadOnly $false }
    Backup-VtFortnite | Out-Null
    return $ro
}

function Complete-VtFortniteEdit([bool] $eraSolaLettura) {
    if ($eraSolaLettura) { Set-VtFortniteReadOnly $true }
}

function Invoke-VtFortnitePreset {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $hz = Get-VtMonitorHz
    $S  = '/Script/FortniteGame.FortGameUserSettings'

    $voci = @(
        # Motore di rendering: es31 e' la Modalita' Prestazioni, quella che su
        # PC modesti vale piu' di tutte le altre voci messe insieme.
        @{ Sez='D3DRHIPreference'; Chiave='PreferredFeatureLevel'; Valore='es31' }
        @{ Sez='PerformanceMode';  Chiave='MeshQuality';           Valore='0' }

        @{ Sez=$S; Chiave='bUseVSync';                Valore='False' }
        @{ Sez=$S; Chiave='bUseDynamicResolution';    Valore='False' }
        @{ Sez=$S; Chiave='bMotionBlur';              Valore='False' }
        @{ Sez=$S; Chiave='bShowGrass';               Valore='False' }
        @{ Sez=$S; Chiave='bAllowUIParallax';         Valore='False' }
        @{ Sez=$S; Chiave='FortAntiAliasingMethod';   Valore='Disabled' }
        @{ Sez=$S; Chiave='bUseNanite';               Valore='False' }
        @{ Sez=$S; Chiave='bRayTracing';              Valore='False' }
        @{ Sez=$S; Chiave='bUseLumenGI';              Valore='False' }
        @{ Sez=$S; Chiave='bUseLumenReflections';     Valore='False' }
        @{ Sez=$S; Chiave='DesiredGlobalIlluminationQuality'; Valore='0' }
        @{ Sez=$S; Chiave='DesiredReflectionQuality'; Valore='0' }

        # Reflex: 2 = On + Boost. bLatencyFlash e' solo l'indicatore a schermo.
        @{ Sez=$S; Chiave='LatencyTweak2';                Valore='2' }
        @{ Sez=$S; Chiave='bLatencyFlash';                Valore='False' }
        @{ Sez=$S; Chiave='LowInputLatencyModeIsEnabled'; Valore='True' }

        # Schermo intero esclusivo: catena di presentazione piu' corta.
        @{ Sez=$S; Chiave='FullscreenMode';              Valore='0' }
        @{ Sez=$S; Chiave='PreferredFullscreenMode';     Valore='0' }
        @{ Sez=$S; Chiave='LastConfirmedFullscreenMode'; Valore='0' }

        @{ Sez=$S; Chiave='FrameRateLimit';         Valore=('{0}.000000' -f $hz) }
        @{ Sez=$S; Chiave='FrontendFrameRateLimit'; Valore=$hz }

        @{ Sez='ScalabilityGroups'; Chiave='sg.ViewDistanceQuality';        Valore='2' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.AntiAliasingQuality';        Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ShadowQuality';              Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.GlobalIlluminationQuality';  Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ReflectionQuality';          Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.PostProcessQuality';         Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.TextureQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.EffectsQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.FoliageQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ShadingQuality';             Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.LandscapeQuality';           Valore='0' }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ResolutionQuality';          Valore='100.000000' }
        @{ Sez=$S; Chiave='PotentiallyUpscaledResolutionQuality'; Valore='100.000000' }
        @{ Sez=$S; Chiave='NeverUpscaledResolutionQuality';       Valore='100.000000' }
    )

    # Out-Null perche' Set-VtIniValues restituisce un riepilogo che qui non
    # serve: senza, finirebbe nel valore di ritorno della funzione insieme
    # agli Hz, e chi chiama si ritroverebbe due oggetti invece di uno.
    Set-VtIniValues $p.Ini $voci | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Preset competitivo Fortnite applicato (limite FPS $hz)" ok
    return $hz
}

function Set-VtFortniteFpsLimit([int] $fps) {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $S  = '/Script/FortniteGame.FortGameUserSettings'
    Set-VtIniValues $p.Ini @(
        @{ Sez=$S; Chiave='FrameRateLimit';         Valore=('{0}.000000' -f $fps) }
        @{ Sez=$S; Chiave='FrontendFrameRateLimit'; Valore=$(if ($fps -eq 0) { 120 } else { $fps }) }
        @{ Sez=$S; Chiave='bUseVSync';              Valore='False' }
    ) | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Limite FPS di Fortnite impostato a $(if ($fps -eq 0) { 'illimitato' } else { $fps })" ok
}

# Il compromesso fra FPS e leggibilita' non e' una scelta che posso fare io al
# posto di chi gioca: la stessa impostazione che rende nitido un bersaglio
# lontano toglie frame a una CPU al limite. Qui sono tre gradini espliciti.
$script:VtQualitaFn = @(
    @{ Nome='Massimo FPS  -  risoluzione 3D 75%, distanza visuale bassa'; Res=75;  Vista=0; Fps=-1 }
    @{ Nome='Equilibrato  -  risoluzione 3D 90%, distanza visuale media'; Res=90;  Vista=1; Fps=0 }
    @{ Nome='Nitidezza    -  risoluzione 3D 100%, distanza visuale alta'; Res=100; Vista=2; Fps=0 }
)

# $fps: -1 = nessun limite, 0 = aggancia al refresh del monitor.
function Set-VtFortniteQualita([int] $res3d, [int] $vista, [int] $fps) {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $S  = '/Script/FortniteGame.FortGameUserSettings'

    $limite = if ($fps -lt 0) { 0 } else { Get-VtMonitorHz }
    Set-VtIniValues $p.Ini @(
        @{ Sez='ScalabilityGroups'; Chiave='sg.ResolutionQuality';   Valore=('{0}.000000' -f $res3d) }
        @{ Sez='ScalabilityGroups'; Chiave='sg.ViewDistanceQuality'; Valore=$vista }
        @{ Sez=$S; Chiave='PotentiallyUpscaledResolutionQuality'; Valore=('{0}.000000' -f $res3d) }
        @{ Sez=$S; Chiave='NeverUpscaledResolutionQuality';       Valore=('{0}.000000' -f $res3d) }
        @{ Sez=$S; Chiave='FrameRateLimit';         Valore=('{0}.000000' -f $limite) }
        @{ Sez=$S; Chiave='FrontendFrameRateLimit'; Valore=$(if ($limite -eq 0) { 120 } else { $limite }) }
    ) | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Fortnite: risoluzione 3D $res3d%, distanza visuale $vista, limite FPS $(if ($limite -eq 0) { 'nessuno' } else { $limite })" ok
}

# L'elenco che finisce nel menu a tendina.
#
# Era una lista fissa di cinque voci, e due di quelle (1600x1080 e 1280x1080)
# su un monitor normale NON esistono: sceglierle scriveva la risoluzione, il
# gioco non riusciva ad andarci in schermo intero esclusivo e riscriveva tutto
# a modo suo. Il cliente vedeva "impostata" e poi non cambiava niente.
#
# Adesso l'elenco viene dallo schermo. Chi si e' creato una stretched nel
# pannello NVIDIA se la ritrova qui da sola, e chi non l'ha creata non puo'
# piu' scegliere qualcosa che non funzionera'.
function Get-VtSceltaRisoluzioni {
    $r = @(Get-VtRisoluzioniProponibili)
    if ($r.Count -eq 0) {
        # Se le modalita' non si leggono si torna alle scelte classiche: meglio
        # una lista imperfetta che un menu vuoto.
        return @(
            @{ Nome='1920 x 1080  (nativa 16:9)'; X=1920; Y=1080 }
            @{ Nome='1440 x 1080  (stretched 4:3)'; X=1440; Y=1080 }
            @{ Nome='1024 x 768   (4:3 classico)'; X=1024; Y=768 }
        )
    }
    @($r | ForEach-Object {
        @{
            Nome = "{0} x {1}  -  {2}{3}" -f $_.X, $_.Y, $_.Formato, $(if ($_.Nativa) { ', nativa' } else { '' })
            X = $_.X; Y = $_.Y
        }
    })
}

function Set-VtFortniteResolution([int] $x, [int] $y) {
    $ro = Start-VtFortniteEdit
    $p  = Get-VtFortnitePaths
    $S  = '/Script/FortniteGame.FortGameUserSettings'
    Set-VtIniValues $p.Ini @(
        @{ Sez=$S; Chiave='ResolutionSizeX';                    Valore=$x }
        @{ Sez=$S; Chiave='ResolutionSizeY';                    Valore=$y }
        @{ Sez=$S; Chiave='LastUserConfirmedResolutionSizeX';   Valore=$x }
        @{ Sez=$S; Chiave='LastUserConfirmedResolutionSizeY';   Valore=$y }
        @{ Sez=$S; Chiave='DesiredScreenWidth';                 Valore=$x }
        @{ Sez=$S; Chiave='DesiredScreenHeight';                Valore=$y }
        @{ Sez=$S; Chiave='LastUserConfirmedDesiredScreenWidth';  Valore=$x }
        @{ Sez=$S; Chiave='LastUserConfirmedDesiredScreenHeight'; Valore=$y }
        @{ Sez=$S; Chiave='WindowWidth';                        Valore=$x }
        @{ Sez=$S; Chiave='WindowHeight';                       Valore=$y }
        @{ Sez=$S; Chiave='bUseDesktopResolutionForFullscreen'; Valore='False' }
        @{ Sez=$S; Chiave='FullscreenMode';                     Valore='0' }
        @{ Sez=$S; Chiave='PreferredFullscreenMode';            Valore='0' }
        @{ Sez=$S; Chiave='LastConfirmedFullscreenMode';        Valore='0' }
    ) | Out-Null
    Complete-VtFortniteEdit $ro
    Write-VtLog "Risoluzione di Fortnite impostata a ${x}x${y}" ok
}

# Fortnite tiene la risoluzione in QUATTRO coppie di chiavi, e devono dire
# tutte la stessa cosa.
#
#   ResolutionSize*                  quella in uso
#   LastUserConfirmedResolutionSize* l'ultima confermata dal gioco
#   DesiredScreen*                   quella chiesta
#   Window*                          la finestra
#
# Quando non concordano vuol dire che il gioco ha rifiutato una risoluzione e
# ne ha rimesso un'altra solo in alcune chiavi: e' lo stato in cui si finisce
# chiedendo una modalita' che lo schermo non ha. Il gioco riparte, ma con la
# risoluzione sbagliata, e cambiarla dal menu spesso non basta perche' le
# chiavi rimaste indietro se lo ritrascinano dietro.
function Test-VtFortniteRisoluzioneCoerente {
    $m = Get-VtFortniteIniMap
    if (-not $m) { return $null }

    $x = $m['ResolutionSizeX']; $y = $m['ResolutionSizeY']
    if (-not $x -or -not $y) { return $null }

    $coppie = @(
        @{ N = 'LastUserConfirmedResolutionSize'; X = $m['LastUserConfirmedResolutionSizeX']; Y = $m['LastUserConfirmedResolutionSizeY'] }
        @{ N = 'DesiredScreen';                   X = $m['DesiredScreenWidth'];               Y = $m['DesiredScreenHeight'] }
        @{ N = 'LastUserConfirmedDesiredScreen';  X = $m['LastUserConfirmedDesiredScreenWidth']; Y = $m['LastUserConfirmedDesiredScreenHeight'] }
        @{ N = 'Window';                          X = $m['WindowWidth'];                      Y = $m['WindowHeight'] }
    )

    $diverse = @()
    foreach ($c in $coppie) {
        # Le chiavi assenti non sono un'incoerenza: Fortnite non le scrive
        # tutte su ogni PC. Contano solo quelle presenti e diverse.
        if ($null -eq $c.X -and $null -eq $c.Y) { continue }
        if ("$($c.X)" -ne "$x" -or "$($c.Y)" -ne "$y") {
            $diverse += "$($c.N) = $($c.X) x $($c.Y)"
        }
    }

    [pscustomobject]@{
        Coerente    = ($diverse.Count -eq 0)
        InUso       = "$x x $y"
        X           = [int] $x
        Y           = [int] $y
        Diverse     = $diverse
        Disponibile = (Test-VtRisoluzioneDisponibile ([int] $x) ([int] $y))
    }
}

# Riallinea tutte le chiavi alla risoluzione indicata. E' lo stesso lavoro di
# Set-VtFortniteResolution: esiste come funzione a se' solo perche' la pagina
# possa offrirla come riparazione, con un nome che dice cosa fa.
function Repair-VtFortniteRisoluzione([int] $x, [int] $y) {
    Set-VtFortniteResolution $x $y
    Write-VtLog "Chiavi della risoluzione di Fortnite riallineate a ${x}x${y}" ok
}

# Riassunto leggibile di com'e' messo il gioco adesso.
function Get-VtFortniteStato {
    $p = Get-VtFortnitePaths
    if (-not $p.Esiste) { return $null }
    $m = Get-VtFortniteIniMap

    $fps = $m['FrameRateLimit']
    $fpsTxt = if (-not $fps -or [double]$fps -eq 0) { 'illimitati' } else { [int][double]$fps }

    $mod = switch ($m['FullscreenMode']) { '0' { 'schermo intero esclusivo' } '1' { 'finestra senza bordi' } '2' { 'finestra' } default { 'sconosciuta' } }
    $rhi = switch ($m['PreferredFeatureLevel']) { 'es31' { 'Prestazioni' } 'sm5' { 'DirectX 11' } 'sm6' { 'DirectX 12' } default { $m['PreferredFeatureLevel'] } }
    $rfx = switch ($m['LatencyTweak2']) { '2' { 'On + Boost' } '1' { 'On' } '0' { 'Off' } default { 'sconosciuto' } }

    [pscustomobject]@{
        Risoluzione = "$($m['ResolutionSizeX']) x $($m['ResolutionSizeY'])"
        Fps         = $fpsTxt
        Modalita    = $mod
        Rendering   = $rhi
        Reflex      = $rfx
        Res3D       = $(if ($m['sg.ResolutionQuality']) { [int][double] $m['sg.ResolutionQuality'] } else { '?' })
        VSync       = $m['bUseVSync']
        SolaLettura = (Test-VtFortniteReadOnly)
        InEsecuzione= (Test-VtFortniteRunning)
    }
}

# ---------------------------------------------------------------------------
# VALORANT
#
# Due file, e vanno tenuti allineati:
#   RiotUserSettings.ini  -> [Settings], chiavi EAresIntSettingName:: e
#                            EAresBoolSettingName:: (qualita' grafica, Reflex)
#   GameUserSettings.ini  -> chiavi Unreal standard (V-Sync, limite FPS,
#                            risoluzione, schermo intero). Esiste in due copie:
#                            una per l'account e una di macchina.
# ---------------------------------------------------------------------------
function Get-VtValorantPaths {
    $base = Join-Path $env:LOCALAPPDATA 'VALORANT\Saved\Config'
    $res = [pscustomobject]@{ Riot = $null; Gus = @(); Esiste = $false }
    if (-not (Test-Path $base)) { return $res }

    # La cartella dell'account ha per nome il PUUID seguito dalla regione.
    $acc = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue |
           Where-Object { Test-Path (Join-Path $_.FullName 'Windows\RiotUserSettings.ini') } |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($acc) {
        $res.Riot = Join-Path $acc.FullName 'Windows\RiotUserSettings.ini'
        $p = Join-Path $acc.FullName 'WindowsClient\GameUserSettings.ini'
        if (Test-Path $p) { $res.Gus += $p }
    }
    $m = Join-Path $base 'WindowsClient\GameUserSettings.ini'
    if (Test-Path $m) { $res.Gus += $m }
    $res.Esiste = ($null -ne $res.Riot)
    return $res
}

function Test-VtValorantRunning {
    [bool] (Get-Process -Name 'VALORANT-Win64-Shipping', 'VALORANT', 'RiotClientServices' -ErrorAction SilentlyContinue)
}

function Get-VtValorantStato {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { return $null }
    $r = @{}
    foreach ($l in (Get-Content -LiteralPath $p.Riot)) {
        if ($l -match '^EAres\w+SettingName::(\w+)=(.+)$') { $r[$matches[1]] = $matches[2] }
    }
    # Come per Fortnite: a parita' di nome vince la sezione delle impostazioni
    # di gioco, non l'ultima riga incontrata nel file. Su Fortnite questo
    # errore faceva leggere WindowHeight da [ChatSettings] invece che dalle
    # impostazioni video, e il programma riportava un valore sbagliato.
    $g = @{}
    if ($p.Gus.Count -gt 0) {
        $sezGioco = '/Script/ShooterGame.ShooterGameUserSettings'
        $gioco = @{}
        $sez = ''
        foreach ($l in (Get-Content -LiteralPath $p.Gus[0])) {
            if ($l -match '^\s*\[(.+)\]\s*$') { $sez = $matches[1]; continue }
            if ($l -notmatch '^\s*(\w+)\s*=\s*(.*)$') { continue }
            if ($sez -eq $sezGioco) { $gioco[$matches[1]] = $matches[2] }
            $g[$matches[1]] = $matches[2]
        }
        foreach ($k in $gioco.Keys) { $g[$k] = $gioco[$k] }
    }
    $aa = switch ($r['AntiAliasing']) { '0' { 'nessuno' } '1' { 'MSAA 2x' } '2' { 'MSAA 4x' } default { $r['AntiAliasing'] } }
    $q  = { param($v) switch ($v) { '0' { 'Basso' } '1' { 'Medio' } '2' { 'Alto' } default { $v } } }
    $rf = switch ($r['NvidiaReflexLowLatencySetting']) { '0' { 'Off' } '1' { 'On' } '2' { 'On + Boost' } default { 'sconosciuto' } }
    $fps = $g['FrameRateLimit']
    [pscustomobject]@{
        Risoluzione = "$($g['ResolutionSizeX']) x $($g['ResolutionSizeY'])"
        Fps         = if (-not $fps -or [double]$fps -eq 0) { 'illimitati' } else { [int][double]$fps }
        VSync       = $g['bUseVSync']
        AntiAlias   = $aa
        Materiali   = (& $q $r['MaterialQuality'])
        Texture     = (& $q $r['TextureQuality'])
        Dettaglio   = (& $q $r['DetailQuality'])
        Ombre       = $r['ShadowsEnabled']
        Chiarezza   = $r['ImproveClarity']
        Reflex      = $rf
        Account     = (Split-Path (Split-Path $p.Riot -Parent) -Parent | Split-Path -Leaf)
        InEsecuzione= (Test-VtValorantRunning)
    }
}

function Invoke-VtValorantPreset {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { throw 'Configurazione di Valorant non trovata. Avvia il gioco una volta.' }
    if (Test-VtValorantRunning) { throw 'Valorant o il Riot Client sono aperti. Chiudili: alla chiusura riscrivono i file.' }

    Backup-VtGameFile $p.Riot | Out-Null
    $r = Set-VtIniValues $p.Riot @(
        @{ Sez='Settings'; Chiave='EAresIntSettingName::AntiAliasing';                 Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::MaterialQuality';              Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::TextureQuality';               Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::DetailQuality';                Valore='0' }
        @{ Sez='Settings'; Chiave='EAresIntSettingName::NvidiaReflexLowLatencySetting'; Valore='2' }
        @{ Sez='Settings'; Chiave='EAresBoolSettingName::ShadowsEnabled';              Valore='False' }
        @{ Sez='Settings'; Chiave='EAresBoolSettingName::ImproveClarity';              Valore='False' }
        @{ Sez='Settings'; Chiave='EAresBoolSettingName::ShowCorpses';                 Valore='False' }
    ) -SoloEsistenti

    $hz = Get-VtMonitorHz
    foreach ($g in $p.Gus) {
        Backup-VtGameFile $g | Out-Null
        Set-VtIniValues $g @(
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='bUseVSync';                Valore='False' }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='bUseDynamicResolution';    Valore='False' }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='FrameRateLimit';           Valore=('{0}.000000' -f $hz) }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='PreferredFullscreenMode';  Valore='0' }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='LastConfirmedFullscreenMode'; Valore='0' }
        ) -SoloEsistenti | Out-Null
    }
    Write-VtLog "Preset Valorant applicato ($($r.Applicate) impostazioni, limite FPS $hz)" ok
    return $hz
}

function Set-VtValorantFps([int] $fps) {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { throw 'Configurazione di Valorant non trovata.' }
    if (Test-VtValorantRunning) { throw 'Valorant o il Riot Client sono aperti. Chiudili prima.' }
    foreach ($g in $p.Gus) {
        Backup-VtGameFile $g | Out-Null
        Set-VtIniValues $g @(
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='FrameRateLimit'; Valore=('{0}.000000' -f $fps) }
            @{ Sez='/Script/ShooterGame.ShooterGameUserSettings'; Chiave='bUseVSync';      Valore='False' }
        ) -SoloEsistenti | Out-Null
    }
    Write-VtLog "Limite FPS di Valorant impostato a $(if ($fps -eq 0) { 'illimitato' } else { $fps })" ok
}

function Restore-VtValorant {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { throw 'Configurazione di Valorant non trovata.' }
    $n = Restore-VtGameFile $p.Riot
    foreach ($g in $p.Gus) { try { Restore-VtGameFile $g | Out-Null } catch { } }
    return $n
}

# ---------------------------------------------------------------------------
# FIVEM / GTA V
#
# FiveM non usa il settings.xml di GTA V: ne tiene uno suo in
# %APPDATA%\CitizenFX\gta5_settings.xml. Le voci che contano qui non sono
# quelle grafiche (che di solito sono gia' al minimo) ma quelle che caricano
# la CPU: densita' della citta', varieta' dei pedoni, distanza delle ombre.
# FiveM e' CPU-bound, ed e' li' che si vince.
# ---------------------------------------------------------------------------
function Get-VtFivemSettings {
    $p = Join-Path $env:APPDATA 'CitizenFX\gta5_settings.xml'
    [pscustomobject]@{ Path = $p; Esiste = (Test-Path -LiteralPath $p) }
}

function Test-VtFivemRunning {
    [bool] (Get-Process -Name 'FiveM', 'FiveM_GTAProcess' -ErrorAction SilentlyContinue) -or
    [bool] (Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'FiveM_*' })
}

function Get-VtFivemStato {
    $f = Get-VtFivemSettings
    if (-not $f.Esiste) { return $null }
    $m = @{}
    foreach ($l in (Get-Content -LiteralPath $f.Path)) {
        if ($l -match '<(\w+)\s+value="([^"]*)"\s*/>') { $m[$matches[1]] = $matches[2] }
    }
    [pscustomobject]@{
        Risoluzione = "$($m['ScreenWidth']) x $($m['ScreenHeight'])"
        Finestra    = switch ($m['Windowed']) { '0' { 'schermo intero' } '1' { 'finestra' } '2' { 'senza bordi' } default { $m['Windowed'] } }
        VSync       = $m['VSync']
        Msaa        = $m['MSAA']
        Ombre       = $m['ShadowQuality']
        DistanzaOmbre = $m['Shadow_Distance']
        Citta       = $m['CityDensity']
        Pedoni      = $m['PedVarietyMultiplier']
        Lod         = $m['LodScale']
        InEsecuzione= (Test-VtFivemRunning)
    }
}

# Preset per FiveM, in due livelli.
#
#   'affollati'  quello di sempre, ma completo. Ci mancava una voce vistosa:
#                densita' citta' e varieta' pedoni erano a meta' mentre la
#                VARIETA' DEI VEICOLI era rimasta al massimo, ed e' proprio
#                quella che su un server pieno fa streammare decine di
#                modelli di auto diversi.
#
#   'spinto'     tutto quello sopra, piu' le voci che hanno un prezzo che si
#                vede. Serve quando il server e' pieno davvero e preferisci
#                una citta' spoglia a una presentazione a scatti.
#
# Su un server affollato il carico grosso lo fanno gli ALTRI GIOCATORI, e
# quelli non si possono togliere: li decide il server. Quello che si toglie
# e' il contorno - traffico e passanti generati dal client, modelli in
# streaming, effetti di luce - ed e' li' che si recupera.
function Invoke-VtFivemPreset([string] $Livello = 'affollati') {
    $f = Get-VtFivemSettings
    if (-not $f.Esiste) { throw 'gta5_settings.xml non trovato. Avvia FiveM una volta e richiudilo.' }
    if (Test-VtFivemRunning) { throw 'FiveM e'' aperto. Chiudilo: alla chiusura riscrive il file.' }
    $spinto = ($Livello -eq 'spinto')

    Backup-VtGameFile $f.Path | Out-Null
    $voci = @(
        # --- densita': le voci che tolgono lavoro alla CPU ----------------
        @{ Tag='CityDensity';              Valore=$(if ($spinto) { '0.000000' } else { '0.500000' }) }
        @{ Tag='PedVarietyMultiplier';     Valore=$(if ($spinto) { '0.000000' } else { '0.500000' }) }
        @{ Tag='VehicleVarietyMultiplier'; Valore=$(if ($spinto) { '0.000000' } else { '0.500000' }) }
        @{ Tag='LodScale';                 Valore=$(if ($spinto) { '0.500000' } else { '0.700000' }) }
        @{ Tag='PedLodBias';               Valore=$(if ($spinto) { '0.000000' } else { '0.200000' }) }

        @{ Tag='Shadow_Distance';        Valore=$(if ($spinto) { '0.200000' } else { '0.400000' }) }
        @{ Tag='Shadow_SoftShadows';     Valore='0' }
        @{ Tag='Shadow_ParticleShadows'; Valore='false' }
        @{ Tag='Shadow_LongShadows';     Valore='false' }
        @{ Tag='UltraShadows_Enabled';   Valore='false' }
        @{ Tag='ShadowQuality';          Valore='0' }

        @{ Tag='MSAA';            Valore='0' }
        @{ Tag='MSAAFragments';   Valore='0' }
        @{ Tag='MSAAQuality';     Valore='0' }
        @{ Tag='ReflectionMSAA';  Valore='0' }
        @{ Tag='ReflectionQuality'; Valore='0' }
        @{ Tag='SSAO';            Valore='0' }
        @{ Tag='Tessellation';    Valore='0' }
        @{ Tag='ParticleQuality'; Valore='0' }
        @{ Tag='WaterQuality';    Valore='0' }
        @{ Tag='GrassQuality';    Valore='0' }
        @{ Tag='PostFX';          Valore='0' }
        @{ Tag='DoF';             Valore='false' }
        @{ Tag='MotionBlurStrength'; Valore='0.000000' }
        @{ Tag='AnisotropicFiltering'; Valore='4' }
        @{ Tag='VSync';           Valore='0' }

        # --- aggiunte: costano poco o niente da vedere --------------------
        @{ Tag='ShaderQuality';       Valore='0' }      # shader in versione economica
        @{ Tag='Lighting_FogVolumes'; Valore='false' }  # nebbia volumetrica: pesa sulla GPU
        @{ Tag='Shader_SSA';          Valore='false' }  # luce che filtra dentro la pelle
        @{ Tag='Reflection_MipBlur';  Valore='false' }  # sfocatura dei riflessi
    )
    $r = Set-VtXmlValues $f.Path $voci

    # --- convar: il buffer del Rockstar Editor ---------------------------
    # profile_replayMode a 1 vuol dire che il gioco sta REGISTRANDO di
    # continuo per l'editor, e per farlo tiene un buffer da centinaia di MB
    # che riscrive senza sosta. In FiveM non lo usa quasi nessuno.
    $cfg = @()
    if ((Get-VtFivemCfg).Esiste -and -not (Test-VtFivemRunning)) {
        $cfg = @(
            @{ Nome='profile_replayMode'; Valore='0' }
            @{ Nome='profile_dof';        Valore='0' }
        )
        if ($spinto) {
            # Texture dei veicoli a meta' risoluzione: su un server pieno di
            # auto e' meno roba da streammare e meno memoria video occupata.
            # Da vicino le carrozzerie si vedono piu' morbide: e' il prezzo.
            $cfg += @{ Nome='str_maxVehicleTextureRes';     Valore='512' }
            $cfg += @{ Nome='str_maxVehicleTextureResRgba'; Valore='256' }
        }
        try {
            Backup-VtGameFile (Get-VtFivemCfg).Path | Out-Null
            Set-VtFivemConvar $cfg | Out-Null
        } catch {
            Write-VtLog "fivem.cfg non modificato: $($_.Exception.Message)" warn
            $cfg = @()
        }
    }

    Write-VtLog "Preset FiveM '$Livello': $($r.Applicate) voci grafiche, $($cfg.Count) convar" ok
    [pscustomobject]@{ Applicate = $r.Applicate; Saltate = $r.Saltate; Convar = $cfg.Count; Livello = $Livello }
}

function Restore-VtFivem {
    $f = Get-VtFivemSettings
    if (-not $f.Esiste) { throw 'gta5_settings.xml non trovato.' }
    Restore-VtGameFile $f.Path
}

# ---------------------------------------------------------------------------
# FIVEM: MOVIMENTO E STRAFE
#
# Mettiamo subito in chiaro cosa si puo' e cosa non si puo' fare, perche' qui
# girano molte promesse false.
#
# La VELOCITA' con cui il personaggio si sposta la decide il server, non il
# tuo PC. Nessun file locale la cambia, e cambiarla sarebbe barare: ti farebbe
# espellere, non vincere. Quindi non la tocco.
#
# Quello che si puo' fare e' togliere tutto cio' che si mette FRA il tasto che
# premi e quello che vedi. Nello strafe A-D questo e' quasi tutto il problema:
#
#   - accelerazione del mouse: lo stesso movimento fisico non da' mai lo
#     stesso risultato, quindi il colpo dopo lo strafe non e' ripetibile;
#   - accelerazione della mira in prima persona (qui era a 7 su 10): la mira
#     "scivola" mentre cambi direzione;
#   - oscillazione della testa: mentre corri e cambi direzione la telecamera
#     si muove da sola, e tu correggi un movimento che non hai fatto tu;
#   - auto-livellamento e auto-centratura: la telecamera si rimette dritta
#     da sola e ti rema contro proprio mentre stai contro-strafando.
#
# Tutte queste stanno in fivem.cfg come convar "seta". Sono le stesse voci
# che cambieresti dalle impostazioni del gioco: qui si cambiano tutte insieme
# e si possono rimettere com'erano.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# PROGRAMMI CHE PARTONO CON WINDOWS
#
# Sono la voce piu' grossa del "lavoro in background": ogni programma che
# parte all'accensione resta acceso per sempre, occupa RAM e ogni tanto si
# sveglia mentre giochi.
#
# Come si disattivano, e perche' cosi'. NON cancello le voci di avvio: uso lo
# stesso interruttore di Gestione attivita', cioe' la chiave StartupApproved.
# Windows ci tiene dodici byte per voce: il primo dice acceso (02) o spento
# (03), gli altri sono la data. Vantaggi veri: la voce originale resta intatta,
# Gestione attivita' mostra lo stesso stato che vedi qui, e se un domani
# disinstalli VejaTweak non resta niente di anomalo.
#
# Alcune voci non le offro proprio: antibarare, audio, driver video e
# sicurezza. Spegnerle non fa guadagnare frame e puo' impedirti di entrare in
# partita.
# ---------------------------------------------------------------------------
$script:VtAvvioProtetti = @(
    'vanguard', 'vgtray', 'vgc', 'easyanticheat', 'battleye', 'beservice', 'faceit',
    'riotclient', 'securitchealth', 'windows security', 'securityhealth', 'defender',
    'realtek', 'nahimic', 'sonic', 'waves', 'dolby', 'audio',
    'nvidia', 'amd', 'radeon', 'igfx', 'intel(r) graphics', 'hkcmd',
    'synaptics', 'elan', 'touchpad', 'wacom'
)

function Get-VtAvvioChiavi {
    @(
        @{ Scope='HKCU'; Run='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
           App='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' }
        @{ Scope='HKLM'; Run='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'
           App='HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' }
        @{ Scope='HKLM32'; Run='HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run'
           App='HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run32' }
    )
}

function Test-VtAvvioProtetto([string] $nome, [string] $comando) {
    $t = "$nome $comando".ToLower()
    foreach ($p in $script:VtAvvioProtetti) { if ($t -like "*$p*") { return $true } }
    return $false
}

function Get-VtAvvio {
    $out = @()
    foreach ($k in Get-VtAvvioChiavi) {
        if (-not (Test-Path $k.Run)) { continue }
        $prop = $null
        try { $prop = Get-ItemProperty -Path $k.Run -ErrorAction Stop } catch { continue }
        foreach ($p in $prop.PSObject.Properties) {
            if ($p.Name -like 'PS*') { continue }
            $cmd = "$($p.Value)"

            # Lo stato spento sta in StartupApproved: primo byte 03 (o 02 con
            # il bit basso a 1 nelle varianti che usa Windows).
            $acceso = $true
            try {
                $b = (Get-ItemProperty -Path $k.App -Name $p.Name -ErrorAction Stop).($p.Name)
                if ($b -is [byte[]] -and $b.Length -gt 0) { $acceso = (($b[0] -band 1) -eq 0) }
            } catch { }

            $out += [pscustomobject]@{
                Nome      = $p.Name
                Comando   = $cmd
                Scope     = $k.Scope
                Acceso    = $acceso
                Protetto  = (Test-VtAvvioProtetto $p.Name $cmd)
            }
        }
    }
    return $out
}

function Set-VtAvvio([string] $nome, [string] $scope, [bool] $acceso) {
    $k = Get-VtAvvioChiavi | Where-Object { $_.Scope -eq $scope } | Select-Object -First 1
    if (-not $k) { throw "Ambito '$scope' sconosciuto." }
    if (-not (Test-Path $k.App)) { New-Item -Path $k.App -Force | Out-Null }

    # 12 byte: stato + data di modifica. La data la mettiamo davvero, cosi'
    # Gestione attivita' non trova un valore che non sa interpretare.
    $b = New-Object byte[] 12
    $b[0] = if ($acceso) { 2 } else { 3 }
    $ticks = [BitConverter]::GetBytes([DateTime]::UtcNow.ToFileTimeUtc())
    [Array]::Copy($ticks, 0, $b, 4, 8)
    Set-ItemProperty -Path $k.App -Name $nome -Value $b -Type Binary -ErrorAction Stop
    Write-VtLog "Avvio automatico '$nome': $(if ($acceso) { 'riacceso' } else { 'spento' })" ok
}

# --- RSC: accorpamento dei pacchetti in arrivo -----------------------------
# Si legge e si scrive per scheda. IPv4 e IPv6 sono separati: vanno guardati
# tutti e due, altrimenti l'interruttore direbbe "spento" con meta' del
# traffico ancora accorpato.
# RSC si comanda in due posti, e non tutti e due esistono sempre.
#
# Su questo PC (Realtek) la scheda NON espone RSC: Get-NetAdapterRsc risponde
# "nessun oggetto trovato" e fra le proprieta' avanzate del driver non c'e'
# niente che assomigli. Esiste pero' l'interruttore globale di Windows, ed e'
# acceso. Se mi fossi fermato al comando per scheda, il tweak sarebbe
# comparso e non avrebbe mai funzionato.
#
# Quindi: comanda il globale, che c'e' sempre, e in piu' la singola scheda
# dove il driver la espone.
# Via CIM invece che con Get-NetOffloadGlobalSetting: stessa identica classe,
# 37 ms contro 600. Il cmdlet non fa altro che avvolgerla, ma per farlo carica
# tutto il modulo NetAdapter, e quel costo si pagava a ogni avvio dentro la
# costruzione del catalogo.
#
# Attenzione al valore: via CIM e' un numero (1 = acceso), col cmdlet e' la
# parola 'Enabled'. Sono la stessa cosa scritta in due modi.
function Get-VtRscGlobale {
    try {
        $g = Get-CimInstance -Namespace 'root\StandardCimv2' -ClassName MSFT_NetOffloadGlobalSetting -ErrorAction Stop |
             Select-Object -First 1
        if ($null -ne $g -and $null -ne $g.ReceiveSegmentCoalescing) {
            return ([int] $g.ReceiveSegmentCoalescing -eq 1)
        }
    } catch { }

    try { return ((Get-NetOffloadGlobalSetting -ErrorAction Stop).ReceiveSegmentCoalescing -eq 'Enabled') }
    catch { return $null }
}

function Get-VtRscStato {
    $out = @()
    foreach ($a in @(Get-VtNicAdapters)) {
        try {
            foreach ($r in (Get-NetAdapterRsc -Name $a.Name -ErrorAction Stop)) {
                $out += [pscustomobject]@{ Nome = $a.Name; V4 = [bool] $r.IPv4Enabled; V6 = [bool] $r.IPv6Enabled }
            }
        } catch { }
    }
    # Niente "return , $out": qui chi chiama avvolge in @(), e la virgola
    # trasformerebbe l'elenco vuoto in un elenco di un elemento vuoto. Era
    # esattamente il bug che faceva rispondere "RSC gia' spento" a un PC
    # dove RSC non era stato nemmeno letto.
    return $out
}

# Vero se RSC si puo' comandare in almeno uno dei due modi.
function Test-VtRscDisponibile {
    if ($null -ne (Get-VtRscGlobale)) { return $true }
    return (@(Get-VtRscStato).Count -gt 0)
}

function Test-VtRscOff {
    $g = Get-VtRscGlobale
    if ($null -ne $g -and $g) { return $false }
    foreach ($x in @(Get-VtRscStato)) { if ($x.V4 -or $x.V6) { return $false } }
    # Se non si legge ne' il globale ne' le schede non si puo' dire di si'.
    if ($null -eq $g -and @(Get-VtRscStato).Count -eq 0) { return $false }
    return $true
}

function Set-VtRsc([bool] $acceso) {
    $fatto = $false

    try {
        Set-NetOffloadGlobalSetting -ReceiveSegmentCoalescing $(if ($acceso) { 'Enabled' } else { 'Disabled' }) -ErrorAction Stop
        $fatto = $true
        Write-VtLog "RSC globale $(if ($acceso) { 'riattivato' } else { 'disattivato' })" ok
    } catch {
        Write-VtLog "RSC globale non modificabile: $($_.Exception.Message)" warn
    }

    $schede = 0
    foreach ($a in @(Get-VtNicAdapters)) {
        try {
            if ($acceso) { Enable-NetAdapterRsc  -Name $a.Name -IPv4 -IPv6 -ErrorAction Stop }
            else         { Disable-NetAdapterRsc -Name $a.Name -IPv4 -IPv6 -ErrorAction Stop }
            $schede++; $fatto = $true
        } catch {
            # Normale: molte schede non espongono RSC per conto proprio.
        }
    }
    if ($schede -gt 0) { Write-VtLog "RSC cambiato anche su $schede schede" ok }
    if (-not $fatto) { throw 'Su questo PC RSC non e'' comandabile: ne'' l''impostazione globale ne'' le schede lo espongono.' }
}

# ---------------------------------------------------------------------------
# MEMORIA: PROFILO IN BASE ALLA RAM INSTALLATA
#
# Non esiste "il" tweak della RAM: le scelte giuste con 8 GB sono sbagliate
# con 64 e viceversa. Qui la RAM si misura e si sceglie di conseguenza.
#
# File di paging. Windows lo gestisce da solo partendo piccolo e allargandolo
# quando serve, e l'allargamento e' una scrittura su disco che avviene mentre
# giochi: e' uno dei modi in cui nasce uno scatto isolato. Una dimensione
# fissa e adeguata toglie sia l'allargamento sia, su 8 GB, i crash per memoria
# esaurita che FiveM e Fortnite sanno dare.
#
# Compressione della memoria. Costa CPU ma evita di andare su disco. Con 8 o
# 16 GB conviene tenerla: senza, un server FiveM pieno ti manda in paging, che
# costa mille volte di piu'. Sopra i 32 GB non serve piu' e la CPU la si
# risparmia. Per questo la spengo solo da 32 GB in su, e non "sempre" come
# fanno molti tweak.
# ---------------------------------------------------------------------------
function Get-VtRamGb {
    try { return [math]::Round((Get-CimInstance Win32_PhysicalMemory | Measure-Object Capacity -Sum).Sum / 1GB) }
    catch { return [math]::Round((Get-CimInstance Win32_OperatingSystem).TotalVisibleMemorySize / 1MB) }
}

# Lo scaglione di appartenenza: 8, 16, 32 o 64.
function Get-VtRamScaglione {
    $g = Get-VtRamGb
    if ($g -le 10) { return 8 }
    if ($g -le 20) { return 16 }
    if ($g -le 40) { return 32 }
    return 64
}

function Get-VtRamProfilo {
    $s = Get-VtRamScaglione
    switch ($s) {
        8       { @{ Gb=8;  PfMin=8192; PfMax=12288; Comprimi=$true;  Nota='Con 8 GB il paging serve davvero: il file resta ampio e con margine di crescita.' } }
        16      { @{ Gb=16; PfMin=8192; PfMax=8192;  Comprimi=$true;  Nota='Con 16 GB il file di paging va fissato, non fatto crescere: la crescita e'' uno scatto. La compressione resta accesa perche'' un server FiveM pieno ti ci fa arrivare.' } }
        32      { @{ Gb=32; PfMin=4096; PfMax=8192;  Comprimi=$false; Nota='Con 32 GB la compressione non serve piu'' e la CPU se la risparmia.' } }
        default { @{ Gb=64; PfMin=4096; PfMax=4096;  Comprimi=$false; Nota='Con 64 GB il paging e'' quasi solo una formalita'' che Windows pretende: piccolo e fisso.' } }
    }
}

function Get-VtPagefileStato {
    $cs = Get-CimInstance Win32_ComputerSystem
    $pf = @(Get-CimInstance Win32_PageFileSetting -ErrorAction SilentlyContinue)
    [pscustomobject]@{
        Automatico = [bool] $cs.AutomaticManagedPagefile
        Min        = $(if ($pf.Count -gt 0) { [int] $pf[0].InitialSize } else { 0 })
        Max        = $(if ($pf.Count -gt 0) { [int] $pf[0].MaximumSize } else { 0 })
        Nome       = $(if ($pf.Count -gt 0) { $pf[0].Name } else { '' })
    }
}

function Get-VtCompressioneMemoria {
    # Get-MMAgent richiede privilegi: senza, restituisce niente invece di
    # mentire. Chi chiama deve saper gestire il $null.
    try { return [bool] (Get-MMAgent -ErrorAction Stop).MemoryCompression } catch { return $null }
}

function Test-VtRamProfilo {
    $p  = Get-VtRamProfilo
    $pf = Get-VtPagefileStato
    if ($pf.Automatico) { return $false }
    if ($pf.Min -ne $p.PfMin -or $pf.Max -ne $p.PfMax) { return $false }

    $mc = Get-VtCompressioneMemoria
    # Se non si riesce a leggere non si puo' dire che sia a posto.
    if ($null -eq $mc) { return $false }
    if ($mc -ne $p.Comprimi) { return $false }
    return $true
}

function Set-VtRamProfilo {
    if (-not (Test-VtAdmin)) { throw 'Servono i permessi di amministratore.' }
    $p  = Get-VtRamProfilo
    $pf = Get-VtPagefileStato
    $mc = Get-VtCompressioneMemoria

    # Il file di paging occupa sul serio lo spazio che gli assegni. Chiederne
    # 8 GB su un disco che ne ha 3 liberi vuol dire riempirlo e mettere il PC
    # in ginocchio: meglio rifiutarsi e dirlo, che riuscire e fare danni.
    try {
        $drv = Get-PSDrive ($env:SystemDrive.TrimEnd(':')) -ErrorAction Stop
        $liberiMb = [math]::Round($drv.Free / 1MB)
        $servono  = $p.PfMax - $pf.Max + 2048     # il margine e' per Windows
        if ($liberiMb -lt $servono) {
            throw ("Servono almeno {0} GB liberi su {1} e ce ne sono {2}. Libera spazio (c'e' la sezione Pulizia file) e riprova." -f `
                   [math]::Round($servono / 1024, 1), $env:SystemDrive, [math]::Round($liberiMb / 1024, 1))
        }
    } catch [System.Management.Automation.RuntimeException] { throw }
      catch { Write-VtLog "Spazio libero non verificabile: $($_.Exception.Message)" warn }

    Set-VtEntry 'ram-profilo' @{
        Automatico   = $pf.Automatico
        Min          = $pf.Min
        Max          = $pf.Max
        Compressione = $mc
    }

    # 1. il file di paging
    $cs = Get-CimInstance Win32_ComputerSystem
    if ($cs.AutomaticManagedPagefile) {
        Set-CimInstance -InputObject $cs -Property @{ AutomaticManagedPagefile = $false } -ErrorAction Stop | Out-Null
    }
    $sistema = "$($env:SystemDrive)\pagefile.sys"
    $ist = @(Get-CimInstance Win32_PageFileSetting -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "$($env:SystemDrive)*" })
    if ($ist.Count -gt 0) {
        Set-CimInstance -InputObject $ist[0] -Property @{ InitialSize = $p.PfMin; MaximumSize = $p.PfMax } -ErrorAction Stop | Out-Null
    } else {
        New-CimInstance -ClassName Win32_PageFileSetting -Property @{ Name = $sistema; InitialSize = $p.PfMin; MaximumSize = $p.PfMax } -ErrorAction Stop | Out-Null
    }

    # 2. la compressione della memoria
    try {
        if ($p.Comprimi) { Enable-MMAgent -MemoryCompression -ErrorAction Stop }
        else             { Disable-MMAgent -MemoryCompression -ErrorAction Stop }
    } catch {
        Write-VtLog "Compressione della memoria non modificata: $($_.Exception.Message)" warn
    }

    Write-VtLog "Profilo memoria per $($p.Gb) GB: paging $($p.PfMin)-$($p.PfMax) MB, compressione $(if ($p.Comprimi) { 'accesa' } else { 'spenta' })" ok
}

function Restore-VtRamProfilo {
    $e = Get-VtEntry 'ram-profilo'
    if (-not $e) { return }
    try {
        $cs = Get-CimInstance Win32_ComputerSystem
        if ($e.Automatico) {
            Set-CimInstance -InputObject $cs -Property @{ AutomaticManagedPagefile = $true } | Out-Null
        } else {
            $ist = @(Get-CimInstance Win32_PageFileSetting -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "$($env:SystemDrive)*" })
            if ($ist.Count -gt 0) {
                Set-CimInstance -InputObject $ist[0] -Property @{ InitialSize = [int] $e.Min; MaximumSize = [int] $e.Max } | Out-Null
            }
        }
    } catch { Write-VtLog "File di paging non ripristinato: $($_.Exception.Message)" warn }

    if ($null -ne $e.Compressione) {
        try {
            if ($e.Compressione) { Enable-MMAgent -MemoryCompression -ErrorAction Stop }
            else                 { Disable-MMAgent -MemoryCompression -ErrorAction Stop }
        } catch { }
    }
    Remove-VtEntry 'ram-profilo'
    Write-VtLog 'Profilo memoria riportato com''era' ok
}

function Get-VtFivemCfg {
    $p = Join-Path $env:APPDATA 'CitizenFX\fivem.cfg'
    [pscustomobject]@{ Path = $p; Esiste = (Test-Path -LiteralPath $p) }
}

# Legge i convar "seta" del file. Chiave -> valore, senza virgolette.
function Get-VtFivemConvar {
    $f = Get-VtFivemCfg
    $m = @{}
    if (-not $f.Esiste) { return $m }
    foreach ($l in (Get-Content -LiteralPath $f.Path)) {
        if ($l -match '^\s*sets?a?\s+"([^"]+)"\s+"([^"]*)"\s*$') { $m[$matches[1]] = $matches[2] }
    }
    return $m
}

# Riscrive solo le righe "seta" interessate.
#
# fivem.cfg contiene ottocento righe di "rbind" generate dalle risorse del
# server: ricostruire il file da capo le perderebbe tutte e le scorciatoie da
# tastiera sparirebbero. Per questo si sostituisce la singola riga, e i
# convar che non ci sono si aggiungono in fondo.
function Set-VtFivemConvar($voci) {
    $f = Get-VtFivemCfg
    if (-not $f.Esiste) { throw 'fivem.cfg non trovato. Avvia FiveM una volta e richiudilo.' }
    if (Test-VtFivemRunning) { throw 'FiveM e'' aperto. Chiudilo: alla chiusura riscrive il file e perderesti le modifiche.' }

    $righe = [System.Collections.Generic.List[string]] (Get-Content -LiteralPath $f.Path)
    $applicate = 0; $aggiunte = 0
    foreach ($v in $voci) {
        $rx = '^\s*sets?a?\s+"' + [regex]::Escape($v.Nome) + '"\s+"'
        $trovata = -1
        for ($i = 0; $i -lt $righe.Count; $i++) {
            if ($righe[$i] -match $rx) { $trovata = $i; break }
        }
        $riga = 'seta "{0}" "{1}"' -f $v.Nome, $v.Valore
        if ($trovata -ge 0) { $righe[$trovata] = $riga; $applicate++ }
        else                { $righe.Add($riga); $aggiunte++ }
    }
    [IO.File]::WriteAllLines($f.Path, $righe, (New-Object Text.UTF8Encoding $false))
    Write-VtLog "fivem.cfg: $applicate convar modificati, $aggiunte aggiunti" ok
    [pscustomobject]@{ Applicate = $applicate; Aggiunte = $aggiunte }
}

# I convar del movimento, con il valore giusto e il perche'.
function Get-VtFivemMovimento {
    @(
        @{ Nome='profile_mouseAcceleration';  Valore='0'
           Etichetta='Accelerazione del mouse'
           Perche='E'' la voce che rompe lo strafe piu'' di ogni altra: con l''accelerazione attiva lo stesso movimento del polso da'' un risultato diverso a seconda di quanto in fretta lo fai. Il colpo dopo il cambio di direzione non e'' ripetibile.' }
        @{ Nome='profile_fpsAimAcceleration'; Valore='0'
           Etichetta='Accelerazione della mira in prima persona'
           Perche='Stessa cosa ma mentre miri, ed e'' proprio il momento in cui conta. Sul tuo file era a 7 su 10.' }
        @{ Nome='profile_aimAcceleration';    Valore='0'
           Etichetta='Accelerazione della mira in terza persona'
           Perche='La stessa voce per la visuale in terza persona, che in molti server RP e'' quella che si usa.' }
        @{ Nome='profile_fpsHeadbob';         Valore='0'
           Etichetta='Oscillazione della testa'
           Perche='Mentre corri e cambi direzione la telecamera si muove da sola. Tu correggi con il mouse un movimento che non hai fatto: e'' rumore aggiunto proprio durante lo strafe.' }
        @{ Nome='profile_fpsAutoLevel';       Valore='0'
           Etichetta='Auto-livellamento della telecamera'
           Perche='La telecamera si rimette dritta da sola. Quando contro-strafi, ti rema contro.' }
        @{ Nome='profile_mouseAutocenterCar';   Valore='0'; Etichetta='Auto-centratura del mouse in auto'
           Perche='In veicolo la visuale viene tirata verso il centro da sola. A 10 su 10 e'' un tiro costante contro il tuo mouse.' }
        @{ Nome='profile_mouseAutocenterBike';  Valore='0'; Etichetta='Auto-centratura in moto';   Perche='Come sopra, per le moto.' }
        @{ Nome='profile_mouseAutocenterPlane'; Valore='0'; Etichetta='Auto-centratura in aereo';  Perche='Come sopra, per gli aerei.' }
        @{ Nome='profile_mouseWeightScale';   Valore='0'
           Etichetta='Peso (inerzia) del mouse'
           Perche='Aggiunge inerzia al movimento: la visuale continua un attimo dopo che hai smesso. Zero significa che si ferma quando ti fermi tu.' }
        @{ Nome='cam_disableCameraShake';     Valore='true'
           Etichetta='Scuotimento della telecamera'
           Perche='Esplosioni e urti scuotono l''inquadratura. Spento, la mira resta dove l''hai messa.' }
    )
}

function Test-VtFivemMovimento {
    $f = Get-VtFivemCfg
    if (-not $f.Esiste) { return $false }
    $m = Get-VtFivemConvar
    foreach ($v in Get-VtFivemMovimento) {
        if (-not $m.ContainsKey($v.Nome)) { return $false }
        if ($m[$v.Nome] -ne $v.Valore) { return $false }
    }
    return $true
}

function Set-VtFivemMovimento {
    $f = Get-VtFivemCfg
    if (-not $f.Esiste) { throw 'fivem.cfg non trovato. Avvia FiveM una volta e richiudilo.' }
    $voci = Get-VtFivemMovimento

    # Il valore di prima va salvato PRIMA di scrivere, altrimenti spegnere
    # l'interruttore vorrebbe dire indovinare.
    $m = Get-VtFivemConvar
    $prima = @()
    foreach ($v in $voci) {
        $prima += @{ Nome = $v.Nome; Valore = $(if ($m.ContainsKey($v.Nome)) { $m[$v.Nome] } else { $null }) }
    }

    Backup-VtGameFile $f.Path | Out-Null
    Set-VtFivemConvar $voci | Out-Null
    if (-not (Test-VtFivemMovimento)) { throw 'Scritto, ma rileggendo il file i valori non tornano.' }
    Set-VtEntry 'fivem-movimento' @{ Convar = $prima }
    Write-VtLog "FiveM: movimento e strafe ottimizzati ($($voci.Count) voci)" ok
}

function Restore-VtFivemMovimento {
    $e = Get-VtEntry 'fivem-movimento'
    if (-not $e) { return }
    $da = @()
    foreach ($b in @($e.Convar)) {
        # Un convar che prima non c'era lo riporto al valore di fabbrica del
        # gioco invece di lasciarlo a zero: cancellare la riga non basta,
        # FiveM la riscriverebbe con quello che ha in memoria.
        if ($null -eq $b.Valore) { continue }
        $da += @{ Nome = $b.Nome; Valore = $b.Valore }
    }
    if ($da.Count -gt 0) { Set-VtFivemConvar $da | Out-Null }
    Remove-VtEntry 'fivem-movimento'
    Write-VtLog 'FiveM: movimento riportato ai valori di prima' ok
}

# ---------------------------------------------------------------------------
# RAINBOW SIX SIEGE
#
# Il file sta in Documenti\My Games\Rainbow Six - Siege\<id Ubisoft>\
# GameSettings.ini. Su questo PC il gioco non e' installato, quindi le chiavi
# non le ho potute verificare di persona: per questo il preset gira in
# modalita' "solo chiavi esistenti" e ti dice quante ne ha saltate.
# La scelta fra Vulkan e DX11 NON sta qui: si fa da Ubisoft Connect al lancio.
# ---------------------------------------------------------------------------
function Get-VtR6Settings {
    $base = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Rainbow Six - Siege'
    $res = [pscustomobject]@{ Path = $null; Esiste = $false; Base = $base }
    if (-not (Test-Path $base)) { return $res }
    $f = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue |
         ForEach-Object { Join-Path $_.FullName 'GameSettings.ini' } |
         Where-Object { Test-Path $_ } |
         Sort-Object { (Get-Item $_).LastWriteTime } -Descending | Select-Object -First 1
    if ($f) { $res.Path = $f; $res.Esiste = $true }
    return $res
}

function Test-VtR6Running {
    [bool] (Get-Process -Name 'RainbowSix', 'RainbowSix_Vulkan' -ErrorAction SilentlyContinue)
}

function Get-VtR6Stato {
    $r = Get-VtR6Settings
    if (-not $r.Esiste) { return $null }
    $m = @{}
    foreach ($l in (Get-Content -LiteralPath $r.Path)) {
        if ($l -match '^\s*(\w+)\s*=\s*(.*)$') { $m[$matches[1]] = $matches[2].Trim() }
    }
    [pscustomobject]@{
        Risoluzione = "$($m['Width']) x $($m['Height'])"
        SchermoIntero = $m['Fullscreen']
        VSync       = $m['VSync']
        Refresh     = $m['RefreshRate']
        Chiavi      = $m.Keys.Count
        InEsecuzione= (Test-VtR6Running)
    }
}

function Invoke-VtR6Preset {
    $r = Get-VtR6Settings
    if (-not $r.Esiste) { throw 'GameSettings.ini di Rainbow Six non trovato. Avvia il gioco una volta e richiudilo.' }
    if (Test-VtR6Running) { throw 'Rainbow Six e'' aperto. Chiudilo prima.' }

    Backup-VtGameFile $r.Path | Out-Null
    $hz = Get-VtMonitorHz
    $res = Set-VtIniValues $r.Path @(
        @{ Sez='DISPLAY';  Chiave='VSync';               Valore='0' }
        @{ Sez='DISPLAY';  Chiave='Fullscreen';          Valore='1' }
        @{ Sez='DISPLAY';  Chiave='RefreshRate';         Valore=$hz }
        @{ Sez='GRAPHICS'; Chiave='ShadowQuality';       Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='ShadowMapQuality';    Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='ReflectionQuality';   Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='AmbientOcclusion';    Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='LensEffects';         Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='LensFlares';          Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='ZoomInDepthOfField';  Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='MotionBlur';          Valore='0' }
        @{ Sez='GRAPHICS'; Chiave='AntiAliasingPostQuality'; Valore='1' }
        @{ Sez='GRAPHICS'; Chiave='RenderScaling';       Valore='100' }
        @{ Sez='GRAPHICS'; Chiave='TextureFilterQuality'; Valore='1' }
    ) -SoloEsistenti
    Write-VtLog "Preset R6 applicato: $($res.Applicate) impostazioni, $($res.Saltate.Count) saltate" ok
    return $res
}

function Restore-VtR6 {
    $r = Get-VtR6Settings
    if (-not $r.Esiste) { throw 'GameSettings.ini di Rainbow Six non trovato.' }
    Restore-VtGameFile $r.Path
}

# ---------------------------------------------------------------------------
# BIOS / UEFI
#
# Chiariamo subito il limite, perche' e' la richiesta piu' comune e la risposta
# onesta e' no: nessun programma in esecuzione su Windows puo' cambiare le
# impostazioni del BIOS. Vivono nella NVRAM del firmware, che il sistema
# operativo non puo' scrivere: non e' una protezione aggirabile, e' proprio
# l'assenza di un'interfaccia. Le utility dei produttori che sembrano farlo
# usano un driver in kernel mode firmato dal produttore stesso, ed e'
# esattamente il tipo di driver che gli anticheat segnalano.
#
# Quello che possiamo fare, e che facciamo qui:
#   - riconoscere dal sistema quali impostazioni del BIOS sono sbagliate
#   - riavviare direttamente nella schermata del firmware con un clic
#   - dire dove stanno le voci sulla marca di scheda madre giusta
#   - alla riapertura, verificare se la modifica ha fatto effetto
# ---------------------------------------------------------------------------
function Get-VtFirmware {
    if ($script:VtFw) { return $script:VtFw }
    $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
    $bi = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue

    $sb = $null
    try { $sb = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -Name UEFISecureBootEnabled -ErrorAction Stop).UEFISecureBootEnabled } catch { }

    $script:VtFw = [pscustomobject]@{
        Produttore = if ($bb) { $bb.Manufacturer } else { 'sconosciuto' }
        Scheda     = if ($bb) { $bb.Product } else { 'sconosciuta' }
        Sistema    = if ($cs) { "$($cs.Manufacturer) $($cs.Model)".Trim() } else { '' }
        Versione   = if ($bi) { $bi.SMBIOSBIOSVersion } else { '?' }
        Data       = if ($bi -and $bi.ReleaseDate) { $bi.ReleaseDate } else { $null }
        Uefi       = ($env:firmware_type -eq 'UEFI')
        SecureBoot = $sb
    }
    return $script:VtFw
}

# Il tasto per entrare nel BIOS e i nomi dei menu cambiano da marca a marca.
# Mandare qualcuno a cercare "XMP" su una scheda dove si chiama "EXPO" o
# "DOCP" e' il modo migliore per fargli pensare che l'opzione non esista.
function Get-VtBiosGuida {
    $fw = Get-VtFirmware
    $m  = "$($fw.Produttore) $($fw.Sistema)"

    if ($m -match 'ASUS|ASUSTeK') {
        return @{ Tasto='CANC (o F2)'; Note='Premi F7 per passare alla Modalita'' Avanzata, altrimenti meta'' delle voci non si vedono.'
                  Xmp='Ai Tweaker > Ai Overclock Tuner > XMP I / DOCP / EXPO'
                  Ht='Advanced > CPU Configuration > Intel (VMX) / Hyper-Threading' }
    }
    if ($m -match 'MSI|Micro-Star') {
        return @{ Tasto='CANC'; Note='Premi F7 per la Modalita'' Avanzata.'
                  Xmp='OC > Extreme Memory Profile (XMP) / EXPO'
                  Ht='OC > CPU Features > Intel Hyper-Threading Technology' }
    }
    if ($m -match 'Gigabyte|AORUS') {
        return @{ Tasto='CANC'; Note='Premi F2 per passare da Easy Mode ad Advanced Mode.'
                  Xmp='Tweaker > Extreme Memory Profile (X.M.P.) / EXPO'
                  Ht='Tweaker > Advanced CPU Settings > Hyper-Threading Technology' }
    }
    if ($m -match 'ASRock') {
        return @{ Tasto='F2 (o CANC)'; Note=''
                  Xmp='OC Tweaker > DRAM Profile Configuration > XMP / EXPO'
                  Ht='Advanced > CPU Configuration > Hyper Threading' }
    }
    if ($m -match '^HP|Hewlett') {
        return @{ Tasto='F10 subito dopo l''accensione (se non prende, prima ESC poi F10)'
                  Note='ATTENZIONE: i BIOS dei PC preassemblati HP sono volutamente ridotti. Su molti modelli consumer le voci per XMP e Hyper-Threading NON esistono proprio. Se dopo aver guardato non le trovi, non le stai cercando male: non ci sono.'
                  Xmp='Se presente: Advanced > Memory Settings (spesso assente sui modelli consumer)'
                  Ht='Se presente: Advanced > System Options > Hyper-Threading / Intel HT Technology' }
    }
    if ($m -match 'Dell|Alienware') {
        return @{ Tasto='F2'; Note='Sui Dell preassemblati molte voci sono bloccate.'
                  Xmp='Memory Settings > XMP (spesso assente)'
                  Ht='Performance > Hyper-Threading Control' }
    }
    if ($m -match 'Lenovo') {
        return @{ Tasto='F1 (o F2)'; Note='Sui Lenovo preassemblati molte voci sono bloccate.'
                  Xmp='Spesso assente sui modelli consumer'
                  Ht='Devices / Advanced > CPU Setup > Intel Hyper-Threading' }
    }
    if ($m -match 'Acer|Predator') {
        return @{ Tasto='F2'; Note='Su alcuni Acer le voci avanzate compaiono solo dopo aver impostato una password supervisore.'
                  Xmp='Advanced > Memory Configuration'
                  Ht='Advanced > CPU Configuration > Hyper-Threading' }
    }
    return @{ Tasto='CANC o F2 subito dopo l''accensione'; Note=''
              Xmp='Cerca XMP (Intel), EXPO o DOCP (AMD) nel menu della memoria o dell''overclock'
              Ht='Cerca Hyper-Threading, Intel HT Technology o SMT nel menu della CPU' }
}

# Problemi che si vedono da Windows ma si risolvono solo nel firmware.
function Get-VtBiosFindings {
    $out = @()
    $sys = Get-VtSystem
    $g   = Get-VtBiosGuida

    if ($sys.Thread -eq $sys.Core -and $sys.Cpu -match 'Core.*i[579]|Ryzen [579]|Core.*Ultra') {
        $out += [pscustomobject]@{
            Peso = 1; Stato = 'DA SISTEMARE'
            Titolo = 'Hyper-Threading / SMT disattivato'
            Testo  = "Windows vede $($sys.Core) core e $($sys.Thread) thread: su questa CPU dovrebbero essere di piu'. Ho gia' controllato che non sia un limite imposto da Windows (nessun numproc nel BCD), quindi e' spento nel firmware.`n`nDove guardare: $($g.Ht)`n`nVale 10-20% di FPS su FiveM, Fortnite e R6, e molto di piu' sui minimi." }
    }

    try {
        $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $conf = ($mods | Measure-Object ConfiguredClockSpeed -Maximum).Maximum
        $max  = ($mods | Measure-Object Speed -Maximum).Maximum
        if ($conf -and $max -and $conf -lt ($max - 100)) {
            $out += [pscustomobject]@{
                Peso = 1; Stato = 'DA SISTEMARE'
                Titolo = 'Profilo XMP / EXPO non attivo'
                Testo  = "La RAM gira a $conf MT/s invece dei $max che i moduli dichiarano.`n`nDove guardare: $($g.Xmp)`n`nNon e' overclock del processore: e' il profilo che i moduli si portano dietro di fabbrica. Sui giochi CPU-bound vale 10-25%." }
        } elseif ($conf) {
            $out += [pscustomobject]@{
                Peso = 3; Stato = 'A POSTO'
                Titolo = 'Frequenza RAM corretta'
                Testo  = "La RAM gira a $conf MT/s, cioe' la frequenza dichiarata dai moduli. Niente da fare qui." }
        }
    } catch { }

    $fw = Get-VtFirmware
    if ($fw.SecureBoot -eq 1) {
        $out += [pscustomobject]@{
            Peso = 3; Stato = 'A POSTO'
            Titolo = 'Secure Boot attivo'
            Testo  = "Serve a Valorant su Windows 11: senza, Vanguard non fa partire il gioco. E' gia' attivo, non toccarlo." }
    } elseif ($null -ne $fw.SecureBoot) {
        $out += [pscustomobject]@{
            Peso = 2; Stato = 'DA SISTEMARE'
            Titolo = 'Secure Boot disattivato'
            Testo  = "Su Windows 11, Valorant richiede Secure Boot e TPM 2.0 attivi o Vanguard blocca l'avvio. Cerca 'Secure Boot' nel menu Boot o Security del BIOS.`n`nAttenzione: se hai installato Windows in modalita' Legacy/CSM, accendere Secure Boot puo' impedire l'avvio. In quel caso serve prima convertire il disco con mbr2gpt." }
    }

    # Resizable BAR non e' interrogabile in modo affidabile da Windows: meglio
    # dire dove si guarda che inventarsi un rilevamento che sbaglia.
    $out += [pscustomobject]@{
        Peso = 2; Stato = 'DA VERIFICARE'
        Titolo = 'Resizable BAR'
        Testo  = "Non e' leggibile da Windows in modo affidabile, quindi controllalo tu: Pannello NVIDIA > Guida > Informazioni sistema, voce 'Resizable BAR'. Su AMD e' in Adrenalin > Prestazioni.`n`nSe risulta No, nel BIOS servono DUE voci accese insieme: 'Above 4G Decoding' e 'Re-Size BAR Support'. Vale qualche punto percentuale, a volte di piu' su GPU recenti." }

    $out | Sort-Object Peso
}

function Test-VtCanRebootToFirmware {
    (Get-VtFirmware).Uefi
}

# shutdown /r /fw chiede al firmware di fermarsi nella schermata di setup al
# prossimo avvio. Funziona solo su UEFI e richiede privilegi elevati.
function Invoke-VtRebootToFirmware {
    if (-not (Test-VtAdmin)) { throw 'Servono privilegi di amministratore.' }
    if (-not (Test-VtCanRebootToFirmware)) { throw 'Questo PC non e'' avviato in modalita'' UEFI.' }
    Write-VtLog 'Riavvio nella schermata del firmware richiesto dall''utente' ok
    Invoke-VtCmd 'shutdown /r /fw /t 3' | Out-Null
}

# ---------------------------------------------------------------------------
# MISURA DELLA STABILITA'
#
# Gli FPS medi non dicono niente sugli scatti. Quello che si vede come
# micro-stutter e' quasi sempre tempo rubato dal kernel ai thread del gioco:
# DPC (lavoro differito dei driver) e ISR (interrupt hardware). Se un driver
# tiene la CPU in DPC per troppo tempo, il frame successivo arriva tardi e tu
# lo vedi, anche con 300 FPS di media.
#
# Non serve installare niente: i contatori stanno in WMI, e i nomi delle
# proprieta' WMI non sono tradotti (a differenza dei contatori di prestazione
# classici, che su questo PC in italiano non rispondono ai nomi inglesi).
# ---------------------------------------------------------------------------
function Get-VtStabilitySample {
    $x = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -ErrorAction Stop
    [pscustomobject]@{
        Dpc      = [double] $x.PercentDPCTime
        Isr      = [double] $x.PercentInterruptTime
        DpcSec   = [double] $x.DPCsQueuedPersec
        IntSec   = [double] $x.InterruptsPersec
        Cpu      = [double] $x.PercentProcessorTime
    }
}

# Trasforma una serie di campioni in un giudizio leggibile.
function Get-VtStabilityVerdetto($campioni) {
    if (-not $campioni -or $campioni.Count -eq 0) { return $null }

    $dpcMed = ($campioni | Measure-Object Dpc -Average).Average
    $dpcMax = ($campioni | Measure-Object Dpc -Maximum).Maximum
    $isrMed = ($campioni | Measure-Object Isr -Average).Average
    $intMed = ($campioni | Measure-Object IntSec -Average).Average
    $intMax = ($campioni | Measure-Object IntSec -Maximum).Maximum
    $picco  = if ($intMed -gt 0) { $intMax / $intMed } else { 1 }

    $problemi = @()
    if ($dpcMed -ge 5)      { $problemi += "Tempo in DPC alto ($([math]::Round($dpcMed,1))% di media): c'e' un driver che tiene occupata la CPU. E' la causa numero uno dei micro-scatti." }
    elseif ($dpcMed -ge 2)  { $problemi += "Tempo in DPC un po' alto ($([math]::Round($dpcMed,1))% di media): sopportabile, ma sotto carico puo' peggiorare." }
    if ($dpcMax -ge 10)     { $problemi += "Picco di DPC al $([math]::Round($dpcMax,1))%: qualcosa ogni tanto blocca la CPU per un tempo lungo. Sono gli scatti isolati che senti ogni pochi secondi." }
    if ($isrMed -ge 4)      { $problemi += "Tempo in interrupt alto ($([math]::Round($isrMed,1))%): spesso e' un dispositivo USB, una scheda di rete o un driver audio." }
    if ($picco -ge 3)       { $problemi += "Gli interrupt vanno a ondate (picco $([math]::Round($picco,1))x sulla media): qualcosa si sveglia a intervalli. Tipico di software di periferiche RGB, overlay e programmi di aggiornamento." }

    $stato = if ($problemi.Count -eq 0) { 'BUONO' } elseif ($dpcMed -ge 5 -or $dpcMax -ge 10) { 'DA SISTEMARE' } else { 'ACCETTABILE' }

    [pscustomobject]@{
        Stato    = $stato
        DpcMedio = [math]::Round($dpcMed, 1)
        DpcMax   = [math]::Round($dpcMax, 1)
        IsrMedio = [math]::Round($isrMed, 1)
        IntMedio = [math]::Round($intMed)
        IntMax   = [math]::Round($intMax)
        Picco    = [math]::Round($picco, 1)
        Campioni = $campioni.Count
        Problemi = $problemi
    }
}

# Gli interrupt "message signaled" non richiedono di bloccare una linea
# condivisa: su GPU e controller di archiviazione riducono la latenza DPC.
# Non lo cambiamo: sulle schede moderne e' gia' attivo, e forzarlo su un
# dispositivo che non lo supporta puo' impedire l'avvio del PC. Lo leggiamo
# e basta.
function Get-VtMsiStato {
    # Duecentocinquanta millisecondi di Win32_PnPEntity: in cache, si svuota
    # con le altre letture di diagnosi.
    if ($null -ne $script:VtMsiC) { return $script:VtMsiC }
    $out = @()
    try {
        $dev = Get-CimInstance Win32_PnPEntity -ErrorAction Stop |
               Where-Object { $_.PNPClass -in 'Display', 'Net', 'SCSIAdapter' -and $_.PNPDeviceID -like 'PCI*' }
        foreach ($d in $dev) {
            $p = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($d.PNPDeviceID)\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties"
            $v = Get-VtReg $p 'MSISupported'
            $out += [pscustomobject]@{
                Nome  = $d.Name
                Tipo  = $d.PNPClass
                Msi   = ($v -eq 1)
                Noto  = ($null -ne $v)
            }
        }
    } catch { }
    $script:VtMsiC = @($out)
    return $script:VtMsiC
}

# Programmi noti per generare interrupt a ondate mentre giochi.
function Get-VtDisturbatori {
    $noti = @(
        @{ P='iCUE';            N='Corsair iCUE';        Nota='polling continuo su tutte le periferiche RGB' }
        @{ P='RazerSynapse';    N='Razer Synapse';       Nota='hook globale sull''input, noto per micro-stutter' }
        @{ P='ArmouryCrate';    N='Armoury Crate';       Nota='monitoraggio hardware a intervalli fissi' }
        @{ P='ArmourySocketServer'; N='Armoury Crate (servizio)'; Nota='monitoraggio hardware a intervalli fissi' }
        @{ P='LogiOverlay';     N='Logitech G Overlay';  Nota='overlay agganciato al render' }
        @{ P='lghub_agent';     N='Logitech G HUB';      Nota='polling periferiche' }
        @{ P='MSIAfterburner';  N='MSI Afterburner';     Nota='campionamento hardware: con intervallo basso genera DPC' }
        @{ P='RTSS';            N='RivaTuner Statistics';Nota='si aggancia alla presentazione dei frame' }
        @{ P='OpenRGB';         N='OpenRGB';             Nota='polling continuo dei controller RGB' }
        @{ P='SignalRgb';       N='SignalRGB';           Nota='polling continuo dei controller RGB' }
        @{ P='NZXT CAM';        N='NZXT CAM';            Nota='monitoraggio hardware aggressivo' }
        @{ P='HWiNFO64';        N='HWiNFO';              Nota='con polling dei sensori basso genera DPC' }
        @{ P='Discord';         N='Discord (overlay)';   Nota='l''overlay in-game si aggancia al render' }
    )
    $attivi = @(Get-Process -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName -Unique)
    @($noti | Where-Object { $attivi -contains $_.P })
}

# ---------------------------------------------------------------------------
# RISOLUZIONI PERSONALIZZATE
#
# Le stretched non sono tutte uguali: 1440x1080 e' la piu' usata, ma c'e' chi
# gioca a 1280x960, chi a 1680x1050. Invece di indovinare un elenco, qui si
# puo' scrivere qualsiasi coppia di numeri.
#
# Il controllo dei valori sta in un posto solo, cosi' vale identico per tutti
# i giochi e non c'e' modo che uno accetti un numero che un altro rifiuta.
# ---------------------------------------------------------------------------
function Test-VtRisoluzione([string] $larghezza, [string] $altezza) {
    $r = [pscustomobject]@{ Valida=$false; X=0; Y=0; Motivo=''; Avviso=''; Disponibile=$true; Hz=0 }

    if ($larghezza -notmatch '^\s*\d+\s*$' -or $altezza -notmatch '^\s*\d+\s*$') {
        $r.Motivo = 'Larghezza e altezza devono essere numeri interi, senza lettere ne'' simboli.'
        return $r
    }
    $x = [int] $larghezza.Trim(); $y = [int] $altezza.Trim()

    # Limiti larghi ma sensati: sotto sono valori che nessun monitor accetta,
    # sopra si va oltre l'8K e quasi certamente e' un errore di battitura.
    if ($x -lt 640 -or $x -gt 7680) { $r.Motivo = "Larghezza fuori scala: $x. Valori ammessi da 640 a 7680."; return $r }
    if ($y -lt 480 -or $y -gt 4320) { $r.Motivo = "Altezza fuori scala: $y. Valori ammessi da 480 a 4320."; return $r }

    # Gli avvisi si sommano: prima li assegnavo uno sopra l'altro e il
    # secondo cancellava il primo, cosi' chi scriveva 1921x1081 su uno
    # schermo 1080p vedeva solo meta' del problema.
    $avvisi = @()

    # I motori grafici lavorano per blocchi: una larghezza dispari puo' dare
    # una riga di pixel sporca sul bordo.
    if ($x % 2 -ne 0 -or $y % 2 -ne 0) {
        $avvisi += 'Numeri dispari: alcuni giochi arrotondano da soli e potresti vedere un bordo sporco. Meglio usare valori pari.'
    }

    $mon = $null
    try {
        $v = Get-CimInstance Win32_VideoController | Where-Object { $_.CurrentHorizontalResolution -gt 0 } | Select-Object -First 1
        if ($v) { $mon = [pscustomobject]@{ X = $v.CurrentHorizontalResolution; Y = $v.CurrentVerticalResolution } }
    } catch { }
    if ($mon -and ($x -gt $mon.X -or $y -gt $mon.Y)) {
        $avvisi += "Stai chiedendo $x" + 'x' + "$y su uno schermo da $($mon.X)x$($mon.Y): il gioco dovra' rimpicciolire l'immagine, e di solito si vede peggio invece che meglio."
    }

    # Il controllo che mancava, ed e' quello che conta di piu'.
    #
    # Per andare in schermo intero ESCLUSIVO il gioco deve chiedere alla
    # scheda video una modalita' che esiste. Se non esiste, non fallisce con
    # un errore: ripiega sulla nativa e riscrive il proprio file di
    # configurazione. Da fuori sembra che la risoluzione "non si salvi", e
    # nel file restano meta' valori nuovi e meta' vecchi.
    #
    # Non blocco, perche' in finestra senza bordi una misura qualsiasi si usa
    # lo stesso: ma va detto prima, non scoperto dopo.
    $r.Disponibile = Test-VtRisoluzioneDisponibile $x $y
    if (-not $r.Disponibile) {
        $avvisi += "ATTENZIONE: ${x}x${y} non esiste fra le modalita' del tuo schermo. In schermo intero esclusivo il gioco non ci puo' andare: ripieghera' sulla nativa e riscrivera' il file, e ti sembrera' che la risoluzione non si salvi. Per usarla davvero va prima creata una volta sola in Pannello NVIDIA > Cambia risoluzione > Personalizza (su AMD: Adrenalin > Display > Risoluzioni personalizzate)."
    } else {
        $r.Hz = Get-VtHzMassimo $x $y
    }

    $r.Avviso = $avvisi -join ' '

    $r.Valida = $true; $r.X = $x; $r.Y = $y
    return $r
}

# Descrive il formato, utile per capire al volo se e' una stretched.
function Get-VtFormato([int] $x, [int] $y) {
    if ($y -eq 0) { return '?' }
    $mcd = { param($a, $b) while ($b -ne 0) { $t = $b; $b = $a % $b; $a = $t } $a }
    $d = & $mcd $x $y
    $rx = $x / $d; $ry = $y / $d
    # I rapporti vanno riconosciuti nella forma RIDOTTA: 1680x1050 si riduce
    # a 8:5, non a 16:10, e prima usciva scritto "8:5" che non dice niente.
    $nome = switch ("$rx`:$ry") {
        '16:9' { '16:9 (nativo panoramico)' }
        '4:3'  { '4:3 (stretched classico)' }
        '8:5'  { '16:10' }
        '5:4'  { '5:4 (stretched stretto)' }
        '3:2'  { '3:2' }
        '21:9' { '21:9 (ultrapanoramico)' }
        '64:27'{ '21:9 (ultrapanoramico)' }
        default { "$rx`:$ry" }
    }
    return $nome
}

function Set-VtValorantRisoluzione([int] $x, [int] $y) {
    $p = Get-VtValorantPaths
    if (-not $p.Esiste) { throw 'Configurazione di Valorant non trovata.' }
    if (Test-VtValorantRunning) { throw 'Valorant o il Riot Client sono aperti. Chiudili prima.' }
    $S = '/Script/ShooterGame.ShooterGameUserSettings'
    foreach ($g in $p.Gus) {
        Backup-VtGameFile $g | Out-Null
        Set-VtIniValues $g @(
            @{ Sez=$S; Chiave='ResolutionSizeX';                  Valore=$x }
            @{ Sez=$S; Chiave='ResolutionSizeY';                  Valore=$y }
            @{ Sez=$S; Chiave='LastUserConfirmedResolutionSizeX'; Valore=$x }
            @{ Sez=$S; Chiave='LastUserConfirmedResolutionSizeY'; Valore=$y }
            @{ Sez=$S; Chiave='PreferredFullscreenMode';          Valore='0' }
            @{ Sez=$S; Chiave='LastConfirmedFullscreenMode';      Valore='0' }
            # Con le stretched il letterbox aggiunge bande nere invece di
            # allargare l'immagine: e' esattamente cio' che non si vuole.
            @{ Sez=$S; Chiave='bShouldLetterbox';                 Valore='False' }
            @{ Sez=$S; Chiave='bLastConfirmedShouldLetterbox';    Valore='False' }
        ) -SoloEsistenti | Out-Null
    }
    Write-VtLog "Risoluzione di Valorant impostata a ${x}x${y}" ok
}

function Set-VtFivemRisoluzione([int] $x, [int] $y) {
    $f = Get-VtFivemSettings
    if (-not $f.Esiste) { throw 'gta5_settings.xml non trovato.' }
    if (Test-VtFivemRunning) { throw 'FiveM e'' aperto. Chiudilo prima.' }
    Backup-VtGameFile $f.Path | Out-Null

    $hz = Get-VtHzMassimo $x $y
    $voci = @(
        @{ Tag='ScreenWidth';  Valore=$x }
        @{ Tag='ScreenHeight'; Valore=$y }
        @{ Tag='Windowed';     Valore='0' }
    )
    # La frequenza va allineata a quella che ESISTE per quella risoluzione:
    # chiedere un modo che non c'e' (per esempio 200 Hz a una risoluzione che
    # arriva a 144) e' un altro modo per finire in finestra.
    if ($hz -gt 0) { $voci += @{ Tag='RefreshRate'; Valore=$hz } }
    $r = Set-VtXmlValues $f.Path $voci

    # FiveM tiene una SECONDA copia delle impostazioni video come convar in
    # fivem.cfg, e all'avvio guarda quelle. Se le due copie non dicono la
    # stessa cosa sul tipo di schermo, vince il convar: percio' si scrive
    # anche li' "schermo intero".
    $convar = 0
    if ((Get-VtFivemCfg).Esiste) {
        try {
            Set-VtFivemConvar @(@{ Nome='profile_vidScreenType'; Valore='0' }) | Out-Null
            $convar = 1
        } catch { Write-VtLog "fivem.cfg non aggiornato: $($_.Exception.Message)" warn }
    }

    $ok = Test-VtRisoluzioneDisponibile $x $y
    Write-VtLog "Risoluzione di FiveM impostata a ${x}x${y}$(if ($hz -gt 0) { " a $hz Hz" })$(if (-not $ok) { ' - ATTENZIONE: modalita'' non disponibile' })" $(if ($ok) { 'ok' } else { 'warn' })
    [pscustomobject]@{ Applicate = $r.Applicate; Saltate = $r.Saltate; Convar = $convar; Disponibile = $ok; Hz = $hz }
}

function Set-VtR6Risoluzione([int] $x, [int] $y) {
    $r6 = Get-VtR6Settings
    if (-not $r6.Esiste) { throw 'GameSettings.ini di Rainbow Six non trovato.' }
    if (Test-VtR6Running) { throw 'Rainbow Six e'' aperto. Chiudilo prima.' }
    Backup-VtGameFile $r6.Path | Out-Null
    $res = Set-VtIniValues $r6.Path @(
        @{ Sez='DISPLAY'; Chiave='Width';      Valore=$x }
        @{ Sez='DISPLAY'; Chiave='Height';     Valore=$y }
        @{ Sez='DISPLAY'; Chiave='Fullscreen'; Valore='1' }
    ) -SoloEsistenti
    Write-VtLog "Risoluzione di R6 impostata a ${x}x${y} ($($res.Applicate) chiavi)" ok
    return $res
}

# ---------------------------------------------------------------------------
# DISCORD
#
# Discord e' un browser Chromium travestito: sul PC in prova gira con sei
# processi e 1,8 GB di RAM, di cui 367 MB nel solo processo che disegna con
# la scheda video. Quel processo compete con il gioco per la GPU, ed e'
# l'unica cosa di Discord che si possa spegnere da fuori.
#
# Il bello e' che l'effetto si VEDE: se l'accelerazione hardware e' spenta,
# alla riapertura il processo "gpu-process" non c'e' piu'. Quindi il tweak si
# puo' verificare invece di doverci credere.
# ---------------------------------------------------------------------------
function Get-VtDiscordSettings {
    foreach ($n in 'discord', 'discordptb', 'discordcanary') {
        $p = Join-Path $env:APPDATA "$n\settings.json"
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Test-VtDiscordRunning {
    [bool] (Get-Process -Name 'Discord', 'DiscordPTB', 'DiscordCanary' -ErrorAction SilentlyContinue)
}

function Get-VtDiscordStato {
    $s = Get-VtDiscordSettings
    if (-not $s) { return $null }

    $proc = @(Get-Process -Name 'Discord', 'DiscordPTB', 'DiscordCanary' -ErrorAction SilentlyContinue)
    $gpu = @()
    try {
        $gpu = @(Get-CimInstance Win32_Process -Filter "Name='Discord.exe'" -ErrorAction SilentlyContinue |
                 Where-Object { $_.CommandLine -match '--type=gpu-process' })
    } catch { }

    $accel = $null
    try {
        $j = Get-Content -LiteralPath $s -Raw | ConvertFrom-Json
        if ($null -ne $j.enableHardwareAcceleration) { $accel = [bool] $j.enableHardwareAcceleration }
    } catch { }

    $cacheMb = 0
    foreach ($c in 'Cache', 'Code Cache', 'GPUCache', 'DawnGraphiteCache', 'DawnWebGPUCache') {
        $p = Join-Path (Split-Path $s -Parent) $c
        if (Test-Path -LiteralPath $p) {
            $m = Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum
            $cacheMb += $m.Sum / 1MB
        }
    }

    [pscustomobject]@{
        File         = $s
        Processi     = $proc.Count
        RamMb        = if ($proc) { [math]::Round((($proc | Measure-Object WorkingSet64 -Sum).Sum) / 1MB) } else { 0 }
        ProcessoGpu  = ($gpu.Count -gt 0)
        GpuMb        = if ($gpu.Count -gt 0) { [math]::Round((Get-Process -Id $gpu[0].ProcessId -ErrorAction SilentlyContinue).WorkingSet64 / 1MB) } else { 0 }
        Accelerazione= $accel      # $null = mai impostata, quindi accesa di default
        CacheMb      = [math]::Round($cacheMb, 1)
        InEsecuzione = ($proc.Count -gt 0)
    }
}

# --- Overlay --------------------------------------------------------------
#
# L'interruttore dell'overlay sta nel database interno di Discord, in formato
# binario: scriverci dentro significa rischiare di azzerare le impostazioni
# dell'utente. La via praticabile e' un'altra: l'overlay e' un MODULO a se',
# in una sua cartella dentro Discord\app-<versione>\modules. Se quella
# cartella non si chiama piu' come Discord si aspetta, il modulo non viene
# caricato e l'overlay non si aggancia ai giochi.
#
# Due proprieta' che rendono la cosa accettabile:
#   - e' reversibile alla lettera: si rinomina indietro e torna com'era;
#   - lo stato si legge dal disco, non da una preferenza salvata. Se un
#     aggiornamento di Discord rimette il modulo al suo posto, l'interruttore
#     si mostra spento da solo invece di mentire.
$script:VtSuffissoOverlay = '.vejatweak-off'

function Get-VtDiscordOverlayModuli([string] $Radice) {
    if (-not $Radice) { $Radice = Join-Path $env:LOCALAPPDATA 'Discord' }
    if (-not (Test-Path -LiteralPath $Radice)) { return @() }
    @(Get-ChildItem -LiteralPath $Radice -Directory -Recurse -Depth 3 -ErrorAction SilentlyContinue |
      Where-Object { $_.Parent.Name -eq 'modules' -and
                     ($_.Name -like 'discord_overlay*' -or $_.Name -like 'discord_desktop_overlay*') })
}

function Test-VtDiscordOverlayOff([string] $Radice) {
    $m = @(Get-VtDiscordOverlayModuli $Radice)
    if ($m.Count -eq 0) { return $false }
    # Spento solo se NESSUN modulo e' rimasto col nome originale.
    return (@($m | Where-Object { $_.Name -notlike "*$($script:VtSuffissoOverlay)" }).Count -eq 0)
}

function Set-VtDiscordOverlay([bool] $attivo, [string] $Radice) {
    if (-not $Radice -and (Test-VtDiscordRunning)) {
        throw 'Discord e'' aperto. Chiudilo del tutto, anche dall''icona vicino all''orologio: con i file in uso la cartella non si puo'' rinominare.'
    }
    $m = @(Get-VtDiscordOverlayModuli $Radice)
    if ($m.Count -eq 0) { throw 'Modulo dell''overlay non trovato: forse Discord non e'' installato.' }

    $fatti = 0
    foreach ($d in $m) {
        $spento = $d.Name -like "*$($script:VtSuffissoOverlay)"
        try {
            if (-not $attivo -and -not $spento) {
                Rename-Item -LiteralPath $d.FullName -NewName ($d.Name + $script:VtSuffissoOverlay) -ErrorAction Stop
                $fatti++
            } elseif ($attivo -and $spento) {
                # Le parentesi attorno al modello sono obbligatorie: senza,
                # la virgola di -replace lega piu' forte del '+' e il modello
                # diventa "\.vejatweak-off$ " con uno spazio in coda, che non
                # corrisponde a niente. Risultato: il nome non cambiava e
                # Windows rifiutava il rinomina "origine uguale a destinazione".
                $nuovo = $d.Name -replace ([regex]::Escape($script:VtSuffissoOverlay) + '$'), ''
                Rename-Item -LiteralPath $d.FullName -NewName $nuovo -ErrorAction Stop
                $fatti++
            }
        } catch {
            throw "Non riesco a rinominare '$($d.Name)': $($_.Exception.Message)"
        }
    }
    Write-VtLog "Overlay di Discord $(if ($attivo) { 'riattivato' } else { 'disattivato' }): $fatti moduli" ok
    return $fatti
}

# Scrittura del settings.json: si rilegge, si cambia la sola chiave e si
# riscrive. Discord riscrive il file quando esce, quindi va chiuso prima,
# esattamente come per i file di configurazione dei giochi.
function Set-VtDiscordAccelerazione([bool] $attiva) {
    $s = Get-VtDiscordSettings
    if (-not $s) { throw 'Discord non risulta installato (settings.json non trovato).' }
    if (Test-VtDiscordRunning) { throw 'Discord e'' aperto. Chiudilo del tutto (anche dall''icona vicino all''orologio): quando esce riscrive il file e cancellerebbe la modifica.' }

    Backup-VtGameFile $s | Out-Null
    $j = Get-Content -LiteralPath $s -Raw | ConvertFrom-Json
    if ($null -eq $j.enableHardwareAcceleration) {
        $j | Add-Member -NotePropertyName 'enableHardwareAcceleration' -NotePropertyValue $attiva -Force
    } else {
        $j.enableHardwareAcceleration = $attiva
    }
    # Depth 10: senza, gli oggetti annidati come WINDOW_BOUNDS verrebbero
    # troncati in una stringa e Discord si ritroverebbe la finestra sballata.
    $j | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $s -Encoding UTF8
    Write-VtLog "Discord: accelerazione hardware = $attiva" ok
}

# ---------------------------------------------------------------------------
# ESPORTAZIONE IN .REG
#
# Un file .reg si applica con un doppio clic, senza VejaTweak: comodo per
# portare le stesse impostazioni su un altro PC, per darle a qualcuno, o per
# tenersi da parte un ripristino che funziona anche se l'app sparisce.
#
# Vengono esportate SOLO le voci di tipo registro. Servizi, attivita'
# pianificate, schede di rete e file dei giochi non stanno nel registro nella
# forma che serve, e mettercele dentro darebbe un file che sembra completo e
# non lo e'. Il file lo dichiara in testa.
# ---------------------------------------------------------------------------
function ConvertTo-VtRegPath([string] $path) {
    $p = $path -replace '^HKLM:\\', 'HKEY_LOCAL_MACHINE\' `
               -replace '^HKCU:\\', 'HKEY_CURRENT_USER\' `
               -replace '^HKCR:\\', 'HKEY_CLASSES_ROOT\' `
               -replace '^HKU:\\',  'HKEY_USERS\'
    return $p
}

function ConvertTo-VtRegValore([string] $tipo, $valore) {
    switch ($tipo) {
        'DWord' {
            # I DWORD vanno in esadecimale a otto cifre. Il -1 (usato per
            # NetworkThrottlingIndex) diventa ffffffff: senza la maschera a
            # 32 bit uscirebbe un numero negativo che regedit rifiuta.
            $n = [int64] $valore
            if ($n -lt 0) { $n += 4294967296 }
            return 'dword:{0:x8}' -f [uint32] $n
        }
        'QWord'  { return 'hex(b):' + (([BitConverter]::GetBytes([int64] $valore) | ForEach-Object { '{0:x2}' -f $_ }) -join ',') }
        'Binary' { return 'hex:' + ((@($valore) | ForEach-Object { '{0:x2}' -f $_ }) -join ',') }
        default  {
            # Le stringhe vanno fra virgolette, con barre e virgolette interne
            # protette: nel formato .reg una barra si scrive doppia.
            #
            # Qui si usa il metodo .Replace e non l'operatore -replace: in
            # -replace la stringa di sostituzione passa comunque per il motore
            # delle espressioni regolari, e '\\\\' finiva per produrre QUATTRO
            # barre invece di due. Il file veniva importato senza errori, ma
            # nel registro finiva "C:\\Program Files" con la barra doppia,
            # cioe' un percorso che non esiste.
            $s = "$valore".Replace('\', '\\').Replace('"', '\"')
            return '"' + $s + '"'
        }
    }
}

# $modo: 'target'    = i valori che i tweak vogliono impostare
#        'attivi'    = solo le voci che risultano gia' applicate
#        'ripristino'= i valori che c'erano PRIMA, presi dal backup
function Export-VtReg([string] $percorso, [string] $modo = 'target', $soloCategorie) {
    $cat = Get-VtCatalog | Where-Object { $_.Kind -eq 'Reg' }
    if ($soloCategorie) { $cat = $cat | Where-Object { $soloCategorie -contains $_.Cat } }

    $righe = New-Object System.Collections.ArrayList
    [void] $righe.Add('Windows Registry Editor Version 5.00')
    [void] $righe.Add('')
    [void] $righe.Add('; VejaTweak - esportazione del ' + (Get-Date -Format 'dd/MM/yyyy HH:mm'))
    [void] $righe.Add('; Modalita'': ' + $(switch ($modo) {
        'attivi'     { 'solo le voci attualmente attive' }
        'ripristino' { 'valori precedenti, per tornare indietro' }
        default      { 'valori consigliati da VejaTweak' }
    }))
    [void] $righe.Add(';')
    [void] $righe.Add('; ATTENZIONE: questo file contiene SOLO le impostazioni di registro.')
    [void] $righe.Add('; Servizi, attivita'' pianificate, scheda di rete e impostazioni dei')
    [void] $righe.Add('; giochi NON ci sono dentro: per quelle serve VejaTweak.')
    [void] $righe.Add('; Le voci di HKEY_LOCAL_MACHINE richiedono i privilegi di amministratore.')
    [void] $righe.Add('')

    $chiavi = [ordered]@{}
    $conteggio = 0; $saltati = 0

    foreach ($t in $cat) {
        $bak = $null
        if ($modo -eq 'ripristino') {
            $bak = Get-VtEntry $t.Id
            if (-not $bak) { $saltati++; continue }   # mai applicato: niente da ripristinare
        }
        if ($modo -eq 'attivi' -and -not (Get-VtState $t)) { $saltati++; continue }

        foreach ($i in $t.Items) {
            $valore = $i.Val
            $tipo   = $i.Type

            if ($modo -eq 'ripristino') {
                $b = @($bak.Reg) | Where-Object { $_.Path -eq $i.Path -and $_.Name -eq $i.Name } | Select-Object -First 1
                if (-not $b) { continue }
                if (-not $b.Existed) {
                    # Prima non esisteva: nel formato .reg si cancella con un
                    # trattino davanti al nome.
                    $k = ConvertTo-VtRegPath $i.Path
                    if (-not $chiavi.Contains($k)) { $chiavi[$k] = New-Object System.Collections.ArrayList }
                    [void] $chiavi[$k].Add('"' + $i.Name + '"=-')
                    $conteggio++
                    continue
                }
                $valore = $b.Val
                $tipo   = $b.Type
            }

            $k = ConvertTo-VtRegPath $i.Path
            if (-not $chiavi.Contains($k)) { $chiavi[$k] = New-Object System.Collections.ArrayList }
            [void] $chiavi[$k].Add('"' + $i.Name + '"=' + (ConvertTo-VtRegValore $tipo $valore))
            $conteggio++
        }
    }

    foreach ($k in $chiavi.Keys) {
        [void] $righe.Add('[' + $k + ']')
        foreach ($r in $chiavi[$k]) { [void] $righe.Add($r) }
        [void] $righe.Add('')
    }

    # I file .reg vanno in UTF-16 LE con BOM: e' il formato che scrive
    # regedit e l'unico che accetta senza storpiare i caratteri accentati.
    [IO.File]::WriteAllLines($percorso, $righe, (New-Object Text.UnicodeEncoding $false, $true))

    Write-VtLog "Esportate $conteggio voci di registro in $(Split-Path $percorso -Leaf) (modo: $modo)" ok
    [pscustomobject]@{ Voci = $conteggio; Chiavi = $chiavi.Count; Saltati = $saltati; File = $percorso }
}

# ---------------------------------------------------------------------------
# PULIZIA DEI FILE
#
# Mettiamo in chiaro una cosa, perche' e' il campo dove si raccontano piu'
# bugie: svuotare cartelle NON rende un PC piu' veloce. Serve a recuperare
# spazio. La velocita' cambia solo quando il disco e' quasi pieno (sotto il
# 10% Windows non riesce piu' a espandere il file di paging e butta via la
# cache delle shader), e quel caso lo segnala gia' la pagina Diagnosi.
#
# Per questo qui NON troverai:
#   - Prefetch: cancellarlo rallenta gli avvii finche' non si ricostruisce.
#     E' il "tweak" piu' diffuso e piu' controproducente che esista.
#   - il file di paging e i punti di ripristino: sono reti di sicurezza.
#   - le cartelle personali (Download, Documenti): non sono spazzatura.
#   - le cache dei browser: sono dati tuoi, e svuotarle rallenta la
#     navigazione per giorni.
# ---------------------------------------------------------------------------
$script:VtPulizia = @(
    @{
        Id='temp-utente'; Nome='File temporanei del tuo utente'; Rischio='sicuro'; Admin=$false
        Desc='La cartella dove i programmi buttano i file di lavoro'
        Perche='Ci finiscono installer scompattati, aggiornamenti a meta'' e file che i programmi si dimenticano di cancellare. Nessuno li rilegge mai.'
        Percorsi=@($env:TEMP)
    }
    @{
        Id='temp-windows'; Nome='File temporanei di Windows'; Rischio='sicuro'; Admin=$true
        Desc='La cartella temporanea di sistema'
        Perche='Stessa cosa della precedente, ma lato sistema. Serve l''amministratore.'
        Percorsi=@("$env:SystemRoot\Temp")
    }
    @{
        Id='cache-update'; Nome='Cache di Windows Update'; Rischio='sicuro'; Admin=$true
        Desc='I pacchetti degli aggiornamenti gia'' installati'
        Perche='Windows tiene i file scaricati anche dopo aver installato l''aggiornamento. Si ricreano da soli al prossimo aggiornamento, non si rompe niente.'
        Percorsi=@("$env:SystemRoot\SoftwareDistribution\Download")
    }
    @{
        Id='log-cbs'; Nome='Log di manutenzione di Windows'; Rischio='sicuro'; Admin=$true
        Desc='I registri del servizio componenti (CBS)'
        Perche='Crescono all''infinito e li legge solo chi diagnostica problemi di aggiornamento.'
        Percorsi=@("$env:SystemRoot\Logs\CBS")
    }
    @{
        Id='errori'; Nome='Segnalazioni errori e crash dump'; Rischio='sicuro'; Admin=$false
        Desc='I rapporti che Windows prepara quando un programma va in crash'
        Perche='Servono a Microsoft, non a te. Si ricreano al prossimo crash.'
        Percorsi=@("$env:ProgramData\Microsoft\Windows\WER\ReportQueue",
                   "$env:ProgramData\Microsoft\Windows\WER\ReportArchive",
                   "$env:LOCALAPPDATA\CrashDumps")
    }
    @{
        Id='miniature'; Nome='Cache delle miniature'; Rischio='sicuro'; Admin=$false
        Desc='Le anteprime che Esplora risorse tiene da parte'
        Perche='Si ricostruisce da sola quando riapri le cartelle. L''unico effetto e'' che la prima apertura di una cartella con tante foto e'' un attimo piu'' lenta.'
        Percorsi=@("$env:LOCALAPPDATA\Microsoft\Windows\Explorer")
        Filtro='thumbcache_*.db', 'iconcache_*.db'
    }
    @{
        Id='cestino'; Nome='Cestino'; Rischio='sicuro'; Admin=$false; Kind='Cestino'
        Desc='Svuota il cestino di tutti i dischi'
        Perche='Finche'' sono nel cestino, i file occupano ancora spazio.'
        Warn='Dopo non si recuperano piu''. Controlla di non averci lasciato dentro qualcosa.'
    }
    @{
        Id='bak-tweaker'; Nome='Vecchi backup lasciati dai tweaker'; Rischio='sicuro'; Admin=$false
        Desc='Le copie .bak dei file di configurazione dei giochi'
        Perche='SapoTweak e altri programmi ne lasciano una a ogni modifica, senza mai ripulirle. VejaTweak ne tiene solo le cinque piu'' recenti: questa voce toglie tutte le altre.'
        Percorsi=@("$env:LOCALAPPDATA\FortniteGame\Saved\Config\WindowsClient")
        Filtro='*.bak'
        TieniRecenti=5
    }
    @{
        Id='cache-discord'; Nome='Cache di Discord'; Rischio='sicuro'; Admin=$false
        Desc='Le cache del browser interno di Discord'
        Perche='Discord e'' Chromium travestito e accumula centinaia di megabyte di cache che non ripulisce mai. Si ricostruisce da sola, l''unico effetto e'' che il primo avvio dopo la pulizia e'' un attimo piu'' lento.'
        Warn='Chiudi Discord prima, altrimenti i file sono in uso e ne resta indietro la maggior parte.'
        Percorsi=@("$env:APPDATA\discord\Cache",
                   "$env:APPDATA\discord\Code Cache",
                   "$env:APPDATA\discord\GPUCache",
                   "$env:APPDATA\discord\DawnGraphiteCache",
                   "$env:APPDATA\discord\DawnWebGPUCache")
    }
    @{
        Id='log-nvidia'; Nome='Log e cache dell''app NVIDIA'; Rischio='sicuro'; Admin=$false
        Desc='I registri di debug e la cache del browser interno dell''app NVIDIA'
        Perche='L''app NVIDIA e'' fatta con un browser incorporato e lascia log da megabyte e una cache che non ripulisce mai. Non servono a niente se non a chi sviluppa l''app.'
        Percorsi=@("$env:LOCALAPPDATA\NVIDIA Corporation\NVIDIA app\CefCache",
                   "$env:LOCALAPPDATA\NVIDIA Corporation\NVIDIA App\CefCache")
        # Nella cartella dell'app si tolgono SOLO i log: accanto ci sono file
        # di configurazione che devono restare.
        Mirati=@(
            @{ Path="$env:LOCALAPPDATA\NVIDIA Corporation\NVIDIA app"; Filtro=@('*.log', '*.bak') }
        )
    }
    @{
        Id='shader'; Nome='Cache delle shader'; Rischio='medio'; Admin=$false
        Desc='Le shader gia'' compilate da driver e giochi'
        Perche='E'' quasi sempre la voce piu'' grossa del PC, ma NON e'' spazzatura: sono i calcoli che il driver ha gia'' fatto per non rifarli a ogni partita.'
        Warn='Cancellandola i giochi devono ricompilare tutto: per i primi minuti avrai STUTTER, che e'' l''opposto di quello che vuoi. Fallo solo se hai artefatti o scatti strani DOPO un aggiornamento del driver, oppure se ti serve davvero lo spazio.'
        Percorsi=@("$env:LOCALAPPDATA\D3DSCache",
                   "$env:LOCALAPPDATA\NVIDIA\DXCache",
                   "$env:LOCALAPPDATA\NVIDIA\GLCache",
                   "$env:LOCALAPPDATA\AMD\DxCache",
                   "$env:LOCALAPPDATA\AMD\GLCache")
    }
)

function Measure-VtPulizia($voce) {
    $mb = 0.0; $n = 0; $negato = $false

    if ($voce.Kind -eq 'Cestino') {
        try {
            $sh = New-Object -ComObject Shell.Application
            foreach ($i in $sh.Namespace(10).Items()) { $mb += $i.Size / 1MB; $n++ }
        } catch { $negato = $true }
        return [pscustomobject]@{ Mb = [math]::Round($mb, 1); File = $n; Negato = $negato }
    }

    foreach ($p in $voce.Percorsi) {
        # Test-Path stesso puo' sollevare "accesso negato" su cartelle di
        # sistema quando non siamo amministratori: va protetto anche lui.
        try { if (-not (Test-Path -LiteralPath $p -ErrorAction Stop)) { continue } }
        catch { $negato = $true; continue }

        try {
            $file = if ($voce.Filtro) {
                        foreach ($f in $voce.Filtro) { Get-ChildItem -LiteralPath $p -Filter $f -File -Force -ErrorAction SilentlyContinue }
                    } else {
                        Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue
                    }
            $file = @($file)
            if ($voce.TieniRecenti) {
                $file = @($file | Sort-Object LastWriteTime -Descending | Select-Object -Skip $voce.TieniRecenti)
            }
            $m = $file | Measure-Object Length -Sum
            $mb += $m.Sum / 1MB
            $n  += $m.Count
        } catch { $negato = $true }
    }

    # Percorsi in cui si tocca solo cio' che corrisponde al filtro, perche'
    # accanto ci sono file che devono restare.
    foreach ($t in @($voce.Mirati)) {
        if (-not $t) { continue }
        try { if (-not (Test-Path -LiteralPath $t.Path -ErrorAction Stop)) { continue } } catch { $negato = $true; continue }
        foreach ($f in $t.Filtro) {
            $x = @(Get-ChildItem -LiteralPath $t.Path -Filter $f -File -Force -ErrorAction SilentlyContinue)
            $m = $x | Measure-Object Length -Sum
            $mb += $m.Sum / 1MB
            $n  += $m.Count
        }
    }

    [pscustomobject]@{ Mb = [math]::Round($mb, 1); File = $n; Negato = $negato }
}

function Invoke-VtPulizia($voce) {
    $prima = Measure-VtPulizia $voce
    $errori = 0

    if ($voce.Kind -eq 'Cestino') {
        try { Clear-RecycleBin -Force -ErrorAction Stop } catch { $errori++ }
        Write-VtLog "Pulizia '$($voce.Id)': cestino svuotato" ok
        return [pscustomobject]@{ Mb = $prima.Mb; File = $prima.File; Errori = $errori }
    }

    foreach ($p in $voce.Percorsi) {
        try { if (-not (Test-Path -LiteralPath $p -ErrorAction Stop)) { continue } } catch { $errori++; continue }

        $file = if ($voce.Filtro) {
                    foreach ($f in $voce.Filtro) { Get-ChildItem -LiteralPath $p -Filter $f -File -Force -ErrorAction SilentlyContinue }
                } else {
                    Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue
                }
        $file = @($file)
        if ($voce.TieniRecenti) {
            $file = @($file | Sort-Object LastWriteTime -Descending | Select-Object -Skip $voce.TieniRecenti)
        }

        foreach ($f in $file) {
            # I file in uso non si cancellano: e' normale e non e' un errore
            # da mostrare in rosso, quindi li contiamo e basta.
            try { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop } catch { $errori++ }
        }

        # Le cartelle rimaste vuote se ne vanno, ma la cartella di partenza
        # resta: cancellare %TEMP% o Windows\Temp romperebbe dei programmi.
        if (-not $voce.Filtro) {
            try {
                Get-ChildItem -LiteralPath $p -Recurse -Directory -Force -ErrorAction SilentlyContinue |
                    Sort-Object { $_.FullName.Length } -Descending |
                    ForEach-Object {
                        if (-not (Get-ChildItem -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue)) {
                            Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
                        }
                    }
            } catch { }
        }
    }

    foreach ($t in @($voce.Mirati)) {
        if (-not $t) { continue }
        try { if (-not (Test-Path -LiteralPath $t.Path -ErrorAction Stop)) { continue } } catch { $errori++; continue }
        foreach ($f in $t.Filtro) {
            foreach ($x in @(Get-ChildItem -LiteralPath $t.Path -Filter $f -File -Force -ErrorAction SilentlyContinue)) {
                try { Remove-Item -LiteralPath $x.FullName -Force -ErrorAction Stop } catch { $errori++ }
            }
        }
    }

    $dopo = Measure-VtPulizia $voce
    $liberati = [math]::Round($prima.Mb - $dopo.Mb, 1)
    Write-VtLog "Pulizia '$($voce.Id)': liberati $liberati MB ($($errori) file in uso saltati)" ok
    [pscustomobject]@{ Mb = $liberati; File = $prima.File - $dopo.File; Errori = $errori }
}

# Compattazione dell'archivio componenti: e' l'unica pulizia che libera
# davvero parecchi GB su un Windows vecchio di qualche anno, ma va fatta con
# lo strumento di Microsoft e ci mette qualche minuto.
function Invoke-VtDism {
    if (-not (Test-VtAdmin)) { throw 'Servono i privilegi di amministratore.' }
    Write-VtLog 'Compattazione archivio componenti (DISM) avviata' ok
    $out = Invoke-VtCmd 'DISM /Online /Cleanup-Image /StartComponentCleanup'
    if ($out -match '100' -or $out -match 'complet') { return 'Compattazione completata.' }
    return 'Compattazione terminata. Riavvia per completare.'
}

# ---------------------------------------------------------------------------
# SALUTE DEL PC
#
# Nessun interruttore risolve un driver video che va in crash o una RAM
# instabile. Questi sono i sintomi che Windows registra da solo e che nessuno
# va mai a leggere.
#
# Regola imparata a mie spese scrivendo questa parte: NON si filtra per solo
# ID evento. Gli ID 17, 18 e 19 su questo PC arrivano da Windows Update, dal
# TPM e dal Bluetooth, non da errori hardware; l'ID 153 era "VBS disabilitata"
# e non un errore disco. Filtrare per solo ID avrebbe prodotto un allarme
# completamente falso. Si filtra sempre per provider PIU' id.
# ---------------------------------------------------------------------------
function Get-VtEventi([int] $giorni = 30) {
    # In cache per numero di giorni: la pagina Salute la chiamava una volta
    # per disegnarsi e una per ogni ritorno, e sono trecento millisecondi di
    # registro eventi ogni volta.
    if ($null -eq $script:VtEventi) { $script:VtEventi = @{} }
    $k = "$giorni"
    if ($script:VtEventi.ContainsKey($k)) { return $script:VtEventi[$k] }
    # Il conto vero sta in una funzione a parte perche' ha piu' di un'uscita
    # ("return $null" quando il registro non si legge): cosi' la cache si
    # riempie una volta sola, qui, invece che a ogni return.
    $script:VtEventi[$k] = Get-VtEventiReale $giorni
    return $script:VtEventi[$k]
}

function Get-VtEventiReale([int] $giorni = 30) {
    $da = (Get-Date).AddDays(-$giorni)
    $prov = @('Microsoft-Windows-WHEA-Logger', 'Display', 'Microsoft-Windows-Kernel-Power',
              'Microsoft-Windows-WER-SystemErrorReporting', 'disk', 'nvlddmkm', 'amdkmdap')

    # Get-WinEvent fallisce l'intera query se anche UNO dei provider elencati
    # non e' registrato: su un PC NVIDIA manca amdkmdap, su uno AMD manca
    # nvlddmkm. Senza questo filtro la pagina non funzionerebbe su nessuna
    # macchina. Costa una sessantina di millisecondi.
    try {
        $registrati = (Get-WinEvent -ListLog System -ErrorAction Stop).ProviderNames
        $prov = @($prov | Where-Object { $registrati -contains $_ })
    } catch { }
    if ($prov.Count -eq 0) { return $null }

    try {
        $ev = Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=$da; ProviderName=$prov } -ErrorAction Stop
    } catch {
        # Nessun evento nel periodo: e' un caso normale, non un errore.
        if ($_.Exception.Message -match 'No events|Nessun evento') {
            $ev = @()
        } else {
            Write-VtLog "Registro eventi non leggibile: $($_.Exception.Message)" warn
            return $null
        }
    }

    $tdr   = @($ev | Where-Object { $_.Id -eq 4101 -or ($_.ProviderName -match 'nvlddmkm|amdkmdap' -and $_.Level -le 2) })
    $whea  = @($ev | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-WHEA-Logger' -and $_.Level -le 3 })
    $spegn = @($ev | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $_.Id -eq 41 })
    $bsod  = @($ev | Where-Object { $_.ProviderName -eq 'Microsoft-Windows-WER-SystemErrorReporting' -and $_.Id -eq 1001 })
    $disco = @($ev | Where-Object { $_.ProviderName -eq 'disk' -and $_.Id -in 7, 11, 51, 52, 153 })

    [pscustomobject]@{
        Giorni = $giorni
        Tdr = $tdr.Count; TdrUltimo = ($tdr | Select-Object -First 1).TimeCreated
        Whea = $whea.Count; WheaUltimo = ($whea | Select-Object -First 1).TimeCreated
        Spegnimenti = $spegn.Count; SpegnUltimo = ($spegn | Select-Object -First 1).TimeCreated
        Bsod = $bsod.Count; BsodUltimo = ($bsod | Select-Object -First 1).TimeCreated
        Disco = $disco.Count; DiscoUltimo = ($disco | Select-Object -First 1).TimeCreated
    }
}

function Get-VtEventiDiagnosi($e) {
    $out = @()
    if (-not $e) {
        $out += [pscustomobject]@{ Peso=3; Stato='NON LEGGIBILE'; Titolo='Registro eventi non accessibile'
            Testo='Serve avviare VejaTweak come amministratore per leggere il registro di sistema.' }
        return $out
    }
    if ($e.Whea -gt 0) {
        $out += [pscustomobject]@{ Peso=1; Stato='GRAVE'; Titolo="$($e.Whea) errori hardware (WHEA) in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.WheaUltimo). Sono errori segnalati dal processore o dal bus, non da Windows. Le cause tipiche sono un profilo XMP/EXPO instabile, un overclock troppo spinto o un alimentatore al limite.`n`nSe hai attivato XMP di recente e vedi questi errori, e' il primo posto dove guardare: prova il profilo XMP piu' lento, o rimettilo su Auto e verifica se spariscono." }
    }
    if ($e.Tdr -gt 0) {
        $out += [pscustomobject]@{ Peso=1; Stato='GRAVE'; Titolo="$($e.Tdr) crash del driver video in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.TdrUltimo). Sono i 'Display driver stopped responding': lo schermo si blocca un attimo e torna. In gioco si sentono come freeze secchi.`n`nCause tipiche in ordine: driver video da reinstallare pulito (con DDU), GPU in overclock o undervolt instabile, alimentatore che non regge i picchi, temperature alte." }
    }
    if ($e.Bsod -gt 0) {
        $out += [pscustomobject]@{ Peso=1; Stato='GRAVE'; Titolo="$($e.Bsod) schermate blu in $($e.Giorni) giorni"
            Testo="Ultima: $($e.BsodUltimo). Il codice di errore sta in Visualizzatore eventi > Sistema, evento 1001. Con schermate blu ricorrenti non ha senso ottimizzare: prima si trova la causa." }
    }
    if ($e.Spegnimenti -gt 0) {
        $out += [pscustomobject]@{ Peso=2; Stato='DA GUARDARE'; Titolo="$($e.Spegnimenti) spegnimenti anomali in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.SpegnUltimo). Il PC si e' spento senza chiudere Windows. Se non e' stato un blackout o il tasto tenuto premuto, guarda alimentatore e temperature: il riavvio improvviso sotto carico e' il sintomo classico di un alimentatore che non regge." }
    }
    if ($e.Disco -gt 0) {
        $out += [pscustomobject]@{ Peso=2; Stato='DA GUARDARE'; Titolo="$($e.Disco) errori di I/O sul disco in $($e.Giorni) giorni"
            Testo="Ultimo: $($e.DiscoUltimo). Operazioni di lettura o scrittura ritentate. Su un disco che ospita i giochi si traduce in caricamenti lunghi e stutter da streaming texture. Controlla il cavo SATA o, su NVMe, le temperature." }
    }
    if ($out.Count -eq 0) {
        $out += [pscustomobject]@{ Peso=3; Stato='PULITO'; Titolo="Nessun problema hardware negli ultimi $($e.Giorni) giorni"
            Testo='Nessun crash del driver video, nessun errore hardware WHEA, nessuna schermata blu, nessuno spegnimento anomalo, nessun errore di I/O sui dischi. Se hai scatti, la causa non e'' hardware.' }
    }
    $out | Sort-Object Peso
}

# La risoluzione del timer si legge da ntdll: e' la prova che il tweak
# corrispondente ha davvero effetto, invece di doverci credere.
if (-not ('VejaTimer' -as [type])) {
    Add-Type -Namespace Veja -Name Timer -MemberDefinition @'
[DllImport("ntdll.dll", SetLastError=true)]
public static extern int NtQueryTimerResolution(out uint Max, out uint Min, out uint Current);
'@ -ErrorAction SilentlyContinue
}

function Get-VtTimerResolution {
    try {
        $mx = 0; $mn = 0; $cur = 0
        [Veja.Timer]::NtQueryTimerResolution([ref]$mx, [ref]$mn, [ref]$cur) | Out-Null
        [pscustomobject]@{
            Attuale = [math]::Round($cur / 10000, 3)
            Minima  = [math]::Round($mn / 10000, 3)
            Default = [math]::Round($mx / 10000, 3)
        }
    } catch { return $null }
}

# Un gioco su disco meccanico e' una causa di stutter che nessun tweak copre.
function Get-VtGiochiSuDisco {
    $out = @()
    $cache = @{}
    foreach ($g in (Find-VtGiochi)) {
        $L = (Split-Path $g.Path -Qualifier).TrimEnd(':')
        if (-not $cache.ContainsKey($L)) {
            $info = [pscustomobject]@{ Disco = 'non determinabile'; Tipo = 'ignoto' }
            try {
                $part = Get-Partition -DriveLetter $L -ErrorAction Stop
                $d = Get-PhysicalDisk -ErrorAction Stop | Where-Object { $_.DeviceId -eq $part.DiskNumber }
                if ($d) { $info = [pscustomobject]@{ Disco = $d.FriendlyName; Tipo = $(if ($d.MediaType) { "$($d.MediaType)" } else { 'ignoto' }) } }
            } catch { }
            $cache[$L] = $info
        }
        $out += [pscustomobject]@{ Nome = $g.Nome; Unita = "$L`:"; Disco = $cache[$L].Disco; Tipo = $cache[$L].Tipo }
    }
    $out
}

function Get-VtDischi {
    # Settecento millisecondi: Get-StorageReliabilityCounter interroga il
    # firmware di ogni disco, uno per uno. Non e' una lettura da rifare a ogni
    # apertura della pagina.
    if ($null -ne $script:VtDischiC) { return $script:VtDischiC }
    $out = @()
    try {
        foreach ($d in (Get-PhysicalDisk -ErrorAction Stop)) {
            $r = $d | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue
            $out += [pscustomobject]@{
                Nome   = $d.FriendlyName
                Tipo   = $(if ($d.MediaType) { "$($d.MediaType)" } else { 'ignoto' })
                Salute = "$($d.HealthStatus)"
                GB     = [math]::Round($d.Size / 1GB)
                Usura  = $r.Wear
                Temp   = $r.Temperature
                Bus    = "$($d.BusType)"
            }
        }
    } catch { }
    $script:VtDischiC = @($out)
    return $script:VtDischiC
}

# ---------------------------------------------------------------------------
# RIEPILOGO HARDWARE (pagina OC / Tuning)
# ---------------------------------------------------------------------------
function Get-VtVram {
    # Win32_VideoController.AdapterRAM e' un intero a 32 bit e sopra i 4 GB
    # restituisce numeri senza senso. Il valore vero sta nel registro.
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
    foreach ($i in 0..8) {
        $k = Join-Path $base ('{0:0000}' -f $i)
        $v = Get-VtReg $k 'HardwareInformation.qwMemorySize'
        if ($v) { return [math]::Round($v / 1GB, 1) }
    }
    return $null
}

# Da "32.0.16.1088" alla versione che NVIDIA usa nelle note di rilascio,
# "610.88": sono le ultime cinque cifre del numero completo.
function ConvertTo-VtDriverVersion([string] $ver) {
    $n = $ver -replace '\D', ''
    if ($n.Length -lt 5) { return $ver }
    $c = $n.Substring($n.Length - 5)
    return "$($c.Substring(0,3)).$($c.Substring(3,2))"
}

function Get-VtRiepilogo {
    # Quadro completo del PC: CPU, banchi di RAM, firmware. Sono fatti che non
    # cambiano mentre il programma e' aperto, e ricalcolarli a ogni apertura di
    # pagina costava un decimo di secondo per niente.
    if ($null -ne $script:VtRiepC) { return $script:VtRiepC }
    $sys = Get-VtSystem
    $fw  = Get-VtFirmware
    $os  = Get-CimInstance Win32_OperatingSystem
    $ver = (Get-VtReg 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' 'DisplayVersion')

    $gpu = $sys.Gpu | Select-Object -First 1
    $vram = Get-VtVram
    $drv  = if ($gpu) { ConvertTo-VtDriverVersion $gpu.DriverVersion } else { '?' }

    $mods = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)
    $marca = ($mods | Select-Object -First 1).Manufacturer
    $pn    = ($mods | Select-Object -First 1).PartNumber
    if ($pn) { $pn = $pn.Trim() }
    $mhz   = ($mods | Measure-Object ConfiguredClockSpeed -Maximum).Maximum
    $mhzMax= ($mods | Measure-Object Speed -Maximum).Maximum

    # Thread attesi: se i logici sono pari ai fisici su una CPU che l'SMT ce
    # l'ha, il processore non e' tutto disponibile.
    $smtSospetto = ($sys.Thread -eq $sys.Core -and $sys.Cpu -match 'Core.*i[579]|Ryzen [579]|Core.*Ultra')

    $script:VtRiepC = [pscustomobject]@{
        Cpu        = $sys.Cpu
        CpuDett    = "$($sys.Core) core | $($sys.Thread) thread"
        CpuStato   = if ($smtSospetto) { 'SMT/Hyper-Threading disattivato' } else { 'CPU completa disponibile' }
        CpuStatoOk = (-not $smtSospetto)
        CpuThread  = "$($sys.Thread) thread pronti"
        Gpu        = if ($gpu) { $gpu.Name } else { 'non rilevata' }
        GpuDett    = "$(if ($vram) { "$vram GB VRAM" } else { 'VRAM ignota' }) | Driver $drv"
        Vram       = $vram
        Vendor     = $sys.Vendor
        Ram        = "$($mods.Count) moduli | $($sys.RamGB) GB$(if ($marca) { " | $marca" })$(if ($pn) { " $pn" })"
        RamDett    = "$($mods.Count) moduli attivi | $mhz MHz"
        RamOk      = (-not ($mhz -and $mhzMax -and $mhz -lt ($mhzMax - 100)))
        RamMhz     = $mhz
        RamMhzMax  = $mhzMax
        Scheda     = "$($fw.Produttore) $($fw.Scheda)"
        SchedaDett = "BIOS $($fw.Versione)"
        Sistema    = "$($os.Caption)$(if ($ver) { " - $ver" }) - build $($os.BuildNumber) - $($os.OSArchitecture)"
        Portatile  = $sys.Portatile
        Disco      = $sys.DiscoSys
    }
    return $script:VtRiepC
}

# ---------------------------------------------------------------------------
# PROFILI AUTOMATICI
#
# Non sono tweak nuovi: sono elenchi di voci gia' presenti nel catalogo,
# applicate in blocco. Cosi' non esiste un "profilo" che fa qualcosa che non
# puoi vedere e disattivare a mano dalla sua sezione.
# ---------------------------------------------------------------------------
$script:VtProfili = @(
    @{
        Id = 'base'; Nome = 'Base Gaming'; Etichetta = 'BASE'
        Sommario = 'Parti da qui se vuoi alleggerire il PC senza cambiare abitudini o toccare servizi importanti.'
        Desc = 'Pulizia leggera: niente registrazione in background, niente distrazioni, mouse e tastiera che non ti remano contro.'
        Punti = @(
            'Spegne cattura video, overlay e app in background',
            'Toglie accelerazione mouse e filtri di accessibilita'' che scartano input',
            'Non tocca servizi, rete, energia o niente che richieda riavvio'
        )
        Ids = @('gamedvr', 'gamemode', 'gamebar-panel', 'bg-apps',
                'mouse-accel', 'mouse-1to1', 'mouse-trails',
                'tasti-accessibilita', 'tastiera-ripetizione',
                'trasparenze', 'animazioni',
                'ctrl-gamebar')
    }
    @{
        Id = 'competitive'; Nome = 'Competitive Gaming'; Etichetta = 'COMPETITIVE'; Consigliato = $true
        Sommario = 'La scelta giusta per Fortnite, Valorant, FiveM e R6 se vuoi un PC piu'' pulito ogni volta che accendi.'
        Desc = 'Aggiunge scheduler, energia, rete e GPU. E'' il profilo che consiglio: tutto quello che c''e'' dentro ha un effetto misurabile e nessun compromesso di comodita''.'
        Punti = @(
            'Tutto il profilo Base',
            'Scheduler, priorita'' di gioco e profilo multimediale',
            'Energia al massimo, niente parcheggio core, USB e PCIe sempre svegli',
            'HAGS, giochi sulla GPU dedicata, Nagle disattivato',
            'Schermo intero vero nei giochi, widget della barra spenti',
            'Pannello NVIDIA: alimentazione al massimo, coda dei frame corta',
            'Telemetria e attivita'' pianificate inutili spente',
            'Controller: driver a posto, porte USB che non si addormentano'
        )
        Ids = @('gamedvr', 'gamemode', 'gamebar-panel', 'bg-apps',
                'nv-power', 'nv-prerender', 'nv-threaded',
                'focus-primo-piano', 'widget-off', 'giochi-schermo-intero',
                'mouse-accel', 'mouse-1to1', 'mouse-trails', 'input-power',
                'tasti-accessibilita', 'tastiera-ripetizione',
                'trasparenze', 'animazioni',
                'mmcss-risposta', 'net-throttling', 'priorita-primo-piano', 'profilo-giochi',
                'hags', 'gpu-preferenza-giochi',
                'piano-energia', 'core-parking', 'usb-suspend', 'pcie-aspm',
                'avvio-rapido', 'kernel-in-ram', 'ntfs-lastaccess',
                'nagle', 'svc-telemetria', 'task-telemetria',
                'nic-risparmio', 'nic-lso', 'nic-interrupt', 'nic-flowcontrol',
                'timer-resolution', 'power-throttling',
                'ctrl-servizi', 'ctrl-usb-power', 'ctrl-gamebar')
    }
    @{
        Id = 'massimo'; Nome = 'Maximum Gaming'; Etichetta = 'SPINTO'
        Sommario = 'Usalo solo se il PC e'' dedicato al gaming e hai gia'' provato Competitive.'
        Desc = 'Aggiunge le voci che hanno un prezzo: niente notifiche, piu'' servizi spenti, CPU sempre a frequenza piena. Ogni voce con un compromesso vero te la elenco prima di applicarla.'
        Punti = @(
            'Tutto il profilo Competitive',
            'Notifiche di Windows spente',
            'Servizi opzionali su Manuale (SuperFetch incluso, se hai un SSD)',
            'CPU sempre a frequenza piena: piu'' calore, meno ritardo di risalita'
        )
        Ids = @('gamedvr', 'gamemode', 'gamebar-panel', 'bg-apps', 'notifiche',
                'nv-power', 'nv-prerender', 'nv-threaded',
                'focus-primo-piano', 'widget-off', 'giochi-schermo-intero',
                'mouse-accel', 'mouse-1to1', 'mouse-trails', 'input-power',
                'tasti-accessibilita', 'tastiera-ripetizione',
                'trasparenze', 'animazioni',
                'mmcss-risposta', 'net-throttling', 'priorita-primo-piano', 'profilo-giochi',
                'hags', 'gpu-preferenza-giochi',
                'piano-energia', 'core-parking', 'usb-suspend', 'pcie-aspm', 'cpu-min-100',
                'avvio-rapido', 'kernel-in-ram', 'ntfs-lastaccess',
                'nagle', 'svc-telemetria', 'task-telemetria',
                'nic-risparmio', 'nic-lso', 'nic-interrupt', 'nic-flowcontrol',
                'svc-superflui',
                'timer-resolution', 'power-throttling',
                'ctrl-servizi', 'ctrl-usb-power', 'ctrl-gamebar')
    }
)

# Solo le voci che esistono davvero su QUESTO PC: il catalogo si adatta
# (SuperFetch appare solo con un SSD, la frequenza minima solo su fisso...),
# quindi il conteggio mostrato e' quello vero, non una promessa.
function Get-VtProfiloTweaks([string] $id) {
    $p = $script:VtProfili | Where-Object { $_.Id -eq $id } | Select-Object -First 1
    if (-not $p) { return @() }
    $cat = Get-VtCatalog
    @($p.Ids | ForEach-Object { $x = $_; $cat | Where-Object { $_.Id -eq $x } })
}

function Get-VtProfiloDaFare([string] $id) {
    @(Get-VtProfiloTweaks $id | Where-Object { -not (Get-VtState $_) })
}

function Invoke-VtProfilo([string] $id) {
    $da = Get-VtProfiloDaFare $id
    $ok = 0; $ko = @(); $reboot = $false
    foreach ($t in $da) {
        if (Set-VtTweak $t $true) { $ok++; if ($t.Reboot) { $reboot = $true } }
        else { $ko += $t.Nome }
    }
    Write-VtLog "Profilo '$id': $ok applicati, $($ko.Count) falliti" ok
    [pscustomobject]@{ Applicati = $ok; Falliti = $ko; Riavvio = $reboot; Totale = $da.Count }
}

# ---------------------------------------------------------------------------
# PANNELLO DELLA SCHEDA VIDEO
#
# Chiariamo il limite come per il BIOS: le impostazioni 3D del pannello NVIDIA
# stanno in un database binario (nvdrsdb0.bin) che si scrive solo con NVAPI,
# una libreria nativa. Farlo alla cieca da PowerShell significa rischiare di
# corrompere i profili del driver. Su AMD e' lo stesso con il suo database.
# Quindi qui: apriamo il pannello con un clic e diciamo esattamente cosa
# mettere, voce per voce, come nella pagina del BIOS.
# ---------------------------------------------------------------------------
# Chi ha fatto la scheda video. Serve dappertutto (pagina NVIDIA, pagina AMD,
# meta' del catalogo), quindi deve costare zero.
#
# Prima chiedeva a Get-VtSystem, che per rispondere fa cinque query WMI piu'
# Get-Partition: due secondi buoni, di cui uno solo per Win32_Processor e
# ottocento millisecondi per il tipo di disco. Niente di tutto cio' serve per
# sapere se la GPU e' NVIDIA. Il registro dice la stessa cosa in 24 ms.
#
# Se il registro non risponde si torna a Get-VtSystem: meglio lento che cieco.
$script:VtVendor = $null
function Get-VtGpuVendor {
    if ($script:VtVendor) { return $script:VtVendor }

    # SilentlyContinue e non Stop: senza privilegi di amministratore una delle
    # sottochiavi risponde "accesso non consentito", e con Stop saltava per
    # aria tutta l'enumerazione - comprese le chiavi leggibili, che sono
    # proprio quelle che servono. Cosi' invece si salta la chiusa e si legge
    # il resto.
    $v = ''
    try {
        $classe = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
        $v = @(
            Get-ChildItem $classe -ErrorAction SilentlyContinue |
            ForEach-Object { (Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue).ProviderName }
        ) -join ' '
    } catch { }

    if (-not $v) { $v = (Get-VtSystem).Vendor }

    # L'ordine conta: sui portatili convivono Intel e NVIDIA, e quella che
    # interessa e' sempre la dedicata.
    $script:VtVendor =
        if     ($v -match 'NVIDIA')         { 'NVIDIA' }
        elseif ($v -match 'AMD|Radeon|ATI') { 'AMD' }
        elseif ($v -match 'Intel')          { 'Intel' }
        else                                { 'sconosciuto' }
    return $script:VtVendor
}

# Nome, VRAM e versione driver della scheda: le due righe che la pagina NVIDIA
# mostra in alto. Prima le prendeva da Get-VtRiepilogo, che pero' per
# rispondere calcola tutto il quadro del PC - CPU, banchi di RAM, firmware -
# e costa un secondo e due decimi. Per due stringhe.
function Get-VtGpuRiga {
    if ($script:VtGpuRiga) { return $script:VtGpuRiga }
    $gpu = (Get-VtSystem).Gpu | Select-Object -First 1
    $vram = Get-VtVram
    $script:VtGpuRiga = [pscustomobject]@{
        Nome  = if ($gpu) { $gpu.Name } else { 'non rilevata' }
        Dett  = "$(if ($vram) { "$vram GB VRAM" } else { 'VRAM ignota' }) | Driver $(if ($gpu) { ConvertTo-VtDriverVersion $gpu.DriverVersion } else { '?' })"
    }
    return $script:VtGpuRiga
}

# Trova come si apre il pannello su questo PC: negli ultimi driver e' una app
# del Microsoft Store, prima era un exe classico.
#
# In cache perche' Get-AppxPackage costa mezzo secondo e la risposta non
# cambia mentre il programma e' aperto.
function Get-VtPannelloGpu {
    if ($script:VtPannello) { return $script:VtPannello.Valore }
    $script:VtPannello = @{ Valore = (Get-VtPannelloGpuReale) }
    return $script:VtPannello.Valore
}

function Get-VtPannelloGpuReale {
    $vend = Get-VtGpuVendor

    if ($vend -eq 'NVIDIA') {
        try {
            $pkg = Get-AppxPackage | Where-Object { $_.Name -eq 'NVIDIACorp.NVIDIAControlPanel' } | Select-Object -First 1
            if ($pkg) {
                return [pscustomobject]@{ Tipo='appx'; Target="shell:AppsFolder\$($pkg.PackageFamilyName)!NVIDIACorp.NVIDIAControlPanel"; Nome='Pannello di controllo NVIDIA' }
            }
        } catch { }
        foreach ($p in @("$env:ProgramFiles\NVIDIA Corporation\Control Panel Client\nvcplui.exe",
                         "${env:ProgramFiles(x86)}\NVIDIA Corporation\Control Panel Client\nvcplui.exe")) {
            if (Test-Path $p) { return [pscustomobject]@{ Tipo='exe'; Target=$p; Nome='Pannello di controllo NVIDIA' } }
        }
        $app = "$env:ProgramFiles\NVIDIA Corporation\NVIDIA app\CEF\NVIDIA app.exe"
        if (Test-Path $app) { return [pscustomobject]@{ Tipo='exe'; Target=$app; Nome='NVIDIA app' } }
    }

    if ($vend -eq 'AMD') {
        foreach ($p in @("$env:ProgramFiles\AMD\CNext\CNext\RadeonSoftware.exe",
                         "$env:ProgramFiles\AMD\CNext\CNext\cncmd.exe",
                         "${env:ProgramFiles(x86)}\AMD\CNext\CNext\RadeonSoftware.exe")) {
            if (Test-Path $p) { return [pscustomobject]@{ Tipo='exe'; Target=$p; Nome='AMD Software: Adrenalin Edition' } }
        }
        try {
            $pkg = Get-AppxPackage | Where-Object { $_.Name -match 'AMDRadeonSoftware|AdvancedMicroDevicesInc' } | Select-Object -First 1
            if ($pkg) { return [pscustomobject]@{ Tipo='appx'; Target="shell:AppsFolder\$($pkg.PackageFamilyName)!App"; Nome='AMD Software' } }
        } catch { }
    }
    return $null
}

function Open-VtPannelloGpu {
    $p = Get-VtPannelloGpu
    if (-not $p) { throw 'Pannello della scheda video non trovato su questo PC.' }
    if ($p.Tipo -eq 'appx') { Start-Process 'explorer.exe' -ArgumentList $p.Target }
    else { Start-Process $p.Target }
    Write-VtLog "Aperto: $($p.Nome)" ok
}

# Impostazioni 3D, in ordine di quanto contano davvero.
function Get-VtGuidaNvidia {
    @(
        @{ Voce='Modalita'' a bassa latenza'; Valore='Ultra (solo se vuoi spingere oltre l''interruttore)'
           Perche='Tiene la coda di rendering della CPU corta: e'' la voce che si sente di piu'' sul ritardo fra mouse e schermo. L''interruttore qui sopra la porta su "On", che e'' il valore che ho verificato di poter scrivere e rimettere a posto. "Ultra" aggiunge anche il ritmo automatico dei frame e quello lo mette solo il pannello. Se il gioco ha NVIDIA Reflex (Fortnite, Valorant, R6 ce l''hanno) lascia pure "On" e attiva Reflex nel gioco: fa lo stesso lavoro meglio, dall''interno del motore.' }
        @{ Voce='Modalita'' gestione alimentazione'; Valore='Preferisci prestazioni massime'
           Perche='Senza questa la GPU abbassa le frequenze fra un picco e l''altro e le rialza con un attimo di ritardo. Nei giochi competitivi, dove il carico e'' irregolare, quel ritardo cade dentro il frame.' }
        @{ Voce='Sincronizzazione verticale'; Valore='Off'
           Perche='Il V-Sync fa aspettare la GPU: aggiunge fino a un frame intero di ritardo. Va spento qui E dentro ogni gioco, perche'' vince l''impostazione piu'' restrittiva.' }
        @{ Voce='Frame rate massimo'; Valore='Off (o il refresh del monitor)'
           Perche='Se non usi G-Sync lascialo libero. Se usi G-Sync, mettilo 3 FPS sotto il refresh: cosi'' resti dentro la finestra adattiva senza mai toccare il tetto del V-Sync.' }
        @{ Voce='Qualita'' filtraggio texture'; Valore='Prestazioni elevate'
           Perche='Qualche punto percentuale gratis. La differenza visiva in movimento e'' praticamente invisibile a 200 Hz.' }
        @{ Voce='Ottimizzazione threaded'; Valore='On'
           Perche='Lascia che il driver distribuisca il lavoro su piu'' core. Su una CPU con 6 o piu'' core e'' sempre un guadagno.' }
        @{ Voce='Cache shader'; Valore='10 GB o Illimitata'
           Perche='Le shader gia'' compilate non vengono ricompilate a ogni partita: e'' la causa piu'' comune degli stutter nei primi minuti di gioco.' }
        @{ Voce='Modalita'' a schermo intero'; Valore='Preferisci sovrapposizione ottimizzata (se presente)'
           Perche='Nei driver recenti sostituisce la vecchia catena esclusiva mantenendo la stessa latenza.' }
    )
}

function Get-VtGuidaColoriNvidia {
    @(
        @{ Voce='Vividezza digitale'; Valore='60-70%'
           Perche='E'' il vero motivo per cui i giocatori entrano in questo menu. Satura i colori e stacca i modelli dei nemici dallo sfondo, soprattutto sul grigio di Valorant e sul verde di Fortnite. Sopra 80 i colori si impastano e le skin chiare diventano una macchia: 60-70 e'' il punto dove guadagni leggibilita'' senza perdere dettaglio.' }
        @{ Voce='Contrasto'; Valore='52-55%'
           Perche='Un filo sopra il neutro aiuta a distinguere le sagome nelle zone in ombra. Alzarlo troppo chiude le ombre e li nasconde del tutto.' }
        @{ Voce='Gamma'; Valore='1.00 (alza a 1.05 solo se le mappe scure ti danno fastidio)'
           Perche='La gamma alta schiarisce tutto e appiattisce l''immagine: si vede peggio, non meglio.' }
        @{ Voce='Formato colore output'; Valore='RGB'
           Perche='Se il monitor e'' collegato in HDMI, Windows a volte sceglie YCbCr 4:2:2, che sottocampiona il colore e rende il testo e i bordi sfocati. RGB e'' pieno.' }
        @{ Voce='Intervallo dinamico output'; Valore='Completo'
           Perche='"Limitato" (16-235) schiaccia neri e bianchi: perdi proprio il dettaglio nelle zone scure dove si nascondono i nemici.' }
        @{ Voce='Profondita'' colore output'; Valore='8 bpc (10 solo con HDR)'
           Perche='A 8 bit puoi tenere il refresh piu'' alto su cavi DisplayPort al limite di banda. Su un 200 Hz conta.' }
    )
}

function Get-VtGuidaAmd {
    @(
        @{ Voce='Radeon Anti-Lag (o Anti-Lag 2)'; Valore='Attivato'
           Perche='L''equivalente della bassa latenza NVIDIA: accorcia la coda di frame fra CPU e GPU. E'' la voce che conta di piu'' sulla reattivita''.' }
        @{ Voce='Attesa sincronizzazione verticale'; Valore='Sempre disattivato'
           Perche='Come su NVIDIA: il V-Sync costa fino a un frame intero di ritardo.' }
        @{ Voce='Radeon Chill'; Valore='Disattivato'
           Perche='Chill abbassa gli FPS quando ti muovi poco per risparmiare energia. In un gioco competitivo significa frame rate che balla proprio mentre stai fermo a mirare.' }
        @{ Voce='Radeon Boost'; Valore='Disattivato'
           Perche='Abbassa la risoluzione durante i movimenti rapidi. Rende sfocato proprio il momento in cui devi vedere meglio.' }
        @{ Voce='Modalita'' filtro texture'; Valore='Prestazioni'
           Perche='Stesso ragionamento del filtraggio texture NVIDIA: guadagno gratis, differenza invisibile in movimento.' }
        @{ Voce='Modalita'' tassellazione'; Valore='Sostituisci impostazioni applicazione, massimo 8x'
           Perche='Alcuni motori chiedono livelli di tassellazione altissimi che non si vedono. Limitarli a 8x e'' il classico guadagno gratuito su Radeon.' }
        @{ Voce='Cache shader'; Valore='AMD ottimizzata'
           Perche='Evita la ricompilazione delle shader a ogni avvio: meno stutter nei primi minuti.' }
        @{ Voce='Frame rate massimo (FRTC)'; Valore='Off, oppure refresh meno 3 con FreeSync'
           Perche='Stessa logica di G-Sync: restare dentro la finestra adattiva senza toccare il tetto.' }
        @{ Voce='Anti-Aliasing morfologico (MLAA)'; Valore='Disattivato'
           Perche='Sfoca l''immagine a costo di prestazioni, e i giochi hanno gia'' il proprio anti-aliasing.' }
    )
}

function Get-VtGuidaColoriAmd {
    @(
        @{ Voce='Saturazione'; Valore='115-125 (su base 100)'
           Perche='L''equivalente AMD della vividezza digitale: stacca i modelli dei nemici dallo sfondo. Oltre 130 i colori si impastano.' }
        @{ Voce='Contrasto'; Valore='102-105'
           Perche='Aiuta a leggere le sagome in ombra senza chiudere del tutto le zone scure.' }
        @{ Voce='Luminosita'''; Valore='0 (alza solo se le mappe scure ti danno fastidio)'
           Perche='Alzarla appiattisce l''immagine invece di rivelare dettaglio.' }
        @{ Voce='Formato colore pixel'; Valore='RGB 4:4:4 Pixel Format PC Standard (Full RGB)'
           Perche='In HDMI AMD a volte imposta YCbCr limitato: neri slavati e bordi sfocati. Questa e'' la voce che lo risolve.' }
        @{ Voce='Profondita'' colore'; Valore='8 bpc (10 solo con HDR)'
           Perche='Tiene la banda del cavo libera per il refresh alto.' }
    )
}

# ---------------------------------------------------------------------------
# Ripristino totale
# ---------------------------------------------------------------------------
function Reset-VtAll {
    $n = 0
    foreach ($t in (Get-VtCatalog)) {
        if (-not (Get-VtEntry $t.Id)) { continue }
        if (Set-VtTweak $t $false) { $n++ }
    }
    Write-VtLog "Ripristino completato: $n tweak riportati allo stato originale." ok
    return $n
}






