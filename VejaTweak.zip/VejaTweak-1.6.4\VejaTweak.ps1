﻿<#
    VejaTweak - interfaccia grafica.

    Tutta la logica sta in VejaTweak.Core.ps1: qui c'e' solo la finestra.
    Ogni interruttore legge il proprio stato reale dal sistema all'apertura,
    quindi quello che vedi acceso e' acceso davvero, non e' una preferenza
    salvata da qualche parte.
#>
[CmdletBinding()]
param(
    # Costruisce la finestra e esce senza mostrarla: serve per il collaudo.
    [switch] $SmokeTest,

    # Preme un interruttore come farebbe l'utente e controlla che il giro
    # completo funzioni. Serve perche' lo smoke test costruisce le pagine ma
    # non clicca mai niente, e il percorso del clic e' proprio quello dove si
    # nascondono gli errori peggiori.
    [switch] $TestToggle,

    # Preme davvero il pulsante "Controlla" nella finestra e riporta cosa
    # scrive. Serve perche' il difetto che bloccava gli aggiornamenti di
    # tutti i clienti si vedeva SOLO passando dal gestore di evento WPF:
    # chiamando la funzione a mano funzionava, ed e' per questo che nessun
    # collaudo l'aveva mai preso.
    [switch] $TestAggiornamento,

    # Finge che esista una versione nuova, per poter vedere com'e' fatto
    # l'avviso senza dover pubblicare per davvero.
    [string] $SimulaAggiornamento,

    # Finge che dei servizi siano fermi, per vedere com'e' fatto l'avviso.
    [switch] $SimulaServiziRotti,

    # Salva le sezioni in PNG invece di aprire il programma. Strumento di
    # sviluppo: serve a guardare com'e' venuta la grafica.
    [switch] $Screenshot,
    [string[]] $ScreenshotSezioni,
    [string] $ScreenshotDir
)

$ErrorActionPreference = 'Stop'

# Parte subito, prima di caricare qualunque cosa: e' il tempo che il cliente
# passa a guardare il desktop dopo aver fatto doppio clic, ed e' la misura che
# mancava. Lo stampa lo smoke test.
$script:SwAvvio = [Diagnostics.Stopwatch]::StartNew()
$script:SwTappa = [Diagnostics.Stopwatch]::StartNew()
$script:Tappe   = @()
function Tappa([string] $nome) {
    if (-not $script:SwTappa) { return }
    $script:Tappe += [pscustomobject]@{ Nome = $nome; Ms = $script:SwTappa.Elapsed.TotalMilliseconds }
    $script:SwTappa.Restart()
}

. (Join-Path $PSScriptRoot 'VejaTweak.Core.ps1')
Tappa 'motore (VejaTweak.Core.ps1)'
. (Join-Path $PSScriptRoot 'VejaTweak.License.ps1')

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

$script:Versione = '1.6.4'

# ---------------------------------------------------------------------------
# Tema
# ---------------------------------------------------------------------------
# Il tema sta in VejaTweak.Theme.xaml, accanto a questo file: cosi' si puo'
# ridisegnare l'interfaccia senza toccare una riga di logica.
$temaPath = Join-Path $PSScriptRoot 'VejaTweak.Theme.xaml'
if (-not (Test-Path $temaPath)) { throw "Tema non trovato: $temaPath" }
$xaml = Get-Content $temaPath -Raw

Tappa 'licenza, WPF, lettura del tema'

$reader = New-Object System.Xml.XmlNodeReader ([xml] $xaml)
$win    = [Windows.Markup.XamlReader]::Load($reader)
Tappa 'costruzione della finestra dal tema'

function Get-El([string] $n) { $win.FindName($n) }

$BarraGruppi = Get-El 'Gruppi'
$Sotto       = Get-El 'Sotto'
$Contenuto  = Get-El 'Contenuto'
$TxtTitolo  = Get-El 'TxtTitolo'
$TxtSub     = Get-El 'TxtSub'
$TxtSearch  = Get-El 'TxtSearch'
$PanelAdmin = Get-El 'PanelAdmin'
$BadgeAdmin = Get-El 'BadgeAdmin'
$TxtAdmin   = Get-El 'TxtAdmin'
(Get-El 'TxtVer').Text = $script:Versione

function New-Brush([string] $hex) {
    [Windows.Media.SolidColorBrush]::new([Windows.Media.ColorConverter]::ConvertFromString($hex))
}

# ---------------------------------------------------------------------------
# Logo
#
# Se accanto all'app c'e' un logo.png lo usiamo; altrimenti disegniamo una V
# vettoriale, cosi' la barra non resta vuota su un'installazione appena
# copiata. Per mettere il proprio logo: .\ImpostaLogo.ps1 -Immagine <file>
# ---------------------------------------------------------------------------
# Icona della finestra, cioe' quella che si vede nella barra delle
# applicazioni e in alt-tab.
#
# Senza questa Windows mostrava l'icona di PowerShell, perche' e' powershell
# che ospita il programma: logo.ico c'era gia' ma veniva usato solo per
# l'icona del collegamento sul desktop, mai per la finestra.
#
# Il secondo pezzo (l'identita' esplicita) serve a non farsi raggruppare
# sotto PowerShell nella barra: senza, Windows considera questa finestra
# "una finestra di PowerShell" e la mette insieme alle altre.
function Set-VtIconaFinestra {
    try {
        Add-Type -Namespace Veja -Name Shell -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
public static extern int SetCurrentProcessExplicitAppUserModelID(string id);
'@ -ErrorAction Stop
        [void] [Veja.Shell]::SetCurrentProcessExplicitAppUserModelID('VejaTweak')
    } catch { }

    # Prima .ico (ha piu' risoluzioni dentro, quindi resta nitida sia nella
    # barra sia in alt-tab), poi .png come ripiego.
    foreach ($n in 'logo.ico', 'logo.png') {
        $f = Join-Path $PSScriptRoot $n
        if (-not (Test-Path -LiteralPath $f)) { continue }
        try {
            $bmp = New-Object Windows.Media.Imaging.BitmapImage
            $bmp.BeginInit()
            $bmp.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.UriSource = New-Object Uri $f
            $bmp.EndInit()
            $win.Icon = $bmp
            Write-VtLog "Icona della finestra presa da $n"
            return
        } catch {
            Write-VtLog "$n non usabile come icona: $($_.Exception.Message)" warn
        }
    }
}

function Set-VtLogo {
    $box = Get-El 'Logo'
    if (-not $box) { return }
    $file = Join-Path $PSScriptRoot 'logo.png'

    if (Test-Path -LiteralPath $file) {
        try {
            $img = New-Object Windows.Controls.Image
            $bmp = New-Object Windows.Media.Imaging.BitmapImage
            $bmp.BeginInit()
            # OnLoad: legge il file e lo chiude subito, altrimenti il PNG
            # resta bloccato e ImpostaLogo.ps1 non potrebbe sovrascriverlo
            # con l'app aperta.
            $bmp.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.UriSource = New-Object Uri $file
            $bmp.EndInit()
            $img.Source = $bmp
            $img.Stretch = 'Uniform'
            [void] $box.Children.Add($img)
            Write-VtLog 'Logo personalizzato caricato da logo.png'
            return
        } catch {
            Write-VtLog "logo.png non leggibile, uso il segno di riserva: $($_.Exception.Message)" warn
        }
    }

    # Riserva vettoriale: una V spezzata, nello stesso rosso dell'accento.
    $path = New-Object Windows.Shapes.Path
    $path.Fill = New-Brush '#FF3B4E'
    $path.Stretch = 'Uniform'
    $path.Data = [Windows.Media.Geometry]::Parse(
        'M 10,8 L 30,8 L 48,62 L 66,8 L 88,8 L 58,92 L 38,92 Z M 74,4 L 96,2 L 62,30 Z')
    [void] $box.Children.Add($path)
}

# ---------------------------------------------------------------------------
# Sezioni
# ---------------------------------------------------------------------------
# Navigazione su due livelli: quattro gruppi in alto, le sezioni del gruppo
# scelto nella riga sotto. Con sedici sezioni una lista unica sarebbe una
# colonna infinita, e comunque la barra laterale la usano tutti.
$script:Gruppi = @('Auto', 'Sistema', 'Prestazioni', 'Giochi', 'Diagnosi')

# La scheda per generare i codici esiste solo dove c'e' la chiave privata,
# cioe' sul PC di chi distribuisce l'app. Sulle copie dei clienti non compare
# proprio, non e' solo disabilitata.
if (Test-VtOwner) { $script:Gruppi += 'Genera Code' }

$script:Sezioni = @(
    @{ Gruppo='Auto';        Cat='#octuning';               Menu='OC / Tuning';       Titolo='OC / Tuning';             Sub='Riepilogo dell''hardware e profili automatici: applicano in blocco le voci che trovi nelle altre sezioni' }
    @{ Gruppo='Auto';        Cat='#nvidia';                 Menu='NVIDIA';            Titolo='Pannello NVIDIA';         Sub='Impostazioni 3D e colore da mettere nel pannello, in ordine di importanza' }
    @{ Gruppo='Auto';        Cat='#amd';                    Menu='AMD';               Titolo='AMD Adrenalin';           Sub='Impostazioni 3D e colore da mettere in AMD Software, in ordine di importanza' }
    @{ Gruppo='Sistema';     Cat='Generali';                Menu='Generali';          Titolo='Ottimizzazioni generali'; Sub='Le voci di base: registrazione in background, modalita'' gioco, app che girano quando non le usi' }
    @{ Gruppo='Sistema';     Cat='Mouse e tastiera';        Menu='Mouse e tastiera';  Titolo='Mouse e tastiera';        Sub='Accelerazione, rapporto 1:1 e i filtri di accessibilita'' che scartano i tuoi input' }
    @{ Gruppo='Sistema';     Cat='#controller';             Menu='Controller';        Titolo='Controller e pad';        Sub='Driver, porte USB e tasto Xbox: perche'' il pad si scollega o non viene riconosciuto' }
    @{ Gruppo='Sistema';     Cat='Interfaccia';             Menu='Interfaccia';       Titolo='Interfaccia di Windows';  Sub='Effetti grafici del desktop che il compositor ricalcola mentre giochi' }
    @{ Gruppo='Sistema';     Cat='Servizi';                 Menu='Servizi';           Titolo='Servizi e attivita''';    Sub='Roba che gira in background e che mentre giochi non ti serve' }
    @{ Gruppo='Sistema';     Cat='#pulizia';                Menu='Pulizia file';      Titolo='Pulizia dei file';        Sub='Recupera spazio su disco, voce per voce, sapendo sempre cosa stai togliendo' }
    @{ Gruppo='Sistema';     Cat='#avvio';                  Menu='Avvio automatico';  Titolo='Programmi all''avvio';    Sub='Cosa parte insieme a Windows e resta acceso mentre giochi' }
    @{ Gruppo='Sistema';     Cat='#essenziali';             Menu='Controllo staff'; Titolo='Servizi che non si toccano'; Sub='Il controllo che fa lo staff dei server di ruolo, piu'' i servizi che devono restare accesi perche'' Windows funzioni' }
    @{ Gruppo='Sistema';     Cat='#reg';                    Menu='Setup .reg';        Titolo='Setup automatico .reg';   Sub='Applica in blocco tutte le voci di registro di una sezione, e le rimette com''erano' }
    @{ Gruppo='Prestazioni'; Cat='CPU e scheduler';         Menu='CPU';               Titolo='CPU e scheduler';         Sub='Come Windows divide il tempo di CPU fra il gioco e tutto il resto' }
    @{ Gruppo='Prestazioni'; Cat='Scheda video';            Menu='GPU';               Titolo='Scheda video';            Sub='Coda di comandi della GPU e scelta della scheda giusta per ogni gioco' }
    @{ Gruppo='Prestazioni'; Cat='Energia';                 Menu='Energia';           Titolo='Energia';                 Sub='Frequenze, parcheggio dei core e risparmio energetico su USB e PCI Express' }
    @{ Gruppo='Prestazioni'; Cat='Memoria e archiviazione'; Menu='Memoria';           Titolo='Memoria e archiviazione'; Sub='Paging del kernel, avvio rapido e scritture inutili sull''SSD' }
    @{ Gruppo='Prestazioni'; Cat='#rete';                   Menu='Rete';              Titolo='Rete';                    Sub='Accorpamento dei pacchetti: conta sul registro dei colpi, non sugli FPS' }
    @{ Gruppo='Prestazioni'; Cat='#stabilita';              Menu='Stabilita'' FPS';   Titolo='Stabilita'' degli FPS';   Sub='Gli scatti non si vedono nella media: qui si misurano DPC e interrupt, e si tolgono le due cause piu'' comuni' }
    @{ Gruppo='Giochi';      Cat='#fortnite';               Menu='Fortnite';          Titolo='Fortnite';                Sub='Scrive direttamente nel file di configurazione del gioco: preset, limite FPS, risoluzione stretched' }
    @{ Gruppo='Giochi';      Cat='#valorant';               Menu='Valorant';          Titolo='Valorant';                Sub='Qualita'' grafica, Reflex e limite FPS. Vanguard non viene toccato in nessun modo' }
    @{ Gruppo='Giochi';      Cat='#r6';                     Menu='Rainbow Six';       Titolo='Rainbow Six Siege';       Sub='Preset competitivo sul GameSettings.ini di Ubisoft' }
    @{ Gruppo='Giochi';      Cat='#fivem';                  Menu='FiveM';             Titolo='FiveM / GTA V';           Sub='Le voci che tolgono lavoro alla CPU: densita'' citta'', pedoni, LOD, ombre' }
    @{ Gruppo='Giochi';      Cat='#discord';                Menu='Discord';           Titolo='Discord';                 Sub='Sei processi e quasi due giga di RAM accanto al gioco: cosa si puo'' davvero spegnere' }
    @{ Gruppo='Giochi';      Cat='#giochi';                 Menu='Tutti i giochi';    Titolo='Giochi';                  Sub='Giochi rilevati sul PC e impostazioni consigliate dentro ognuno' }
    @{ Gruppo='Diagnosi';    Cat='#salute';                 Menu='Salute del PC';     Titolo='Salute del PC';           Sub='Crash del driver video, errori hardware, spegnimenti anomali, dischi: i sintomi che nessun tweak puo'' curare' }
    @{ Gruppo='Diagnosi';    Cat='#diagnosi';               Menu='Analisi del PC';    Titolo='Diagnosi';                Sub='I problemi che nessun interruttore puo'' risolvere al posto tuo' }
    @{ Gruppo='Diagnosi';    Cat='#bios';                   Menu='BIOS / UEFI';       Titolo='BIOS / UEFI';             Sub='Le impostazioni del firmware: cosa e'' sbagliato, dove sta la voce sulla tua scheda, e un pulsante per riavviare nel BIOS' }
    @{ Gruppo='Diagnosi';    Cat='#aggiornamenti';          Menu='Aggiornamenti';     Titolo='Aggiornamenti';           Sub='Controlla se esiste una versione piu'' recente, verificandone la firma prima di scaricarla' }
    @{ Gruppo='Genera Code'; Cat='#genera';                 Menu='Genera codice';     Titolo='Genera codice';           Sub='Crea i codici di attivazione da dare a chi scarica VejaTweak' }
)

# Sulle copie dei clienti la pagina di generazione non deve nemmeno esistere
# nell'elenco: senza scheda in alto sarebbe gia' irraggiungibile, ma toglierla
# del tutto evita che un domani qualche scorciatoia ci arrivi lo stesso.
if (-not (Test-VtOwner)) {
    $script:Sezioni = @($script:Sezioni | Where-Object { $_.Cat -ne '#genera' })
}

$script:SezioneAttiva = '#octuning'
$script:GruppoAttivo  = 'Sistema'
$script:BottoniGruppo = @{}
$script:BottoniSotto  = @{}

# ---------------------------------------------------------------------------
# Costruzione delle card
# ---------------------------------------------------------------------------
function New-Badge([string] $testo, [string] $fg, [string] $bg, [string] $bd) {
    $b = New-Object Windows.Controls.Border
    $b.CornerRadius = [Windows.CornerRadius]::new(6)
    $b.Background   = New-Brush $bg
    $b.BorderBrush  = New-Brush $bd
    $b.BorderThickness = [Windows.Thickness]::new(1)
    $b.Padding      = [Windows.Thickness]::new(8, 2, 8, 3)
    $b.Margin       = [Windows.Thickness]::new(0, 0, 6, 0)
    $b.VerticalAlignment = 'Center'
    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $testo; $t.FontSize = 10; $t.Foreground = New-Brush $fg
    $b.Child = $t
    $b
}

# Guscio comune a tutte le card: cornice, striscia di stato a sinistra e
# reazione al passaggio del mouse. Restituisce il contenitore in cui infilare
# il contenuto vero e proprio.
function New-CardShell([string] $coloreStriscia) {
    # Senza bordo. Il bordo serviva a staccare la card dal fondo quando i due
    # colori erano quasi uguali; ora che il fondo e' piu' scuro la card si
    # stacca da sola, e togliere il contorno leva una riga di disegno da ogni
    # voce dell'elenco. Con 'nessuno' sparisce anche il segno laterale.
    $card = New-Object Windows.Controls.Border
    $card.Background      = New-Brush '#2A2A37'
    $card.CornerRadius    = [Windows.CornerRadius]::new(12)
    $card.Margin          = [Windows.Thickness]::new(0, 0, 0, 9)

    # Bordo con il lato ALTO piu' chiaro degli altri: e' il modo in cui la
    # luce cade su un oggetto reale, e basta questo per far sembrare la card
    # un pezzo di materiale invece di un rettangolo colorato.
    $bordo = New-Object Windows.Media.LinearGradientBrush
    $bordo.StartPoint = New-Object Windows.Point (0, 0)
    $bordo.EndPoint   = New-Object Windows.Point (0, 1)
    [void] $bordo.GradientStops.Add((New-Object Windows.Media.GradientStop ([Windows.Media.ColorConverter]::ConvertFromString('#5C5C72'), 0)))
    [void] $bordo.GradientStops.Add((New-Object Windows.Media.GradientStop ([Windows.Media.ColorConverter]::ConvertFromString('#434352'), 1)))
    $card.BorderBrush     = $bordo
    $card.BorderThickness = [Windows.Thickness]::new(1)

    # Ombra sotto: e' quello che stacca la card dal fondo e da' la sensazione
    # di profondita' che mancava. Sfocatura larga e opacita' bassa, altrimenti
    # sembra un riquadro con il contorno nero.
    $ombra = New-Object Windows.Media.Effects.DropShadowEffect
    $ombra.Color = [Windows.Media.Colors]::Black
    $ombra.BlurRadius = 16
    $ombra.ShadowDepth = 3
    $ombra.Direction = 270
    $ombra.Opacity = 0.45
    $card.Effect = $ombra

    # La schiarita sotto il puntatore e' SFUMATA, non a scatto: 120 ms di
    # transizione bastano a togliere quella sensazione di scatto secco che
    # rendeva la pagina nervosa quando ci passavi sopra scorrendo.
    $card.Background = New-Object Windows.Media.SolidColorBrush ([Windows.Media.Color]::FromRgb(0x2A, 0x2A, 0x37))
    $card.Add_MouseEnter({
        $a = New-Object Windows.Media.Animation.ColorAnimation
        $a.To = [Windows.Media.Color]::FromRgb(0x35, 0x35, 0x44)
        $a.Duration = [Windows.Duration]::new([TimeSpan]::FromMilliseconds(120))
        $this.Background.BeginAnimation([Windows.Media.SolidColorBrush]::ColorProperty, $a)
    })
    $card.Add_MouseLeave({
        $a = New-Object Windows.Media.Animation.ColorAnimation
        $a.To = [Windows.Media.Color]::FromRgb(0x2A, 0x2A, 0x37)
        $a.Duration = [Windows.Duration]::new([TimeSpan]::FromMilliseconds(160))
        $this.Background.BeginAnimation([Windows.Media.SolidColorBrush]::ColorProperty, $a)
    })

    $corpo = New-Object Windows.Controls.Grid
    $s1 = New-Object Windows.Controls.ColumnDefinition; $s1.Width = [Windows.GridLength]::Auto
    $s2 = New-Object Windows.Controls.ColumnDefinition
    $s2.Width = New-Object Windows.GridLength (1, [Windows.GridUnitType]::Star)
    $corpo.ColumnDefinitions.Add($s1); $corpo.ColumnDefinitions.Add($s2)

    # L'accento non e' piu' una barra alta quanto tutta la card: era il pezzo
    # che rendeva pesante una pagina con dieci voci, dieci sbarre rosse in
    # colonna. Ora e' un segno breve e arrotondato, staccato dai bordi: dice
    # la stessa cosa senza gridarla.
    $striscia = New-Object Windows.Controls.Border
    $striscia.Width = 3
    $striscia.Height = 22
    $striscia.VerticalAlignment = 'Top'
    $striscia.CornerRadius = [Windows.CornerRadius]::new(2)
    $striscia.Margin = [Windows.Thickness]::new(12, 21, 0, 0)
    if ($coloreStriscia -eq 'nessuno') {
        # Sulle voci con interruttore il segno non aggiungeva niente: lo stato
        # lo dice gia' la levetta, e ripeterlo su ogni riga faceva una colonna
        # di trattini rossi che era il vero peso della pagina.
        $striscia.Visibility = 'Collapsed'
        $striscia.Width = 0
    } else {
        $striscia.Background = New-Brush $coloreStriscia
    }
    [Windows.Controls.Grid]::SetColumn($striscia, 0)
    [void] $corpo.Children.Add($striscia)

    $card.Child = $corpo
    return [pscustomobject]@{ Card = $card; Corpo = $corpo; Striscia = $striscia }
}

function New-TweakCard($tweak) {
    $attivo = [bool] (Get-VtState $tweak)
    $shell = New-CardShell 'nessuno'
    $card = $shell.Card

    $grid = New-Object Windows.Controls.Grid
    $grid.Margin = [Windows.Thickness]::new(18, 15, 18, 15)
    [Windows.Controls.Grid]::SetColumn($grid, 1)
    $c1 = New-Object Windows.Controls.ColumnDefinition
    $c1.Width = New-Object Windows.GridLength (1, [Windows.GridUnitType]::Star)
    $c2 = New-Object Windows.Controls.ColumnDefinition
    $c2.Width = [Windows.GridLength]::Auto
    $grid.ColumnDefinitions.Add($c1); $grid.ColumnDefinitions.Add($c2)
    [void] $shell.Corpo.Children.Add($grid)

    $sp = New-Object Windows.Controls.StackPanel
    [Windows.Controls.Grid]::SetColumn($sp, 0)

    # Titolo in bianco, non colorato: il colore lo porta l'accento laterale.
    $tit = New-Object Windows.Controls.TextBlock
    $tit.Text = $tweak.Nome; $tit.FontSize = 14.5; $tit.FontWeight = 'SemiBold'
    $tit.Foreground = New-Brush '#F7F7FA'; $tit.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($tit)

    # Interlinea piu' larga del corpo: due righe attaccate sono la cosa che
    # fa sembrare "compresso" un testo, anche quando lo spazio non manca.
    $des = New-Object Windows.Controls.TextBlock
    $des.Text = $tweak.Desc; $des.FontSize = 12; $des.Foreground = New-Brush '#ADADBA'
    $des.LineHeight = 18; $des.LineStackingStrategy = 'BlockLineHeight'
    $des.TextWrapping = 'Wrap'; $des.Margin = [Windows.Thickness]::new(0, 5, 24, 0)
    [void] $sp.Children.Add($des)

    # Etichette: rischio e riavvio
    $badges = New-Object Windows.Controls.StackPanel
    $badges.Orientation = 'Horizontal'
    $badges.Margin = [Windows.Thickness]::new(0, 10, 0, 0)
    if ($tweak.Rischio -eq 'alto') {
        [void] $badges.Children.Add((New-Badge 'compromesso vero' '#F06A6A' '#3A0F16' '#5C2028'))
    } elseif ($tweak.Rischio -eq 'medio') {
        [void] $badges.Children.Add((New-Badge 'da valutare' '#E5A94E' '#3A2408' '#5C4A12'))
    }
    if ($tweak.Reboot) {
        [void] $badges.Children.Add((New-Badge 'richiede riavvio' '#E5A94E' '#3A2408' '#7A3410'))
    }
    if ($badges.Children.Count -gt 0) { [void] $sp.Children.Add($badges) }

    # Dettagli richiudibili
    # In ambra su ogni singola card era la cosa piu' rumorosa della pagina:
    # dieci voci, dieci scritte colorate identiche. Ora resta un invito
    # discreto, e il colore lo prende solo quando ci passi sopra.
    $exp = New-Object Windows.Controls.Expander
    $exp.Header = 'Perche'' conta'
    $exp.Foreground = New-Brush '#A2989A'
    $exp.FontSize = 11
    $exp.Margin = [Windows.Thickness]::new(0, 11, 0, 0)
    $exp.Add_MouseEnter({ $this.Foreground = New-Brush '#E5A94E' })
    $exp.Add_MouseLeave({ $this.Foreground = New-Brush '#A2989A' })
    $det = New-Object Windows.Controls.StackPanel
    $det.Margin = [Windows.Thickness]::new(0, 8, 24, 2)

    $why = New-Object Windows.Controls.TextBlock
    $why.Text = $tweak.Perche; $why.FontSize = 11.5; $why.TextWrapping = 'Wrap'
    $why.LineHeight = 18; $why.LineStackingStrategy = 'BlockLineHeight'
    $why.Foreground = New-Brush '#9494A2'
    [void] $det.Children.Add($why)

    if ($tweak.Warn) {
        $w = New-Object Windows.Controls.TextBlock
        $w.Text = 'Attenzione: ' + $tweak.Warn
        $w.FontSize = 11; $w.TextWrapping = 'Wrap'
        $w.Foreground = New-Brush '#E5A94E'
        $w.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
        [void] $det.Children.Add($w)
    }
    $exp.Content = $det
    [void] $sp.Children.Add($exp)
    [void] $grid.Children.Add($sp)

    # Interruttore in alto a destra, non centrato: con le descrizioni lunghe
    # centrarlo lo faceva ballare a meta' card.
    $tog = New-Object Windows.Controls.CheckBox
    $tog.Style = $win.FindResource('Toggle')
    $tog.VerticalAlignment = 'Top'
    $tog.Margin = [Windows.Thickness]::new(0, 2, 0, 0)
    [Windows.Controls.Grid]::SetColumn($tog, 1)
    $tog.IsChecked = $attivo
    $tog.Tag = $tweak
    # Riferimento diretto alla striscia della propria card, cosi' il gestore
    # non deve andarsela a cercare risalendo l'albero degli elementi.
    $tog | Add-Member -NotePropertyName Striscia -NotePropertyValue $shell.Striscia -Force
    [void] $grid.Children.Add($tog)

    # Il gestore usa $tog.Tag invece di catturare la variabile del ciclo:
    # cosi' ogni card lavora sul proprio tweak senza sorprese di scoping.
    # Il lavoro non parte subito: prima si lascia disegnare l'animazione della
    # levetta, poi si blocca pure il thread. Sembra una sottigliezza ma e'
    # tutta la differenza fra "risponde subito" e "e' impallato": prima il
    # clic congelava la finestra a meta' scorrimento del pomello, e sembrava
    # che il programma ci mettesse un secondo anche quando ce ne metteva un
    # decimo.
    $handler = {
        param($sender, $e)
        $sender.IsEnabled = $false
        [void] $win.Dispatcher.BeginInvoke(
            [Windows.Threading.DispatcherPriority]::Background,
            [action] { Invoke-VtToggle $sender }.GetNewClosure())
    }
    $tog.Add_Click($handler)

    # Il grid e' gia' stato agganciato al corpo della card piu' sopra: farlo
    # una seconda volta fa fallire tutta la pagina con "questo elemento e'
    # gia' figlio di un altro".
    return $card
}

# Il lavoro vero dell'interruttore, staccato dal gestore del clic.
function Invoke-VtToggle($sender) {
    try {
        try {
        $t  = $sender.Tag
        $on = [bool] $sender.IsChecked
        $win.Cursor = [Windows.Input.Cursors]::Wait
        try {
            $ok = Set-VtTweak $t $on

            # Rilettura dal sistema, sempre. Prima si dava per buono l'esito
            # della scrittura, e c'era un caso in cui l'interruttore mentiva:
            # se il valore che c'era PRIMA coincide con quello che il tweak
            # imposta (mouse-trails su un PC dove la scia era gia' spenta),
            # rimetterlo com'era non cambia niente e la voce resta attiva -
            # ma la levetta era gia' andata su "spento". Assegnare IsChecked
            # da codice non rilancia Click, quindi non cicla.
            $reale = [bool] (Get-VtState $t)
            $sender.IsChecked = $reale

            if (-not $ok) {
                Show-Toast "Non riuscito: $($t.Nome). Apri il registro attivita' per il dettaglio."
            } elseif ($reale -ne $on) {
                $spiega = if ($on) {
                    "L'ho scritto, ma rileggendolo il sistema lo riporta ancora come spento: probabilmente qualcosa lo ha rimesso subito com'era."
                } else {
                    "Su questo PC il valore che c'era prima e' lo stesso che imposta il tweak, quindi rimetterlo com'era non cambia niente: la voce resta di fatto attiva. Non e' un errore, e' che qui non c'era niente da annullare."
                }
                Show-Toast "$($t.Nome)`n`n$spiega"
            } elseif ($t.Reboot) {
                Show-Toast "$($t.Nome): ha effetto dopo il riavvio del PC."
            }
        } finally {
            $win.Cursor = $null
        }
        } catch {
            # Girando dentro il dispatcher, un'eccezione non gestita farebbe
            # cadere l'intera finestra invece di una sola voce.
            $sender.IsChecked = -not [bool] $sender.IsChecked
            Write-VtLog "Interruttore '$($sender.Tag.Id)': $($_.Exception.Message)" err
            Show-Toast "Non riuscito: $($sender.Tag.Nome).`n`n$($_.Exception.Message)"
        }
    } finally {
        # Riabilitare sta nel finally: se qualcosa esplode, l'interruttore non
        # deve restare morto per sempre.
        $sender.IsEnabled = $true
    }
}

function New-InfoCard([string] $titolo, [string] $testo, [string] $colore = '#E5A94E') {
    $shell = New-CardShell $colore
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(18, 15, 20, 15)
    [Windows.Controls.Grid]::SetColumn($sp, 1)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $titolo; $t.FontSize = 13; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush $colore; $t.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = $testo; $d.FontSize = 12; $d.Foreground = New-Brush '#ADADBA'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
    [void] $sp.Children.Add($d)

    [void] $shell.Corpo.Children.Add($sp)
    $shell.Card
}

# Aggiunge al pannello l'interruttore di un profilo NVIDIA per singolo gioco
# piu' l'elenco di cosa ci finisce dentro. Sta in una funzione perche' lo
# stesso blocco serve nella pagina NVIDIA e nella pagina del gioco.
function Add-CardProfiloNv($pannello, [string] $id) {
    $t = Get-VtCatalog | Where-Object { $_.Id -eq $id } | Select-Object -First 1
    if (-not $t) { return $false }
    [void] $pannello.Children.Add((New-TweakCard $t))

    $def = Get-VtNvProfilo $id
    if ($def) {
        $voci  = @(Get-VtNvVociValide $def)
        $righe = @($voci | ForEach-Object { "  $($_.Voce)  ->  $($_.Val_)" })
        $coda  = if ($voci.Count -lt @($def.Voci).Count) {
            "`n`nDelle $(@($def.Voci).Count) voci del file, $($voci.Count) le conosce il driver che hai installato adesso. Le altre le salto invece di far fallire tutto il profilo."
        } else { '' }
        [void] $pannello.Children.Add((New-InfoCard "Cosa entra nel profilo $($def.Gioco)" `
            (($righe -join "`n") + $coda) '#ADADBA'))
    }
    return $true
}

# Card con un pulsante invece dell'interruttore: per le azioni che si fanno
# una volta e non hanno uno stato "acceso/spento".
function New-ActionCard([string] $titolo, [string] $testo, [string] $pulsante, $azione, [string] $colore = '#FF3B4E',
                        [string] $pulsante2 = '', $azione2 = $null) {
    $shell = New-CardShell $colore
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(18, 15, 20, 15)
    [Windows.Controls.Grid]::SetColumn($sp, 1)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $titolo; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush '#F7F7FA'; $t.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = $testo; $d.FontSize = 12; $d.Foreground = New-Brush '#ADADBA'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 20, 0)
    [void] $sp.Children.Add($d)

    # I pulsanti stanno su una riga sola: due card separate per "fai" e
    # "disfa" raddoppiavano l'altezza della pagina senza aggiungere niente.
    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $riga.Margin = [Windows.Thickness]::new(0, 14, 0, 0)

    $b = New-Object Windows.Controls.Button
    $b.Style = $win.FindResource($(if ($colore -eq '#FF3B4E') { 'BtnAccent' } else { 'Btn' }))
    $b.Content = $pulsante
    $b.Add_Click($azione)
    [void] $riga.Children.Add($b)

    if ($pulsante2 -and $azione2) {
        $b2 = New-Object Windows.Controls.Button
        $b2.Style = $win.FindResource('Btn')
        $b2.Content = $pulsante2
        $b2.Margin = [Windows.Thickness]::new(10, 0, 0, 0)
        $b2.Add_Click($azione2)
        [void] $riga.Children.Add($b2)
    }

    [void] $sp.Children.Add($riga)
    [void] $shell.Corpo.Children.Add($sp)
    $shell.Card
}

# Intestazione di un blocco dentro una pagina.
#
# Prima ogni pagina se la costruiva a mano con margini leggermente diversi:
# bastava quello per far sembrare la finestra fatta a pezzi. Qui il ritmo e'
# uno solo per tutte.
function Add-Intestazione($pannello, [string] $titolo, [string] $sotto = '') {
    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $titolo
    $t.FontSize = 16; $t.FontWeight = 'Bold'; $t.Foreground = New-Brush '#F7F7FA'
    $t.Margin = [Windows.Thickness]::new(2, 22, 0, $(if ($sotto) { 3 } else { 9 }))
    [void] $pannello.Children.Add($t)

    if ($sotto) {
        $s = New-Object Windows.Controls.TextBlock
        $s.Text = $sotto
        $s.FontSize = 12; $s.Foreground = New-Brush '#ADADBA'
        $s.TextWrapping = 'Wrap'; $s.MaxWidth = 820
        $s.HorizontalAlignment = 'Left'
        $s.Margin = [Windows.Thickness]::new(2, 0, 0, 10)
        [void] $pannello.Children.Add($s)
    }
}

# Card con un menu a tendina e un pulsante: per le azioni che hanno bisogno
# di una scelta prima di partire.
function New-ChoiceCard([string] $titolo, [string] $testo, $voci, [string] $pulsante, $azione) {
    $shell = New-CardShell '#FF3B4E'
    $card = $shell.Card
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(18, 15, 20, 15)
    [Windows.Controls.Grid]::SetColumn($sp, 1)
    [void] $shell.Corpo.Children.Add($sp)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $titolo; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush '#F7F7FA'; $t.TextWrapping = 'Wrap'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = $testo; $d.FontSize = 12; $d.Foreground = New-Brush '#ADADBA'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 20, 0)
    [void] $sp.Children.Add($d)

    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $riga.Margin = [Windows.Thickness]::new(0, 14, 0, 0)

    $cb = New-Object Windows.Controls.ComboBox
    $cb.Width = 320
    $cb.Padding = [Windows.Thickness]::new(10, 6, 10, 6)
    $cb.VerticalContentAlignment = 'Center'
    foreach ($v in $voci) { [void] $cb.Items.Add($v.Nome) }
    $cb.SelectedIndex = 0
    $cb.Tag = $voci
    [void] $riga.Children.Add($cb)

    $b = New-Object Windows.Controls.Button
    $b.Style = $win.FindResource('BtnAccent')
    $b.Content = $pulsante
    $b.Margin = [Windows.Thickness]::new(12, 0, 0, 0)
    $b.Tag = $cb
    $b.Add_Click($azione)
    [void] $riga.Children.Add($b)

    [void] $sp.Children.Add($riga)
    $card
}

function Show-Toast([string] $msg) {
    # Durante il collaudo automatico non si aprono finestre modali: nessuno
    # le chiuderebbe, e il test resterebbe fermo li' a chiedersi perche' il
    # programma non risponde. (E' successo: venti secondi di finto ritardo.)
    if ($script:SenzaDialoghi) { Write-VtLog "Messaggio: $($msg -replace '\r?\n', ' / ')"; return }
    [void] [Windows.MessageBox]::Show($msg, 'VejaTweak', 'OK', 'Information')
}

# Card con due caselle numeriche per una risoluzione scritta a mano.
# La usano tutte le pagine dei giochi: stessa validazione, stessi messaggi,
# nessun gioco che accetta un valore che un altro rifiuta.
function New-RisoluzioneCard([string] $gioco, [int] $xAttuale, [int] $yAttuale, $azione) {
    $shell = New-CardShell '#FF3B4E'
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(18, 15, 20, 15)
    [Windows.Controls.Grid]::SetColumn($sp, 1)
    [void] $shell.Corpo.Children.Add($sp)

    $t = New-Object Windows.Controls.TextBlock
    $t.Text = 'Risoluzione personalizzata'; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
    $t.Foreground = New-Brush '#F7F7FA'
    [void] $sp.Children.Add($t)

    $d = New-Object Windows.Controls.TextBlock
    $d.Text = "Scrivi i numeri che vuoi: qualsiasi stretched, non solo quelle dell'elenco. Adesso $gioco e' a $xAttuale" + 'x' + "$yAttuale ($(Get-VtFormato $xAttuale $yAttuale))."
    $d.FontSize = 12; $d.Foreground = New-Brush '#ADADBA'
    $d.TextWrapping = 'Wrap'; $d.Margin = [Windows.Thickness]::new(0, 8, 20, 0)
    [void] $sp.Children.Add($d)

    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $riga.Margin = [Windows.Thickness]::new(0, 14, 0, 0)

    function New-Casella($valore) {
        $tb = New-Object Windows.Controls.TextBox
        $tb.Text = "$valore"
        $tb.Width = 90; $tb.FontSize = 14
        $tb.Background = New-Brush '#1C070A'
        $tb.Foreground = New-Brush '#F7F7FA'
        $tb.CaretBrush = New-Brush '#FF3B4E'
        $tb.BorderBrush = New-Brush '#3D1219'
        $tb.Padding = [Windows.Thickness]::new(10, 7, 10, 7)
        $tb.VerticalContentAlignment = 'Center'
        $tb
    }
    $fx = New-Casella $xAttuale
    $fy = New-Casella $yAttuale
    [void] $riga.Children.Add($fx)

    $per = New-Object Windows.Controls.TextBlock
    $per.Text = 'x'; $per.FontSize = 15; $per.Foreground = New-Brush '#7A7A88'
    $per.Margin = [Windows.Thickness]::new(10, 0, 10, 0); $per.VerticalAlignment = 'Center'
    [void] $riga.Children.Add($per)
    [void] $riga.Children.Add($fy)

    $btn = New-Object Windows.Controls.Button
    $btn.Style = $win.FindResource('BtnAccent')
    $btn.Content = 'Applica'
    $btn.Margin = [Windows.Thickness]::new(14, 0, 0, 0)
    [void] $riga.Children.Add($btn)
    [void] $sp.Children.Add($riga)

    $esito = New-Object Windows.Controls.TextBlock
    $esito.FontSize = 11; $esito.TextWrapping = 'Wrap'
    $esito.Margin = [Windows.Thickness]::new(0, 10, 20, 0)
    $esito.Foreground = New-Brush '#ADADBA'
    [void] $sp.Children.Add($esito)

    $btn.Add_Click({
        $v = Test-VtRisoluzione $fx.Text $fy.Text
        if (-not $v.Valida) {
            $esito.Foreground = New-Brush '#F06A6A'
            $esito.Text = $v.Motivo
            return
        }
        $win.Cursor = [Windows.Input.Cursors]::Wait
        try {
            & $azione $v.X $v.Y
            $esito.Foreground = New-Brush '#57C98A'
            $esito.Text = "Impostata $($v.X)x$($v.Y) - $(Get-VtFormato $v.X $v.Y)." +
                          $(if ($v.Avviso) { "`n$($v.Avviso)" } else { '' })
            Show-Toast "$gioco impostato a $($v.X)x$($v.Y).$(if ($v.Avviso) { "`n`n$($v.Avviso)" })"
        } catch {
            $esito.Foreground = New-Brush '#F06A6A'
            $esito.Text = $_.Exception.Message
        } finally { $win.Cursor = $null }
    }.GetNewClosure())

    $shell.Card
}

# ---------------------------------------------------------------------------
# Finestra di attivazione
#
# Compare solo al primo avvio su un PC che non ha ancora un codice valido.
# Dopo, l'attivazione viene risalvata e rivalidata in silenzio a ogni apertura.
# ---------------------------------------------------------------------------
function Show-VtAttivazione {
    $w = New-Object Windows.Window
    $w.Title = 'VejaTweak - attivazione'
    $w.Width = 620; $w.SizeToContent = 'Height'
    $w.WindowStartupLocation = 'CenterScreen'
    $w.ResizeMode = 'NoResize'
    $w.Background = New-Brush '#140507'

    $sp = New-Object Windows.Controls.StackPanel
    $sp.Margin = [Windows.Thickness]::new(28, 24, 28, 24)

    function Add-Testo($testo, $size, $colore, $bold, $top) {
        $t = New-Object Windows.Controls.TextBlock
        $t.Text = $testo; $t.FontSize = $size; $t.Foreground = New-Brush $colore
        $t.TextWrapping = 'Wrap'; $t.Margin = [Windows.Thickness]::new(0, $top, 0, 0)
        if ($bold) { $t.FontWeight = 'Bold' }
        [void] $sp.Children.Add($t)
    }

    Add-Testo 'VejaTweak' 24 '#F7F7FA' $true 0
    Add-Testo 'Questa copia non e'' ancora attivata. Serve un codice, una volta sola: dalla prossima apertura non te lo chiede piu''.' 12 '#ADADBA' $false 8

    Add-Testo 'ID di questo PC (mandalo a chi ti ha dato il programma)' 11 '#7A7A88' $false 20
    $idBox = New-Object Windows.Controls.TextBox
    $idBox.Text = Get-VtMachineId
    $idBox.IsReadOnly = $true
    $idBox.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
    $idBox.FontSize = 16
    $idBox.Background = New-Brush '#1C070A'
    $idBox.Foreground = New-Brush '#E5A94E'
    $idBox.BorderBrush = New-Brush '#3D1219'
    $idBox.Padding = [Windows.Thickness]::new(12, 9, 12, 9)
    $idBox.Margin = [Windows.Thickness]::new(0, 6, 0, 0)
    [void] $sp.Children.Add($idBox)

    $btnCopiaId = New-Object Windows.Controls.Button
    $btnCopiaId.Style = $win.FindResource('Btn')
    $btnCopiaId.Content = 'Copia ID'
    $btnCopiaId.HorizontalAlignment = 'Left'
    $btnCopiaId.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
    $btnCopiaId.Add_Click({ try { [Windows.Clipboard]::SetText($idBox.Text) } catch { } }.GetNewClosure())
    [void] $sp.Children.Add($btnCopiaId)

    Add-Testo 'Codice di attivazione' 11 '#7A7A88' $false 20
    $codeBox = New-Object Windows.Controls.TextBox
    $codeBox.AcceptsReturn = $true
    $codeBox.TextWrapping = 'Wrap'
    $codeBox.Height = 90
    $codeBox.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
    $codeBox.FontSize = 12
    $codeBox.Background = New-Brush '#1C070A'
    $codeBox.Foreground = New-Brush '#F7F7FA'
    $codeBox.CaretBrush = New-Brush '#FF3B4E'
    $codeBox.BorderBrush = New-Brush '#3D1219'
    $codeBox.Padding = [Windows.Thickness]::new(12, 9, 12, 9)
    $codeBox.Margin = [Windows.Thickness]::new(0, 6, 0, 0)
    $codeBox.VerticalScrollBarVisibility = 'Auto'
    [void] $sp.Children.Add($codeBox)

    $msg = New-Object Windows.Controls.TextBlock
    $msg.FontSize = 12; $msg.TextWrapping = 'Wrap'
    $msg.Margin = [Windows.Thickness]::new(0, 12, 0, 0)
    $msg.Foreground = New-Brush '#F06A6A'
    [void] $sp.Children.Add($msg)

    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $riga.Margin = [Windows.Thickness]::new(0, 18, 0, 0)

    $btnOk = New-Object Windows.Controls.Button
    $btnOk.Style = $win.FindResource('BtnAccent')
    $btnOk.Content = 'Attiva'
    $btnOk.Margin = [Windows.Thickness]::new(0, 0, 10, 0)
    [void] $riga.Children.Add($btnOk)

    $btnEsci = New-Object Windows.Controls.Button
    $btnEsci.Style = $win.FindResource('Btn')
    $btnEsci.Content = 'Esci'
    [void] $riga.Children.Add($btnEsci)
    [void] $sp.Children.Add($riga)

    $w.Content = $sp
    $script:LicOk = $false

    $btnOk.Add_Click({
        $r = Test-VtCode $codeBox.Text
        if ($r.Valido) {
            Save-VtAttivazione ($codeBox.Text.Trim())
            $script:LicOk = $true
            Write-VtLog "Attivazione riuscita (serial $($r.Serial))" ok
            $w.Close()
        } else {
            $msg.Text = $r.Motivo
            Write-VtLog "Attivazione rifiutata: $($r.Motivo)" warn
        }
    }.GetNewClosure())

    $btnEsci.Add_Click({ $w.Close() }.GetNewClosure())

    [void] $w.ShowDialog()
    return $script:LicOk
}

# ---------------------------------------------------------------------------
# Pagine
# ---------------------------------------------------------------------------
# Riempie la seconda riga con le sezioni del gruppo scelto.
function Build-Sotto([string] $gruppo) {
    $script:GruppoAttivo = $gruppo
    $Sotto.Children.Clear()
    $script:BottoniSotto = @{}

    foreach ($s in ($script:Sezioni | Where-Object { $_.Gruppo -eq $gruppo })) {
        $cat = $s.Cat
        $b = New-Object Windows.Controls.Button
        $b.Style   = $win.FindResource('SottoBtn')
        if ($cat -eq '#aggiornamenti' -and $script:Sync.Nuova) {
            # Pallino accanto al nome: si vede senza leggere.
            $r = New-Object Windows.Controls.StackPanel
            $r.Orientation = 'Horizontal'
            $t = New-Object Windows.Controls.TextBlock
            $t.Text = $s.Menu; $t.VerticalAlignment = 'Center'
            [void] $r.Children.Add($t)
            $pa = New-Object Windows.Shapes.Ellipse
            $pa.Width = 7; $pa.Height = 7
            $pa.Fill = New-Brush '#FF3B4E'
            $pa.VerticalAlignment = 'Center'
            $pa.Margin = [Windows.Thickness]::new(8, 0, 0, 0)
            [void] $r.Children.Add($pa)
            $b.Content = $r
        } else {
            $b.Content = $s.Menu
        }
        $b.Add_Click({ Show-Sezione $cat }.GetNewClosure())
        $script:BottoniSotto[$s.Cat] = $b
        [void] $Sotto.Children.Add($b)
    }

    foreach ($k in $script:BottoniGruppo.Keys) {
        # Lo stile usa Tag='on' per accendere l'indicatore ambra: cambiare il
        # Tag fa partire da solo lo storyboard definito nel tema.
        $script:BottoniGruppo[$k].Tag = if ($k -eq $gruppo) { 'on' } else { 'off' }
    }
}

# Accende il pulsante in alto e il pallino nella colonna. Chiamata una volta
# sola, quando il controllo in background ha finito.
function Show-VtAvvisoAggiornamento([string] $nuova) {
    $b = Get-El 'BtnAggiorna'

    $riga = New-Object Windows.Controls.StackPanel
    $riga.Orientation = 'Horizontal'
    $pallino = New-Object Windows.Shapes.Ellipse
    $pallino.Width = 7; $pallino.Height = 7
    $pallino.Fill = New-Brush '#FF3B4E'
    $pallino.VerticalAlignment = 'Center'
    $pallino.Margin = [Windows.Thickness]::new(0, 0, 8, 0)
    [void] $riga.Children.Add($pallino)
    $txt = New-Object Windows.Controls.TextBlock
    $txt.Text = "Versione $nuova disponibile"
    $txt.VerticalAlignment = 'Center'
    [void] $riga.Children.Add($txt)

    $b.Content = $riga
    $b.Visibility = 'Visible'
    $b.Add_Click({ Show-Sezione '#aggiornamenti' })

    # L'avviso grande, sopra il titolo: e' la prima cosa che si vede aprendo
    # il programma, ed e' li' che sta il pulsante per installare.
    (Get-El 'TxtAggiorna').Text = "E' disponibile VejaTweak $nuova (tu hai la $($script:Versione))"
    (Get-El 'TxtAggiornaSub').Text = "Il pacchetto viene scaricato, ne viene verificata la firma e poi l'impronta. Attivazione, backup e impostazioni restano dove sono."
    (Get-El 'PanelAggiorna').Visibility = 'Visible'

    Write-VtLog "Disponibile la versione $nuova (installata $($script:Versione))" ok
}

# Scarica e installa, e poi si riavvia da solo se glielo dici. Il riavvio
# serve perche' i file appena sostituiti sono quelli che il programma sta
# gia' eseguendo: finche' non riparte, sei ancora sulla versione vecchia.
function Invoke-VtInstallaAggiornamento {
    $url = Get-VtUrlAggiornamenti
    if (-not $url) { Show-Toast 'Manca l''indirizzo degli aggiornamenti.'; return }
    $ver = "$($script:Versione)"

    $btn = Get-El 'BtnInstallaOra'
    $btn.IsEnabled = $false
    $btn.Content = 'Installo...'
    $win.Cursor = [Windows.Input.Cursors]::Wait
    try {
        $info = Get-VtAggiornamento $url $ver
        if (-not $info.Disponibile) {
            Show-Toast $info.Motivo
            (Get-El 'PanelAggiorna').Visibility = 'Collapsed'
            return
        }
        $n = Install-VtAggiornamento $info

        $r = [Windows.MessageBox]::Show(
            "Aggiornamento alla $($info.Versione) completato: $n file sostituiti.`n`nPer usarla VejaTweak deve ripartire. Lo riavvio adesso?",
            'VejaTweak', 'YesNo', 'Information')
        if ($r -eq 'Yes') {
            $bat = Join-Path $PSScriptRoot 'VEJATWEAK.bat'
            if (Test-Path -LiteralPath $bat) {
                Start-Process -FilePath $bat -WorkingDirectory $PSScriptRoot
                $win.Close()
                return
            }
            Show-Toast 'Non trovo VEJATWEAK.bat: chiudi e riapri il programma a mano.'
        }
        (Get-El 'PanelAggiorna').Visibility = 'Collapsed'
        (Get-El 'BtnAggiorna').Visibility = 'Collapsed'
    } catch {
        Show-Toast $_.Exception.Message
    } finally {
        $win.Cursor = $null
        $btn.IsEnabled = $true
        $btn.Content = 'Installa ora'
    }

    # Se sei gia' nel gruppo che contiene Aggiornamenti, la colonna va
    # ridisegnata subito, altrimenti il pallino comparirebbe solo cambiando
    # sezione e sembrerebbe apparso dal nulla.
    $g = ($script:Sezioni | Where-Object { $_.Cat -eq '#aggiornamenti' } | Select-Object -First 1).Gruppo
    if ($script:GruppoAttivo -eq $g) { Build-Sotto $g; if ($script:SezioneAttiva) { Show-Sezione $script:SezioneAttiva } }

    Write-VtLog "Disponibile la versione $nuova (installata $($script:Versione))" ok
}

function Show-Sezione([string] $cat) {
    $sez = $script:Sezioni | Where-Object { $_.Cat -eq $cat } | Select-Object -First 1
    if (-not $sez) { return }
    $script:SezioneAttiva = $cat

    if ($sez.Gruppo -ne $script:GruppoAttivo) { Build-Sotto $sez.Gruppo }
    if ($script:SwTappa) { Tappa 'menu delle sezioni' }

    $TxtTitolo.Text = $sez.Titolo
    $TxtSub.Text    = $sez.Sub

    foreach ($k in $script:BottoniSotto.Keys) {
        $script:BottoniSotto[$k].Tag = if ($k -eq $cat) { 'on' } else { 'off' }
    }

    # Diagnosi e Giochi non sono elenchi di tweak: la ricerca li' non serve.
    (Get-El 'PanelSearch').Visibility = if ($cat -like '#*') { 'Collapsed' } else { 'Visible' }

    # Leggere lo stato reale di una sezione puo' richiedere qualche decimo di
    # secondo: meglio dirlo con il cursore che lasciare la finestra ferma.
    $win.Cursor = [Windows.Input.Cursors]::AppStarting
    try { Update-Contenuto } finally { $win.Cursor = $null }
    if ($script:SwTappa) { Tappa 'contenuto della pagina' }

    # Senza questo la nuova sezione eredita lo scorrimento della precedente e
    # si apre a meta' pagina, con le prime card gia' sopra il bordo.
    (Get-El 'Scroller').ScrollToTop()

    Start-VtEntrata
}

# Entrata a cascata: le card salgono e sfumano una dopo l'altra, non tutte
# insieme. Prima si animava il pannello intero, e il risultato era un blocco
# unico che scivolava; a cascata l'occhio segue l'ordine di lettura e la
# pagina sembra costruirsi davanti a te.
#
# Solo le prime dodici hanno il ritardo progressivo: oltre, l'attesa
# diventerebbe un difetto invece che un effetto, e le card sotto non si
# vedono comunque.
function Start-VtEntrata {
    # Con la griglia a due colonne le card non sono figlie dirette del
    # pannello: senza scendere di un livello si animerebbe un blocco solo e
    # la cascata sparirebbe proprio dove serve di piu'.
    $elenco = @()
    foreach ($c in $Contenuto.Children) {
        if ($c -is [Windows.Controls.Grid] -and $c.ColumnDefinitions.Count -eq 2) {
            $sx = @($c.Children)[0]; $dx = @($c.Children)[1]
            $max = [Math]::Max($sx.Children.Count, $dx.Children.Count)
            for ($k = 0; $k -lt $max; $k++) {
                if ($k -lt $sx.Children.Count) { $elenco += $sx.Children[$k] }
                if ($k -lt $dx.Children.Count) { $elenco += $dx.Children[$k] }
            }
        } else { $elenco += $c }
    }

    $i = 0
    foreach ($c in $elenco) {
        if ($c -isnot [Windows.UIElement]) { continue }

        $tt = New-Object Windows.Media.TranslateTransform
        $c.RenderTransform = $tt
        $c.Opacity = 0

        # Cascata piu' stretta di prima: 20 ms di scarto invece di 32, e solo
        # sulle prime otto invece che sulle prime dodici. Con i vecchi valori
        # l'ultima scheda cominciava a muoversi dopo 350 ms e la pagina si
        # assestava dopo quasi 700: l'effetto c'era, ma sommato al tempo di
        # costruzione faceva sembrare lento il cambio sezione. Cosi' la pagina
        # e' ferma in circa 400 ms e la cascata si vede lo stesso.
        $ritardo = [TimeSpan]::FromMilliseconds([Math]::Min($i, 7) * 20)

        $op = New-Object Windows.Media.Animation.DoubleAnimation
        $op.From = 0; $op.To = 1
        $op.Duration = [Windows.Duration]::new([TimeSpan]::FromMilliseconds(180))
        $op.BeginTime = $ritardo

        $sl = New-Object Windows.Media.Animation.DoubleAnimation
        $sl.From = 14; $sl.To = 0
        $sl.Duration = [Windows.Duration]::new([TimeSpan]::FromMilliseconds(240))
        $sl.BeginTime = $ritardo
        $ease = New-Object Windows.Media.Animation.CubicEase
        $ease.EasingMode = 'EaseOut'
        $sl.EasingFunction = $ease

        $c.BeginAnimation([Windows.UIElement]::OpacityProperty, $op)
        $tt.BeginAnimation([Windows.Media.TranslateTransform]::YProperty, $sl)
        $i++
    }
}

function Update-Contenuto {
    $Contenuto.Children.Clear()
    $cat = $script:SezioneAttiva
    $q   = $TxtSearch.Text.Trim()

    if ($cat -eq '#diagnosi') {
        $Contenuto.Children.Add((New-InfoCard 'Analisi in corso...' 'Sto leggendo BIOS, RAM, monitor, driver e servizi.' '#E0785E')) | Out-Null
        $win.Dispatcher.Invoke([action] {}, 'Background')

        $res = @(Get-VtDiagnosi)
        $Contenuto.Children.Clear()
        if ($res.Count -eq 0) {
            $msg = 'Le cose che un tweaker non puo'' sistemare da solo (RAM, BIOS, monitor, driver, servizi anticheat) sul tuo PC sono gia'' a posto.'
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun problema rilevato' $msg))
            return
        }
        foreach ($r in $res) {
            $col = if ($r.Peso -eq 1) { '#F06A6A' } else { '#E5A94E' }
            [void] $Contenuto.Children.Add((New-InfoCard $r.Titolo $r.Testo $col))
        }
        return
    }

    if ($cat -eq '#octuning') {
        $r = Get-VtRiepilogo

        # Riquadri del riepilogo, tre per riga.
        # UniformGrid sta in Primitives, non in Controls.
        $griglia = New-Object Windows.Controls.Primitives.UniformGrid
        $griglia.Columns = 3
        $griglia.Margin = [Windows.Thickness]::new(0, 0, 0, 6)
        $voci = @(
            @{ T='CPU';           V=$r.Cpu;     D=$r.CpuDett;    Ok=$true }
            @{ T='GPU RILEVATA';  V=$r.Gpu;     D=$r.GpuDett;    Ok=$true }
            @{ T='RAM RILEVATA';  V=$r.Ram;     D=$r.RamDett;    Ok=$r.RamOk }
            @{ T='SCHEDA MADRE';  V=$r.Scheda;  D=$r.SchedaDett; Ok=$true }
            @{ T='SISTEMA';       V=$r.Sistema; D="Disco di sistema: $($r.Disco)"; Ok=$true }
            @{ T='STATO CPU';     V=$r.CpuStato; D=$r.CpuThread; Ok=$r.CpuStatoOk }
        )
        foreach ($v in $voci) {
            $b = New-Object Windows.Controls.Border
            $b.Background      = New-Brush '#210A0E'
            $b.BorderBrush     = New-Brush $(if ($v.Ok) { '#3D1219' } else { '#F06A6A' })
            $b.BorderThickness = [Windows.Thickness]::new(1)
            $b.CornerRadius    = [Windows.CornerRadius]::new(10)
            $b.Margin          = [Windows.Thickness]::new(0, 0, 9, 9)
            $b.Padding         = [Windows.Thickness]::new(16, 13, 16, 13)
            $sp = New-Object Windows.Controls.StackPanel
            $t1 = New-Object Windows.Controls.TextBlock
            $t1.Text = $v.T; $t1.FontSize = 9; $t1.Foreground = New-Brush '#7A7A88'
            [void] $sp.Children.Add($t1)
            $t2 = New-Object Windows.Controls.TextBlock
            $t2.Text = $v.V; $t2.FontSize = 13; $t2.FontWeight = 'SemiBold'
            $t2.Foreground = New-Brush $(if ($v.Ok) { '#F7F7FA' } else { '#F06A6A' })
            $t2.TextWrapping = 'Wrap'; $t2.Margin = [Windows.Thickness]::new(0, 5, 0, 0)
            [void] $sp.Children.Add($t2)
            $t3 = New-Object Windows.Controls.TextBlock
            $t3.Text = $v.D; $t3.FontSize = 11; $t3.Foreground = New-Brush '#ADADBA'
            $t3.TextWrapping = 'Wrap'; $t3.Margin = [Windows.Thickness]::new(0, 5, 0, 0)
            [void] $sp.Children.Add($t3)
            $b.Child = $sp
            [void] $griglia.Children.Add($b)
        }
        [void] $Contenuto.Children.Add($griglia)

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa NON trovi qui' `
            "Overclock vero di CPU, voltaggi e timing della RAM non si toccano da Windows: stanno nel firmware, e le utility che ci provano lo fanno con un driver in kernel mode. Qui c'e' solo la parte automatica che Windows controlla davvero.`n`nPer le voci di firmware vai in Diagnosi > BIOS / UEFI: ti dice cosa e' sbagliato e ti porta nel BIOS con un clic." '#E5A94E'))

        # --- profili automatici -------------------------------------------
        $tit = New-Object Windows.Controls.TextBlock
        $tit.Text = 'Profili automatici'; $tit.FontSize = 18; $tit.FontWeight = 'Bold'
        $tit.Foreground = New-Brush '#F7F7FA'
        $tit.Margin = [Windows.Thickness]::new(0, 18, 0, 4)
        [void] $Contenuto.Children.Add($tit)

        $sub = New-Object Windows.Controls.TextBlock
        $sub.Text = 'Ogni profilo accende un elenco di voci che trovi anche nelle altre sezioni: niente di nascosto, e puoi spegnerle una per una quando vuoi. Il conteggio e'' quello reale per questo PC, perche'' alcune voci non esistono su tutte le macchine.'
        $sub.FontSize = 12; $sub.Foreground = New-Brush '#ADADBA'
        $sub.TextWrapping = 'Wrap'; $sub.Margin = [Windows.Thickness]::new(0, 0, 0, 12)
        [void] $Contenuto.Children.Add($sub)

        $colori = @{ base = '#E5A94E'; competitive = '#FF3B4E'; massimo = '#F06A6A' }
        foreach ($prof in $script:VtProfili) {
            $tutti = @(Get-VtProfiloTweaks $prof.Id)
            $da    = @(Get-VtProfiloDaFare $prof.Id)
            $col   = $colori[$prof.Id]

            $testo = @()
            $testo += $prof.Sommario
            $testo += $prof.Desc
            $testo += ($prof.Punti | ForEach-Object { "  -  $_" }) -join "`n"
            $testo += "$($tutti.Count) azioni compatibili con questo PC  |  $($da.Count) ancora da applicare"
            if ($prof.Consigliato) { $testo += 'CONSIGLIATO' }

            $idProf = $prof.Id
            $nomeProf = $prof.Nome
            $etichetta = if ($da.Count -eq 0) { 'Gia'' tutto applicato' } else { "Esegui auto tuning ($($da.Count))" }

            $card = New-ActionCard "$($prof.Etichetta)  -  $($prof.Nome)" ($testo -join "`n`n") $etichetta {
                $da2 = @(Get-VtProfiloDaFare $idProf)
                if ($da2.Count -eq 0) { Show-Toast 'Su questo PC e'' gia'' tutto applicato.'; return }

                # Elenco esatto prima di toccare qualcosa, con le voci che
                # hanno un compromesso segnalate a parte.
                $elenco = ($da2 | ForEach-Object { "  - $($_.Nome)" }) -join "`n"
                $rischiose = @($da2 | Where-Object { $_.Rischio -ne 'sicuro' })
                $avviso = ''
                if ($rischiose.Count -gt 0) {
                    $avviso = "`n`nATTENZIONE, queste hanno un compromesso vero:`n" +
                              (($rischiose | ForEach-Object { "  - $($_.Nome): $($_.Warn)" }) -join "`n")
                }
                $risposta = [Windows.MessageBox]::Show(
                    "Profilo $nomeProf`n`nSto per applicare $($da2.Count) voci:`n$elenco$avviso`n`nOgnuna si puo' disattivare dopo, una per una. Procedo?",
                    'Conferma profilo', 'YesNo', 'Question')
                if ($risposta -ne 'Yes') { return }

                $win.Cursor = [Windows.Input.Cursors]::Wait
                try { $res = Invoke-VtProfilo $idProf } finally { $win.Cursor = $null }

                $msg = "Applicate $($res.Applicati) voci su $($res.Totale)."
                if ($res.Falliti.Count -gt 0) { $msg += "`n`nNon riuscite (servono i privilegi di amministratore?):`n" + (($res.Falliti | ForEach-Object { "  - $_" }) -join "`n") }
                if ($res.Riavvio) { $msg += "`n`nAlcune hanno effetto dopo il riavvio del PC." }
                Show-Toast $msg
                Update-Contenuto
            }.GetNewClosure() $col
            [void] $Contenuto.Children.Add($card)
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Dopo aver applicato un profilo' `
            "Riavvia quando hai finito: HAGS, avvio rapido e i parametri del kernel valgono dal boot successivo. VejaTweak non riavvia mai da solo.`n`nSe qualcosa non ti torna, 'Ripristina tutto' in alto a destra rimette ogni voce al valore che aveva sul tuo PC prima." '#E5A94E'))
        return
    }

    if ($cat -eq '#genera') {
        if (-not (Test-VtOwner)) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Riservato a chi distribuisce l''app' `
                'Questa pagina richiede owner.key, la chiave privata di firma. Non e'' presente su questo PC.' '#E5A94E'))
            return
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Come funziona' `
            @(
                "I codici sono firmati con la tua chiave privata (owner.key). L'app che distribuisci contiene solo public.key, che verifica ma non firma: nessuno puo' fabbricarsi un codice.",
                "Codice universale: funziona su qualsiasi PC. Comodo, ma se qualcuno lo gira ad altri funziona anche a loro.",
                "Codice legato a un PC: fatti mandare dal cliente l'ID che l'app gli mostra all'avvio, incollalo qui. Quel codice funzionera' solo sul suo PC.",
                "NON distribuire mai owner.key insieme all'app, e tienine una copia: se lo perdi non puoi piu' generare codici che funzionino con le app gia' consegnate."
            ) -join "`n`n"))

        # --- modulo -------------------------------------------------------
        $shell = New-CardShell '#FF3B4E'
        $form = New-Object Windows.Controls.StackPanel
        $form.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
        [Windows.Controls.Grid]::SetColumn($form, 1)
        [void] $shell.Corpo.Children.Add($form)

        $t = New-Object Windows.Controls.TextBlock
        $t.Text = 'Genera un codice'; $t.FontSize = 14; $t.FontWeight = 'SemiBold'
        $t.Foreground = New-Brush '#F7F7FA'
        [void] $form.Children.Add($t)

        function New-Campo([string] $etichetta, [string] $valore, [string] $suggerimento) {
            $l = New-Object Windows.Controls.TextBlock
            $l.Text = $etichetta; $l.FontSize = 11; $l.Foreground = New-Brush '#7A7A88'
            $l.Margin = [Windows.Thickness]::new(0, 14, 0, 4)
            [void] $form.Children.Add($l)
            $tb = New-Object Windows.Controls.TextBox
            $tb.Text = $valore
            $tb.FontSize = 13
            $tb.Background = New-Brush '#1C070A'
            $tb.Foreground = New-Brush '#F7F7FA'
            $tb.CaretBrush = New-Brush '#FF3B4E'
            $tb.BorderBrush = New-Brush '#3D1219'
            $tb.Padding = [Windows.Thickness]::new(10, 7, 10, 7)
            $tb.Width = 380; $tb.HorizontalAlignment = 'Left'
            [void] $form.Children.Add($tb)
            if ($suggerimento) {
                $h = New-Object Windows.Controls.TextBlock
                $h.Text = $suggerimento; $h.FontSize = 10; $h.Foreground = New-Brush '#7A7A88'
                $h.TextWrapping = 'Wrap'; $h.Margin = [Windows.Thickness]::new(0, 4, 0, 0)
                [void] $form.Children.Add($h)
            }
            $tb
        }

        $fSerial = New-Campo 'Numero di serie / riferimento cliente' '' 'Lascia vuoto per uno casuale. Serve solo a te per ricordarti a chi hai dato cosa.'
        $fGiorni = New-Campo 'Giorni di validita''' '0' '0 = non scade mai.'
        $fMid    = New-Campo 'ID del PC del cliente' '' 'Vuoto = codice universale, funziona ovunque. Altrimenti incolla i 16 caratteri che il cliente ti manda.'

        $btn = New-Object Windows.Controls.Button
        $btn.Style = $win.FindResource('BtnAccent')
        $btn.Content = 'Genera il codice'
        $btn.HorizontalAlignment = 'Left'
        $btn.Margin = [Windows.Thickness]::new(0, 18, 0, 0)
        [void] $form.Children.Add($btn)

        $out = New-Object Windows.Controls.TextBox
        $out.IsReadOnly = $true
        $out.AcceptsReturn = $true
        $out.TextWrapping = 'Wrap'
        $out.Height = 110
        $out.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
        $out.FontSize = 12
        $out.Background = New-Brush '#1C070A'
        $out.Foreground = New-Brush '#E5A94E'
        $out.BorderBrush = New-Brush '#3D1219'
        $out.Padding = [Windows.Thickness]::new(10, 8, 10, 8)
        $out.Margin = [Windows.Thickness]::new(0, 14, 0, 0)
        $out.VerticalScrollBarVisibility = 'Auto'
        [void] $form.Children.Add($out)

        $esito = New-Object Windows.Controls.TextBlock
        $esito.FontSize = 11; $esito.TextWrapping = 'Wrap'
        $esito.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
        $esito.Foreground = New-Brush '#ADADBA'
        [void] $form.Children.Add($esito)

        $btnCopia = New-Object Windows.Controls.Button
        $btnCopia.Style = $win.FindResource('Btn')
        $btnCopia.Content = 'Copia negli appunti'
        $btnCopia.HorizontalAlignment = 'Left'
        $btnCopia.Margin = [Windows.Thickness]::new(0, 10, 0, 0)
        $btnCopia.Add_Click({
            if ($out.Text) { try { [Windows.Clipboard]::SetText($out.Text); $esito.Text = 'Codice copiato negli appunti.' } catch { } }
        }.GetNewClosure())
        [void] $form.Children.Add($btnCopia)

        $btn.Add_Click({
            try {
                $ser = 0
                if ($fSerial.Text -match '^\d+$') { $ser = [uint32] $fSerial.Text }
                $gg = 0
                if ($fGiorni.Text -match '^\d+$') { $gg = [int] $fGiorni.Text }

                $codice = New-VtCode -Serial $ser -Giorni $gg -MacchinaId ($fMid.Text.Trim())
                $out.Text = $codice

                $v = Test-VtCode $codice
                $dett = @("Serie: $($v.Serial)")
                $dett += if ($v.Scadenza) { "Scade il $($v.Scadenza.ToString('dd/MM/yyyy'))" } else { 'Non scade' }
                $dett += if ($v.Legato) { 'Legato al PC indicato' } else { 'Valido su qualsiasi PC' }
                # Nota: la verifica appena fatta gira su QUESTO PC, quindi un
                # codice legato a un altro PC risulterebbe non valido qui.
                # E' normale e non vuol dire che il codice sia sbagliato.
                $esito.Foreground = New-Brush '#57C98A'
                $esito.Text = ($dett -join '  |  ') + '   -   generato e copiabile.'
                Write-VtLog "Generato codice serie $($v.Serial)" ok
            } catch {
                $out.Text = ''
                $esito.Foreground = New-Brush '#F06A6A'
                $esito.Text = $_.Exception.Message
            }
        }.GetNewClosure())

        [void] $Contenuto.Children.Add($shell.Card)

        [void] $Contenuto.Children.Add((New-InfoCard 'Quanto vale davvero questa protezione' `
            "Onesto: VejaTweak e' uno script PowerShell in chiaro. Chi lo scarica puo' aprirlo e togliere il controllo del codice in trenta secondi. Nessuna licenza lato client lo impedisce.`n`nQuello che questa protezione fa davvero e' impedire che qualcuno si INVENTI un codice: senza la tua chiave privata non e' possibile, e i codici legati a un PC non funzionano se girati ad altri.`n`nSe ti serve una protezione piu' seria servono un eseguibile compilato e un server di attivazione, e anche allora si tratta di alzare l'asticella, non di renderla invalicabile." '#E5A94E'))
        return
    }

    if ($cat -eq '#salute') {
        [void] $Contenuto.Children.Add((New-InfoCard 'A cosa serve questa pagina' `
            "Nessun interruttore risolve un driver video che va in crash, una RAM instabile o un alimentatore che non regge. Windows registra questi sintomi da solo, e non li legge mai nessuno.`n`nQui li tiro fuori. Se trovi qualcosa in rosso, sistemare quello vale piu' di tutti i tweak di questa app messi insieme." '#E5A94E'))

        $ev = Get-VtEventi 30
        foreach ($d in (Get-VtEventiDiagnosi $ev)) {
            $col = switch ($d.Stato) { 'GRAVE' { '#F06A6A' } 'DA GUARDARE' { '#E5A94E' } 'PULITO' { '#57C98A' } default { '#ADADBA' } }
            [void] $Contenuto.Children.Add((New-InfoCard "[$($d.Stato)]  $($d.Titolo)" $d.Testo $col))
        }

        # --- risoluzione del timer, misurata ------------------------------
        $tr = Get-VtTimerResolution
        if ($tr) {
            $buono = ($tr.Attuale -le 1.1)
            $txt = @(
                "Attuale: $($tr.Attuale) ms   |   migliore ottenibile: $($tr.Minima) ms   |   default di Windows: $($tr.Default) ms"
                ''
                "E' ogni quanto il kernel puo' svegliare un thread. A $($tr.Default) ms un frame puo' arrivare fino a un sedicesimo di secondo fuori tempo: e' il micro-scatto che vedi con FPS medi altissimi."
                $(if ($buono) {
                    "Il valore attuale va bene. Se qui leggessi $($tr.Default) ms vorrebbe dire che nessun programma sta chiedendo la risoluzione fine."
                } else {
                    "Il sistema sta girando alla granularita' grossa. La voce 'Risoluzione del timer a livello di sistema' in Prestazioni > Stabilita' FPS serve esattamente a questo."
                })
                "Questo numero e' letto da ntdll, non stimato: e' la prova che quel tweak fa effetto o no."
            ) -join "`n"
            [void] $Contenuto.Children.Add((New-InfoCard "Risoluzione del timer: $($tr.Attuale) ms" $txt $(if ($buono) { '#57C98A' } else { '#E5A94E' })))
        }

        # --- dove stanno i giochi -----------------------------------------
        $gd = @(Get-VtGiochiSuDisco)
        if ($gd.Count -gt 0) {
            $suHdd = @($gd | Where-Object { $_.Tipo -match 'HDD' })
            $righe = ($gd | ForEach-Object { "  -  $($_.Nome): unita' $($_.Unita) - $($_.Disco) [$($_.Tipo)]" }) -join "`n"
            if ($suHdd.Count -gt 0) {
                [void] $Contenuto.Children.Add((New-InfoCard "$($suHdd.Count) giochi installati su disco meccanico" `
                    "$righe`n`nUn gioco su HDD e' una causa di stutter che nessun tweak puo' coprire: lo streaming delle texture e delle mesh non sta dietro. Spostarlo su un SSD e' la modifica singola piu' efficace che puoi fare su quei giochi, piu' di qualunque impostazione di questa app." '#F06A6A'))
            } else {
                [void] $Contenuto.Children.Add((New-InfoCard 'Tutti i giochi su unita'' a stato solido' "$righe`n`nNiente da fare: lo streaming delle risorse non e' un collo di bottiglia." '#57C98A'))
            }
        }

        # --- salute dei dischi --------------------------------------------
        $dischi = @(Get-VtDischi)
        if ($dischi.Count -gt 0) {
            $righe = $dischi | ForEach-Object {
                $extra = @()
                if ($null -ne $_.Usura) { $extra += "usura $($_.Usura)%" }
                if ($null -ne $_.Temp)  { $extra += "$($_.Temp) C" }
                "  -  $($_.Nome) [$($_.Tipo), $($_.GB) GB, $($_.Bus)] - salute: $($_.Salute)$(if ($extra) { ' - ' + ($extra -join ', ') })"
            }
            $malati = @($dischi | Where-Object { $_.Salute -ne 'Healthy' })
            $testo = ($righe -join "`n")
            if ($dischi | Where-Object { $null -eq $_.Usura }) {
                $testo += "`n`nUsura e temperatura non sono esposte da tutti i controller: dove mancano, il dato non c'e', non e' zero."
            }
            [void] $Contenuto.Children.Add((New-InfoCard $(if ($malati.Count -gt 0) { "$($malati.Count) dischi non in salute" } else { 'Dischi in salute' }) `
                $testo $(if ($malati.Count -gt 0) { '#F06A6A' } else { '#57C98A' })))
        }
        return
    }

    if ($cat -eq '#aggiornamenti') {
        $url = Get-VtUrlAggiornamenti
        # La versione va copiata in una variabile LOCALE prima di finire nel
        # gestore del clic. Dentro un gestore di evento WPF il riferimento
        # $script:Versione puo' arrivare vuoto, e la funzione di confronto
        # concludeva "sei gia' aggiornato": nessun cliente riusciva piu' a
        # scaricare niente, e il messaggio lo diceva pure - "(versione )",
        # con le parentesi vuote. Una variabile locale la chiusura la cattura
        # per valore e non puo' perderla.
        $ver = "$($script:Versione)"
        [void] $Contenuto.Children.Add((New-InfoCard 'Versione installata' "VejaTweak $ver"))

        if (-not $url) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Controllo automatico non configurato' `
                "Manca il file aggiornamenti.url accanto all'applicazione, quindi non c'e' nessun indirizzo da controllare.`n`nChi ti ha dato il programma ti mandera' le versioni nuove a mano." '#E5A94E'))
        } else {
            $stato = New-Object Windows.Controls.TextBlock
            $stato.FontSize = 12; $stato.TextWrapping = 'Wrap'
            $stato.Foreground = New-Brush '#ADADBA'
            $stato.Text = "Indirizzo configurato. Premi 'Controlla' per vedere se c'e' una versione nuova."

            $azioni = New-Object Windows.Controls.StackPanel

            $cardCtrl = New-ActionCard 'Controlla aggiornamenti' `
                "Scarica solo il file che descrive l'ultima versione e ne verifica la firma. Non installa niente da solo." `
                'Controlla' {
                    param($sender, $e)
                    $sender.IsEnabled = $false
                    $win.Cursor = [Windows.Input.Cursors]::AppStarting
                    $azioni.Children.Clear()
                    try {
                        $info = Get-VtAggiornamento $url $ver
                        $stato.Text = $info.Motivo
                        $stato.Foreground = New-Brush $(if ($info.Disponibile) { '#57C98A' } elseif ($info.Motivo -match 'FIRMA') { '#F06A6A' } else { '#ADADBA' })

                        if ($info.Disponibile) {
                            $testo = "Versione $($info.Versione)."
                            if ($info.Note) { $testo += "`n`nNovita': $($info.Note)" }
                            $testo += "`n`nIl pacchetto viene scaricato, ne viene ricontrollata l'impronta e poi sostituisce i file del programma. Attivazione, backup e impostazioni restano dove sono."
                            [void] $azioni.Children.Add((New-ActionCard "Aggiorna alla $($info.Versione)" $testo 'Scarica e installa' {
                                $win.Cursor = [Windows.Input.Cursors]::Wait
                                try {
                                    $n = Install-VtAggiornamento $info
                                    Show-Toast "Aggiornamento completato: $n file sostituiti.`n`nChiudi e riapri VejaTweak per usare la versione nuova."
                                } catch { Show-Toast $_.Exception.Message }
                                finally { $win.Cursor = $null }
                            }.GetNewClosure()))
                        }
                    } catch {
                        $stato.Text = $_.Exception.Message
                        $stato.Foreground = New-Brush '#F06A6A'
                    } finally {
                        $win.Cursor = $null
                        $sender.IsEnabled = $true
                        $sender.Content = 'Ricontrolla'
                    }
                }.GetNewClosure()
            [void] $Contenuto.Children.Add($cardCtrl)

            $box = New-CardShell '#E5A94E'
            $sp = New-Object Windows.Controls.StackPanel
            $sp.Margin = [Windows.Thickness]::new(20, 14, 20, 14)
            [Windows.Controls.Grid]::SetColumn($sp, 1)
            [void] $sp.Children.Add($stato)
            [void] $box.Corpo.Children.Add($sp)
            [void] $Contenuto.Children.Add($box.Card)
            [void] $Contenuto.Children.Add($azioni)
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' puoi fidarti di questo aggiornamento' `
            "Un programma che scarica codice da internet e lo esegue e' il modo classico in cui una cosa innocua diventa un veicolo di malware: basta che qualcuno metta le mani sul sito da cui scarica.`n`nQui non funziona cosi'. Il file che descrive l'aggiornamento e' firmato con una chiave privata che sta solo sul PC di chi ha creato il programma, e VejaTweak verifica quella firma PRIMA di scaricare qualsiasi cosa. Poi ricontrolla l'impronta SHA-256 del pacchetto scaricato.`n`nAnche prendendo il controllo del sito, senza quella chiave non si riesce a far accettare niente." '#E0785E'))
        return
    }

    if ($cat -eq '#essenziali') {
        $tutti = @(Get-VtServiziEssenziali)
        $rotti = @($tutti | Where-Object { $_.Disattivato -or $_.Fermo })

        # --- il controllo che fa lo staff dei server di ruolo -------------
        $staff = @(Get-VtControlloStaff)
        $bocciati = @($staff | Where-Object { -not $_.Passa })

        Add-Intestazione $Contenuto 'Controllo dello staff (server di ruolo)' `
            'Sui server di ruolo lo staff ti fa eseguire un comando che elenca questi servizi. Non c''entra niente con le prestazioni: sono quelli che tengono traccia di cosa hai eseguito sul PC. Chi bara li spegne per cancellare le prove, quindi trovarli fermi vale come colpevolezza anche se non hai fatto niente.'

        if ($bocciati.Count -eq 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Passi il controllo' `
                ("Tutti e $($staff.Count) i servizi controllati risultano in esecuzione:`n`n" +
                 (($staff | ForEach-Object { "  $($_.Name)  -  $($_.Stato)" }) -join "`n") +
                 "`n`nVejaTweak non ne spegne nessuno, e il collaudo lo verifica a ogni versione.") '#57C98A'))
        } else {
            [void] $Contenuto.Children.Add((New-ActionCard "Non passeresti il controllo: $($bocciati.Count) servizi fermi" `
                @(
                    "Questi risultano fermi o disattivati, e lo staff li vedrebbe cosi':",
                    (($bocciati | ForEach-Object { "  $($_.Name)  -  $($_.Stato)" }) -join "`n"),
                    "Il pulsante li rimette al valore di fabbrica e li avvia. Usa Set-Service e non la scrittura diretta nel registro: cambiando il valore a mano il registro risulta giusto ma il Gestore servizi continua a rispondere 'servizio disabilitato', ed e' il motivo per cui certi script .cmd sembrano non funzionare."
                ) -join "`n`n" `
                'Rimettili in esecuzione' {
                    param($sender, $e)
                    $win.Cursor = [Windows.Input.Cursors]::Wait
                    try {
                        $r = Repair-VtServizi
                        $m = "$($r.Riparati) servizi rimessi a posto."
                        if ($r.AlRiavvio.Count -gt 0) { $m += "`n`nDriver che ripartiranno al riavvio: " + ($r.AlRiavvio -join ', ') }
                        if ($r.Falliti.Count -gt 0)   { $m += "`n`nNon riusciti:`n" + ($r.Falliti -join "`n") }
                        Show-Toast $m
                        Update-Contenuto
                    } catch { Show-Toast $_.Exception.Message }
                    finally { $win.Cursor = $null }
                } '#F06A6A'))
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa ho cambiato nel programma per non farti bocciare' `
            @(
                "Il profilo Competitive disattivava DiagTrack e ti avrebbe fatto fallire il controllo. Adesso nessun profilo tocca nessuno di questi servizi: l'ho verificato e c'e' un controllo automatico che lo impedisce anche in futuro.",
                "PcaSvc e' uscito dal gruppo 'servizi superflui'. SuperFetch resta disponibile come voce singola ma e' uscito dal profilo Maximum e porta un'avvertenza: i file di prefetch che genera sono la prova di quali programmi hai lanciato.",
                "Se giochi solo su server normali niente di tutto questo ti riguarda, e quelle voci puoi accenderle. Se giochi di ruolo, lasciale stare."
            ) -join "`n`n" '#E5A94E'))

        if ($rotti.Count -eq 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Tutti a posto' `
                "Ho controllato $($tutti.Count) servizi che non vanno mai disattivati: nessuno risulta spento o fermo.`n`nVejaTweak non li tocca in nessun caso, e la verifica lo controlla a ogni collaudo. Se un domani un altro programma ne spegne uno, qui comparira' con il pulsante per rimetterlo a posto." '#57C98A'))
        } else {
            [void] $Contenuto.Children.Add((New-ActionCard "$($rotti.Count) servizi essenziali risultano disattivati" `
                @(
                    "Questi non sono servizi 'superflui': sono quelli che devono restare accesi perche' Windows e i giochi funzionino. Qualcuno li ha messi su Disabilitato - non e' stato VejaTweak, che non li tocca mai.",
                    ($rotti | ForEach-Object { "  $($_.Name)  -  $($_.Nome)" }) -join "`n",
                    "Il pulsante rimette a ognuno il valore di avvio GIUSTO, non 'automatico' a tappeto: 'bam' e' un driver che parte al boot e metterlo su automatico ne cambierebbe l'ordine di caricamento, 'Appinfo' di fabbrica e' manuale e va benissimo cosi'. Gli script .cmd che girano in rete mettono auto su tutto e questi due li peggiorano."
                ) -join "`n`n" `
                'Rimetti a posto' {
                    param($sender, $e)
                    $win.Cursor = [Windows.Input.Cursors]::Wait
                    try {
                        $r = Repair-VtServizi
                        $m = "$($r.Riparati) servizi rimessi a posto."
                        if ($r.Falliti.Count -gt 0) { $m += "`n`nNon riusciti:`n" + ($r.Falliti -join "`n") }
                        $m += "`n`nQuelli che sono driver ripartono al riavvio."
                        Show-Toast $m
                        Update-Contenuto
                    } catch { Show-Toast $_.Exception.Message }
                    finally { $win.Cursor = $null }
                } '#F06A6A'))
        }

        Add-Intestazione $Contenuto 'L''elenco completo' `
            'Per ognuno c''e'' scritto cosa succede se lo spegni. Serve anche a te: quando un cliente ti scrive che FiveM non parte piu'' dopo aver usato un altro tweak, di solito la risposta e'' in questa lista.'

        foreach ($s in $tutti) {
            $stato = if ($s.Disattivato) { 'DISATTIVATO' }
                     elseif ($s.Attuale -eq $s.Atteso) { "a posto ($($s.Stato))" }
                     else { "avvio $($s.Attuale) invece di $($s.Atteso) ($($s.Stato))" }
            $col = if ($s.Disattivato) { '#F06A6A' } elseif ($s.Attuale -ne $s.Atteso) { '#E5A94E' } else { '#57C98A' }
            [void] $Contenuto.Children.Add((New-InfoCard "$($s.Name)  -  $stato" $s.Perche $col))
        }
        return
    }

    if ($cat -eq '#avvio') {
        $voci = @(Get-VtAvvio)
        if ($voci.Count -eq 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Non parte niente con Windows' `
                "Nelle chiavi di avvio non c'e' nessuna voce. E' una buona notizia: significa che all'accensione non si accoda nessun programma di terze parti." '#57C98A'))
            return
        }
        $accesi   = @($voci | Where-Object { $_.Acceso -and -not $_.Protetto }).Count
        $protetti = @($voci | Where-Object { $_.Protetto }).Count

        [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' questa pagina esiste' `
            "Ogni programma che parte con Windows resta acceso per sempre: occupa RAM, e ogni tanto si sveglia per controllare aggiornamenti o sincronizzare qualcosa. Se lo fa mentre giochi, quello e' uno scatto.`n`nSul tuo PC partono $($voci.Count) programmi, di cui $accesi spegnibili$(if ($protetti -gt 0) { " e $protetti che non ti faccio toccare" }).`n`nNon cancello niente: uso lo stesso interruttore di Gestione attivita', quindi lo stato che vedi qui e' lo stesso che vedi li', e riaccendere e' sempre possibile." '#FF3B4E'))

        foreach ($v in $voci) {
            $cmd = if ($v.Comando.Length -gt 110) { $v.Comando.Substring(0, 110) + '...' } else { $v.Comando }
            if ($v.Protetto) {
                [void] $Contenuto.Children.Add((New-InfoCard "$($v.Nome)  -  non la tocco" `
                    "$cmd`n`nQuesta la lascio stare: e' antibarare, audio, driver video o sicurezza. Spegnerla non fa guadagnare un frame e puo' impedirti di entrare in partita o toglierti l'audio." '#E5A94E'))
                continue
            }
            $vC = $v
            $stato = if ($v.Acceso) { 'parte con Windows' } else { 'gia'' spento' }
            $etichetta = if ($v.Acceso) { 'Non farlo partire' } else { 'Rimettilo all''avvio' }
            $prossimo  = -not $v.Acceso
            [void] $Contenuto.Children.Add((New-ActionCard "$($v.Nome)  -  $stato" `
                "$cmd`n`nAmbito: $($v.Scope)" `
                $etichetta {
                    param($sender, $e)
                    try {
                        Set-VtAvvio $vC.Nome $vC.Scope $prossimo
                        Show-Toast "$($vC.Nome): $(if ($prossimo) { 'tornera'' a partire con Windows' } else { 'non partira'' piu'' con Windows' }).`n`nHa effetto dal prossimo avvio; se e'' aperto adesso resta aperto."
                        Update-Contenuto
                    } catch { Show-Toast $_.Exception.Message }
                }.GetNewClosure() $(if ($v.Acceso) { '#FF3B4E' } else { '#57C98A' })))
        }
        return
    }

    if ($cat -eq '#reg') {
        $desk = [Environment]::GetFolderPath('Desktop')
        $nReg = @(Get-VtCatalog | Where-Object { $_.Kind -eq 'Reg' }).Count
        $nAtt = @(Get-VtCatalog | Where-Object { $_.Kind -eq 'Reg' -and (Get-VtState $_) }).Count

        [void] $Contenuto.Children.Add((New-InfoCard 'Applica in blocco, sezione per sezione' `
            "Qui non devi esportare niente e non devi fare doppio clic su nessun file: ogni sezione si applica con un pulsante, e con l'altro torna esattamente com'era.`n`nSono le stesse $nReg voci di registro che trovi sparse nelle altre sezioni, raggruppate per poterle fare tutte insieme. Adesso ne risultano attive $nAtt.`n`nOgni voce viene salvata com'era prima di essere toccata, quindi 'Rimetti com'era' non e' un modo di dire." '#FF3B4E'))

        # Un blocco per categoria: applica tutte le voci di registro di quella
        # sezione, e le rimette. Le voci si contano sul momento, non da un
        # elenco fisso: cosi' una sezione vuota su questo PC non compare.
        $perCat = @{}
        foreach ($t in (Get-VtCatalog | Where-Object { $_.Kind -eq 'Reg' })) {
            $k = "$($t.Cat)"
            if (-not $perCat.ContainsKey($k)) { $perCat[$k] = @() }
            $perCat[$k] += $t
        }

        foreach ($nome in ($perCat.Keys | Sort-Object)) {
            $voci = @($perCat[$nome])
            $fatte = @($voci | Where-Object { Get-VtState $_ }).Count
            $rischiose = @($voci | Where-Object { $_.Rischio -ne 'sicuro' })
            $riavvio   = @($voci | Where-Object { $_.Reboot })

            # Virgolette doppie: qui l'apostrofo NON va raddoppiato, altrimenti
            # ne compaiono due sullo schermo.
            $testo = @("$($voci.Count) voci di registro, $fatte gia' applicate.")
            $testo += ($voci | ForEach-Object { '  ' + $_.Nome }) -join "`n"
            if ($rischiose.Count -gt 0) {
                $testo += "Con un compromesso vero ($($rischiose.Count)): " + (($rischiose | ForEach-Object { $_.Nome }) -join ', ') + ". Aprile una per una nella loro sezione se vuoi leggere l'avvertenza prima."
            }
            if ($riavvio.Count -gt 0) { $testo += "$($riavvio.Count) di queste hanno effetto dopo il riavvio." }

            $vociC = $voci
            $nomeC = $nome
            $indietro = if ($fatte -gt 0) { 'Rimetti com''erano' } else { '' }
            [void] $Contenuto.Children.Add((New-ActionCard "$nome  -  $fatte / $($voci.Count) applicate" ($testo -join "`n`n") `
                'Applica tutte' {
                    param($sender, $e)
                    $win.Cursor = [Windows.Input.Cursors]::Wait
                    $ok = 0; $ko = @()
                    try {
                        foreach ($v in $vociC) {
                            if (Get-VtState $v) { continue }
                            try { if (Set-VtTweak $v $true) { $ok++ } else { $ko += $v.Nome } }
                            catch { $ko += "$($v.Nome): $($_.Exception.Message)" }
                        }
                    } finally { $win.Cursor = $null }
                    $m = "$nomeC`n`n$ok voci applicate."
                    if ($ko.Count -gt 0) { $m += "`n`nNon riuscite ($($ko.Count)):`n" + ($ko -join "`n") }
                    Show-Toast $m
                    Update-Contenuto
                }.GetNewClosure() '#FF3B4E' $indietro {
                    param($sender, $e)
                    $win.Cursor = [Windows.Input.Cursors]::Wait
                    $ok = 0; $ko = @()
                    try {
                        foreach ($v in $vociC) {
                            if (-not (Get-VtState $v)) { continue }
                            try { if (Set-VtTweak $v $false) { $ok++ } else { $ko += $v.Nome } }
                            catch { $ko += "$($v.Nome): $($_.Exception.Message)" }
                        }
                    } finally { $win.Cursor = $null }
                    $m = "$nomeC`n`n$ok voci riportate com'erano."
                    if ($ko.Count -gt 0) { $m += "`n`nNon riuscite ($($ko.Count)):`n" + ($ko -join "`n") }
                    Show-Toast $m
                    Update-Contenuto
                }.GetNewClosure()))
        }

        Add-Intestazione $Contenuto 'Se invece ti serve il file' `
            'Un .reg si applica con un doppio clic anche su un PC dove VejaTweak non c''e''. Serve per portare la configurazione altrove o per tenersi un ripristino che sopravvive alla disinstallazione.'

        $azione = {
            param($modo, $nomeFile, $titolo)
            $file = Join-Path $desk $nomeFile
            $win.Cursor = [Windows.Input.Cursors]::Wait
            try {
                $r = Export-VtReg $file $modo
                if ($r.Voci -eq 0) {
                    Show-Toast "Niente da esportare.$(if ($modo -eq 'ripristino') { "`n`nNon hai ancora applicato nessuna voce di registro, quindi non c'e' niente da rimettere com'era." })"
                } else {
                    Show-Toast "$titolo`n`n$($r.Voci) voci in $($r.Chiavi) chiavi.`n`nSalvato sul desktop: $nomeFile"
                }
            } catch { Show-Toast $_.Exception.Message }
            finally { $win.Cursor = $null }
        }

        [void] $Contenuto.Children.Add((New-ActionCard 'Esporta le impostazioni consigliate' `
            "Tutte le voci di registro del catalogo con i valori che VejaTweak consiglia, applicate o no.`n`nE' il file da passare a qualcun altro o da usare su un PC dove non vuoi installare niente." `
            'Esporta sul desktop' { & $azione 'target' 'VejaTweak-consigliate.reg' 'Impostazioni consigliate esportate.' }.GetNewClosure()))

        [void] $Contenuto.Children.Add((New-ActionCard 'Esporta solo quelle che hai attivo tu' `
            "Fotografia delle voci di registro attualmente attive su questo PC: $nAtt su $nReg.`n`nE' il file giusto per replicare esattamente la TUA configurazione su un altro computer." `
            'Esporta sul desktop' { & $azione 'attivi' 'VejaTweak-attive.reg' 'Configurazione attuale esportata.' }.GetNewClosure()))

        [void] $Contenuto.Children.Add((New-ActionCard 'Esporta il ripristino' `
            "I valori che c'erano PRIMA che VejaTweak li cambiasse, presi dai backup.`n`nTienilo da parte: rimette tutto com'era anche se un domani cancelli l'app o il file di backup." `
            'Esporta sul desktop' { & $azione 'ripristino' 'VejaTweak-ripristino.reg' 'File di ripristino esportato.' }.GetNewClosure() '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa NON c''e'' dentro, e perche'' te lo dico' `
            "Il .reg contiene solo le impostazioni di registro. Servizi, attivita' pianificate, proprieta' della scheda di rete e configurazioni dei giochi non stanno nel registro nella forma che servirebbe, quindi restano fuori.`n`nUn file che sembrasse completo e non lo fosse sarebbe peggio di uno che dichiara i suoi limiti: l'avviso e' scritto anche in testa al file, cosi' resta chiaro a chiunque lo apra.`n`nLe voci di HKEY_LOCAL_MACHINE chiedono i permessi di amministratore quando si fa doppio clic." '#ADADBA'))
        return
    }

    if ($cat -eq '#pulizia') {
        $d = Get-PSDrive C -ErrorAction SilentlyContinue
        $liberi = if ($d) { [math]::Round($d.Free / 1GB, 1) } else { 0 }
        $tot    = if ($d) { [math]::Round(($d.Free + $d.Used) / 1GB, 1) } else { 0 }
        $pct    = if ($tot -gt 0) { [math]::Round(100 * $liberi / $tot) } else { 0 }

        $intro = if ($pct -ge 20) {
            "Hai $liberi GB liberi su $tot ($pct%): di spazio ne hai. Te lo dico perche' e' il campo dove si raccontano piu' bugie: svuotare cartelle NON rende un PC piu' veloce. Serve a recuperare spazio, e basta.`n`nLa velocita' cambia solo quando il disco e' quasi pieno, sotto il 10%: li' Windows non riesce piu' a espandere il file di paging e butta via la cache delle shader. Non e' il tuo caso."
        } else {
            "Hai $liberi GB liberi su $tot ($pct%): sei sotto la soglia in cui lo spazio inizia a costare prestazioni. Windows fatica a espandere il file di paging e butta via la cache delle shader, che si traduce in stutter. Qui liberare serve davvero."
        }
        [void] $Contenuto.Children.Add((New-InfoCard 'Prima di tutto, la verita'' sulla pulizia' $intro $(if ($pct -ge 20) { '#E5A94E' } else { '#F06A6A' })))

        $riepilogo = New-Object Windows.Controls.TextBlock
        $riepilogo.FontSize = 12; $riepilogo.TextWrapping = 'Wrap'
        $riepilogo.Foreground = New-Brush '#ADADBA'
        $riepilogo.Text = 'Nessuna analisi ancora eseguita.'

        # Contenitore delle voci: riempito dall'analisi.
        $lista = New-Object Windows.Controls.StackPanel

        $cardScan = New-ActionCard 'Analizza cosa si puo'' liberare' `
            'Misura ogni categoria senza cancellare niente. Poi decidi voce per voce.' `
            'Analizza' {
                param($sender, $e)
                $sender.IsEnabled = $false
                $sender.Content = 'Analisi in corso...'
                $win.Cursor = [Windows.Input.Cursors]::AppStarting
                $lista.Children.Clear()
                $totale = 0.0
                try {
                    foreach ($v in $script:VtPulizia) {
                        $m = Measure-VtPulizia $v
                        $totale += $m.Mb

                        $etichetta = if ($m.Negato -and $m.File -eq 0) { 'serve amministratore' }
                                     elseif ($m.File -eq 0) { 'niente da togliere' }
                                     else { "$($m.Mb) MB in $($m.File) file" }

                        $testo = @($v.Desc, $v.Perche)
                        if ($v.Warn) { $testo += 'ATTENZIONE: ' + $v.Warn }
                        $testo += "Trovato adesso: $etichetta"

                        $col = if ($v.Rischio -ne 'sicuro') { '#E5A94E' } else { '#FF3B4E' }
                        $voceCorrente = $v

                        if ($m.File -gt 0) {
                            [void] $lista.Children.Add((New-ActionCard "$($v.Nome)  -  $($m.Mb) MB" ($testo -join "`n`n") 'Elimina' {
                                param($s2, $e2)
                                if ($voceCorrente.Warn) {
                                    $r = [Windows.MessageBox]::Show(
                                        "$($voceCorrente.Nome)`n`n$($voceCorrente.Warn)`n`nProcedo?",
                                        'Conferma', 'YesNo', 'Warning')
                                    if ($r -ne 'Yes') { return }
                                }
                                $s2.IsEnabled = $false
                                $win.Cursor = [Windows.Input.Cursors]::Wait
                                try {
                                    $res = Invoke-VtPulizia $voceCorrente
                                    $msg = "Liberati $($res.Mb) MB."
                                    if ($res.Errori -gt 0) { $msg += "`n`n$($res.Errori) file erano in uso e sono stati saltati: e' normale, si tolgono al prossimo riavvio." }
                                    Show-Toast $msg
                                } catch { Show-Toast $_.Exception.Message }
                                finally { $win.Cursor = $null }
                                Update-Contenuto
                            }.GetNewClosure() $col))
                        } else {
                            [void] $lista.Children.Add((New-InfoCard "$($v.Nome)  -  $etichetta" ($testo -join "`n`n") '#7A7A88'))
                        }
                    }
                } finally {
                    $win.Cursor = $null
                    $sender.IsEnabled = $true
                    $sender.Content = 'Rianalizza'
                }
                $riepilogo.Text = "Totale recuperabile: $([math]::Round($totale,1)) MB. Le voci qui sotto si eliminano una per una, cosi' sai sempre cosa stai togliendo."
                $riepilogo.Foreground = New-Brush '#57C98A'
            }.GetNewClosure()
        [void] $Contenuto.Children.Add($cardScan)

        $box = New-CardShell '#E5A94E'
        $sp = New-Object Windows.Controls.StackPanel
        $sp.Margin = [Windows.Thickness]::new(20, 14, 20, 14)
        [Windows.Controls.Grid]::SetColumn($sp, 1)
        [void] $sp.Children.Add($riepilogo)
        [void] $box.Corpo.Children.Add($sp)
        [void] $Contenuto.Children.Add($box.Card)

        [void] $Contenuto.Children.Add($lista)

        [void] $Contenuto.Children.Add((New-ActionCard 'Compatta l''archivio componenti di Windows' `
            "E' l'unica pulizia che libera davvero parecchi GB su un Windows vecchio di qualche anno: rimuove le versioni superate dei componenti di sistema rimaste dopo gli aggiornamenti.`n`nLa fa DISM, lo strumento di Microsoft, non io. Ci mette qualche minuto e durante l'operazione il PC puo' sembrare lento. Serve l'amministratore." `
            'Avvia la compattazione' {
                $r = [Windows.MessageBox]::Show(
                    "DISM impieghera' qualche minuto e nel frattempo il PC potrebbe rallentare.`n`nDopo non potrai piu' disinstallare gli aggiornamenti gia' installati. Procedo?",
                    'Compattazione componenti', 'YesNo', 'Question')
                if ($r -ne 'Yes') { return }
                $win.Cursor = [Windows.Input.Cursors]::Wait
                try { Show-Toast (Invoke-VtDism) } catch { Show-Toast $_.Exception.Message } finally { $win.Cursor = $null }
            } '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa NON cancello, e perche''' `
            @(
                "Prefetch - cancellarlo RALLENTA gli avvii finche' Windows non lo ricostruisce. E' il tweak piu' diffuso e piu' controproducente che esista: se un programma te lo propone come ottimizzazione, sai gia' quanto vale il resto.",
                "File di paging e punti di ripristino - sono reti di sicurezza. Toglierli non da' FPS, toglie solo il paracadute.",
                "Download, Documenti, Immagini - sono roba tua, non spazzatura. Nessun programma dovrebbe decidere al posto tuo.",
                "Cache dei browser - sono dati tuoi, e svuotarle rende la navigazione piu' lenta per giorni senza darti niente in cambio."
            ) -join "`n`n" '#E0785E'))
        return
    }

    if ($cat -eq '#rete') {
        $nic = @(Get-VtNicAdapters)
        if ($nic.Count -eq 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessuna scheda di rete fisica attiva' `
                'Le impostazioni della scheda compaiono solo con un collegamento attivo. Se sei in Wi-Fi, molte di queste voci non esistono proprio.' '#E5A94E'))
        } else {
            foreach ($a in $nic) {
                $tipo = if ($a.InterfaceDescription -match 'Wi-?Fi|Wireless|802\.11|AX2|Dual Band') { 'Wi-Fi' } else { 'Ethernet (cavo)' }
                $righe = @(
                    "Scheda    : $($a.InterfaceDescription)"
                    "Tipo      : $tipo"
                    "Velocita' : $($a.LinkSpeed)"
                )
                $col = '#57C98A'
                if ($tipo -eq 'Wi-Fi') {
                    $righe += ''
                    $righe += "Sei in Wi-Fi. Nessuna impostazione qui sotto recupera i millisecondi che aggiunge il collegamento radio: il cavo resta la modifica singola piu' efficace sulla latenza."
                    $col = '#E5A94E'
                } elseif ($a.LinkSpeed -match '^(10|100) Mbps') {
                    $righe += ''
                    $righe += "Il collegamento e' negoziato sotto il gigabit: cavo vecchio o rovinato, oppure porta del router a 100. Per il ping non cambia nulla, per i download si'."
                    $col = '#E5A94E'
                }
                [void] $Contenuto.Children.Add((New-InfoCard 'La tua connessione' ($righe -join "`n") $col))
            }
        }

        foreach ($t in (Get-VtCatalog | Where-Object { $_.Cat -eq 'Rete' })) {
            [void] $Contenuto.Children.Add((New-TweakCard $t))
        }

        if ($nic.Count -gt 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Cosa aspettarti da queste voci' `
                "Non danno FPS: agiscono sul ritardo e sulla regolarita' con cui i pacchetti arrivano e partono. Si sentono sul registro dei colpi, non sul contatore dei frame.`n`nOgni scheda espone un insieme diverso di impostazioni: quelle che il tuo driver non ha vengono saltate in silenzio, non forzate. Se un interruttore resta spento anche dopo averlo attivato, vuol dire che il tuo hardware non ha nessuna di quelle voci." '#ADADBA'))
        }
        return
    }

    if ($cat -eq '#stabilita') {
        [void] $Contenuto.Children.Add((New-InfoCard 'Media alta, scatti lo stesso: perche''' `
            "Gli FPS medi non dicono niente sugli scatti. Quello che senti come micro-stutter e' quasi sempre tempo che il kernel toglie ai thread del gioco per servire i driver: DPC (lavoro differito) e ISR (interrupt hardware).`n`nSe un driver tiene la CPU in DPC troppo a lungo, il frame dopo arriva in ritardo e tu lo vedi, anche con 300 FPS di media. Qui lo misuriamo davvero invece di indovinare." '#E5A94E'))

        # La misura richiede qualche secondo: se la facessi in un ciclo qui
        # dentro la finestra resterebbe bloccata. Campiono con un timer e
        # aggiorno la card mentre va.
        $risultato = New-Object Windows.Controls.TextBlock
        $risultato.FontSize = 12
        $risultato.Foreground = New-Brush '#ADADBA'
        $risultato.TextWrapping = 'Wrap'
        $risultato.Text = 'Nessuna misura ancora eseguita. Per un risultato utile lasciala girare mentre NON stai facendo altro, oppure mentre un gioco e'' aperto in finestra.'

        $cardMis = New-ActionCard 'Misura la stabilita''' `
            "Campiona per 10 secondi il tempo che la CPU passa in DPC e in interrupt, e quanto sono regolari. Non installa niente: legge i contatori di Windows." `
            'Avvia la misura (10 s)' {
                param($sender, $e)
                $sender.IsEnabled = $false
                $sender.Content = 'Misura in corso...'
                $campioni = New-Object System.Collections.ArrayList
                $t = New-Object Windows.Threading.DispatcherTimer
                $t.Interval = [TimeSpan]::FromMilliseconds(1000)
                $t.Add_Tick({
                    try { [void] $campioni.Add((Get-VtStabilitySample)) } catch { }
                    $risultato.Text = "Misura in corso... $($campioni.Count)/10 campioni"
                    if ($campioni.Count -ge 10) {
                        $t.Stop()
                        $v = Get-VtStabilityVerdetto $campioni
                        $righe = @(
                            "Esito: $($v.Stato)"
                            ''
                            "Tempo in DPC       : $($v.DpcMedio)% medio, picco $($v.DpcMax)%"
                            "Tempo in interrupt : $($v.IsrMedio)% medio"
                            "Interrupt al secondo: $($v.IntMedio) medi, picco $($v.IntMax) ($($v.Picco)x)"
                        )
                        if ($v.Problemi.Count -gt 0) {
                            $righe += ''
                            $righe += 'Cosa non va:'
                            $righe += ($v.Problemi | ForEach-Object { "  -  $_" })
                        } else {
                            $righe += ''
                            $righe += 'Nessun segnale di driver che rubano tempo alla CPU. Se hai scatti lo stesso, guarda nel gioco: compilazione shader al primo giro, streaming texture da disco lento, o server affollato.'
                        }
                        $risultato.Text = $righe -join "`n"
                        $risultato.Foreground = New-Brush $(switch ($v.Stato) { 'BUONO' { '#57C98A' } 'DA SISTEMARE' { '#F06A6A' } default { '#E5A94E' } })
                        Write-VtLog "Stabilita': $($v.Stato) - DPC $($v.DpcMedio)% (picco $($v.DpcMax)%), ISR $($v.IsrMedio)%"
                        $sender.IsEnabled = $true
                        $sender.Content = 'Ripeti la misura (10 s)'
                    }
                }.GetNewClosure())
                $t.Start()
            }.GetNewClosure()

        [void] $Contenuto.Children.Add($cardMis)

        $bordo = New-CardShell '#E5A94E'
        $wrap = New-Object Windows.Controls.StackPanel
        $wrap.Margin = [Windows.Thickness]::new(20, 16, 20, 16)
        [Windows.Controls.Grid]::SetColumn($wrap, 1)
        $ttl = New-Object Windows.Controls.TextBlock
        $ttl.Text = 'Risultato'; $ttl.FontSize = 13; $ttl.FontWeight = 'SemiBold'
        $ttl.Foreground = New-Brush '#F7F7FA'
        [void] $wrap.Children.Add($ttl)
        $risultato.Margin = [Windows.Thickness]::new(0, 8, 0, 0)
        [void] $wrap.Children.Add($risultato)
        [void] $bordo.Corpo.Children.Add($wrap)
        [void] $Contenuto.Children.Add($bordo.Card)

        # --- le due voci che agiscono sulla regolarita' --------------------
        $tit = New-Object Windows.Controls.TextBlock
        $tit.Text = 'Voci che agiscono sulla regolarita'''
        $tit.FontSize = 17; $tit.FontWeight = 'Bold'; $tit.Foreground = New-Brush '#F7F7FA'
        $tit.Margin = [Windows.Thickness]::new(0, 18, 0, 10)
        [void] $Contenuto.Children.Add($tit)

        foreach ($t in (Get-VtCatalog | Where-Object { $_.Cat -eq 'Stabilita' })) {
            [void] $Contenuto.Children.Add((New-TweakCard $t))
        }

        $nota = New-Object Windows.Controls.TextBlock
        $nota.Text = 'Altre voci che aiutano la regolarita'' stanno gia'' nelle loro sezioni: parcheggio core e frequenza minima CPU in Energia, priorita'' I/O e profilo multimediale in CPU, kernel sempre in RAM in Memoria. Il profilo Competitive le accende tutte.'
        $nota.FontSize = 12; $nota.Foreground = New-Brush '#ADADBA'
        $nota.TextWrapping = 'Wrap'; $nota.Margin = [Windows.Thickness]::new(0, 4, 0, 14)
        [void] $Contenuto.Children.Add($nota)

        # --- interrupt MSI ------------------------------------------------
        $msi = @(Get-VtMsiStato | Where-Object { $_.Tipo -eq 'Display' })
        if ($msi.Count -gt 0) {
            foreach ($m in $msi) {
                $ok = $m.Msi
                $txt = if ($ok) {
                    "Gli interrupt della scheda video sono di tipo MSI (message signaled): e' la modalita' giusta, non c'e' niente da fare.`n`nCon gli interrupt a linea condivisa la GPU deve aspettare che la linea si liberi, e quell'attesa diventa latenza DPC, cioe' scatti."
                } else {
                    "La scheda video usa interrupt a linea condivisa invece che MSI. Passare a MSI riduce la latenza DPC, ma NON lo faccio da qui: forzarlo su un dispositivo che non lo gestisce bene puo' impedire l'avvio del PC, e ripararlo richiede la modalita' provvisoria. Se vuoi provarci, fallo consapevolmente con uno strumento dedicato e con un punto di ripristino pronto.`n`nSull'AUDIO invece l'interruttore qui sopra c'e', ed e' una scelta voluta: se l'audio non riparte resti senza suono, fastidioso ma reversibile in un clic. Se non riparte la scheda video resti senza schermo, e non puoi piu' annullare niente. La differenza non e' il rischio che vada storto: e' se poi puoi rimediare."
                }
                [void] $Contenuto.Children.Add((New-InfoCard "Interrupt della GPU: $(if ($ok) { 'MSI (corretto)' } else { 'linea condivisa' })" "$($m.Nome)`n`n$txt" $(if ($ok) { '#57C98A' } else { '#E5A94E' })))
            }
        }

        # --- memoria in standby -------------------------------------------
        # Non e' un interruttore: e' un'azione da fare quando serve, come
        # svuotare un cestino. Per questo sta qui e non fra le voci sopra.
        $mem = Get-VtMemoriaStato
        $ora = if ($null -ne $mem.StandbyMb) {
            "In questo momento la riserva e' di $($mem.StandbyMb) MB, su $($mem.TotaleMb) MB di RAM totale, e ne hai $($mem.LiberaMb) MB liberi."
        } else { 'Non sono riuscito a leggere i contatori della memoria su questo PC.' }

        [void] $Contenuto.Children.Add((New-ActionCard 'Svuota la memoria in standby' `
            ("Quando chiudi un programma Windows non butta via la memoria che aveva letto dal disco: la tiene da parte, pronta nel caso serva ancora. E' una buona idea, finche' quella riserva non diventa enorme. A quel punto un gioco che chiede molta memoria tutta insieme costringe il sistema a liberarla di corsa, e quel lavoro si sente come uno scatto secco.`n`nSuccede soprattutto dopo ore di sessione, o dopo aver chiuso qualcosa di pesante e averne aperto subito un altro.`n`n$ora`n`nNon disattiva niente e non cambia nessuna impostazione: svuota la riserva adesso, una volta sola. Windows ricomincia a riempirla subito dopo, come e' giusto che faccia. Ha senso premerlo prima di entrare in partita, non a ripetizione.") `
            'Svuota adesso' {
                param($sender, $e)
                $sender.IsEnabled = $false
                try {
                    $r = Clear-VtMemoriaStandby
                    $liberati = $r.Dopo.LiberaMb - $r.Prima.LiberaMb
                    Show-Toast "Memoria in standby: da $($r.Prima.StandbyMb) a $($r.Dopo.StandbyMb) MB, $liberati MB tornati liberi"
                    Show-Sezione '#stabilita'
                } catch {
                    Show-Toast $_.Exception.Message
                    $sender.IsEnabled = $true
                }
            }))

        # --- programmi che disturbano -------------------------------------
        $dist = @(Get-VtDisturbatori)
        if ($dist.Count -gt 0) {
            $el = ($dist | ForEach-Object { "  -  $($_.N): $($_.Nota)" }) -join "`n"
            [void] $Contenuto.Children.Add((New-InfoCard "$($dist.Count) programmi che possono causare scatti sono aperti adesso" `
                "$el`n`nNon li tocco: alcuni ti servono. Ma se la misura qui sopra segnala interrupt a ondate, prova a chiuderli e a rifarla: la differenza si vede subito.`n`nQuelli con polling dei sensori (Afterburner, HWiNFO) spesso basta rallentarli, portando l'intervallo di campionamento a 1000-2000 ms." '#E5A94E'))
        } else {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun programma disturbatore noto in esecuzione' `
                "Non ho trovato aperti software RGB, overlay o monitor hardware fra quelli che tipicamente generano interrupt a ondate." '#57C98A'))
        }
        return
    }

    if ($cat -eq '#nvidia' -or $cat -eq '#amd') {
        $vend = Get-VtGpuVendor
        $atteso = if ($cat -eq '#nvidia') { 'NVIDIA' } else { 'AMD' }
        # Get-VtGpuRiga e non Get-VtRiepilogo: qui servono solo nome e driver
        # della scheda, e il riepilogo completo del PC costava un secondo.
        $r = Get-VtGpuRiga

        if ($vend -ne $atteso) {
            [void] $Contenuto.Children.Add((New-InfoCard "Nessuna scheda $atteso rilevata" `
                "Su questo PC ho trovato: $($r.Nome).`n`nQuesta pagina resta comunque leggibile: le voci qui sotto sono quelle da mettere su una scheda $atteso, se un domani ne monti una o se stai sistemando il PC di qualcun altro." '#E5A94E'))
        } else {
            [void] $Contenuto.Children.Add((New-InfoCard 'Scheda rilevata' "$($r.Nome)`n$($r.Dett)"))
        }

        # --- impostazioni 3D scritte via NVAPI ----------------------------
        if ($cat -eq '#nvidia' -and (Test-VtNvApi)) {
            $tNv = @(Get-VtCatalog | Where-Object { $_.Kind -eq 'Nvapi' })
            if ($tNv.Count -gt 0) {
                Add-Intestazione $Contenuto 'Impostazioni 3D: interruttori veri' `
                    'Queste le scrive VejaTweak dentro il profilo globale del driver, le stesse "Impostazioni globali 3D" che cambieresti a mano nel pannello. Spegnendo l''interruttore torna il valore di prima.'

                foreach ($t in $tNv) { [void] $Contenuto.Children.Add((New-TweakCard $t)) }
            }

            # Profili per singolo gioco: quello che si fa con Profile Inspector.
            $tProf = @(Get-VtCatalog | Where-Object { $_.Kind -eq 'NvProf' })
            if ($tProf.Count -gt 0) {
                Add-Intestazione $Contenuto 'Profili per singolo gioco' `
                    'E'' quello che si fa con NVIDIA Profile Inspector, senza doverlo scaricare: un profilo vale solo per il suo gioco, quindi si puo'' spingere di piu'' senza toccare tutto il resto. I profili dei giochi noti il driver ce li ha gia'' dentro e non si possono cancellare, quindi li modifico e mi segno ogni valore di prima per poterlo rimettere.'

                foreach ($t in $tProf) { [void] (Add-CardProfiloNv $Contenuto $t.Id) }
            }

            # --- ventole -------------------------------------------------
            $vent = Get-VtVentolaStato
            if ($vent) {
                Add-Intestazione $Contenuto 'Ventole della scheda video' `
                    'Letto direttamente dal driver, non stimato. Il voltaggio non lo tocco di proposito: le ventole non rovinano niente, la tensione del core si''.'

                $modo = try { [VejaVentole]::Modo() } catch { -1 }
                [void] $Contenuto.Children.Add((New-InfoCard 'Come gira adesso' `
                    ("Giri: $($vent.Giri) rpm`nVelocita': $($vent.Attuale)%`nIntervallo consentito dalla scheda: $($vent.Min)% - $($vent.Max)%`nControllo: " +
                     $(if ($modo -eq 1) { 'manuale (impostato da VejaTweak o da un altro programma)' } else { 'automatico, deciso dal driver' })) '#57C98A'))

                if (Test-VtVentoleControllabili) {
                    $preset = @(
                        @{ N='Base';        L=50; D='Silenzioso. Un filo piu'' delle ventole di serie a riposo: la scheda resta un po'' piu'' fresca senza che tu la senta.' }
                        @{ N='Competitive'; L=70; D='Equilibrio. Le temperature restano stabili sotto carico, quindi il boost non cala a meta'' partita. Si sente, ma con le cuffie no.' }
                        @{ N='Maximum';     L=90; D='Massimo raffreddamento. Rumorosa. Ha senso d''estate o se la scheda supera gli 80 gradi.' }
                    )
                    foreach ($p in $preset) {
                        $pc = $p
                        [void] $Contenuto.Children.Add((New-ActionCard "$($p.N)  -  ventola al $($p.L)%" `
                            ($p.D + "`n`nATTENZIONE: in manuale la ventola resta FISSA a questa percentuale e non sale piu' con la temperatura. E' il modo in cui funziona il driver, non una scelta mia. Torna automatica con il pulsante qui sotto, con 'Ripristina tutto', e comunque al riavvio del PC.") `
                            "Metti al $($p.L)%" {
                                param($sender, $e)
                                try {
                                    Set-VtVentola $pc.L
                                    Set-VtEntry 'ventola-gpu' @{ Livello = $pc.L }
                                    Show-Toast "Ventola portata al $($pc.L)%.`n`nResta fissa li' finche' non la rimetti in automatico."
                                    Update-Contenuto
                                } catch { Show-Toast $_.Exception.Message }
                            }.GetNewClosure() $(if ($p.L -ge 90) { '#E5A94E' } else { '#FF3B4E' })))
                    }
                    [void] $Contenuto.Children.Add((New-ActionCard 'Torna in automatico' `
                        'Ridai al driver il comando delle ventole. E'' quello che conviene tenere quasi sempre: la curva di fabbrica alza le ventole quando serve, cosa che una percentuale fissa non fa.' `
                        'Rimetti automatico' {
                            try {
                                Set-VtVentola -1
                                Remove-VtEntry 'ventola-gpu'
                                Show-Toast 'Ventole di nuovo in automatico.'
                                Update-Contenuto
                            } catch { Show-Toast $_.Exception.Message }
                        } '#57C98A'))
                } else {
                    [void] $Contenuto.Children.Add((New-InfoCard 'Su questa scheda non posso comandarle' `
                        @(
                            "Ho provato per davvero: leggere i giri funziona, ma il comando torna indietro con 'non supportato'. Sui PC preassemblati la ventola della scheda video la gestisce spesso il controller della scheda madre, non il BIOS della GPU, e NVIDIA non lascia scriverci da fuori.",
                            "Non e' un limite di VejaTweak: sugli stessi PC nemmeno MSI Afterburner riesce a muoverle. Se avessi una scheda non preassemblata, i tre preset comparirebbero qui da soli - il controllo c'e', si accende solo dove il driver lo permette.",
                            "Quello che resta e' la lettura qui sopra, che almeno ti dice come sta andando davvero."
                        ) -join "`n`n" '#E5A94E'))
                }
            }

            # --- caricare un .nip qualsiasi -------------------------------
            Add-Intestazione $Contenuto 'Carica un tuo file .nip' `
                'Trascina qui la configurazione che vuoi: VejaTweak la legge e la scrive nel driver da solo. NVIDIA Profile Inspector non serve averlo, ed e'' un bene: sono le stesse chiamate al driver, fatte da dentro il programma.'

            $caricati = @(Get-VtNipImporti)
            $etichetta2 = if ($caricati.Count -gt 0) { 'Annulla l''ultimo' } else { '' }

            $testoNip = @(
                "Il file viene letto e applicato voce per voce. Prima di scrivere fotografo ogni impostazione, quindi 'Annulla l'ultimo' rimette esattamente i valori di prima.",
                "Cosa NON applico, e te lo dico invece di nasconderlo: le voci di tipo diverso da Dword (testo o binario), e quelle che il driver installato non conosce. Del file di Fortnite, per esempio, il tuo driver ne salta una su quindici."
            )
            if ($caricati.Count -gt 0) {
                $ultimo = $caricati[-1]
                $testoNip += "Ultimo caricato: $($ultimo.File) il $($ultimo.Data)."
            }

            [void] $Contenuto.Children.Add((New-ActionCard 'Scegli un file .nip' ($testoNip -join "`n`n") `
                'Scegli il file...' {
                    param($sender, $e)
                    $dlg = New-Object Microsoft.Win32.OpenFileDialog
                    $dlg.Filter = 'Profili NVIDIA (*.nip)|*.nip|Tutti i file|*.*'
                    $dlg.Title  = 'Scegli il file .nip da applicare'
                    if (-not $dlg.ShowDialog()) { return }

                    # Prima si mostra cosa entra, poi si scrive: applicare a
                    # scatola chiusa un file che arriva da fuori non va bene.
                    try { $prof = @(Read-VtNipFile $dlg.FileName) }
                    catch { Show-Toast $_.Exception.Message; return }

                    $ante = @("Sto per applicare $($dlg.SafeFileName).", '')
                    foreach ($p in $prof) {
                        $ante += "$($p.Nome): $($p.Voci.Count) impostazioni su $($p.Exe.Count) eseguibili"
                        foreach ($v in ($p.Voci | Select-Object -First 8)) { $ante += "   $($v.Voce) -> $($v.Val_)" }
                        if ($p.Voci.Count -gt 8) { $ante += "   ... e altre $($p.Voci.Count - 8)" }
                        foreach ($ig in $p.Ignorate) { $ante += "   saltata: $ig" }
                    }
                    $ante += ''
                    $ante += 'Procedo?'
                    if ([Windows.MessageBox]::Show(($ante -join "`n"), 'VejaTweak', 'YesNo', 'Question') -ne 'Yes') { return }

                    $win.Cursor = [Windows.Input.Cursors]::Wait
                    try {
                        $r = Import-VtNip $dlg.FileName
                        Show-Toast ("Applicato.`n`n" + ($r.Righe -join "`n"))
                        Update-Contenuto
                    } catch { Show-Toast $_.Exception.Message }
                    finally { $win.Cursor = $null }
                } '#FF3B4E' $etichetta2 {
                    param($sender, $e)
                    $win.Cursor = [Windows.Input.Cursors]::Wait
                    try {
                        $n = Undo-VtNipUltimo
                        Show-Toast "Annullato: $n`n`nOgni impostazione e' tornata al valore che aveva prima."
                        Update-Contenuto
                    } catch { Show-Toast $_.Exception.Message }
                    finally { $win.Cursor = $null }
                }))

            # Se Profile Inspector ce l'hai gia', tanto vale poterlo aprire.
            # Scaricarlo no: un tweak che tira giu' eseguibili da internet sui
            # PC dei clienti e' un rischio che non vale niente, visto che qui
            # i .nip si applicano gia' senza.
            $pi = Find-VtProfileInspector
            if ($pi) {
                [void] $Contenuto.Children.Add((New-ActionCard 'Hai gia'' NVIDIA Profile Inspector' `
                    "L'ho trovato qui:`n$pi`n`nNon serve per applicare i .nip, quello lo fa VejaTweak. Serve semmai per CREARNE uno nuovo: imposti quello che vuoi, esporti il file, e poi lo carichi qui sopra." `
                    'Apri Profile Inspector' {
                        param($sender, $e)
                        try { Start-Process -FilePath $pi } catch { Show-Toast $_.Exception.Message }
                    }.GetNewClosure() '#E5A94E'))
            }
        }

        # --- quello che si puo' davvero eseguire -------------------------
        if ($vend -eq $atteso) {
            $eseguibili = @(Get-VtCatalog | Where-Object {
                $_.Cat -eq 'Scheda video' -and
                ($cat -eq '#nvidia' -and $_.Id -like 'nv-*' -or $_.Id -in 'hags', 'gpu-preferenza-giochi')
            })
            if ($eseguibili.Count -gt 0) {
                $tE = New-Object Windows.Controls.TextBlock
                $tE.Text = 'Queste le applico io'
                $tE.FontSize = 17; $tE.FontWeight = 'Bold'; $tE.Foreground = New-Brush '#F7F7FA'
                $tE.Margin = [Windows.Thickness]::new(0, 16, 0, 4)
                [void] $Contenuto.Children.Add($tE)

                $sE = New-Object Windows.Controls.TextBlock
                $sE.Text = 'Sono le sole voci della scheda video che Windows lascia scrivere a un programma. Le trovi anche in Prestazioni > GPU: sono le stesse, non doppioni.'
                $sE.FontSize = 12; $sE.Foreground = New-Brush '#ADADBA'
                $sE.TextWrapping = 'Wrap'; $sE.Margin = [Windows.Thickness]::new(0, 0, 0, 10)
                [void] $Contenuto.Children.Add($sE)

                foreach ($t in $eseguibili) { [void] $Contenuto.Children.Add((New-TweakCard $t)) }
            }

            # L'overlay non e' spegnibile da script, ma quanto costa si misura.
            $ov = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'NVIDIA Overlay|nvcontainer' })
            if ($ov.Count -gt 0) {
                $mb = [math]::Round((($ov | Measure-Object WorkingSet64 -Sum).Sum) / 1MB)
                [void] $Contenuto.Children.Add((New-InfoCard "Overlay NVIDIA: $($ov.Count) processi, $mb MB di RAM" `
                    "L'overlay si aggancia al rendering di ogni gioco, e questa e' la memoria che occupa adesso sul tuo PC.`n`nNon posso spegnerlo da qui: l'impostazione non sta in nessun file scrivibile (ho guardato, storage.json e overrides.json sono vuoti). Si toglie dall'app NVIDIA: Impostazioni > Overlay di gioco, e lo metti su Off.`n`nSe non usi la registrazione istantanea ne' il contatore FPS di NVIDIA, e' RAM e frame time regalati." '#E5A94E'))
            }
        }

        $resto = if ($cat -eq '#nvidia' -and (Test-VtNvApi)) {
            @(
                "Gli interruttori qui sopra scrivono davvero nel database del driver (nvdrsdb0.bin) passando per NVAPI, la libreria di NVIDIA: e' la stessa strada che usa il pannello, non una scorciatoia. Quello che resta sotto va messo a mano perche' NVAPI non lo espone o perche' dipende dal tuo monitor.",
                "La vividezza digitale e' uno di questi. Ho provato la strada alternativa, la rampa gamma di Windows: su questo PC il driver non la espone proprio, la lettura fallisce. Un preset di colore eseguibile sarebbe finto.",
                "Il limite di potenza della scheda si potrebbe cambiare con nvidia-smi, ma la tua e' gia' al massimo consentito: non c'e' niente da guadagnare, solo da perdere."
            )
        } elseif ($cat -eq '#nvidia') {
            @(
                "Su questo PC NVAPI non risponde (driver troppo vecchio o scheda NVIDIA assente), quindi le impostazioni 3D non posso scriverle io: restano da mettere a mano.",
                "Ti apro il pannello con un clic e ti dico esattamente cosa mettere e perche'. Sono una decina di clic, si fanno una volta sola."
            )
        } else {
            @(
                "Le impostazioni 3D di AMD stanno dentro Adrenalin e non esiste una libreria pubblica per scriverle da fuori come fa NVAPI su NVIDIA. Inventarsi delle chiavi di registro qui significa scrivere valori che il driver poi ignora: un tweak finto.",
                "Faccio quindi come per il BIOS: ti apro il pannello con un clic e ti dico esattamente cosa mettere e perche'. Sono una decina di clic, si fanno una volta sola."
            )
        }
        [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' il resto va messo a mano' ($resto -join "`n`n") '#E5A94E'))

        $pan = Get-VtPannelloGpu
        if ($pan) {
            [void] $Contenuto.Children.Add((New-ActionCard 'Apri il pannello' `
                "Apre $($pan.Nome) direttamente, senza cercarlo nel menu Start." 'Apri il pannello' {
                    try { Open-VtPannelloGpu } catch { Show-Toast $_.Exception.Message }
                }))
        } elseif ($vend -eq $atteso) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Pannello non trovato' `
                "Non ho trovato il pannello installato. Su NVIDIA si scarica dal Microsoft Store ('Pannello di controllo NVIDIA'), su AMD e' dentro AMD Software: Adrenalin Edition." '#E5A94E'))
        }

        $guida = if ($cat -eq '#nvidia') { Get-VtGuidaNvidia } else { Get-VtGuidaAmd }

        # Le voci che ora hanno un interruttore non le ripeto come istruzioni:
        # due posti che dicono la stessa cosa sono un posto che mente.
        if ($cat -eq '#nvidia' -and (Test-VtNvApi)) {
            $guida = @($guida | Where-Object {
                $_.Voce -notmatch 'gestione alimentazione|Sincronizzazione verticale|Ottimizzazione threaded'
            })
        }

        if ($guida.Count -gt 0) {
            $tit = New-Object Windows.Controls.TextBlock
            $tit.Text = 'Impostazioni 3D, in ordine di importanza'
            $tit.FontSize = 17; $tit.FontWeight = 'Bold'; $tit.Foreground = New-Brush '#F7F7FA'
            $tit.Margin = [Windows.Thickness]::new(0, 16, 0, 10)
            [void] $Contenuto.Children.Add($tit)

            foreach ($g in $guida) {
                [void] $Contenuto.Children.Add((New-InfoCard "$($g.Voce)  ->  $($g.Valore)" $g.Perche '#FF3B4E'))
            }
        }

        $tit2 = New-Object Windows.Controls.TextBlock
        $tit2.Text = 'Colore: come vedere meglio i nemici'
        $tit2.FontSize = 17; $tit2.FontWeight = 'Bold'; $tit2.Foreground = New-Brush '#F7F7FA'
        $tit2.Margin = [Windows.Thickness]::new(0, 20, 0, 4)
        [void] $Contenuto.Children.Add($tit2)

        $sub2 = New-Object Windows.Controls.TextBlock
        $sub2.Text = 'Queste non danno FPS: danno leggibilita''. Un modello che stacca dallo sfondo lo vedi mezzo secondo prima, e mezzo secondo in un duello vale piu'' di venti frame.'
        $sub2.FontSize = 12; $sub2.Foreground = New-Brush '#ADADBA'
        $sub2.TextWrapping = 'Wrap'; $sub2.Margin = [Windows.Thickness]::new(0, 0, 0, 10)
        [void] $Contenuto.Children.Add($sub2)

        $colori = if ($cat -eq '#nvidia') { Get-VtGuidaColoriNvidia } else { Get-VtGuidaColoriAmd }
        foreach ($g in $colori) {
            [void] $Contenuto.Children.Add((New-InfoCard "$($g.Voce)  ->  $($g.Valore)" $g.Perche '#E5A94E'))
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Un avvertimento onesto sui colori' `
            "La vividezza alta e' legale e non e' un cheat, ma e' anche una scorciatoia: ti abitua a cercare la macchia colorata invece della sagoma. Se esageri e poi giochi su un altro PC, ti trovi peggio di prima. Tienila dove ti aiuta, non dove ti droga l'occhio.`n`nE ricorda che queste impostazioni valgono per il monitor collegato adesso: se ne cambi uno, vanno rifatte." '#E0785E'))
        return
    }

    if ($cat -eq '#controller') {
        $pad     = @(Get-VtGamepad)
        $storici = @(Get-VtGamepadStorici)
        $spenti  = @(Get-VtControllerSpenti)

        if ($pad.Count -gt 0) {
            $righe = @($pad | ForEach-Object { "$($_.Nome)  -  $($_.Stato)" }) -join "`n"
            [void] $Contenuto.Children.Add((New-InfoCard "Controller collegati adesso: $($pad.Count)" $righe '#57C98A'))
        } elseif ($storici.Count -gt 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun controller collegato in questo momento' `
                ("Questo PC pero' ne ha gia' visti: " + ($storici -join ', ') + ".`n`nLe voci qui sotto restano valide: si applicano al sistema, non al singolo pad, e valgono anche per quello che collegherai domani.")))
        } else {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun controller collegato' `
                "Non ho trovato pad collegati ne' tracce di pad usati in passato su questo PC.`n`nLe voci qui sotto si possono applicare lo stesso: agiscono sul sistema, e servono proprio a far si' che il primo pad che colleghi venga riconosciuto subito." '#E5A94E'))
        }

        # Il guaio piu' frequente, e quello che il cliente non collega mai al
        # PC: pensa di avere il controller rotto.
        if ($spenti.Count -gt 0) {
            $el = @($spenti | ForEach-Object { "$($_.Name) - $($_.Perche)" }) -join "`n`n"
            [void] $Contenuto.Children.Add((New-InfoCard "$($spenti.Count) driver dei controller risultano DISATTIVATI" `
                ("Non e' il valore con cui Windows li installa: qualcosa li ha spenti, quasi sempre uno di quegli script che disattivano servizi in blocco.`n`n" + $el + "`n`nSi rimettono a posto con il primo interruttore qui sotto.") '#F06A6A'))
        }

        Add-Intestazione $Contenuto 'Quello che posso sistemare io' `
            'Tre cose, e sono le tre che rompono davvero l''esperienza col pad: driver spenti, porte USB che si addormentano, e il tasto Xbox che apre l''overlay sopra il gioco.'

        foreach ($t in (Get-VtCatalog | Where-Object { $_.Cat -eq 'Controller' })) {
            [void] $Contenuto.Children.Add((New-TweakCard $t))
        }

        Add-Intestazione $Contenuto 'Quello che NON sta in Windows' `
            'Perche'' tu sappia dove cercare invece di girare a vuoto fra i tweak.'

        [void] $Contenuto.Children.Add((New-InfoCard 'Zona morta e sensibilita'' degli stick' `
            "Non esistono in Windows: sono impostazioni interne a ogni gioco. Un tweak che promette di togliere la zona morta a livello di sistema sta cambiando qualcosa che i giochi non leggono.`n`nDove si mettono davvero: dentro il gioco, di solito sotto Controlli o Gamepad. Su Steam c'e' anche Steam Input (Impostazioni > Controller), che riscrive le zone morte per i giochi lanciati da li'." '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Cavo o senza filo: la differenza vera' `
            "Via cavo il pad manda i dati ogni millisecondo circa. In Bluetooth il ritardo aggiunto sta tipicamente fra i 5 e i 15 millisecondi, e soprattutto e' meno regolare: e' l'irregolarita' che si sente, non il ritardo medio.`n`nCon un adattatore wireless dedicato (quello Xbox, o il dongle di un pad da gioco) si sta molto piu' vicino al cavo che al Bluetooth.`n`nSe giochi competitivo e hai il dubbio: cavo. Costa zero e toglie una variabile." '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Batteria quasi scarica = ritardo e disconnessioni' `
            "Un pad sotto il 15% di batteria abbassa la potenza della radio per durare di piu'. Il risultato sono micro-interruzioni che sembrano lag del gioco.`n`nSe il pad ti fa scherzi solo a fine serata, e' quasi sempre questo." '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Due driver che si contendono lo stesso pad' `
            "Se hai installato DS4Windows, x360ce, reWASD o simili, quel programma crea un pad virtuale ACCANTO a quello vero. Certi giochi li vedono tutti e due e leggono quello sbagliato: sembra che il controller non risponda, o che risponda doppio.`n`nSe succede, chiudi quei programmi e riprova prima di cercare altro. Non li tocco io: sono scelte tue, e disinstallarli senza chiedere sarebbe scorretto." '#E5A94E'))

        return
    }

    if ($cat -eq '#discord') {
        $st = Get-VtDiscordStato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Discord non risulta installato' `
                "Cercato settings.json in %APPDATA%\discord. Se usi la versione dal browser non c'e' niente da ottimizzare: il peso ce l'ha il browser, non Discord." '#E5A94E'))
            return
        }

        $accelTxt = switch ($st.Accelerazione) {
            $true  { 'accesa (impostata a mano)' }
            $false { 'spenta' }
            default { 'accesa (valore predefinito)' }
        }
        $riass = @(
            "Processi aperti adesso : $($st.Processi)"
            "RAM occupata           : $($st.RamMb) MB"
            "Accelerazione hardware : $accelTxt"
            "Processo GPU attivo    : $(if ($st.ProcessoGpu) { "SI, $($st.GpuMb) MB" } else { 'no' })"
            "Cache su disco         : $($st.CacheMb) MB"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo Discord adesso' $riass))

        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Discord e'' aperto' `
                "Chiudilo del tutto prima di toccare le impostazioni, anche dall'icona vicino all'orologio: quando esce riscrive settings.json e cancellerebbe la modifica. I pulsanti si rifiutano di partire finche' lo trovano aperto." '#F06A6A'))
        }

        # Interruttori veri, con backup e ripristino come tutti gli altri.
        foreach ($t in (Get-VtCatalog | Where-Object { $_.Cat -eq 'Discord' })) {
            [void] $Contenuto.Children.Add((New-TweakCard $t))
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Come verificare che abbiano funzionato' `
            "Applica, chiudi Discord del tutto (anche dall'icona vicino all'orologio), riaprilo e torna qui.`n`nAccelerazione hardware: la riga 'Processo GPU attivo' deve diventare 'no'.`n`nOverlay: entra in un gioco e prova la scorciatoia dell'overlay (di solito MAIUSC+`) - non deve comparire niente." '#E5A94E'))

        if ($st.CacheMb -gt 50) {
            [void] $Contenuto.Children.Add((New-InfoCard "Cache: $($st.CacheMb) MB da recuperare" `
                "La trovi in Sistema > Pulizia file, voce 'Cache di Discord'. Chiudi Discord prima, altrimenti i file sono in uso e ne resta indietro la maggior parte." '#E5A94E'))
        }

        # L'overlay: modulo presente su disco, ma l'interruttore sta nel
        # database interno di Discord. Lo rileviamo e spieghiamo, non lo
        # forziamo: vedi la card sotto.
        $modOv = @(Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Discord') -Directory -Recurse -Depth 3 -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -like 'discord_overlay*' -or $_.Name -like 'discord_desktop_overlay*' })
        $ovAttivo = $false
        try {
            $ovAttivo = @(Get-CimInstance Win32_Process -Filter "Name='Discord.exe'" -ErrorAction SilentlyContinue |
                          Where-Object { $_.CommandLine -match 'overlay' }).Count -gt 0
        } catch { }

        [void] $Contenuto.Children.Add((New-InfoCard 'Come funziona l''interruttore dell''overlay' `
            @(
                "L'impostazione dell'overlay sta nel database interno di Discord, in formato binario: scriverci dentro rischierebbe di azzerare tutte le tue impostazioni. Quindi agisco altrove.",
                "L'overlay e' un modulo a se', in una sua cartella dentro Discord\modules. Spegnendolo, quella cartella viene rinominata: Discord non la trova e il modulo non parte. Sul tuo PC i moduli sono $($modOv.Count), e in questo momento l'overlay risulta $(if ($ovAttivo) { 'ATTIVO' } else { 'non in esecuzione' }).",
                "Non viene cancellato niente: riaccendendo l'interruttore il nome torna quello di prima.",
                "L'unico limite onesto: un aggiornamento di Discord puo' rimettere il modulo al suo posto. Non e' un guasto silenzioso, perche' l'interruttore legge la situazione vera del disco e si mostra spento da solo: te ne accorgi e ricliccki."
            ) -join "`n`n" '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Cosa non tocco, e perche''' `
            "Avvio automatico: sul tuo PC Discord non e' in avvio automatico, quindi non c'e' niente da togliere. Non aggiungo interruttori per cose che sul tuo sistema non esistono.`n`nQualita' del servizio vocale, riduzione del rumore, codec: sono impostazioni del tuo account e cambiarle dall'esterno vorrebbe dire indovinare. Stanno in Discord > Voce e video." '#ADADBA'))
        return
    }

    if ($cat -eq '#fortnite') {
        $p = Get-VtFortnitePaths
        if (-not $p.Esiste) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Configurazione di Fortnite non trovata' "Non ho trovato GameUserSettings.ini in:`n$($p.Dir)`n`nAvvia Fortnite una volta e richiudilo: il file lo crea il gioco al primo avvio." '#E5A94E'))
            return
        }

        $st = Get-VtFortniteStato
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Fortnite e'' aperto adesso' "Chiudi il gioco prima di toccare qualcosa qui. Fortnite riscrive GameUserSettings.ini quando esce, quindi qualsiasi modifica fatta ora verrebbe cancellata. I pulsanti si rifiutano di partire finche' e' aperto." '#F06A6A'))
        }

        $riass = @(
            "Risoluzione      : $($st.Risoluzione)"
            "Limite FPS       : $($st.Fps)"
            "Modalita' schermo: $($st.Modalita)"
            "Rendering        : $($st.Rendering)"
            "NVIDIA Reflex    : $($st.Reflex)"
            "Risoluzione 3D   : $($st.Res3D)%"
            "V-Sync           : $($st.VSync)"
            "File bloccato    : $(if ($st.SolaLettura) { 'SI (sola lettura)' } else { 'no' })"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo il gioco adesso' $riass))

        # Profilo del driver per Fortnite: e' la stessa cosa che si fa con
        # NVIDIA Profile Inspector, ma agisce fuori dal gioco, sul driver.
        if (Get-VtCatalog | Where-Object { $_.Id -eq 'nip-fortnite' }) {
            Add-Intestazione $Contenuto 'Profilo NVIDIA per Fortnite'
            [void] (Add-CardProfiloNv $Contenuto 'nip-fortnite')
        }

        [void] $Contenuto.Children.Add((New-ActionCard 'Preset competitivo' `
            "Modalita' Prestazioni, ombre ed effetti a zero, anti-aliasing off, motion blur off, erba off, Reflex On + Boost, schermo intero esclusivo, V-Sync off, risoluzione 3D al 100% e limite FPS agganciato al tuo monitor ($(Get-VtMonitorHz) Hz).`n`nLa risoluzione 3D la porta a 100: piu' nitido e bersagli piu' leggibili. Se preferisci qualche FPS in piu' a costo di un'immagine piu' morbida, in gioco rimettila a 90." `
            'Applica il preset' {
                try {
                    $hz = Invoke-VtFortnitePreset
                    Show-Toast "Preset applicato. Limite FPS impostato a $hz."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        $hz = Get-VtMonitorHz
        [void] $Contenuto.Children.Add((New-ActionCard "Blocca gli FPS a $hz (refresh del monitor)" `
            "Imposta il limite FPS al refresh reale del tuo schermo senza attivare il V-Sync.`n`nA cosa serve: sopra il refresh gli FPS in piu' non li vedi, ma la GPU li calcola lo stesso, scalda e alza il frame time. Con un limite fisso il frame time diventa regolare, ed e' quello che si sente." `
            "Blocca a $hz FPS" {
                try { Set-VtFortniteFpsLimit (Get-VtMonitorHz); Show-Toast 'Limite FPS impostato.'; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        [void] $Contenuto.Children.Add((New-ActionCard 'FPS illimitati' `
            "Toglie del tutto il limite interno di Fortnite.`n`nHa senso solo se usi Reflex (che gestisce la coda da solo) o se stai facendo dei test. Nell'uso normale il limite agganciato al monitor da' un frame time piu' costante." `
            'Togli il limite' {
                try { Set-VtFortniteFpsLimit 0; Show-Toast 'Limite FPS rimosso.'; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        [void] $Contenuto.Children.Add((New-ChoiceCard 'Compromesso FPS / nitidezza' `
            "Le tre voci che pesano davvero, in un solo gradino: risoluzione 3D, distanza visuale e limite FPS.`n`nSe dopo il preset ti sembra di aver perso frame, e' quasi sempre questo: il preset alza la risoluzione 3D al 100% e la distanza visuale, che si vedono meglio ma costano. Scegli 'Massimo FPS' e torni indietro.`n`nAttenzione al contatore: con il limite agganciato al monitor leggerai $(Get-VtMonitorHz) invece di 300, ma sopra il refresh del tuo schermo quei frame non li vedevi comunque." `
            $script:VtQualitaFn 'Applica' {
                param($sender, $e)
                $cb = $sender.Tag
                $q  = $cb.Tag[$cb.SelectedIndex]
                try {
                    Set-VtFortniteQualita $q.Res $q.Vista $q.Fps
                    Show-Toast "Applicato: risoluzione 3D $($q.Res)%, distanza visuale $($q.Vista)."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        $rx = 0; $ry = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $rx = [int]$matches[1]; $ry = [int]$matches[2] }

        # Il file mezzo riscritto: e' lo stato in cui si finisce dopo aver
        # chiesto una risoluzione che lo schermo non ha. Va segnalato prima di
        # tutto il resto, perche' finche' resta cosi' qualsiasi altra cosa si
        # imposti da qui verra' sovrascritta dal gioco.
        $coe = Test-VtFortniteRisoluzioneCoerente
        if ($coe -and -not $coe.Coerente) {
            $el = ($coe.Diverse | ForEach-Object { "  -  $_" }) -join "`n"
            $cx = $coe.X; $cy = $coe.Y
            # Le parentesi attorno alla concatenazione sono obbligatorie: senza,
            # PowerShell prende "Riallinea tutto a 1920" come parametro e poi
            # tratta il resto come argomenti a se', spostando di posto il blocco
            # e il colore. L'errore che ne usciva parlava di colori non validi.
            $etichetta = "Riallinea tutto a ${cx}x${cy}"
            [void] $Contenuto.Children.Add((New-ActionCard 'Il file di Fortnite non e'' coerente' `
                ("Fortnite tiene la risoluzione in quattro coppie di chiavi, e devono dire tutte la stessa cosa. Sul tuo PC non e' cosi':`n`nIn uso: $($coe.InUso)`n$el`n`nSuccede quando si chiede una risoluzione che lo schermo non ha: il gioco la rifiuta, rimette la nativa solo in alcune chiavi, e le altre restano indietro. Da quel momento la risoluzione sembra non salvarsi piu', e cambiarla dal menu del gioco spesso non basta perche' le chiavi rimaste indietro se la ritrascinano dietro.`n`nRiallineo tutte le chiavi a $($coe.InUso), che sul tuo schermo esiste. Poi puoi scegliere quella che vuoi qui sotto.") `
                $etichetta {
                    try {
                        Repair-VtFortniteRisoluzione $cx $cy
                        Show-Toast 'Chiavi della risoluzione riallineate.'
                        Update-Contenuto
                    } catch { Show-Toast $_.Exception.Message }
                }.GetNewClosure() '#F06A6A'))
        }

        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'Fortnite' $rx $ry {
            param($x, $y) Set-VtFortniteResolution $x $y
        }))

        [void] $Contenuto.Children.Add((New-ChoiceCard 'Risoluzione (scelte pronte)' `
            "Scrive la risoluzione dentro Fortnite e forza lo schermo intero esclusivo.`n`nQui trovi SOLO le risoluzioni che il tuo schermo espone davvero: se ne scegliessi una che non esiste, il gioco non riuscirebbe ad andarci in schermo intero e riscriverebbe il file da solo. Le stretched che ti sei creato nel pannello NVIDIA compaiono in questo elenco.`n`nPerche' la stretched si veda davvero devi anche impostare, nel Pannello NVIDIA > Regola dimensioni e posizione del desktop: Modalita' di ridimensionamento su 'Schermo intero' ed 'Esegui ridimensionamento su: GPU'. Senza quello ti ritrovi due bande nere ai lati invece dei modelli piu' larghi." `
            (Get-VtSceltaRisoluzioni) 'Applica' {
                param($sender, $e)
                $cb = $sender.Tag
                $r  = $cb.Tag[$cb.SelectedIndex]
                try {
                    Set-VtFortniteResolution $r.X $r.Y
                    Show-Toast "Risoluzione impostata a $($r.X)x$($r.Y)."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        if ($st.SolaLettura) {
            [void] $Contenuto.Children.Add((New-ActionCard 'Sblocca il file di configurazione' `
                "Il file e' in SOLA LETTURA: qualcuno l'ha bloccato (SapoTweak lo fa) perche' Fortnite non possa riscriverlo.`n`nEffetto collaterale: anche le impostazioni che cambi TU dal menu del gioco non vengono piu' salvate. Se ti sembra che il gioco 'dimentichi' le opzioni, e' questo." `
                'Sblocca il file' {
                    try { Set-VtFortniteReadOnly $false; Show-Toast 'File sbloccato.'; Update-Contenuto }
                    catch { Show-Toast $_.Exception.Message }
                } '#E5A94E'))
        } else {
            [void] $Contenuto.Children.Add((New-ActionCard 'Blocca il file di configurazione' `
                "Mette GameUserSettings.ini in sola lettura, cosi' Fortnite non puo' riscriverlo all'uscita e le impostazioni restano quelle.`n`nAttenzione: da quel momento nemmeno le modifiche che fai TU dal menu del gioco vengono salvate. Bloccalo solo quando hai finito di sistemare tutto." `
                'Blocca il file' {
                    try { Set-VtFortniteReadOnly $true; Show-Toast 'File bloccato in sola lettura.'; Update-Contenuto }
                    catch { Show-Toast $_.Exception.Message }
                }))
        }

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            "Rimette il GameUserSettings.ini come stava prima dell'ultima modifica fatta da VejaTweak. Una copia viene fatta automaticamente prima di ogni azione di questa pagina (ne teniamo le cinque piu' recenti)." `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtFortnite; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#E5A94E'))

        return
    }

    if ($cat -eq '#valorant') {
        $st = Get-VtValorantStato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Configurazione di Valorant non trovata' "Cercata in %LOCALAPPDATA%\VALORANT\Saved\Config. Avvia il gioco una volta e richiudilo: i file li crea Valorant al primo avvio." '#E5A94E'))
            return
        }
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Valorant o il Riot Client sono aperti' "Chiudili entrambi prima di toccare qualcosa: alla chiusura riscrivono i file di configurazione e le modifiche verrebbero perse. I pulsanti si rifiutano di partire finche' sono aperti." '#F06A6A'))
        }
        $riass = @(
            "Risoluzione    : $($st.Risoluzione)"
            "Limite FPS     : $($st.Fps)"
            "V-Sync         : $($st.VSync)"
            "Anti-aliasing  : $($st.AntiAlias)"
            "Materiali      : $($st.Materiali)"
            "Texture        : $($st.Texture)"
            "Dettaglio      : $($st.Dettaglio)"
            "Ombre          : $($st.Ombre)"
            "Migliora nitidezza: $($st.Chiarezza)"
            "NVIDIA Reflex  : $($st.Reflex)"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo Valorant adesso' $riass))

        $hz = Get-VtMonitorHz
        [void] $Contenuto.Children.Add((New-ActionCard 'Preset competitivo' `
            "Anti-aliasing off, materiali/texture/dettaglio al minimo, ombre off, 'Migliora nitidezza' off, Reflex su On + Boost, V-Sync off, schermo intero, limite FPS a $hz.`n`nDue note oneste: l'anti-aliasing e' la voce piu' costosa e lo porto a zero, ma con la tua 4060 a 1080p MSAA 4x te lo potresti permettere: se preferisci i bordi puliti rimettilo dal menu del gioco. Il filtro anisotropico non lo tocco: su una GPU moderna e' praticamente gratis, spegnerlo sarebbe un guadagno finto." `
            'Applica il preset' {
                try { $h = Invoke-VtValorantPreset; Show-Toast "Preset applicato. Limite FPS a $h."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        [void] $Contenuto.Children.Add((New-ActionCard "Blocca gli FPS a $hz" `
            "Imposta il limite al refresh del monitor senza V-Sync, su entrambe le copie del file (quella dell'account e quella di macchina: Valorant ne tiene due e vanno tenute allineate)." `
            "Blocca a $hz FPS" {
                try { Set-VtValorantFps (Get-VtMonitorHz); Show-Toast 'Limite FPS impostato.'; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            }))

        $vx = 0; $vy = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $vx = [int]$matches[1]; $vy = [int]$matches[2] }
        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'Valorant' $vx $vy {
            param($x, $y) Set-VtValorantRisoluzione $x $y
        }))

        [void] $Contenuto.Children.Add((New-InfoCard 'Nota sulle stretched in Valorant' `
            "Quando imposto una risoluzione tolgo anche il letterbox, altrimenti Valorant ti mette due bande nere ai lati invece di allargare l'immagine: e' esattamente il contrario di quello che serve.`n`nPerche' la stretched si veda davvero serve anche il ridimensionamento a schermo intero sulla GPU, dal pannello NVIDIA." '#E5A94E'))

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            "Rimette i file di Valorant come stavano prima dell'ultima modifica di VejaTweak." `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtValorant; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Vanguard' "Non tocchiamo il servizio vgc ne' Vanguard in nessun modo: si scrivono solo i file di impostazioni del gioco, cioe' gli stessi che Valorant scrive da solo quando cambi le opzioni dal menu. Se qualche 'ottimizzatore' ti propone di disattivare vgc, il gioco poi non parte." '#E0785E'))
        return
    }

    if ($cat -eq '#fivem') {
        $st = Get-VtFivemStato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Impostazioni di FiveM non trovate' "Cercato %APPDATA%\CitizenFX\gta5_settings.xml. Avvia FiveM una volta e richiudilo.`n`nNota: FiveM NON usa il settings.xml di GTA V, ne tiene uno suo. Modificare quello di GTA V non cambia niente in FiveM." '#E5A94E'))
            return
        }
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'FiveM e'' aperto' 'Chiudilo prima: alla chiusura riscrive il file e le modifiche andrebbero perse.' '#F06A6A'))
        }
        $riass = @(
            "Risoluzione       : $($st.Risoluzione)"
            "Modalita' schermo : $($st.Finestra)"
            "V-Sync            : $($st.VSync)"
            "MSAA              : $($st.Msaa)"
            "Qualita' ombre    : $($st.Ombre)"
            "Distanza ombre    : $($st.DistanzaOmbre)"
            "Densita' citta'   : $($st.Citta)"
            "Varieta' pedoni   : $($st.Pedoni)"
            "Scala LOD         : $($st.Lod)"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo FiveM adesso' $riass))

        # --- cosa non torna nel file -------------------------------------
        # Prima di tutto il resto: se una di queste righe e' storta, tutto
        # quello che si imposta piu' sotto non serve a niente.
        foreach ($a in (Get-VtFivemAnomalie)) {
            $col = if ($a.Peso -eq 1) { '#F06A6A' } else { '#E5A94E' }
            [void] $Contenuto.Children.Add((New-InfoCard $a.Titolo $a.Testo $col))
        }

        # --- se il gioco non parte piu' -----------------------------------
        # Il ripristino esisteva gia' ma stava in fondo alla pagina, dove chi
        # ha appena visto crashare il gioco non lo trova. Il momento in cui
        # serve e' esattamente questo, quindi sta qui in alto.
        $bak = @()
        try {
            $ff = Get-VtFivemSettings
            $bak = @(Get-ChildItem (Split-Path $ff.Path -Parent) -Filter 'gta5_settings.xml.vejatweak.*.bak' -ErrorAction SilentlyContinue)
        } catch { }
        if ($bak.Count -gt 0) {
            [void] $Contenuto.Children.Add((New-ActionCard 'FiveM non parte piu''? Rimetti tutto com''era' `
                ("Ogni volta che tocco il file ne conservo una copia: ne ho $($bak.Count). Questo pulsante rimette la piu' recente, e FiveM torna esattamente com'era prima dell'ultima modifica fatta da qui.`n`nUsalo subito se dopo un preset il gioco crasha all'avvio, invece di reinstallare o cancellare la cache: sono trenta secondi e non perdi niente.`n`nSe crasha ancora dopo il ripristino, allora la causa non e' in questo file e va cercata altrove - tipicamente driver video o cache di FiveM.") `
                'Ripristina il file di FiveM' {
                    try {
                        $n = Restore-VtFivem
                        Show-Toast "Ripristinato da $n"
                        Update-Contenuto
                    } catch { Show-Toast $_.Exception.Message }
                } '#E5A94E'))
        }

        # Profilo del driver per FiveM, scritto da noi.
        if (Get-VtCatalog | Where-Object { $_.Id -eq 'nip-fivem' }) {
            Add-Intestazione $Contenuto 'Profilo NVIDIA per FiveM'
            [void] (Add-CardProfiloNv $Contenuto 'nip-fivem')
        }

        # --- Movimento e strafe ------------------------------------------
        $tMov = @(Get-VtCatalog | Where-Object { $_.Cat -eq 'FiveM movimento' })
        if ($tMov.Count -gt 0) {
            Add-Intestazione $Contenuto 'Movimento e strafe'

            foreach ($t in $tMov) { [void] $Contenuto.Children.Add((New-TweakCard $t)) }

            # Cosa cambia, voce per voce, con il valore che hai adesso: cosi'
            # si vede se il tweak ha qualcosa da fare o e' gia' tutto a posto.
            $conv = Get-VtFivemConvar
            $righe = @()
            foreach ($v in (Get-VtFivemMovimento)) {
                $ora = if ($conv.ContainsKey($v.Nome)) { $conv[$v.Nome] } else { 'assente' }
                $segno = if ("$ora" -eq "$($v.Valore)") { 'gia'' a posto' } else { "$ora  ->  $($v.Valore)" }
                $righe += "  {0,-42} {1}" -f $v.Etichetta, $segno
            }
            [void] $Contenuto.Children.Add((New-InfoCard 'Le dieci voci, con il tuo valore attuale' `
                ($righe -join "`n") '#ADADBA'))

            [void] $Contenuto.Children.Add((New-InfoCard 'Cosa NON faccio, e perche'' te lo dico' `
                "La velocita' con cui il personaggio si sposta la decide il server, non il tuo PC: non esiste nessun file locale che la cambi, e cambiarla sarebbe barare. Chi ti vende uno 'strafe boost' che promette di muoverti piu' in fretta ti sta vendendo o niente o un ban.`n`nQuello che si puo' fare davvero e' togliere tutto quello che sta FRA il tasto che premi e quello che vedi, ed e' esattamente quello che c'e' qui sopra. Sul cambio di direzione A-D il problema non e' la velocita': e' che con l'accelerazione attiva lo stesso movimento del polso non da' mai lo stesso risultato, e il colpo dopo lo strafe non e' ripetibile." '#E0785E'))
        }

        Add-Intestazione $Contenuto 'Preset' `
            'Su un server pieno il carico grosso lo fanno gli altri giocatori, e quelli non si tolgono: li decide il server. Quello che si toglie e'' il contorno - traffico e passanti generati dal tuo client, modelli in streaming, effetti di luce - ed e'' li'' che si recupera.'

        [void] $Contenuto.Children.Add((New-ActionCard 'Server affollati' `
            @(
                "Densita' citta', varieta' pedoni e varieta' VEICOLI a meta'; scala LOD 0.7; distanza ombre 0.4; ombre morbide, ombre delle particelle e MSAA a zero. In piu': shader in versione economica, nebbia volumetrica off, luce sottopelle off, sfocatura dei riflessi off.",
                "La varieta' dei veicoli prima restava al massimo mentre le altre due densita' erano gia' a meta': era una dimenticanza, ed e' proprio quella che su un server pieno fa streammare decine di modelli di auto diversi.",
                "Spegne anche il buffer del Rockstar Editor. Con la registrazione attiva il gioco tiene centinaia di MB che riscrive di continuo, per una funzione che in FiveM non usa quasi nessuno. Se ti servisse, si riaccende dalle impostazioni del gioco."
            ) -join "`n`n" `
            'Applica' {
                try {
                    $r = Invoke-VtFivemPreset 'affollati'
                    Show-Toast "Applicato: $($r.Applicate) voci grafiche e $($r.Convar) impostazioni di FiveM.$(if ($r.Saltate.Count) { "`n`n$($r.Saltate.Count) non presenti nel file, saltate." })"
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        [void] $Contenuto.Children.Add((New-ActionCard 'Spinto: citta'' spoglia' `
            @(
                "Tutto quello sopra, piu' le voci che hanno un prezzo che si vede: densita' citta', pedoni e veicoli a ZERO, dettaglio dei passanti al minimo, scala LOD 0.5, distanza ombre 0.2, texture dei veicoli a meta' risoluzione.",
                "Cosa cambia davvero: sparisce il traffico e spariscono i passanti generati dal tuo client. Le auto e le persone messe dal SERVER restano tutte, perche' quelle non le decidi tu - quindi su un server di ruolo pieno perdi il contorno, non il gioco.",
                "Il prezzo: la citta' e' vuota quando non c'e' nessuno, e da vicino le carrozzerie si vedono piu' morbide. Usalo quando il server e' pieno davvero e preferisci una citta' spoglia a una presentazione a scatti."
            ) -join "`n`n" `
            'Applica lo spinto' {
                try {
                    $r = Invoke-VtFivemPreset 'spinto'
                    Show-Toast "Applicato lo spinto: $($r.Applicate) voci grafiche e $($r.Convar) impostazioni di FiveM."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            } '#E5A94E'))

        $fx = 0; $fy = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $fx = [int]$matches[1]; $fy = [int]$matches[2] }
        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'FiveM' $fx $fy {
            param($x, $y)
            $r = Set-VtFivemRisoluzione $x $y
            if (-not $r.Disponibile) {
                Show-Toast @"
Scritta, ma attenzione: ${x}x${y} non esiste fra le modalita' della tua scheda video.

Senza quella modalita' il gioco NON puo' andare a schermo intero esclusivo e ripiega su una finestra: e' esattamente il motivo per cui una stretched scritta a mano "va solo in finestra".

Si risolve creandola una volta nel pannello NVIDIA (Cambia risoluzione > Personalizza > Crea risoluzione personalizzata). Dopo, il gioco la trovera'.
"@
            }
        }))

        # La causa piu' frequente del "me la mette in finestra" e' proprio
        # questa, quindi va detta prima che uno provi, non dopo.
        $modi = @(Get-VtModiSchermo | ForEach-Object { $_.Split('@')[0] } | Select-Object -Unique | Sort-Object)
        if ($modi.Count -gt 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' una stretched a volte "va solo in finestra"' `
                @(
                    "Per andare a schermo intero ESCLUSIVO la risoluzione che chiedi deve esistere come modalita' della scheda video. Se non esiste, il gioco non puo' cambiare modo e ripiega su una finestra: non e' un difetto del gioco ne' di VejaTweak.",
                    "Le stretched che il pannello NVIDIA ha gia' registrato ci sono. Una inventata al momento no: va creata una volta da Pannello NVIDIA > Cambia risoluzione > Personalizza.",
                    "Sul tuo schermo adesso sono disponibili queste $($modi.Count):",
                    ($modi -join '   ')
                ) -join "`n`n" '#E5A94E'))
        }

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            'Rimette gta5_settings.xml come stava prima dell''ultima modifica di VejaTweak.' `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtFivem; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#E5A94E'))

        [void] $Contenuto.Children.Add((New-InfoCard 'Quello che pesa di piu'' non e'' qui' "Su FiveM i mod grafici lato client (NVE, QuantV e simili) costano piu' di qualunque impostazione di questa pagina, e i server con tante risorse personalizzate ti fanno crollare il frame time a prescindere dal PC. Se giochi su un server pesante, la differenza la fa il server, non tu." '#E0785E'))
        return
    }

    if ($cat -eq '#r6') {
        $r6 = Get-VtR6Settings
        $st = Get-VtR6Stato
        if (-not $st) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Rainbow Six Siege non risulta installato' "Cercato GameSettings.ini in:`n$($r6.Base)\<id Ubisoft>\`n`nSe installi il gioco, avvialo una volta e riapri questa pagina: i controlli e il preset si attivano da soli." '#E5A94E'))
            [void] $Contenuto.Children.Add((New-InfoCard 'Vulkan invece di DX11' "Quando lo installi: scegli Vulkan dal menu di avvio di Ubisoft Connect, non dalle impostazioni del gioco. Su quasi tutte le configurazioni da' piu' FPS e frame time piu' stabile di DX11. Questa scelta non sta nel file di configurazione, quindi nessun tweaker puo' farla al posto tuo." '#E0785E'))
            return
        }
        if ($st.InEsecuzione) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Rainbow Six e'' aperto' 'Chiudilo prima di applicare qualcosa.' '#F06A6A'))
        }
        $riass = @(
            "Risoluzione   : $($st.Risoluzione)"
            "Schermo intero: $($st.SchermoIntero)"
            "V-Sync        : $($st.VSync)"
            "Refresh       : $($st.Refresh)"
            "Chiavi lette  : $($st.Chiavi)"
        ) -join "`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Com''e'' messo R6 adesso' $riass))

        [void] $Contenuto.Children.Add((New-ActionCard 'Preset competitivo' `
            "Ombre, riflessi, occlusione ambientale, effetti lente e sfocatura al minimo; V-Sync off, schermo intero, refresh agganciato al monitor, render scaling 100.`n`nATTENZIONE, ed e' giusto che tu lo sappia: su questo PC R6 non era installato quando ho scritto questa parte, quindi i nomi delle chiavi non li ho potuti verificare sul file vero. Per questo il preset gira in modalita' prudente: modifica SOLO le chiavi gia' presenti nel tuo file e ne salta di sicuro qualcuna. Al termine ti dice quante ne ha applicate e quante saltate." `
            'Applica il preset' {
                try {
                    $r = Invoke-VtR6Preset
                    Show-Toast "Applicate $($r.Applicate) impostazioni. Saltate perche' non presenti nel file: $($r.Saltate.Count)."
                    Update-Contenuto
                } catch { Show-Toast $_.Exception.Message }
            }))

        $r6x = 0; $r6y = 0
        if ($st.Risoluzione -match '(\d+)\s*x\s*(\d+)') { $r6x = [int]$matches[1]; $r6y = [int]$matches[2] }
        [void] $Contenuto.Children.Add((New-RisoluzioneCard 'Rainbow Six' $r6x $r6y {
            param($x, $y) Set-VtR6Risoluzione $x $y | Out-Null
        }))

        [void] $Contenuto.Children.Add((New-ActionCard 'Ripristina la configurazione' `
            'Rimette GameSettings.ini come stava prima dell''ultima modifica di VejaTweak.' `
            'Ripristina l''ultima copia' {
                try { $n = Restore-VtR6; Show-Toast "Ripristinato da $n."; Update-Contenuto }
                catch { Show-Toast $_.Exception.Message }
            } '#E5A94E'))
        return
    }

    if ($cat -eq '#bios') {
        $fw = Get-VtFirmware
        $g  = Get-VtBiosGuida

        $info = "Scheda madre: $($fw.Produttore) $($fw.Scheda)"
        if ($fw.Sistema) { $info += "  ($($fw.Sistema))" }
        $info += "`nBIOS: versione $($fw.Versione)"
        if ($fw.Data) { $info += " del $($fw.Data.ToString('dd/MM/yyyy'))" }
        $info += "`nModalita' di avvio: $(if ($fw.Uefi) { 'UEFI' } else { 'Legacy / CSM' })"
        [void] $Contenuto.Children.Add((New-InfoCard 'Il tuo firmware' $info))

        # Il punto in cui bisogna essere onesti, invece di far finta.
        $limite = @(
            'Nessun programma avviato da Windows puo'' scrivere le impostazioni del BIOS: stanno nella memoria del firmware, e il sistema operativo non ha alcun modo di modificarle. Non e'' una protezione da aggirare, e'' proprio l''assenza di un''interfaccia.',
            'Le utility dei produttori che sembrano farlo installano un driver in kernel mode firmato dal produttore stesso: e'' esattamente il tipo di driver che Vanguard, BattlEye ed EAC segnalano, ed e'' anche il modo piu'' rapido per non far piu'' avviare un PC.',
            'Quindi qui trovi le tre cose che si possono fare davvero: riconoscere cosa e'' sbagliato, portarti nel BIOS con un clic, e dirti dove sta la voce sul TUO modello di scheda.'
        ) -join "`n`n"
        [void] $Contenuto.Children.Add((New-InfoCard 'Perche'' non c''e'' un pulsante "applica tutto"' $limite '#E5A94E'))

        if ($fw.Uefi) {
            $testo = "Riavvia il PC ed entra direttamente nella schermata del BIOS, senza dover azzeccare il tasto al volo.`n`nSalva tutto quello che hai aperto prima di premere: il riavvio parte dopo 3 secondi."
            if (-not (Test-VtAdmin)) { $testo += "`n`nServe avviare VejaTweak come amministratore." }
            [void] $Contenuto.Children.Add((New-ActionCard 'Riavvia direttamente nel BIOS' $testo 'Riavvia nel BIOS ora' {
                $r = [Windows.MessageBox]::Show(
                    "Il PC si riavviera' fra 3 secondi e si fermera' nella schermata del BIOS.`n`nHai salvato tutto quello che stavi facendo?",
                    'Riavvio nel BIOS', 'YesNo', 'Warning')
                if ($r -ne 'Yes') { return }
                try { Invoke-VtRebootToFirmware }
                catch { Show-Toast "Non riuscito: $($_.Exception.Message)" }
            }))
        } else {
            [void] $Contenuto.Children.Add((New-InfoCard 'Riavvio diretto nel BIOS non disponibile' "Questo PC risulta avviato in modalita' Legacy/CSM invece che UEFI, e in quel caso Windows non puo' chiedere al firmware di fermarsi nel setup. Entra nel BIOS con il tasto qui sotto, subito dopo l'accensione." '#E5A94E'))
        }

        $comeEntrare = "Tasto da premere: $($g.Tasto)"
        if ($g.Note) { $comeEntrare += "`n`n$($g.Note)" }
        [void] $Contenuto.Children.Add((New-InfoCard 'Come entrare nel BIOS su questo PC' $comeEntrare))

        foreach ($f in (Get-VtBiosFindings)) {
            $col = switch ($f.Stato) { 'DA SISTEMARE' { '#F06A6A' } 'DA VERIFICARE' { '#E5A94E' } default { '#34D399' } }
            [void] $Contenuto.Children.Add((New-InfoCard "[$($f.Stato)]  $($f.Titolo)" $f.Testo $col))
        }

        [void] $Contenuto.Children.Add((New-InfoCard 'Dopo aver cambiato qualcosa' "Salva ed esci dal BIOS (di solito F10), fai ripartire Windows e riapri VejaTweak su questa pagina. I controlli qui sopra rileggono la situazione reale e ti dicono se la modifica ha fatto effetto davvero." '#E0785E'))
        return
    }

    if ($cat -eq '#giochi') {
        $g = @(Find-VtGiochi)
        if ($g.Count -eq 0) {
            [void] $Contenuto.Children.Add((New-InfoCard 'Nessun gioco rilevato' 'Non ho trovato Fortnite, Valorant, GTA V, FiveM o Rainbow Six nei percorsi standard. Se li hai installati altrove, la preferenza GPU va impostata a mano da Impostazioni > Schermo > Grafica.'))
        } else {
            foreach ($x in $g) {
                $pref = Get-VtReg 'HKCU:\SOFTWARE\Microsoft\DirectX\UserGpuPreferences' $x.Path
                $st = if ($pref -match 'GpuPreference=2') { 'forzato sulla GPU dedicata' } else { 'nessuna preferenza GPU impostata' }
                [void] $Contenuto.Children.Add((New-InfoCard $x.Nome ("$($x.Path)`n`nStato: $st")))
            }
        }
        foreach ($c in (Get-VtConsigli)) {
            [void] $Contenuto.Children.Add((New-InfoCard $c.Titolo $c.Testo '#E0785E'))
        }
        return
    }

    $lista = @(Get-VtCatalog | Where-Object { $_.Cat -eq $cat })
    if ($q) {
        $lista = @($lista | Where-Object { $_.Nome -like "*$q*" -or $_.Desc -like "*$q*" -or $_.Perche -like "*$q*" })
    }
    if ($lista.Count -eq 0) {
        [void] $Contenuto.Children.Add((New-InfoCard 'Nessun risultato' 'Nessun tweak di questa sezione corrisponde alla ricerca.'))
        return
    }
    Add-VtGriglia $Contenuto $lista
}

# Elenco di tweak su DUE colonne.
#
# Una colonna sola con voci indipendenti fa scorrere il doppio e riempie la
# pagina di spazio vuoto a destra. Due colonne dimezzano l'altezza e fanno
# sembrare la finestra molto meno pesante, che e' poi la differenza che si
# nota guardando i tool fatti bene.
#
# Le card hanno altezze diverse, quindi non si usa una griglia rigida: si
# riempiono due pile mettendo ogni voce in quella piu' corta. Cosi' non
# restano buchi e le due colonne finiscono piu' o meno insieme.
#
# Sotto i 900 pixel di larghezza si torna a una colonna: due colonne strette
# spezzano le righe di testo ogni tre parole e si leggono peggio di una.
function Add-VtGriglia($pannello, $voci) {
    $doppia = ($win.ActualWidth -ge 1180) -and (@($voci).Count -ge 4)
    if (-not $doppia) {
        foreach ($t in $voci) { [void] $pannello.Children.Add((New-TweakCard $t)) }
        return
    }

    $g = New-Object Windows.Controls.Grid
    $c1 = New-Object Windows.Controls.ColumnDefinition
    $c1.Width = New-Object Windows.GridLength (1, [Windows.GridUnitType]::Star)
    $c2 = New-Object Windows.Controls.ColumnDefinition
    $c2.Width = New-Object Windows.GridLength (1, [Windows.GridUnitType]::Star)
    $g.ColumnDefinitions.Add($c1); $g.ColumnDefinitions.Add($c2)

    $sx = New-Object Windows.Controls.StackPanel
    $sx.Margin = [Windows.Thickness]::new(0, 0, 5, 0)
    [Windows.Controls.Grid]::SetColumn($sx, 0)
    $dx = New-Object Windows.Controls.StackPanel
    $dx.Margin = [Windows.Thickness]::new(5, 0, 0, 0)
    [Windows.Controls.Grid]::SetColumn($dx, 1)
    [void] $g.Children.Add($sx); [void] $g.Children.Add($dx)

    # Stima dell'altezza dalla lunghezza del testo: non serve precisione,
    # basta non accumulare tutte le card lunghe da una parte sola.
    $hSx = 0; $hDx = 0
    foreach ($t in $voci) {
        $peso = 60 + [Math]::Ceiling("$($t.Desc)".Length / 34) * 16
        if ($t.Rischio -ne 'sicuro' -or $t.Reboot) { $peso += 22 }
        if ($hSx -le $hDx) { [void] $sx.Children.Add((New-TweakCard $t)); $hSx += $peso }
        else               { [void] $dx.Children.Add((New-TweakCard $t)); $hDx += $peso }
    }
    [void] $pannello.Children.Add($g)
}

function Get-VtConsigli {
    $sys = Get-VtSystem
    $out = @()
    $out += [pscustomobject]@{ Titolo='Validi per tutti i giochi'; Testo=@(
        'V-Sync sempre off, nel gioco E nel pannello del driver: aggiunge fino a un frame intero di ritardo.',
        'Raw input attivo dove esiste: bypassa accelerazione e filtri di Windows.',
        'Schermo intero esclusivo dove il gioco lo offre: catena di presentazione piu'' corta.',
        'Ombre e post-processing sono i due cursori che pesano di piu'': abbassa quelli prima delle texture.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='Fortnite'; Testo=@(
        'Modalita'' rendering: Performance. DX11 e DX12 sono molto piu'' pesanti; Performance puo'' triplicare gli FPS.',
        'Ombre OFF, anti-aliasing OFF, effetti Bassi, post-processing Basso.',
        'Distanza visuale Epica: costa pochissimo e ti fa vedere i nemici lontani.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='Valorant'; Testo=@(
        'Limita FPS sempre: ON, con il limite al refresh del monitor.',
        'Multithreaded Rendering: ON, altrimenti usa un core solo.',
        'Ombre OFF, vignetta OFF, distorsione OFF, dettaglio e texture su Basso.',
        'Vanguard (vgc) deve restare attivo: se lo disattivi, il gioco non parte.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='GTA V e FiveM'; Testo=@(
        'MSAA OFF: e'' la voce che costa di piu'' in assoluto.',
        'Ombre Normali, riflessi MSAA off, ombreggiatura morbida "Piu'' nitida".',
        'Avanzate: ombre a lunga distanza OFF, popolazione a meta''.',
        'FiveM e'' CPU-bound: gli FPS li decide il singolo core, non la GPU. Su server affollati il frame time peggiora e non e'' colpa del tuo PC. I mod grafici tipo NVE o QuantV pesano piu'' di qualunque tweak di Windows.'
    ) -join "`n`n" }
    $out += [pscustomobject]@{ Titolo='Rainbow Six Siege'; Testo=@(
        'API Vulkan: piu'' FPS e frame time piu'' stabile di DX11 su quasi tutte le configurazioni.',
        'Render scaling 100, ombre e riflessi Bassi.',
        'BattlEye deve restare attivo.'
    ) -join "`n`n" }

    if ($sys.Vendor -match 'NVIDIA') {
        $out += [pscustomobject]@{ Titolo='Pannello di controllo NVIDIA'; Testo=@(
            'Modalita'' a bassa latenza: Ultra. Se il gioco ha Reflex (Fortnite, Valorant, R6) usa quello e lascia stare il limite manuale.',
            'Gestione alimentazione: prestazioni massime. Sincronizzazione verticale: Off.',
            'Filtraggio texture qualita'': Prestazioni.'
        ) -join "`n`n" }
    }
    if ($sys.Vendor -match 'AMD|Radeon') {
        $out += [pscustomobject]@{ Titolo='AMD Adrenalin'; Testo=@(
            'Anti-Lag: On. Radeon Chill: Off. Sincronizzazione verticale: Off.',
            'Modalita'' texture: Prestazioni. Attenua tassellazione: Sostituisci, 8x.'
        ) -join "`n`n" }
    }
    $out
}

# ---------------------------------------------------------------------------
# Navigazione: quattro gruppi nella barra in alto
# ---------------------------------------------------------------------------
# Tag e' gia' impegnato dallo stile (Tag='on' accende l'indicatore ambra),
# quindi il nome del gruppo lo catturiamo in una closure invece di appoggiarlo
# sul controllo.
foreach ($g in $script:Gruppi) {
    $gruppo = $g
    $b = New-Object Windows.Controls.Button
    $b.Style   = $win.FindResource('GruppoBtn')
    $b.Content = $g.ToUpper()
    $b.Add_Click({
        Build-Sotto $gruppo
        # Entrando in un gruppo si apre la sua prima sezione.
        $prima = $script:Sezioni | Where-Object { $_.Gruppo -eq $gruppo } | Select-Object -First 1
        Show-Sezione $prima.Cat
    }.GetNewClosure())
    $script:BottoniGruppo[$g] = $b
    [void] $BarraGruppi.Children.Add($b)
}

# ---------------------------------------------------------------------------
# Eventi
# ---------------------------------------------------------------------------
$TxtSearch.Add_TextChanged({
    (Get-El 'TxtHint').Visibility = if ($TxtSearch.Text) { 'Collapsed' } else { 'Visible' }
    if ($script:SezioneAttiva -notlike '#*') { Update-Contenuto }
})

(Get-El 'BtnLog').Add_Click({
    $w = New-Object Windows.Window
    $w.Title = 'VejaTweak - registro attivita'''
    $w.Width = 900; $w.Height = 560
    $w.Background = New-Brush '#0E0A14'
    $w.WindowStartupLocation = 'CenterOwner'
    $w.Owner = $win
    $tb = New-Object Windows.Controls.TextBox
    $tb.Text = Get-VtLog
    $tb.IsReadOnly = $true
    $tb.Background = New-Brush '#151020'
    $tb.Foreground = New-Brush '#C8C0DA'
    $tb.BorderThickness = [Windows.Thickness]::new(0)
    $tb.FontFamily = New-Object Windows.Media.FontFamily 'Consolas'
    $tb.FontSize = 12
    $tb.VerticalScrollBarVisibility = 'Auto'
    $tb.Padding = [Windows.Thickness]::new(16)
    $w.Content = $tb
    [void] $w.ShowDialog()
})

(Get-El 'BtnReset').Add_Click({
    $r = [Windows.MessageBox]::Show(
        "Rimetto TUTTO com'era prima di VejaTweak?`n`nOgni tweak che hai attivato torna al valore che aveva sul tuo PC, uno per uno.",
        'Ripristina tutto', 'YesNo', 'Question')
    if ($r -ne 'Yes') { return }
    $win.Cursor = [Windows.Input.Cursors]::Wait
    try { $n = Reset-VtAll } finally { $win.Cursor = $null }
    Show-Toast "Ripristinati $n tweak. Riavvia il PC per completare."
    Update-Contenuto
})

# Controllo dei servizi all'apertura.
#
# Serve per una ragione precisa: chi ha applicato un profilo con una versione
# vecchia si ritrova DiagTrack spento sul PC, e aggiornare il programma non
# glielo riaccende - l'aggiornamento cambia il catalogo, non lo stato della
# macchina. Senza un avviso qui, quella gente continuerebbe a farsi bocciare
# allo screenshare senza sapere perche'.
function Test-VtAvvisoServizi {
    try {
        $rotti = @(Get-VtServiziRotti)
        if ($rotti.Count -eq 0) { return }
        $staff = @($rotti | Where-Object { $_.Staff })
        (Get-El 'TxtServizi').Text = if ($staff.Count -gt 0) {
            "$($staff.Count) servizi controllati dallo staff dei server di ruolo risultano fermi"
        } else {
            "$($rotti.Count) servizi che dovrebbero restare accesi risultano spenti"
        }
        (Get-El 'TxtServiziSub').Text = (($rotti | ForEach-Object { $_.Name }) -join ', ') +
            $(if ($staff.Count -gt 0) { ' - cosi'' non passeresti un controllo dello staff.' } else { '.' })
        (Get-El 'PanelServizi').Visibility = 'Visible'
        Write-VtLog "All'avvio: $($rotti.Count) servizi essenziali non a posto" warn
    } catch { }
}

(Get-El 'BtnServizi').Add_Click({
    $win.Cursor = [Windows.Input.Cursors]::Wait
    try {
        $r = Repair-VtServizi
        $m = "$($r.Riparati) servizi rimessi a posto."
        if ($r.AlRiavvio.Count -gt 0) { $m += "`n`nDriver che ripartiranno al riavvio: " + ($r.AlRiavvio -join ', ') }
        if ($r.Falliti.Count -gt 0)   { $m += "`n`nNon riusciti:`n" + ($r.Falliti -join "`n") }
        Show-Toast $m
        if (@(Get-VtServiziRotti).Count -eq 0) { (Get-El 'PanelServizi').Visibility = 'Collapsed' }
        Update-Contenuto
    } catch { Show-Toast $_.Exception.Message }
    finally { $win.Cursor = $null }
})

(Get-El 'BtnInstallaOra').Add_Click({ Invoke-VtInstallaAggiornamento })

# "Piu' tardi" nasconde solo il riquadro grande: il pulsante in alto resta,
# cosi' non si perde l'informazione ma non la si ha piu' davanti.
(Get-El 'BtnPiuTardi').Add_Click({
    (Get-El 'PanelAggiorna').Visibility = 'Collapsed'
    Write-VtLog 'Aggiornamento rimandato dall''utente'
})

(Get-El 'BtnAdmin').Add_Click({
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @(
            '-NoProfile', '-Sta', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
        $win.Close()
    } catch {
        Show-Toast 'Elevazione annullata.'
    }
})

# ---------------------------------------------------------------------------
# Indicatori CPU / GPU / RAM
#
# I contatori GPU costano circa un secondo a campione: se li leggessimo sul
# thread della UI la finestra si impianterebbe a ogni aggiornamento. Girano
# quindi in un runspace separato che scrive su una hashtable condivisa, e la
# UI si limita a leggerla.
# ---------------------------------------------------------------------------
# Cpu0 (il NOME del processore) e' dichiarata qui insieme alle altre anche se
# la riempie un runspace a parte: una chiave che esiste da subito si legge
# senza sorprese dal gestore del timer.
$script:Sync = [hashtable]::Synchronized(@{ Cpu = 0; Gpu = 0; Ram = 0; Stop = $false; Nuova = $null; Cpu0 = $null })

# ---------------------------------------------------------------------------
# CONTROLLO AGGIORNAMENTI ALL'AVVIO
#
# Prima esisteva solo il pulsante "Controlla" dentro Diagnosi > Aggiornamenti,
# e il risultato era prevedibile: chi non andava a cercarlo non sapeva
# nemmeno che esistesse una versione nuova. Adesso il controllo si fa da solo
# all'apertura.
#
# Due cose che NON fa, di proposito:
#   - non scarica e non installa niente: accende solo un pulsante in alto, e
#     resta all'utente decidere. Un programma che tira giu' ed esegue codice
#     da solo e' il modo classico in cui una cosa innocua diventa un guaio;
#   - non blocca la finestra: gira in un runspace suo e scrive su una
#     hashtable condivisa, come gia' fanno gli indicatori in basso.
#
# Serve solo Write-VtLog, che nel runspace non c'e': lo si tappa con una
# funzione vuota invece di caricare tutto il motore (che compilerebbe pure
# la classe NVAPI, per niente).
# ---------------------------------------------------------------------------
$controlloAgg = {
    try {
        function Write-VtLog { param($m, $l) }
        . (Join-Path $cartella 'VejaTweak.License.ps1')
        $u = Get-VtUrlAggiornamenti
        if (-not $u) { return }
        $i = Get-VtAggiornamento $u $versione
        if ($i.Disponibile) { $sync.Nuova = $i.Versione }
    } catch { }
}

$monitor = {
    while (-not $sync.Stop) {
        try {
            $sync.Cpu = [int] (Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'").PercentProcessorTime
        } catch { }
        try {
            $os = Get-CimInstance Win32_OperatingSystem
            $sync.Ram = [int] (100 * ($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize)
        } catch { }
        try {
            $g = (Get-Counter '\GPU Engine(*engtype_3D)\Utilization Percentage' -ErrorAction Stop).CounterSamples |
                 Measure-Object CookedValue -Sum
            $sync.Gpu = [int] [math]::Min(100, [math]::Round($g.Sum))
        } catch { }
        Start-Sleep -Milliseconds 900
    }
}

$rs = [runspacefactory]::CreateRunspace()
$rs.ApartmentState = 'MTA'
$rs.ThreadOptions  = 'ReuseThread'
$rs.Open()
$rs.SessionStateProxy.SetVariable('sync', $script:Sync)
$ps = [powershell]::Create()
$ps.Runspace = $rs
[void] $ps.AddScript($monitor)
$hMon = $ps.BeginInvoke()

$rsAgg = [runspacefactory]::CreateRunspace()
$rsAgg.ApartmentState = 'MTA'
$rsAgg.Open()
$rsAgg.SessionStateProxy.SetVariable('sync',     $script:Sync)
$rsAgg.SessionStateProxy.SetVariable('cartella', $PSScriptRoot)
$rsAgg.SessionStateProxy.SetVariable('versione', $script:Versione)
$psAgg = [powershell]::Create()
$psAgg.Runspace = $rsAgg
[void] $psAgg.AddScript($controlloAgg)
$hAgg = $psAgg.BeginInvoke()

$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(700)
$timer.Add_Tick({
    (Get-El 'TxtCpu').Text  = "$($script:Sync.Cpu)%"
    (Get-El 'BarCpu').Value = $script:Sync.Cpu
    (Get-El 'TxtGpu').Text  = "$($script:Sync.Gpu)%"
    (Get-El 'BarGpu').Value = $script:Sync.Gpu
    (Get-El 'TxtRam').Text  = "$($script:Sync.Ram)%"
    (Get-El 'BarRam').Value = $script:Sync.Ram

    # Il nome della CPU arriva dal suo runspace: si aggiunge in testa alla
    # riga di stato appena c'e', una volta sola.
    if ($script:Sync.Cpu0 -and -not $script:CpuMostrata) {
        $script:CpuMostrata = $true
        (Get-El 'TxtStato').Text = "$($script:Sync.Cpu0)   |   $($script:RigaStato)"
    }

    # Il controllo aggiornamenti finisce quando finisce: la sua risposta si
    # raccoglie qui, una volta sola.
    if ($script:Sync.Nuova -and -not $script:AvvisoMostrato) {
        $script:AvvisoMostrato = $true
        Show-VtAvvisoAggiornamento $script:Sync.Nuova
    }
})

# Sei uscito dal programma e sei tornato: puo' essere passato di tutto nel
# frattempo (hai aperto i servizi, hai lanciato un altro tweaker, hai
# riavviato un driver). La fotografia dello stato si butta, cosi' la prima
# pagina che apri e' letta dal sistema com'e' adesso.
#
# Si butta e basta, senza ridisegnare: ridisegnare qui vorrebbe dire un
# secondo di attesa e la pagina che salta all'inizio a ogni alt-tab.
#
# Solo lo stato degli interruttori, non le letture di diagnosi: quelle costano
# un secondo e mezzo e non cambiano perche' hai cambiato finestra.
$win.Add_Activated({ Clear-VtStatiTweak })

$win.Add_Closed({
    $script:Sync.Stop = $true
    $timer.Stop()
    try { $ps.Dispose(); $rs.Close(); $rs.Dispose() } catch { }
    try { $psAgg.Dispose(); $rsAgg.Close(); $rsAgg.Dispose() } catch { }
    try { $psCpu.Dispose(); $rsCpu.Close(); $rsCpu.Dispose() } catch { }
})

# ---------------------------------------------------------------------------
# Avvio
# ---------------------------------------------------------------------------
if (Test-VtAdmin) {
    $PanelAdmin.Visibility = 'Collapsed'
    $TxtAdmin.Text = 'amministratore'
} else {
    $PanelAdmin.Visibility = 'Visible'
    # Spento, non ambra acceso: "utente normale" e' uno stato, non un
    # allarme. L'allarme vero e' la riga sotto il titolo, che dice cosa
    # comporta; qui basta l'informazione.
    $BadgeAdmin.Background  = New-Brush '#191919'
    $BadgeAdmin.BorderBrush = New-Brush '#3A3A46'
    $TxtAdmin.Foreground    = New-Brush '#ADADBA'
    $TxtAdmin.Text = 'utente normale'
}

Tappa 'definizione di funzioni e gestori'

Set-VtLogo
Set-VtIconaFinestra
Tappa 'Set-VtLogo'

# --- licenza ---------------------------------------------------------------
# Il controllo sta qui, prima di mostrare la finestra principale. In modalita'
# collaudo si salta: serve a verificare le pagine, non l'attivazione.
$script:Licenza = Get-VtStatoLicenza
if (-not $script:Licenza.Attivo -and -not $SmokeTest) {
    Write-VtLog "Copia non attivata: $($script:Licenza.Motivo)" warn
    if (-not (Show-VtAttivazione)) {
        Write-VtLog 'Attivazione annullata, chiusura.' warn
        $script:Sync.Stop = $true
        try { $ps.Dispose(); $rs.Close() } catch { }
        exit 1
    }
    $script:Licenza = Get-VtStatoLicenza
}

Tappa 'controllo della licenza'

$sysInfo = Get-VtSystem
Tappa 'Get-VtSystem'
$lic = if ($script:Licenza.Owner) { 'autore' }
       elseif ($script:Licenza.Scadenza) { "licenza $($script:Licenza.Serial), scade il $($script:Licenza.Scadenza.ToString('dd/MM/yyyy'))" }
       else { "licenza $($script:Licenza.Serial)" }

# Il nome della CPU si chiede a Win32_Processor, che da solo costa un secondo
# pieno. Un secondo di finestra chiusa per scrivere una riga in basso che
# nessuno legge nel primo istante: si mostra subito il resto e il nome della
# CPU si aggiunge appena arriva, come gia' fanno gli indicatori accanto.
$script:RigaStato = "$($sysInfo.GpuNome)   |   $($sysInfo.RamGB) GB   |   $lic"
(Get-El 'TxtStato').Text = $script:RigaStato

$rsCpu = [runspacefactory]::CreateRunspace()
$rsCpu.ApartmentState = 'MTA'
$rsCpu.Open()
$rsCpu.SessionStateProxy.SetVariable('sync', $script:Sync)
$psCpu = [powershell]::Create()
$psCpu.Runspace = $rsCpu
[void] $psCpu.AddScript({
    try {
        $c = Get-CimInstance Win32_Processor | Select-Object -First 1
        $sync.Cpu0 = ($c.Name -replace '\s+', ' ').Trim()
    } catch { }
})
$hCpu = $psCpu.BeginInvoke()

Write-VtLog "VejaTweak $($script:Versione) avviato (admin: $(Test-VtAdmin))"
# GruppoAttivo parte vuoto apposta: cosi' la prima Show-Sezione costruisce
# anche la riga delle sezioni, che altrimenti resterebbe vuota.
$script:GruppoAttivo = ''
Tappa 'avvio dei thread di sottofondo'

# Costruire il catalogo e disegnare la prima pagina vuol dire leggere mezzo
# sistema: due secondi di catalogo e tre e mezzo di prima disposizione WPF.
# Farlo PRIMA di mostrare la finestra significa sette secondi di desktop vuoto
# dopo il doppio clic, in cui il cliente non sa se il programma sia partito.
#
# Quindi la finestra si mostra subito, con una riga che dice cosa sta
# succedendo, e il lavoro pesante parte appena e' comparsa (lo fa il timer
# $warm in fondo al file, che gia' precaricava attivita' e giochi).
#
# Nelle modalita' di collaudo si fa tutto subito: quelle non arrivano mai a
# ShowDialog, quindi un timer non scatterebbe mai.
$script:PrimaPagina = {
    Get-VtCatalog | Out-Null
    Tappa 'costruzione del catalogo'
    Show-Sezione '#octuning'
    Tappa 'disegno della prima pagina'
    $script:MsAvvio = $script:SwAvvio.Elapsed.TotalMilliseconds
    Write-VtLog ("Pronto in {0:N0} ms" -f $script:MsAvvio)
    # Fine delle misure: Tappa e' chiamata anche dentro Show-Sezione, e senza
    # questo continuerebbe ad accumulare una riga a ogni cambio di sezione per
    # tutta la sessione.
    $script:SwTappa = $null
}

# Precaricamento a passi.
#
# Ogni sezione ha una o due letture care che si pagano la PRIMA volta che la
# apri: il registro eventi per Salute, il firmware dei dischi, la validazione
# dei profili NVIDIA. Sono uno-tantum, ma cadono nel momento peggiore -
# esattamente quando clicchi - e sono quelle che fanno sembrare il programma
# lento nel cambio sezione.
#
# Qui si fanno prima, mentre l'utente sta ancora guardando la prima pagina.
# Un passo per scatto di timer, non tutti in fila: fra un passo e l'altro il
# dispatcher torna libero, quindi la finestra risponde sempre. Facendoli tutti
# insieme si guadagnerebbe lo stesso tempo, ma con quattro secondi di finestra
# congelata, che e' peggio del problema che si voleva risolvere.
#
# L'ordine e' quello di probabilita': prima cio' che serve alle sezioni dove
# la gente va davvero.
#
# Definito QUI e non accanto al timer che li esegue: i blocchi di collaudo
# stanno in mezzo, e li' serve gia' pieno.
$script:Passi = @(
    @{ N = 'attivita'' pianificate'; A = { Get-VtAllTasks | Out-Null } }
    @{ N = 'giochi installati';     A = { Find-VtGiochi  | Out-Null } }
    @{ N = 'avviso servizi';        A = { Test-VtAvvisoServizi } }
    @{ N = 'profili NVIDIA';        A = { Get-VtCatalog | Where-Object { $_.Kind -eq 'NvProf' -or $_.Kind -eq 'Nvapi' } | ForEach-Object { Get-VtState $_ | Out-Null } } }
    @{ N = 'pannello GPU';          A = { Get-VtPannelloGpu | Out-Null } }
    @{ N = 'registro eventi';       A = { Get-VtEventi 30 | Out-Null } }
    @{ N = 'salute dei dischi';     A = { Get-VtDischi | Out-Null } }
    @{ N = 'interrupt MSI';         A = { Get-VtMsiStato | Out-Null } }
    @{ N = 'servizi essenziali';    A = { Get-VtServiziEssenziali | Out-Null } }
    @{ N = 'controller collegati';  A = { Get-VtGamepad | Out-Null } }
    @{ N = 'quadro del PC';         A = { Get-VtRiepilogo | Out-Null } }
    @{ N = 'analisi del PC';        A = { Get-VtDiagnosi | Out-Null } }
)

# Lo stato di tutte le voci del catalogo, a fette da otto.
#
# Tutto in un passo solo sarebbe un secondo e mezzo di finestra ferma: se
# proprio in quell'istante il cliente clicca una sezione, il clic aspetta.
# A fette nessun singolo scatto supera i due decimi.
#
# GetNewClosure serve a congelare $da dentro il blocco: senza, tutte le fette
# leggerebbero l'ultimo valore assunto dalla variabile e si farebbe otto volte
# la stessa fetta.
foreach ($k in 0..11) {
    $da = $k * 8
    $script:Passi += @{
        N = "stato voci $($da + 1)-$($da + 8)"
        A = { Get-VtCatalog | Select-Object -Skip $da -First 8 | ForEach-Object { Get-VtState $_ | Out-Null } }.GetNewClosure()
    }
}

$script:SubitoTutto = $SmokeTest -or $TestToggle -or $TestAggiornamento -or $Screenshot
if ($script:SubitoTutto) {
    & $script:PrimaPagina
} else {
    $attesa = New-Object Windows.Controls.TextBlock
    $attesa.Text = 'Sto leggendo le impostazioni del PC...'
    $attesa.FontSize = 15
    $attesa.Foreground = New-Brush '#ADADBA'
    $attesa.Margin = [Windows.Thickness]::new(4, 24, 0, 0)
    [void] $Contenuto.Children.Add($attesa)
}

if ($SimulaServiziRotti) {
    (Get-El 'TxtServizi').Text = '3 servizi controllati dallo staff dei server di ruolo risultano fermi'
    (Get-El 'TxtServiziSub').Text = 'DiagTrack, PcaSvc, SysMain - cosi'' non passeresti un controllo dello staff.'
    (Get-El 'PanelServizi').Visibility = 'Visible'
}

if ($SimulaAggiornamento) {
    $script:Sync.Nuova = $SimulaAggiornamento
    $script:AvvisoMostrato = $true
    Show-VtAvvisoAggiornamento $SimulaAggiornamento
}

if ($SmokeTest) {
    # Attraversa tutte le sezioni: e' il modo piu' rapido per accorgersi che
    # una pagina non si costruisce, senza doverci cliccare sopra a mano.
    # Il tempo per sezione serve piu' del numero di card: e' quello che
    # l'utente sente quando cambia pagina.
    Write-Host ("  avvio: pronto in {0:N0} ms" -f $script:MsAvvio)
    $script:Tappe | Sort-Object Ms -Descending |
        ForEach-Object { Write-Host ("      {0,-38} {1,7:N0} ms" -f $_.Nome, $_.Ms) }

    # Gli stessi passi che l'app vera fa da sola nei primi secondi. Senza,
    # il collaudo misurerebbe un caso che il cliente non vive mai: quello di
    # chi apre il programma e clicca una sezione entro il primo istante.
    $swP = [Diagnostics.Stopwatch]::StartNew()
    foreach ($p in $script:Passi) { try { & $p.A } catch { } }
    Write-Host ("  precaricamento: {0:N0} ms" -f $swP.Elapsed.TotalMilliseconds)
    Write-Host ''
    $tempi = @()
    foreach ($s in $script:Sezioni) {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        Show-Sezione $s.Cat
        $ms = $sw.Elapsed.TotalMilliseconds
        $tempi += [pscustomobject]@{ Sez = $s.Titolo; Ms = $ms }
        Write-Host ("  {0,-28} {1,3} card  {2,7:N0} ms" -f $s.Titolo, $Contenuto.Children.Count, $ms)
    }
    Write-Host ''
    Write-Host '  Le piu lente, alla prima apertura:'
    $tempi | Sort-Object Ms -Descending | Select-Object -First 5 |
        ForEach-Object { Write-Host ("    {0,-28} {1,7:N0} ms" -f $_.Sez, $_.Ms) }
    Write-Host ("  totale: {0:N0} ms" -f ($tempi | Measure-Object Ms -Sum).Sum)

    # Secondo giro. E' questo che conta davvero: nessuno apre il programma e
    # guarda una pagina sola. L'utente ci clicca dentro, e la lentezza che
    # segnala e' quella del RITORNO su una sezione gia' vista. Se il primo
    # giro e' lento ma il secondo no, il costo era una lettura una-tantum
    # (WMI, driver, disco) e non il disegno delle schede.
    $tempi2 = @()
    foreach ($s in $script:Sezioni) {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        Show-Sezione $s.Cat
        $tempi2 += [pscustomobject]@{ Sez = $s.Titolo; Ms = $sw.Elapsed.TotalMilliseconds }
    }
    Write-Host ''
    Write-Host '  Le piu lente, tornandoci sopra:'
    $tempi2 | Sort-Object Ms -Descending | Select-Object -First 5 |
        ForEach-Object { Write-Host ("    {0,-28} {1,7:N0} ms" -f $_.Sez, $_.Ms) }
    Write-Host ("  totale: {0:N0} ms" -f ($tempi2 | Measure-Object Ms -Sum).Sum)
    Write-Host ''
    $script:Sync.Stop = $true
    try { $ps.Dispose(); $rs.Close() } catch { }
    Write-Host "SMOKE OK - $($script:Sezioni.Count) sezioni, $((Get-VtCatalog).Count) tweak"
    exit 0
}

if ($TestAggiornamento) {
    $script:SenzaDialoghi = $true
    $win.Width = 1280; $win.Height = 820
    $win.WindowStartupLocation = 'Manual'; $win.Left = -4000; $win.Top = -4000
    $win.Show()
    Show-Sezione '#aggiornamenti'
    $win.Dispatcher.Invoke([Windows.Threading.DispatcherPriority]::ContextIdle, [action] {})

    # Trova il pulsante "Controlla" scendendo nell'albero degli elementi.
    $btn = $null
    $coda = [System.Collections.Generic.Queue[object]]::new()
    $coda.Enqueue($Contenuto)
    while ($coda.Count -gt 0) {
        $n = $coda.Dequeue()
        if ($n -is [Windows.Controls.Button] -and "$($n.Content)" -match 'Controlla|Ricontrolla') { $btn = $n; break }
        $q = [Windows.Media.VisualTreeHelper]::GetChildrenCount($n)
        for ($i = 0; $i -lt $q; $i++) { $coda.Enqueue([Windows.Media.VisualTreeHelper]::GetChild($n, $i)) }
    }
    if (-not $btn) { Write-Host '  PULSANTE NON TROVATO'; exit 1 }

    Write-Host "  versione dichiarata dal programma: $($script:Versione)"
    $btn.RaiseEvent((New-Object Windows.RoutedEventArgs ([Windows.Controls.Primitives.ButtonBase]::ClickEvent)))
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt 30 -and -not $btn.IsEnabled) {
        $win.Dispatcher.Invoke([Windows.Threading.DispatcherPriority]::Background, [action] {})
        Start-Sleep -Milliseconds 50
    }

    # Rilegge il testo di stato: e' quello che vede l'utente.
    $testo = ''
    $coda2 = [System.Collections.Generic.Queue[object]]::new()
    $coda2.Enqueue($Contenuto)
    while ($coda2.Count -gt 0) {
        $n = $coda2.Dequeue()
        if ($n -is [Windows.Controls.TextBlock] -and "$($n.Text)" -match 'aggiornat|Disponibile|versione') { $testo = "$($n.Text)" }
        $q = [Windows.Media.VisualTreeHelper]::GetChildrenCount($n)
        for ($i = 0; $i -lt $q; $i++) { $coda2.Enqueue([Windows.Media.VisualTreeHelper]::GetChild($n, $i)) }
    }
    Write-Host "  messaggio mostrato: $testo"
    $rotto = ($testo -match 'versione\s*\)') -or ($testo -match '\(\s*\)')
    Write-Host "  contiene una versione vuota: $rotto"

    $win.Close()
    $script:Sync.Stop = $true
    try { $ps.Dispose(); $rs.Close() } catch { }
    if ($rotto) { Write-Host 'AGGIORNAMENTO ROTTO - la versione non arriva al confronto'; exit 1 }
    Write-Host 'AGGIORNAMENTO OK - il pulsante legge la versione giusta'
    exit 0
}

if ($TestToggle) {
    # Voce scelta apposta: sta in HKCU, si scrive in pochi millisecondi e si
    # rimette identica. Non tocco niente di importante per fare una prova.
    $bersaglio = 'mouse-trails'
    $script:SenzaDialoghi = $true
    $win.Width = 1280; $win.Height = 820
    $win.WindowStartupLocation = 'Manual'; $win.Left = -4000; $win.Top = -4000
    $win.Show()
    Show-Sezione 'Mouse e tastiera'
    $win.Dispatcher.Invoke([Windows.Threading.DispatcherPriority]::ContextIdle, [action] {})

    $tw = Get-VtCatalog | Where-Object { $_.Id -eq $bersaglio } | Select-Object -First 1
    $prima = [bool] (Get-VtState $tw)
    Write-Host "  stato di partenza : $prima"

    # Trova la levetta di quella card scendendo nell'albero degli elementi.
    $lev = $null
    foreach ($card in $Contenuto.Children) {
        $trovate = @()
        $coda = [System.Collections.Generic.Queue[object]]::new()
        $coda.Enqueue($card)
        while ($coda.Count -gt 0) {
            $n = $coda.Dequeue()
            if ($n -is [Windows.Controls.CheckBox]) { $trovate += $n }
            $q = [Windows.Media.VisualTreeHelper]::GetChildrenCount($n)
            for ($i = 0; $i -lt $q; $i++) { $coda.Enqueue([Windows.Media.VisualTreeHelper]::GetChild($n, $i)) }
        }
        foreach ($cb in $trovate) { if ($cb.Tag -and $cb.Tag.Id -eq $bersaglio) { $lev = $cb } }
        if ($lev) { break }
    }
    if (-not $lev) { Write-Host '  LEVETTA NON TROVATA'; exit 1 }

    $esito = 0
    foreach ($giro in 1, 2) {
        $atteso = if ($giro -eq 1) { -not $prima } else { $prima }
        $lev.IsChecked = $atteso
        $lev.RaiseEvent((New-Object Windows.RoutedEventArgs ([Windows.Controls.Primitives.ButtonBase]::ClickEvent)))

        # Il lavoro e' rimandato al dispatcher: bisogna lasciarlo girare.
        $sw = [Diagnostics.Stopwatch]::StartNew()
        while ($sw.Elapsed.TotalSeconds -lt 20 -and -not $lev.IsEnabled) {
            $win.Dispatcher.Invoke([Windows.Threading.DispatcherPriority]::Background, [action] {})
            Start-Sleep -Milliseconds 30
        }
        # La cosa da verificare non e' "il sistema ha fatto quello che ho
        # chiesto" - ci sono voci che su un dato PC non hanno niente da
        # cambiare - ma "quello che la levetta mostra e' quello che il
        # sistema dice davvero". Quella e' la promessa del programma.
        $reale = [bool] (Get-VtState $tw)
        $mostrato = [bool] $lev.IsChecked
        $ok = ($mostrato -eq $reale) -and $lev.IsEnabled
        if (-not $ok) { $esito = 1 }
        Write-Host ("  giro {0}: chiesto {1}, sistema {2}, levetta mostra {3}, riattiva {4}, {5:N0} ms  -> {6}" -f `
            $giro, $atteso, $reale, $mostrato, $lev.IsEnabled, $sw.Elapsed.TotalMilliseconds, $(if ($ok) { 'ok' } else { 'FALLITO' }))
    }

    $win.Close()
    $script:Sync.Stop = $true
    try { $ps.Dispose(); $rs.Close() } catch { }
    Write-Host $(if ($esito -eq 0) { 'TOGGLE OK - il clic funziona e lo stato torna al punto di partenza' } else { 'TOGGLE FALLITO' })
    exit $esito
}

# Fotografa una o piu' sezioni in PNG, senza mostrare la finestra.
#
# Serve a me, non a chi usa il programma: e' l'unico modo per giudicare come
# viene davvero la grafica invece di immaginarsela. WPF sa disegnare la
# finestra in un bitmap anche se non e' mai comparsa a schermo, purche' le si
# imponga misura e disposizione a mano.
if ($Screenshot) {
    $dest = if ($ScreenshotDir) { $ScreenshotDir } else { Join-Path ([Environment]::GetFolderPath('Desktop')) 'vejatweak-schermate' }
    New-Item -ItemType Directory -Path $dest -Force | Out-Null
    # La virgola si perde passando i parametri con -File: "-ScreenshotSezioni
    # '#a','#b'" arriva come UNA stringa "#a,#b". Prima Show-Sezione non
    # trovava quella sezione, usciva zitta, e veniva salvata la schermata
    # della pagina precedente con un nome che prometteva un'altra cosa: e' un
    # inganno che e' gia' costato un confronto "prima/dopo" sbagliato.
    $quali = if ($ScreenshotSezioni) { @($ScreenshotSezioni) -split ',' } else { @('#octuning', 'Generali', '#reg', '#fivem') }
    $quali = @($quali | ForEach-Object { "$_".Trim() } | Where-Object { $_ })

    $ignote = @($quali | Where-Object { $c = $_; -not ($script:Sezioni | Where-Object { $_.Cat -eq $c }) })
    if ($ignote.Count -gt 0) {
        Write-Host "  SEZIONI INESISTENTI: $($ignote -join ', ')"
        Write-Host "  quelle valide sono: $(($script:Sezioni | ForEach-Object { $_.Cat }) -join ', ')"
        exit 1
    }

    $win.Width = 1280; $win.Height = 820
    $win.WindowStartupLocation = 'Manual'
    $win.Left = -4000; $win.Top = -4000          # fuori schermo, non a video
    $win.Show()

    foreach ($c in $quali) {
        Show-Sezione $c
        # Due giri di dispatcher: uno per la disposizione, uno per lasciar
        # finire l'animazione di entrata della pagina.
        foreach ($i in 1..2) {
            $win.Dispatcher.Invoke([Windows.Threading.DispatcherPriority]::ContextIdle, [action] {})
            Start-Sleep -Milliseconds 350
        }
        $win.UpdateLayout()

        $w = [int] $win.ActualWidth; $h = [int] $win.ActualHeight
        if ($w -le 0 -or $h -le 0) { $w = 1280; $h = 820 }
        $bmp = New-Object Windows.Media.Imaging.RenderTargetBitmap($w, $h, 96, 96, [Windows.Media.PixelFormats]::Pbgra32)
        $bmp.Render($win)
        $enc = New-Object Windows.Media.Imaging.PngBitmapEncoder
        [void] $enc.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bmp))
        $nome = ($c -replace '[^A-Za-z0-9]', '_') + '.png'
        $fs = [IO.File]::Create((Join-Path $dest $nome))
        try { $enc.Save($fs) } finally { $fs.Close() }
        Write-Host "  $nome  ($w x $h, $($Contenuto.Children.Count) card)"
    }

    $win.Close()
    $script:Sync.Stop = $true
    try { $ps.Dispose(); $rs.Close() } catch { }
    Write-Host "Schermate in $dest"
    exit 0
}

$timer.Start()

# Precaricamento a passi.
#
# Ogni sezione ha una o due letture care che si pagano la PRIMA volta che la
# apri: il registro eventi per Salute, il firmware dei dischi, la validazione
# dei profili NVIDIA. Sono uno-tantum, ma cadono nel momento peggiore -
# esattamente quando clicchi - e sono quelle che fanno sembrare il programma
# lento nel cambio sezione.
#
# Qui si fanno prima, mentre l'utente sta ancora guardando la prima pagina.
# Un passo per scatto di timer, non tutti in fila: fra un passo e l'altro il
# dispatcher torna libero, quindi la finestra risponde sempre. Facendoli tutti
# insieme si guadagnerebbe lo stesso tempo, ma con tre secondi di finestra
# congelata, che e' peggio del problema che si voleva risolvere.
#
# L'elenco dei passi sta piu' in alto, prima dei blocchi di collaudo, perche'
# lo usa anche lo smoke test.
$script:PassoN = 0
$script:SwPassi = $null

$warm = New-Object Windows.Threading.DispatcherTimer
$warm.Interval = [TimeSpan]::FromMilliseconds(120)
$warm.Add_Tick({
    # Primo scatto: finestra gia' disegnata, quindi il tempo misurato qui e'
    # esattamente quello che il cliente aspetta guardando il desktop vuoto.
    if ($script:PassoN -eq 0) {
        $script:MsFinestra = $script:SwAvvio.Elapsed.TotalMilliseconds
        Write-VtLog ("Finestra a schermo in {0:N0} ms" -f $script:MsFinestra)

        # Prima di tutto la pagina: e' quella che l'utente sta aspettando di
        # vedere al posto della riga "sto leggendo".
        if (-not $script:SubitoTutto) {
            try { & $script:PrimaPagina }
            catch { Write-VtLog "Prima pagina non riuscita: $($_.Exception.Message)" err }
        }
        $script:SwPassi = [Diagnostics.Stopwatch]::StartNew()
        # 80 ms fra un passo e l'altro: abbastanza perche' il dispatcher
        # smaltisca clic e ridisegni, abbastanza poco perche' i venti passi
        # non si trascinino per mezzo minuto.
        $warm.Interval = [TimeSpan]::FromMilliseconds(80)
    }

    if ($script:PassoN -ge $script:Passi.Count) {
        $warm.Stop()
        Write-VtLog ("Precaricamento completo in {0:N0} ms: le sezioni ora si aprono senza attese" -f $script:SwPassi.Elapsed.TotalMilliseconds)
        return
    }

    $p = $script:Passi[$script:PassoN]
    $script:PassoN++
    try { & $p.A }
    catch { Write-VtLog "Precaricamento '$($p.N)' non riuscito: $($_.Exception.Message)" warn }
})
$warm.Start()

[void] $win.ShowDialog()








